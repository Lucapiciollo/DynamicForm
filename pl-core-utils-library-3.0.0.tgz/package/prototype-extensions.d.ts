export declare function alert(message?: any, body?: any): void;
