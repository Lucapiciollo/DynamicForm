import { ElementRef, OnDestroy, OnInit } from '@angular/core';
import * as i0 from "@angular/core";
interface AlertMessageInfo {
    title: string | null;
    body: string;
    type?: string;
}
export declare class AlertComponent implements OnInit, OnDestroy {
    /**
     * Contenitore di messaggi.
     */
    queueMessageInfo: AlertMessageInfo[];
    /**
     * Messaggio corrente processato dalla coda.
     */
    messageInfo: AlertMessageInfo | null;
    /**
     * Riferimento al modale html.
     */
    dialog: ElementRef | undefined;
    private readonly infoServiceDialogListener;
    constructor();
    /** Registra il listener broadcast e inizializza la coda con push intercettato. */
    ngOnInit(): void;
    /** Rimuove il listener broadcast alla distruzione del componente. */
    ngOnDestroy(): void;
    /**
     * Funzionalità per la chiusura della modale.
     */
    closeDialog(): void;
    /** Apre il prossimo messaggio disponibile in coda. */
    private openDialog;
    /** Intercetta push della coda per aprire automaticamente il dialog quando libero. */
    private push;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertComponent, "app-alert", never, {}, {}, never, never, false, never>;
}
export {};
