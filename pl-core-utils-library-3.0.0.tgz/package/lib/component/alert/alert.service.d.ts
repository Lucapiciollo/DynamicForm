import { ApplicationRef, ComponentFactoryResolver, Injector } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Classe di servizio per il componente Alert.
 * Al momento dell'abilitazione sovrascrive window.alert().
 * Alla chiamata di alert(), viene visualizzato un alert custom tramite AlertComponent.
 */
export declare class AlertService {
    private componentFactoryResolver;
    private appRef;
    private injector;
    private readonly oldAlert;
    private componentRef;
    private alertEnabled;
    constructor(componentFactoryResolver: ComponentFactoryResolver, appRef: ApplicationRef, injector: Injector);
    /**
     * Funzionalità per abilitare/disabilitare il componente
     * e ripristinare alert() nativo messo a disposizione da window.
     */
    enableAlertMessage(enable: boolean): void;
    /** Sostituisce `window.alert` con un broadcast verso il componente alert. */
    private overrideWindowAlert;
    /** Ripristina l'implementazione nativa di `window.alert`. */
    private restoreWindowAlert;
    /** Crea e aggancia dinamicamente il componente alert al `body`. */
    private createAlertComponent;
    /** Distrugge il componente alert dinamico se presente. */
    private destroyAlertComponent;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AlertService>;
}
