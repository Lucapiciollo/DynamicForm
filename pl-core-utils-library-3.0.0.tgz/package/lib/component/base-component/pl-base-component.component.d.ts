import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, DoCheck, Injector, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ReplaySubject, Subscription } from 'rxjs';
import { PlGraphicService } from '../../service/pl-graphic.service';
import { PlHttpService } from '../../service/pl-http.service';
import { PlNetworkService } from '../../service/pl-network.service';
import { PlUtilsService } from '../../service/pl-utils.service';
import { PLWorkerService } from '../../service/pl-worker.service';
import * as i0 from "@angular/core";
export declare class PlBaseComponent implements OnChanges, OnInit, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {
    protected injector: Injector;
    protected graphicService: PlGraphicService;
    protected httpService: PlHttpService;
    protected networkService: PlNetworkService;
    protected utilsService: PlUtilsService;
    protected workerService: PLWorkerService;
    protected queryParams: ReplaySubject<Record<string, any>>;
    protected params: ReplaySubject<Record<string, any>>;
    protected data: ReplaySubject<Record<string, any>>;
    protected queryParamsObs: Subscription | null;
    protected paramsObs: Subscription | null;
    protected dataObs: Subscription | null;
    protected router: Router;
    protected route: ActivatedRoute;
    constructor(injector: Injector);
    /**
     * Funzione che si occupa di navigare verso una pagina
     * e di passare eventuali query params.
     *
     * È possibile preservare alcuni query params già presenti nella rotta corrente.
     */
    goToPage(pageUrl: string, extras?: Record<string, any>, queryParams?: Record<string, any>, preservedQueryParams?: string[]): void;
    /** Inizializza il componente esteso. */
    ngOnInit(): void;
    /** Hook post-inizializzazione del content projection. */
    ngAfterContentInit(): void;
    /** Rilascia subscription e subject usati dalla base class. */
    ngOnDestroy(): void;
    /** Hook post-inizializzazione della view. */
    ngAfterViewInit(): void;
    /** Hook eseguito dopo ogni check della view. */
    ngAfterViewChecked(): void;
    /** Hook eseguito dopo ogni check del contenuto proiettato. */
    ngAfterContentChecked(): void;
    /** Hook di change detection custom. */
    ngDoCheck(): void;
    /** Hook chiamato al cambio degli input. */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlBaseComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PlBaseComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
