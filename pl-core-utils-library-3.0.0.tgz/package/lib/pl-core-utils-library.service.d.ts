import { Subject } from 'rxjs';
import { TYPE_EVENT } from './decorator/decordator';
export interface PlProgressBar {
    uuid: string;
    totalbyte: number;
    byte: number;
    changed: Subject<PlProgressBar>;
    blocked: boolean;
    url: string;
    loaded: string;
    speed: number;
    percent: number;
    size: string;
    interrupt: Subject<boolean>;
}
/**
 * @deprecated Usa PlProgressBar.
 */
export type progressBarItemInterface = PlProgressBar;
/**
 * Interfaccia di presentazione per le progressBar.
 * Qui sono definiti gli attributi esposti dal singolo oggetto.
 */
export interface progressBarsInterface {
    [key: string]: PlProgressBar;
}
export type PlBroadcastEventListener<T = any> = (event: CustomEvent<T>) => void;
/**
 * Classe di utilità.
 * Permette di accedere alla lista delle progressbar e alla gestione eventi.
 */
export declare class PlCoreUtils {
    /**
     * Variabile contenente le progress di ajax download/upload.
     */
    /**
     * Mappa globale delle progress bar attive (download/upload ajax).
     * @type {progressBarsInterface}
     * @example
     * PlCoreUtils.progressBars['uuid']?.percent
     */
    static progressBars: progressBarsInterface;
    /**
     * Metodi per lancio, registrazione e cancellazione eventi.
      * @returns API broadcast con funzioni di publish/subscribe/unsubscribe.
     */
    /**
     * API broadcast per publish/subscribe/unsubscribe eventi custom su document (browser).
     * Permette di lanciare, ascoltare e rimuovere eventi custom tipizzati.
     * @returns API broadcast con funzioni di execEvent, listenEvent, removeListenEvent.
     * @example
     * const api = PlCoreUtils.Broadcast();
     * api.listenEvent('MY_EVENT', (e) => ...);
     * api.execEvent('MY_EVENT', { foo: 1 });
     * api.removeListenEvent('MY_EVENT', callback);
     */
    static Broadcast(): {
        execEvent<T = any>(event: TYPE_EVENT | string, object: T): void;
        listenEvent<T = any>(event: TYPE_EVENT | string, callBack: PlBroadcastEventListener<T>): void;
        removeListenEvent<T = any>(event: TYPE_EVENT | string, callBack: PlBroadcastEventListener<T>): void;
        /**
         * @deprecated Usa removeListenEvent.
         */
        removeLlistenEvent<T = any>(event: TYPE_EVENT | string, callBack: PlBroadcastEventListener<T>): void;
    };
}
