/** eventi registrati per PLlibrary */
export declare enum TYPE_EVENT {
    PL_SET_PERMISSION = "PL:SET-PERMISSION"
}
/** Decoratore di metodo: traccia input/output/error in console. */
export declare function PLTraceMethod(): (target: any, key: any, descriptor: any) => {
    value: (...args: any[]) => any;
};
/** Decoratore di classe: abilita il trace dei lifecycle hook Angular. */
export declare function PLTraceHooks(disabled?: Array<string>): ClassDecorator;
/**
 * Decoratore di classe che applica controlli permesso su elementi con attributo `PL-permission`.
 * Il meccanismo prevede l'ascolto
 * dell'evento TYPE_EVENT.PL_SET_PERMISSION, dove viene reperito l'array dei permessi previsti per un utente.
 * ricevuto l'array dei permessi, la routine si occupa di prelevare tutti i DOM che riportano l'attributo  PL-permission, e controlla
 * se contiene o meno uno dei permessi passati precedentemente con il listener.
 * verranno rimossi tutti i componenti DOM che non soddifano i requisiti
 * la direttiva posta in AppComponent, monitorizza tutta l'applicazione
 * il decoratore rimane in attesa in ad un evento di caricamento.. l'evento deve essere
 * @example
 * lanciare document.dispatchEvent(new CustomEvent('PL:SET-PERMISSION', { detail: [PROFILO1,PROFILO2,PROFILO3,...] }));
 * inserire nel DOM <input permission="READONLY" type="text>" e al decoratore passare @PLPermission(true)
 * l'elemento del dom viene elininato in quanto non contiene il permesso READONLY.
 *
 * per NON far eliminare il componente dalla routin.
 * inserire nel DOM  <input permission="PROFILO1" type="text>" e al decoratore passare @PLPermission(true)*
 * il componente non viene eliminato in quanto il permesso è presente.
 *
 * @param permission : Array<string>  array di permessi per il quale il componente deve essere presente, se vuoto non verranno
 * elaborate le routine
 */
export declare function PLPermission(enabled?: boolean): ClassDecorator;
