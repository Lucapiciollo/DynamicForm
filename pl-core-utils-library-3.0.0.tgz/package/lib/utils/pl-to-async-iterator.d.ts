/**
 * @file pl-to-async-iterator.ts
 * @description
 * Estende automaticamente `Array.prototype` con API avanzate per la reattività e l’iterazione asincrona.
 *
 * ## Funzionalità principali
 * - `toReactiveArray()`: restituisce un Proxy che notifica ogni mutazione dell’array ai listener.
 * - `onArrayChange(listener)`: registra un listener per tutte le mutazioni (push, set, splice, ...).
 * - `toAsyncIterator(options?)`: trasforma l’array in un iteratore asincrono che può emettere sia i valori iniziali che tutte le mutazioni future, con opzioni avanzate (delay, abort, callback, ...).
 *
 * ## Esempi d’uso
 *
 * Reactive array e ascolto mutazioni:
 * ```ts
 * const arr = [1, 2, 3].toReactiveArray();
 * const unsubscribe = arr.onArrayChange(change => {
 *   console.log('Mutazione:', change.type, change);
 * });
 * arr.push(4); // notifica il listener
 * unsubscribe();
 * ```
 *
 * Iterazione asincrona con delay e ascolto live:
 * ```ts
 * for await (const item of arr.toAsyncIterator({ delayMs: 100, live: true })) {
 *   console.log('Elemento o mutazione:', item);
 * }
 * ```
 *
 * Iterazione solo sui valori iniziali:
 * ```ts
 * for await (const item of arr.toAsyncIterator({ live: false, emitInitial: false })) {
 *   console.log('Solo valori:', item);
 * }
 * ```
 *
 * Abort dell’iterazione:
 * ```ts
 * const controller = new AbortController();
 * setTimeout(() => controller.abort(), 500);
 * for await (const item of arr.toAsyncIterator({ signal: controller.signal })) {
 *   // ...
 * }
 * ```
 *
 * ## Note
 * - Le patch sono applicate automaticamente importando la libreria: non serve importare questo file manualmente.
 * - Le API sono disponibili su tutti gli array, anche creati dinamicamente.
 * - Ideale per pattern reattivi, animazioni, sincronizzazione dati, testing, e casi d’uso avanzati in Angular, RxJS, ecc.
 *
 * @author Luca Piciollo
 * @since 2026
 */
export {};
type ArrayChangeType = 'set' | 'push' | 'pop' | 'shift' | 'unshift' | 'splice' | 'sort' | 'reverse';
interface ArrayChange<T> {
    type: ArrayChangeType;
    property?: string | symbol;
    value?: T;
    oldValue?: T;
    index?: number;
    args?: unknown[];
    array: T[];
}
type ArrayChangeListener<T> = (change: ArrayChange<T>) => void;
/**
 * Opzioni per `toAsyncIterator()`.
 */
interface ToAsyncIteratorOptions<T> {
    /** Ritardo tra emissioni in ms. Default: `0`. */
    delayMs?: number;
    /** Se `true`, resta in ascolto dei cambiamenti dell'array. Default: `true`. */
    live?: boolean;
    /** Se `true`, emette lo stato iniziale come eventi `set`. Default: `false`. */
    emitInitial?: boolean;
    /** Se `true`, emette gli eventi di mutazione (`push`, `splice`, ...). Default: `false`. */
    emitChanges?: boolean;
    /** Segnale per interrompere l'iterazione. */
    signal?: AbortSignal;
    /** Callback invocata a ogni modifica dell'array (anche se `emitChanges` è `false`). */
    onChange?: (change: ArrayChange<T>) => void;
    /** Callback invocata quando l'iterazione termina normalmente. */
    onComplete?: () => void;
    /** Callback invocata in caso di abort. */
    onAbort?: () => void;
}
declare global {
    interface Array<T> {
        /**
         * Restituisce un `Proxy` dell'array che notifica le mutazioni tramite `onArrayChange()`.
         */
        toReactiveArray(): T[];
        /**
         * Registra un listener di mutazioni dell'array.
         * @returns funzione di unsubscribe.
         */
        onArrayChange(listener: ArrayChangeListener<T>): () => void;
        /**
         * Converte l'array in iteratore asincrono.
         *
         * Esempio rapido:
         * ```ts
         * const arr = [1, 2, 3].toReactiveArray();
         * for await (const item of arr.toAsyncIterator({ delayMs: 250 })) {
         *   console.log(item);
         * }
         * ```
         */
        toAsyncIterator(options?: ToAsyncIteratorOptions<T>): AsyncIterableIterator<T | ArrayChange<T>>;
    }
}
