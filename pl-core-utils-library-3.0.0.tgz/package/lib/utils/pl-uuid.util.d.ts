/**
 * Genera un UUID v4.
 *
 * Usa crypto.randomUUID() quando disponibile.
 * In fallback usa una generazione compatibile browser.
 */
export declare function createPlUuid(): string;
