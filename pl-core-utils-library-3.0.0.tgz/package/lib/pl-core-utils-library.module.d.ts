import { InjectionToken, ModuleWithProviders, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { AlertService } from './component/alert/alert.service';
import { BROWSER, PlAmbientModeLoaderService } from './service/pl-ambient-mode.service';
import * as i0 from "@angular/core";
import * as i1 from "./component/alert/alert.component";
import * as i2 from "./component/base-component/pl-base-component.component";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "@angular/common/http";
import * as i6 from "@ng-bootstrap/ng-bootstrap";
export interface PlCoreModuleConfig {
    browserValid?: BROWSER[];
    disableLog?: boolean;
    maxCacheAge?: number;
    cacheTag?: string;
    mockPath?: string;
    enableAlert?: boolean;
}
export declare const PL_CORE_MODULE_CONFIG: InjectionToken<PlCoreModuleConfig>;
export declare class PlCoreModule implements OnDestroy {
    private alertService;
    private plAmbientModeLoaderService;
    private router?;
    private static interrupter;
    private routeEventsSubscription;
    static forRoot(config?: PlCoreModuleConfig): ModuleWithProviders<PlCoreModule>;
    /**
     * Modulo di inizializzazione della libreria.
     *
     * Uso base:
     *
     * imports: [PlCoreModule]
     *
     * Uso configurabile:
     *
     * imports: [
     *   PlCoreModule.forRoot({
     *     mockPath: 'assets/mock',
     *     cacheTag: '@cachable@',
     *     maxCacheAge: 300000,
     *     disableLog: false
     *   })
     * ]
     */
    constructor(alertService: AlertService, plAmbientModeLoaderService: PlAmbientModeLoaderService, router?: Router);
    ngOnDestroy(): void;
    /**
     * Funzionalità per il reperimento dell'interrupt di rotta.
     * In caso di NavigationStart viene lanciato il subject.
     * Utile per terminare le richieste HTTP.
     */
    static Routing(): {
        getIinterrupt(): Subject<boolean>;
    };
    private initializeAlert;
    private initializeRoutingInterrupt;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlCoreModule, [null, null, { optional: true; }]>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PlCoreModule, [typeof i1.AlertComponent, typeof i2.PlBaseComponent], [typeof i3.CommonModule, typeof i4.FormsModule, typeof i5.HttpClientModule, typeof i6.NgbModule], [typeof i3.CommonModule, typeof i5.HttpClientModule, typeof i2.PlBaseComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PlCoreModule>;
}
