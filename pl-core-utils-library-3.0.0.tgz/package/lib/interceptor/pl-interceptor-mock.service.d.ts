import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { InjectionToken } from '@angular/core';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
/**
 * Token per la valorizzazione del path di default
 * usato per risalire ai JSON di mock.
 */
export declare const DEFAULT_PATH_MOCK: InjectionToken<string>;
export declare class PlHttpInterceptorMockService implements HttpInterceptor {
    protected pathMock: string | null;
    protected tagCache: string | null;
    constructor(pathMock: string | null, tagCache: string | null);
    /**
     * Se la request contiene header mocked=true, la chiamata viene trasformata
     * in una GET verso il file JSON corrispondente:
     *
     * /assets/{pathMock}/{url-path}/{method}.json
     *
     * Esempio:
     *
     * GET /api/users con mocked=true
     * diventa:
     * /assets/public/mock/api/users/get.json
     */
    intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>>;
    private createMockRequest;
    private createUrl;
    private normalizePath;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlHttpInterceptorMockService, [{ optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PlHttpInterceptorMockService>;
}
