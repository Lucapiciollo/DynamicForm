import { HttpHeaders } from '@angular/common/http';
export type PlHttpMethod = 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
export interface PlHttpRequestConfig {
    url?: string;
    method?: PlHttpMethod | string;
    body?: any;
    queryParams?: Record<string, any> | null;
    httpHeaders?: HttpHeaders | Record<string, any> | null;
    mocked?: boolean;
}
/**
 * Modello richiesta HTTP tipizzato usato da PlHttpService.
 * Permette di costruire richieste fortemente tipizzate e di utilizzare factory statiche per ogni metodo.
 * @example
 * // GET
 * const req = PlHttpRequest.get({ url: '/api/data', queryParams: { id: 1 } });
 * // POST
 * const req = PlHttpRequest.post({ url: '/api/data', body: { foo: 'bar' } });
 * // Uso diretto
 * const req = new PlHttpRequest({ url: '/api/data', method: 'PATCH', body: { ... } });
 */
export declare class PlHttpRequest {
    url: string;
    method: PlHttpMethod;
    body?: any;
    queryParams?: Record<string, any> | null;
    httpHeaders?: HttpHeaders | Record<string, any> | null;
    mocked?: boolean;
    /**
     * Crea una richiesta HTTP tipizzata.
     * @param data Configurazione iniziale della richiesta.
     * @example
     * const req = new PlHttpRequest({ url: '/api', method: 'GET' });
     */
    constructor(data?: PlHttpRequestConfig);
    /**
     * Factory per richiesta GET.
     * @param config Configurazione della richiesta senza metodo.
     * @returns Nuova istanza `PlHttpRequest` con metodo `GET`.
     * @example
     * const req = PlHttpRequest.get({ url: '/api/data', queryParams: { id: 1 } });
     */
    static get(config?: Omit<PlHttpRequestConfig, 'method'>): PlHttpRequest;
    /**
     * Factory per richiesta POST.
     * @param config Configurazione della richiesta senza metodo.
     * @returns Nuova istanza `PlHttpRequest` con metodo `POST`.
     * @example
     * const req = PlHttpRequest.post({ url: '/api/data', body: { foo: 'bar' } });
     */
    static post(config?: Omit<PlHttpRequestConfig, 'method'>): PlHttpRequest;
    /**
     * Factory per richiesta PATCH.
     * @param config Configurazione della richiesta senza metodo.
     * @returns Nuova istanza `PlHttpRequest` con metodo `PATCH`.
     * @example
     * const req = PlHttpRequest.patch({ url: '/api/data', body: { foo: 'bar' } });
     */
    static patch(config?: Omit<PlHttpRequestConfig, 'method'>): PlHttpRequest;
    /**
     * Factory per richiesta PUT.
     * @param config Configurazione della richiesta senza metodo.
     * @returns Nuova istanza `PlHttpRequest` con metodo `PUT`.
     * @example
     * const req = PlHttpRequest.put({ url: '/api/data', body: { foo: 'bar' } });
     */
    static put(config?: Omit<PlHttpRequestConfig, 'method'>): PlHttpRequest;
    /**
     * Factory per richiesta DELETE.
     * @param config Configurazione della richiesta senza metodo.
     * @returns Nuova istanza `PlHttpRequest` con metodo `DELETE`.
     */
    static delete(config?: Omit<PlHttpRequestConfig, 'method'>): PlHttpRequest;
    /**
     * Normalizza e valida il metodo HTTP.
     * @param method Metodo HTTP in ingresso.
     * @returns Metodo HTTP valido; fallback a `GET` se non valido.
     */
    static normalizeMethod(method?: PlHttpMethod | string): PlHttpMethod;
    /**
     * Verifica se il metodo passato è supportato.
     * @param method Metodo da validare.
     * @returns `true` se il metodo è valido.
     */
    static isValidMethod(method: string): method is PlHttpMethod;
    /**
     * Clona la richiesta sovrascrivendo i campi specificati.
     * @param config Proprietà da sovrascrivere nella clone.
     * @returns Nuova istanza `PlHttpRequest`.
     */
    clone(config?: PlHttpRequestConfig): PlHttpRequest;
    /**
     * Restituisce una clone con header aggiornati.
     * @param httpHeaders Header HTTP da impostare.
     * @returns Nuova istanza `PlHttpRequest`.
     */
    withHeaders(httpHeaders: HttpHeaders | Record<string, any> | null): PlHttpRequest;
    /**
     * Restituisce una clone con query params aggiornati.
     * @param queryParams Query params da impostare.
     * @returns Nuova istanza `PlHttpRequest`.
     */
    withQueryParams(queryParams: Record<string, any> | null): PlHttpRequest;
    /**
     * Restituisce una clone con body aggiornato.
     * @param body Payload da impostare.
     * @returns Nuova istanza `PlHttpRequest`.
     */
    withBody(body: any): PlHttpRequest;
    /**
     * Restituisce una clone con flag mock aggiornato.
     * @param mocked Flag mock da applicare.
     * @returns Nuova istanza `PlHttpRequest`.
     */
    withMocked(mocked?: boolean): PlHttpRequest;
}
