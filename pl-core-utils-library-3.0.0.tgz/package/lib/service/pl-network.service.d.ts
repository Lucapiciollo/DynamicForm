import * as i0 from "@angular/core";
export interface PlLocalHttpInfo {
    headers: Record<string, string>;
    params: Record<string, string>;
}
export declare class PlNetworkService {
    constructor();
    /**
     * Ritorna gli header della richiesta corrente e i query params della URL.
     *
     * Nota:
     * la lettura degli header tramite XMLHttpRequest sincrona è mantenuta
     * per retrocompatibilità, ma può non funzionare in tutti gli ambienti.
      * @returns Promise con header e query params correnti.
     */
    /**
     * Restituisce headers HTTP e query params della pagina corrente.
     * Utile per debug, diagnostica o per propagare info di contesto lato client.
     * Nota: la lettura degli header tramite XMLHttpRequest sincrona è mantenuta per retrocompatibilità, ma può non funzionare in tutti gli ambienti.
     * @returns Promise con header e query params correnti.
     * @example
     * service.getLocalHttpHeaders().then(({ headers, params }) => console.log(headers, params));
     */
    getLocalHttpHeaders(): Promise<PlLocalHttpInfo>;
    /**
     * Legge gli header HTTP del documento corrente tramite chiamata locale sincrona.
     * @returns Record con header HTTP della pagina.
     */
    private readCurrentDocumentHeaders;
    /**
     * Effettua il parse dei query param della URL corrente in un record key/value.
     * @param search Stringa query (es: location.search).
     * @returns Record con i parametri query.
     */
    private parseQueryParams;
    /**
     * Effettua il parse di una stringa header HTTP in un record key/value.
     * @param httpHeaders Stringa header HTTP (formato raw).
     * @returns Record con header HTTP.
     * @example
     * const headers = service['parseHttpHeaders']('X-Token: abc\nX-Id: 123');
     */
    private parseHttpHeaders;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlNetworkService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PlNetworkService>;
}
