import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { PlHttpRequest } from '../bean/Pl-http-request';
import * as i0 from "@angular/core";
/** eventi registrati per PLlibrary */
export declare enum TYPE_EVENT_NETWORK {
    PL_BREACK_NET = "PL:BREACK_NET"
}
/**
 * Tipologica per identificare il tipo di chiamata http che si sta facendo.
 * Mantiene le chiavi storiche con trattino per retrocompatibilità.
 */
export declare enum RESPONSE_TYPE {
    'TEXT' = "application/text",
    'ARRAYBUFFER' = "arraybuffer",
    'BLOB' = "blob",
    'MS_STREAM' = "ms-stream",
    'JAVA-ARCHIVE' = "application/java-archive",
    'EDI-X12' = "application/EDI-X12",
    'EDIFACT' = "application/EDIFACT",
    'JAVASCRIPT' = "application/javascript",
    'OCTET-STREAM' = "application/octet-stream",
    'OGG' = "application/ogg",
    'PDF' = "application/pdf",
    'XHTML+XML' = "application/xhtml+xml",
    'X-SHOCKWAVE-FLASH' = "application/x-shockwave-flash",
    'JSON' = "application/json",
    'LD+JSON' = "application/ld+json",
    'XML' = "application/xml",
    'ZIP' = "application/zip",
    'X-WWW-FORM-URLENCODED' = "application/x-www-form-urlencoded",
    'MPEG' = "audio/mpeg",
    'X-MS-WMA' = "audio/x-ms-wma",
    'VND.RN-REALAUDIO' = "audio/vnd.rn-realaudio",
    'X-WAV' = "audio/x-wav",
    'GIF' = "image/gif",
    'JPEG' = "image/jpeg",
    'PNG' = "image/png",
    'TIFF' = "image/tiff",
    'VND.MICROSOFT.ICON' = "image/vnd.microsoft.icon",
    'X-ICON' = "image/x-icon",
    'VND.DJVU' = "image/vnd.djvu",
    'SVG+XML' = "image/svg+xml",
    'MIXED' = "multipart/mixed",
    'ALTERNATIVE' = "multipart/alternative",
    'RELATED' = "multipart/related",
    'FORM-DATA' = "multipart/form-data; boundary=something",
    'CSS' = "text/css",
    'CSV' = "text/csv",
    'HTML' = "text/html",
    'PLAIN' = "text/plain",
    'MP4' = "video/mp4",
    'QUICKTIME' = "video/quicktime",
    'X-MS-WMV' = "video/x-ms-wmv",
    'X-MSVIDEO' = "video/x-msvideo",
    'X-FLV' = "video/x-flv",
    'WEBM' = "video/webm",
    'VND.ANDROID.PACKAGE-ARCHIVE' = "application/vnd.android.package-archive",
    'VND.OASIS.OPENDOCUMENT.TEXT' = "application/vnd.oasis.opendocument.text",
    'VND.OASIS.OPENDOCUMENT.SPREADSHEET' = "application/vnd.oasis.opendocument.spreadsheet",
    'VND.OASIS.OPENDOCUMENT.PRESENTATION' = "application/vnd.oasis.opendocument.presentation",
    'VND.OASIS.OPENDOCUMENT.GRAPHICS' = "application/vnd.oasis.opendocument.graphics",
    'VND.MS-EXCEL' = "application/vnd.ms-excel",
    'VND.OPENXMLFORMATS-OFFICEDOCUMENT.SPREADSHEETML.SHEET' = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    'VND.MS-POWERPOINT' = "application/vnd.ms-powerpoint",
    'VND.OPENXMLFORMATS-OFFICEDOCUMENT.PRESENTATIONML.PRESENTATION' = "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    'MSWORD' = "application/msword",
    'VND.OPENXMLFORMATS-OFFICEDOCUMENT.WORDPROCESSINGML.DOCUMENT' = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    'VND.MOZILLA.XUL+XML' = "application/vnd.mozilla.xul+xml"
}
/**
 * Tipologica per identificare il tipo di contenuto http che si sta chiedendo.
 * Mantiene le chiavi storiche con trattino per retrocompatibilità.
 */
export declare enum CONTENT_TYPE {
    'TEXT' = "application/text",
    'ARRAYBUFFER' = "arraybuffer",
    'BLOB' = "blob",
    'MS_STREAM' = "ms-stream",
    'JAVA-ARCHIVE' = "application/java-archive",
    'EDI-X12' = "application/EDI-X12",
    'EDIFACT' = "application/EDIFACT",
    'JAVASCRIPT' = "application/javascript",
    'OCTET-STREAM' = "application/octet-stream",
    'OGG' = "application/ogg",
    'PDF' = "application/pdf",
    'XHTML+XML' = "application/xhtml+xml",
    'X-SHOCKWAVE-FLASH' = "application/x-shockwave-flash",
    'JSON' = "application/json",
    'LD+JSON' = "application/ld+json",
    'XML' = "application/xml",
    'ZIP' = "application/zip",
    'X-WWW-FORM-URLENCODED' = "application/x-www-form-urlencoded",
    'MPEG' = "audio/mpeg",
    'X-MS-WMA' = "audio/x-ms-wma",
    'VND.RN-REALAUDIO' = "audio/vnd.rn-realaudio",
    'X-WAV' = "audio/x-wav",
    'GIF' = "image/gif",
    'JPEG' = "image/jpeg",
    'PNG' = "image/png",
    'TIFF' = "image/tiff",
    'VND.MICROSOFT.ICON' = "image/vnd.microsoft.icon",
    'X-ICON' = "image/x-icon",
    'VND.DJVU' = "image/vnd.djvu",
    'SVG+XML' = "image/svg+xml",
    'MIXED' = "multipart/mixed",
    'ALTERNATIVE' = "multipart/alternative",
    'RELATED' = "multipart/related",
    'FORM-DATA' = "multipart/form-data; boundary=something",
    'CSS' = "text/css",
    'CSV' = "text/csv",
    'HTML' = "text/html",
    'PLAIN' = "text/plain",
    'MP4' = "video/mp4",
    'QUICKTIME' = "video/quicktime",
    'X-MS-WMV' = "video/x-ms-wmv",
    'X-MSVIDEO' = "video/x-msvideo",
    'X-FLV' = "video/x-flv",
    'WEBM' = "video/webm",
    'VND.ANDROID.PACKAGE-ARCHIVE' = "application/vnd.android.package-archive",
    'VND.OASIS.OPENDOCUMENT.TEXT' = "application/vnd.oasis.opendocument.text",
    'VND.OASIS.OPENDOCUMENT.SPREADSHEET' = "application/vnd.oasis.opendocument.spreadsheet",
    'VND.OASIS.OPENDOCUMENT.PRESENTATION' = "application/vnd.oasis.opendocument.presentation",
    'VND.OASIS.OPENDOCUMENT.GRAPHICS' = "application/vnd.oasis.opendocument.graphics",
    'VND.MS-EXCEL' = "application/vnd.ms-excel",
    'VND.OPENXMLFORMATS-OFFICEDOCUMENT.SPREADSHEETML.SHEET' = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    'VND.MS-POWERPOINT' = "application/vnd.ms-powerpoint",
    'VND.OPENXMLFORMATS-OFFICEDOCUMENT.PRESENTATIONML.PRESENTATION' = "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    'MSWORD' = "application/msword",
    'VND.OPENXMLFORMATS-OFFICEDOCUMENT.WORDPROCESSINGML.DOCUMENT' = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    'VND.MOZILLA.XUL+XML' = "application/vnd.mozilla.xul+xml"
}
export declare class PlHttpService {
    private http;
    private level;
    private partialItem;
    private decoder;
    private readonly JTOKEN_START_OBJECT;
    private readonly JTOKEN_END_OBJECT;
    constructor(http: HttpClient);
    /**
     * Converte un oggetto headers generico o HttpHeaders in un oggetto HttpHeaders.
     * @param headers Oggetto headers (HttpHeaders o Record<string, any>).
     * @returns Oggetto HttpHeaders pronto per l’uso nelle chiamate Angular HttpClient.
     * @example
     * const headers = service.toHttpHeaders({ Authorization: 'Bearer token' });
     */
    private toHttpHeaders;
    /**
     * Crea una nuova progress bar associata a una richiesta HTTP.
     * @param uuid Identificativo univoco della progress bar.
     */
    private createProgressBar;
    /**
     * Completa e rimuove la progress bar associata a una richiesta HTTP.
     * @param uuid Identificativo progress bar.
     * @param remove Se true rimuove la progress bar, altrimenti la completa soltanto.
     */
    private completeProgressBar;
    /**
     * Completa la progress bar con un ritardo opzionale (default 3s).
     * @param uuid Identificativo progress bar.
     * @param delayMs Millisecondi di ritardo prima della rimozione.
     */
    private completeProgressBarDelayed;
    /** @ignore */
    /**
     * Costruisce le opzioni per una richiesta HTTP Angular (headers, params, responseType, ecc).
     * @param params Parametri query string.
     * @param header Headers HTTP.
     * @param responseType Tipo di risposta atteso.
     * @param contentType Content-Type esplicito.
     * @returns Oggetto opzioni per HttpClient.
     * @example
     * const options = service.requestOption({ id: 1 }, null, RESPONSE_TYPE.JSON, CONTENT_TYPE.JSON);
     */
    requestOption(params: Record<string, any> | null, header: HttpHeaders | null, responseType?: RESPONSE_TYPE, contentType?: CONTENT_TYPE | string): any;
    /**
     * Aggiorna lo stato della progress bar associata a una richiesta HTTP.
     * @param uuid Identificativo progress bar.
     * @param event Evento di progresso HTTP.
     * @returns Subject che emette lo stato aggiornato della progress bar.
     */
    private refreshProgress;
    /**
     * Gestisce i vari eventi HTTP (progress, risposta, errore) e aggiorna la progress bar.
     * @param event Evento HTTP.
     * @param uuid Identificativo progress bar.
     * @param observer Observer RxJS per la risposta.
     */
    private checkEventHttp;
    /**
     * Normalizza una URL decodificandola e sostituendo i caratteri speciali.
     * @param url URL da normalizzare.
     * @returns URL normalizzata.
     */
    private normalizeUrl;
    /**
     * Crea una URL con i parametri query forniti.
     * @param url URL base.
     * @param queryParams Parametri query string.
     * @returns URL completa di query string.
     */
    private createUrlWithQueryParams;
    /**
     * Crea un oggetto URL robusto anche in ambienti non-browser.
     * @param url Stringa URL.
     * @returns Oggetto URL.
     */
    private createUrl;
    /**
     * Normalizza il metodo HTTP in uno dei valori accettati.
     * @param method Metodo HTTP (stringa).
     * @returns Metodo normalizzato o null se non valido.
     */
    private normalizeMethod;
    /**
     * Applica gli header HTTP a una richiesta XMLHttpRequest.
     * @param xhr Oggetto XMLHttpRequest.
     * @param headers Headers da applicare.
     */
    private applyXhrHeaders;
    /**
     * Esegue una richiesta HTTP tramite Angular HttpClient con gestione avanzata di progress, interrupt e callback.
     * @param method Metodo HTTP (GET, POST, ecc).
     * @param plHttpRequest Oggetto richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress bar.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.requestWithAngularHttp('GET', new PlHttpRequest({ url: '/api/data' }), RESPONSE_TYPE.JSON)
     *   .subscribe(res => console.log(res));
     */
    private requestWithAngularHttp;
    /**
     * Crea un blob URL da uno stream binario.
     * @param streamData Contenuto binario da trasformare in blob.
     * @param applicationType MIME type da associare al blob.
     * @returns Promise con blob URL creato.
     */
    /**
     * Crea un blob URL da uno stream binario (es. per download file).
     * @param streamData Contenuto binario da trasformare in blob.
     * @param applicationType MIME type da associare al blob.
     * @returns Promise con blob URL creato.
     * @example
     * service.CREATEBLOB(arrayBuffer, CONTENT_TYPE.PDF).then(url => ...);
     */
    CREATEBLOB(streamData: ArrayBuffer, applicationType?: CONTENT_TYPE | string): Promise<string>;
    /**
     * Elimina blob URL dalla memoria.
      * @param blobUrl Blob URL da revocare.
      * @returns Promise `true` se l'operazione completa senza errori.
     */
    /**
     * Elimina un blob URL dalla memoria del browser.
     * @param blobUrl Blob URL da revocare.
     * @returns Promise `true` se l'operazione completa senza errori.
     * @example
     * service.DESTROYBLOB(url).then(() => ...);
     */
    DESTROYBLOB(blobUrl: string): Promise<boolean>;
    /**
     * Effettua il download di uno stream dati come file.
      * @param streamData Dato binario da scaricare.
      * @param contentType Content type del file.
      * @param fileName Nome file di destinazione.
      * @returns Promise `true` a download avviato.
     */
    /**
     * Effettua il download di uno stream dati come file locale.
     * @param streamData Dato binario da scaricare.
     * @param contentType Content type del file.
     * @param fileName Nome file di destinazione.
     * @returns Promise `true` a download avviato.
     * @example
     * service.DOWNLOAD(arrayBuffer, CONTENT_TYPE.PDF, 'file.pdf');
     */
    DOWNLOAD(streamData: ArrayBuffer, contentType: CONTENT_TYPE | string, fileName?: string): Promise<boolean>;
    /**
     * Download di un file da URL/blob URL.
      * @param url URL o blob URL sorgente.
      * @param filename Nome file di download.
     */
    /**
     * Download di un file da URL/blob URL (browser only).
     * @param url URL o blob URL sorgente.
     * @param filename Nome file di download.
     * @example
     * service.DOWNLOADURL(blobUrl, 'file.pdf');
     */
    DOWNLOADURL(url: string, filename?: string): void;
    /** @ignore */
    private revokeURL;
    /**
     * Decodifica incrementale di chunk JSON per streaming.
     * @param value Chunk binario.
     * @param decodedItemCallback Callback per ogni item decodificato.
     */
    private decodeChunk;
    /**
     * Converte headers generici in Record<string, string> per fetch/streaming.
     * @param headers Headers da convertire.
     * @returns Record<string, string>.
     */
    private toHeaderRecord;
    /**
     * Esegue una richiesta fetch in streaming e emette gli item decodificati chunk-by-chunk.
     * Se `decodeChunk` non è fornito, usa il decoder JSON incrementale interno.
      * @param plttpRequest Richiesta HTTP da eseguire in streaming.
      * @param interrupt Segnale di abort esterno opzionale.
      * @param decodeChunk Decoder custom opzionale per il chunk.
      * @returns Observable che emette gli item decodificati.
     */
    /**
     * Esegue una richiesta fetch in streaming e emette gli item decodificati chunk-by-chunk.
     * Se `decodeChunk` non è fornito, usa il decoder JSON incrementale interno.
     * @param plttpRequest Richiesta HTTP da eseguire in streaming.
     * @param interrupt Segnale di abort esterno opzionale.
     * @param decodeChunk Decoder custom opzionale per il chunk.
     * @returns Observable che emette gli item decodificati.
     * @example
     * service.STREAM(new PlHttpRequest({ url: '/api/stream' })).subscribe(item => ...);
     */
    STREAM<T>(plttpRequest: PlHttpRequest, interrupt?: AbortSignal, decodeChunk?: (value: Uint8Array, decodedItemCallback: (item: T) => void) => void): Observable<T>;
    /**
     * Esegue la request con XMLHttpRequest (fallback compatibilità/browser legacy).
     * Supporta interrupt esterno e progressbar interna.
      * @param plHttpRequest Richiesta HTTP da eseguire.
      * @param responseType Tipo risposta XMLHttpRequest.
      * @param interrupt Subject per interrompere la richiesta.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback invocata con id progress bar.
      * @returns Observable con risposta raw XHR.
     */
    /**
     * Esegue la request con XMLHttpRequest (fallback compatibilità/browser legacy).
     * Supporta interrupt esterno e progressbar interna.
     * @param plHttpRequest Richiesta HTTP da eseguire.
     * @param responseType Tipo risposta XMLHttpRequest.
     * @param interrupt Subject per interrompere la richiesta.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback invocata con id progress bar.
     * @returns Observable con risposta raw XHR.
     * @example
     * service.nativeHttp(new PlHttpRequest({ url: '/api/data' }), 'json').subscribe(res => ...);
     */
    nativeHttp(plHttpRequest: PlHttpRequest, responseType?: XMLHttpRequestResponseType, interrupt?: Subject<boolean>, contentType?: CONTENT_TYPE | string, callBack?: (id: string) => void): Observable<any>;
    /**
     * Servizio GET.
      * @param plHttpRequest Configurazione richiesta.
      * @param responseType Tipo risposta atteso.
      * @param interrupt Subject di interruzione.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback con id progress.
      * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Servizio GET (shortcut per REQUEST con method GET).
     * @param plHttpRequest Configurazione richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.GET(new PlHttpRequest({ url: '/api/data' })).subscribe(res => ...);
     */
    GET<T>(plHttpRequest: PlHttpRequest, responseType?: RESPONSE_TYPE, interrupt?: Subject<boolean>, contentType?: CONTENT_TYPE | string, callBack?: (id: string) => void): Observable<HttpResponse<T>>;
    /**
     * Servizio POST.
      * @param plHttpRequest Configurazione richiesta.
      * @param responseType Tipo risposta atteso.
      * @param interrupt Subject di interruzione.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback con id progress.
      * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Servizio POST (shortcut per REQUEST con method POST).
     * @param plHttpRequest Configurazione richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.POST(new PlHttpRequest({ url: '/api/data', body: { foo: 'bar' } })).subscribe(res => ...);
     */
    POST<T>(plHttpRequest: PlHttpRequest, responseType?: RESPONSE_TYPE, interrupt?: Subject<boolean>, contentType?: CONTENT_TYPE | string, callBack?: (id: string) => void): Observable<HttpResponse<T>>;
    /**
     * Servizio PATCH.
      * @param plHttpRequest Configurazione richiesta.
      * @param responseType Tipo risposta atteso.
      * @param interrupt Subject di interruzione.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback con id progress.
      * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Servizio PATCH (shortcut per REQUEST con method PATCH).
     * @param plHttpRequest Configurazione richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.PATCH(new PlHttpRequest({ url: '/api/data', body: { foo: 'bar' } })).subscribe(res => ...);
     */
    PATCH<T>(plHttpRequest: PlHttpRequest, responseType?: RESPONSE_TYPE, interrupt?: Subject<boolean>, contentType?: CONTENT_TYPE | string, callBack?: (id: string) => void): Observable<HttpResponse<T>>;
    /**
     * Servizio PUT.
      * @param plHttpRequest Configurazione richiesta.
      * @param responseType Tipo risposta atteso.
      * @param interrupt Subject di interruzione.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback con id progress.
      * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Servizio PUT (shortcut per REQUEST con method PUT).
     * @param plHttpRequest Configurazione richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.PUT(new PlHttpRequest({ url: '/api/data', body: { foo: 'bar' } })).subscribe(res => ...);
     */
    PUT<T>(plHttpRequest: PlHttpRequest, responseType?: RESPONSE_TYPE, interrupt?: Subject<boolean>, contentType?: CONTENT_TYPE | string, callBack?: (id: string) => void): Observable<HttpResponse<T>>;
    /**
     * Servizio DELETE.
      * @param plHttpRequest Configurazione richiesta.
      * @param responseType Tipo risposta atteso.
      * @param interrupt Subject di interruzione.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback con id progress.
      * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Servizio DELETE (shortcut per REQUEST con method DELETE).
     * @param plHttpRequest Configurazione richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.DELETE(new PlHttpRequest({ url: '/api/data' })).subscribe(res => ...);
     */
    DELETE<T>(plHttpRequest: PlHttpRequest, responseType?: RESPONSE_TYPE, interrupt?: Subject<boolean>, contentType?: CONTENT_TYPE | string, callBack?: (id: string) => void): Observable<HttpResponse<T>>;
    /**
     * Esegue più chiamate GET in parallelo e restituisce il risultato aggregato.
     * @param plHttpRequest Lista richieste GET da eseguire.
     * @param interrupt Subject opzionale di interruzione globale.
     * @returns Observable con array di risposte HTTP.
     */
    /**
     * Esegue più chiamate GET in parallelo e restituisce il risultato aggregato.
     * @param plHttpRequest Lista richieste GET da eseguire.
     * @param interrupt Subject opzionale di interruzione globale.
     * @returns Observable con array di risposte HTTP.
     * @example
     * service.FORKJOIN([
     *   new PlHttpRequest({ url: '/api/1' }),
     *   new PlHttpRequest({ url: '/api/2' })
     * ]).subscribe(responses => ...);
     */
    FORKJOIN<T = any>(plHttpRequest: Array<PlHttpRequest>, interrupt?: Subject<boolean>): Observable<Array<HttpResponse<T>>>;
    /**
     * Metodo generico per eseguire una richiesta HTTP in base al method del `PlHttpRequest`.
     * @param plHttpRequest Configurazione completa richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Metodo generico per eseguire una richiesta HTTP in base al method del `PlHttpRequest`.
     * @param plHttpRequest Configurazione completa richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.REQUEST(new PlHttpRequest({ url: '/api/data', method: 'POST', body: { foo: 'bar' } }))
     *   .subscribe(res => ...);
     */
    REQUEST<T>(plHttpRequest: PlHttpRequest, responseType?: RESPONSE_TYPE, interrupt?: Subject<boolean>, contentType?: CONTENT_TYPE | string, callBack?: (id: string) => void): Observable<HttpResponse<T>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlHttpService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PlHttpService>;
}
