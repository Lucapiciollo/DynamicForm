import { InjectionToken } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Token per identificare il tag usato nelle chiamate cacheabili.
 */
export declare const CACHE_TAG: InjectionToken<string>;
/**
 * Token per identificare il tempo massimo di validità cache.
 */
export declare const MAX_CACHE_AGE: InjectionToken<number>;
export interface PlCacheItem<T = any> {
    value: T;
    timestamp: number;
    maxAge: number;
}
export declare class PlCacheMapService {
    private readonly maxCacheAge;
    private readonly cacheTag;
    private readonly cache;
    constructor(maxCacheAge: number | null, cacheTag: string | null);
    /**
     * Restituisce il tag cache configurato.
      * @returns Tag cache corrente.
     */
    getCacheTag(): string;
    /**
     * Restituisce il tempo massimo cache configurato.
      * @returns Durata massima cache in millisecondi.
     */
    getMaxCacheAge(): number;
    /**
     * Verifica se una URL contiene il tag cache.
      * @param url URL da verificare.
      * @returns `true` se la URL contiene il tag cache.
     */
    hasCacheTag(url: string): boolean;
    /**
     * Rimuove il tag cache da una URL.
      * @param url URL da normalizzare.
      * @returns URL senza cache tag.
     */
    removeCacheTag(url: string): string;
    /**
     * Salva un valore in cache.
      * @param key Chiave cache.
      * @param value Valore da memorizzare.
      * @param maxAge Durata elemento cache in millisecondi.
     */
    set<T = any>(key: string, value: T, maxAge?: number): void;
    /**
     * Recupera un valore dalla cache.
      * @param key Chiave cache.
      * @returns Valore trovato oppure `null` se assente/scaduto.
     */
    /**
     * Recupera un valore dalla cache, se presente e non scaduto.
     * @param key Chiave cache.
     * @returns Valore trovato oppure `null` se assente/scaduto.
     * @example
     * const value = service.get('myKey');
     */
    get<T = any>(key: string): T | null;
    /**
     * Verifica se una chiave è presente ed è ancora valida.
      * @param key Chiave cache.
      * @returns `true` se esiste un elemento non scaduto.
     */
    /**
     * Verifica se una chiave è presente ed è ancora valida.
     * @param key Chiave cache.
     * @returns `true` se esiste un elemento non scaduto.
     * @example
     * if (service.has('myKey')) { ... }
     */
    has(key: string): boolean;
    /**
     * Rimuove una chiave dalla cache.
      * @param key Chiave cache da eliminare.
      * @returns `true` se la chiave è stata rimossa.
     */
    /**
     * Rimuove una chiave dalla cache.
     * @param key Chiave cache da eliminare.
     * @returns `true` se la chiave è stata rimossa.
     * @example
     * service.delete('myKey');
     */
    delete(key: string): boolean;
    /**
     * Pulisce tutta la cache.
     */
    /**
     * Pulisce tutta la cache.
     * @example
     * service.clear();
     */
    clear(): void;
    /**
     * Restituisce tutte le chiavi presenti.
      * @returns Lista delle chiavi cache.
     */
    /**
     * Restituisce tutte le chiavi presenti in cache.
     * @returns Lista delle chiavi cache.
     * @example
     * const allKeys = service.keys();
     */
    keys(): string[];
    /**
     * Restituisce la dimensione della cache.
      * @returns Numero elementi presenti in cache.
     */
    /**
     * Restituisce la dimensione della cache (numero di elementi).
     * @returns Numero elementi presenti in cache.
     * @example
     * const n = service.size();
     */
    size(): number;
    /**
     * Verifica se un elemento cache è scaduto.
     * @param item Oggetto cache.
     * @returns `true` se scaduto.
     */
    private isExpired;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlCacheMapService, [{ optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PlCacheMapService>;
}
