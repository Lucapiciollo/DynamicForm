import { Observable, Subscription } from 'rxjs';
import * as i0 from "@angular/core";
/**
 * Dimensione finestra.
 */
export interface PlWindowSize {
    W: number;
    h: number;
}
/**
 * Input per ricerca dicotomica.
 */
export interface PlBinaryFindInput<T = any> {
    arr: T[];
    searchElement: T;
}
/**
 * Classe di servizio che espone metodi di utilità.
 */
export declare class PlUtilsService {
    private traceSizeWindowOBS;
    constructor();
    /**
     * Ricerca dicotomica asincrona di un elemento in un array ordinato.
     *
     * @param input Oggetto `{ arr, searchElement }` dove `arr` è l'array ordinato e `searchElement` il valore da cercare.
     * @returns Promise che risolve con l'indice dell'elemento trovato, o `-1` se non presente.
     *
     * @example
     * const idx = await utils.binaryFind({ arr: [1, 2, 3, 4], searchElement: 3 }); // idx = 2
     *
     * // Con oggetti custom:
     * const arr = [{id: 1}, {id: 2}];
     * const idx = await utils.binaryFind({ arr, searchElement: {id: 2} });
     */
    binaryFind<T = any>(input: PlBinaryFindInput<T>): Promise<number>;
    /**
     * Ricerca dicotomica sincrona di un elemento in un array ordinato.
     *
     * @param input Oggetto `{ arr, searchElement }` come per `binaryFind`.
     * @returns Indice dell'elemento trovato, o `-1` se non presente.
     *
     * @example
     * const idx = utils.binaryFindSync({ arr: [10, 20, 30], searchElement: 20 }); // idx = 1
     */
    binaryFindSync<T = any>(input: PlBinaryFindInput<T>): number;
    /**
     * Osserva le dimensioni della finestra browser in tempo reale.
     *
     * @returns Observable che emette `{ W, h }` a ogni resize.
     *
     * @example
     * utils.traceSizeWindow().subscribe(size => console.log(size.W, size.h));
     */
    traceSizeWindow(): Observable<PlWindowSize>;
    /**
     * Avvia il trace delle dimensioni finestra con callback custom.
     * Mantiene la subscription internamente (utile per componenti singleton).
     *
     * @param callback Funzione chiamata a ogni resize con `{ W, h }`.
     * @returns Subscription attiva (puoi chiamare `.unsubscribe()` per fermare).
     *
     * @example
     * const sub = utils.startTraceSizeWindow(size => console.log(size));
     * // ...
     * sub.unsubscribe();
     */
    startTraceSizeWindow(callback: (size: PlWindowSize) => void): Subscription;
    /**
     * Ferma il trace delle dimensioni finestra avviato con `startTraceSizeWindow`.
     *
     * @example
     * utils.stopTraceSizeWindow();
     */
    stopTraceSizeWindow(): void;
    private getWindowSize;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlUtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PlUtilsService>;
}
