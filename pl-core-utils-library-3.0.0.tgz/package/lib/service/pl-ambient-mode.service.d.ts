import { InjectionToken, Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { PlHttpService } from './pl-http.service';
import * as i0 from "@angular/core";
/**
 * @author l.piciollo
 * Mappa dei browser name
 */
export declare enum BROWSER {
    EDGE = "edge",
    OPERA = "opera",
    CHROME = "chrome",
    IE = "ie",
    FIREFOX = "firefox",
    SAFARI = "safari",
    OTHER = "other",
    ALL = "all"
}
/**
 * @author l.piciollo
 * token per identificare quali browser sono supportati
 * @example { provide: BROWSER_VALID, useValue: [BROWSER.ALL] }
 */
export declare const BROWSER_VALID: InjectionToken<BROWSER[]>;
/**
* @author l.piciollo
* token per identificare se disabilitare o meno la console.log, valido in un contesto produzione
* @example { provide: DISABLE_LOG, useValue: true }
*/
export declare const DISABLE_LOG: InjectionToken<boolean[]>;
/**
 * @author l.piciollo
 * Servizio per identificare e settare funzionalità in base al browser o a preferenze runtime.
 * Permette di bloccare browser, disabilitare log, patchare estensioni prototype e altro.
 * Invocare il metodo detect() all’inizializzazione del sistema per abilitare patch runtime e comportamenti custom.
 * @example
 * // In app.module.ts
 * { provide: APP_INITIALIZER, useFactory: AmbientModeProviderFactory, deps: [PlAmbientModeLoaderService], multi: true }
 * // In main.ts
 * PlAmbientModeLoaderService.detect();
 */
export declare class PlAmbientModeLoaderService {
    private httpService;
    injector: Injector;
    /**
     * Mappa delle icone base64 per i browser supportati.
     * @ignore
     */
    private mapIcons;
    /**
     * @ignore
     * @param httpService
     * @param injector
     */
    constructor(httpService: PlHttpService, injector: Injector);
    /**
     * @author l.piciollo
     * inizializzazione della fase di autenticazione del browser e innesco delle funzionlaità aggiuntive
     */
    /**
     * Inizializza le estensioni di prototipo e le funzionalità aggiuntive per il browser.
     * Da invocare all'avvio dell'applicazione (es. tramite APP_INITIALIZER).
     * @returns Observable che emette lo userAgent del browser
     * @example
     *   PlAmbientModeLoaderService.detect().subscribe();
     */
    detect(): Observable<any>;
    /*********************************************************************************************************/
    /**
     * @ignore
     * @param html
     * @param browser
     */
    /**
     * Restituisce una stringa HTML con l'icona e il nome del browser.
     * @ignore
     * @param html HTML di base
     * @param browser Nome browser
     * @returns HTML personalizzato
     */
    private htmlToElement;
    /*********************************************************************************************************/
    /**@ignore */
    /**
     * Estende i prototipi nativi di Array, String, Object e JSON con metodi custom.
     * Da invocare una sola volta all'avvio tramite detect().
     *
     * @example
     *   // Dopo detect() puoi usare:
     *   [1,2,3].moveDown(0);
     *   'test'.isNullOrEmpty();
     *   JSON.changeValues(obj, 'a', 'b');
     */
    private extendsFunction;
    /**
     * @author l.piciollo
     * Identifica il brawser in uso
     */
    /**
     * Identifica il browser in uso tramite userAgent.
     * @returns Enum BROWSER
     * @example
     *   const browser = service.browserIdentify();
     */
    browserIdentify(): BROWSER;
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Crea un link e un blob per il download di un file.
     * @ignore
     * @param streamData Dati binari
     * @param nomeFile Nome file
     * @param isTextfile Se true aggiunge BOM per file di testo
     * @returns Promise con [link, blob]
     */
    private createLinkBlob;
    /****************************************************************************************** */
    /**@ignore */
    /**
     * Revoca l'URL e rimuove il link dal DOM.
     * @ignore
     * @param link Elemento link
     * @returns Promise<void>
     */
    private destroiLinkBlob;
    /****************************************************************************************** */
    /**@ignore */
    /**
     * Simula il click su un link per download (browser non Microsoft).
     * @ignore
     * @param link Elemento link
     * @returns Promise<link>
     */
    private noMicro;
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Download file per browser Microsoft (msSaveOrOpenBlob).
     * @ignore
     * @param obj Array [link, blob]
     * @param nomeFile Nome file
     * @returns Promise
     */
    private micro;
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Estrae il nome file dagli header HTTP.
     * @ignore
     * @param headers HttpHeaders
     * @param fileName Nome file opzionale
     * @returns Nome file
     */
    private getFileName;
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Verifica se il file è di tipo testo (json/text).
     * @ignore
     * @param headers HttpHeaders
     * @returns true se testo
     */
    private isTextfile;
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Gestisce il download di un file (compatibile con tutti i browser).
     * @ignore
     * @param streamData Dati binari
     * @param contentType Tipo contenuto
     * @param fileNamed Nome file opzionale
     * @returns Promise
     */
    private downloadFile;
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Collega la funzione di download custom al servizio HTTP.
     * @ignore
     */
    private downloadFileOver;
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Disabilita tutte le funzioni di console.log/info/warn/debug/error.
     * @ignore
     */
    private disableConsole;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlAmbientModeLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PlAmbientModeLoaderService>;
}
