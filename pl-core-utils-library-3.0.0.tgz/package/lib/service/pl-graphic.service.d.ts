import { Observable } from 'rxjs';
import { PlHttpService } from './pl-http.service';
import * as i0 from "@angular/core";
/**
 * Classe di servizio per utility grafiche.
 */
export declare class PlGraphicService {
    private plHttpService;
    constructor(plHttpService: PlHttpService);
    /**
     * Converte un'immagine SVG caricata da URL in base64.
     *
     * Nota: usa XMLHttpRequest sincrono per retrocompatibilità con il comportamento storico.
      * @param imageUrl URL immagine SVG da convertire.
      * @returns Promise con data URL base64 dell'immagine.
     */
    /**
     * Converte un'immagine SVG caricata da URL in una stringa base64 (data URL).
     * Usa XMLHttpRequest sincrono per retrocompatibilità.
     * @param imageUrl URL immagine SVG da convertire.
     * @returns Promise con data URL base64 dell'immagine.
     * @example
     * service.image2base64('/assets/logo.svg').then(base64 => ...);
     */
    image2base64(imageUrl: string): Promise<string>;
    /**
     * Esporta un elemento SVG in un file .svg.
      * @param elementSVG Elemento SVG/HTML da serializzare.
      * @param nameFile Nome file da scaricare.
      * @returns Observable che emette `true` a completamento download.
     */
    /**
     * Esporta un elemento SVG/HTML in un file .svg scaricabile (browser only).
     * @param elementSVG Elemento SVG/HTML da serializzare.
     * @param nameFile Nome file da scaricare.
     * @returns Observable che emette `true` a completamento download.
     * @example
     * service.svg2File(document.getElementById('mysvg'), 'export.svg').subscribe();
     */
    svg2File(elementSVG: HTMLElement | SVGElement, nameFile: string): Observable<boolean>;
    /**
     * Converte un elemento SVG/HTML in JPEG tramite html-to-image.
      * @param elementSVG Elemento sorgente da convertire.
      * @returns Observable con data URL JPEG.
     */
    svgToJpeg(elementSVG: HTMLElement | SVGElement): Observable<string>;
    /**
     * Crea un canvas a partire da un elemento DOM.
     *
     * Restituisce l'URL blob del canvas e passa il canvas alla callback, se presente.
      * @param elementoDom Elemento DOM da renderizzare su canvas.
      * @param call Callback opzionale con il canvas creato.
      * @returns Observable con blob URL del canvas.
     */
    domToCanvas(elementoDom: HTMLElement, call?: (canvas: HTMLCanvasElement) => void): Observable<string>;
    /**
     * Crea un URL blob a partire da un canvas.
      * @param canvas Canvas da convertire in blob URL.
      * @returns Observable con blob URL dell'immagine.
     */
    canvasToImg(canvas: HTMLCanvasElement): Observable<string>;
    /**
     * Crea una immagine dataURL a partire da un SVG.
     * Restituisce il dataURL e passa il canvas alla callback, se presente.
      * @param svgElement Elemento SVG/DOM da convertire.
      * @param call Callback opzionale con canvas risultante.
      * @returns Observable con dataURL dell'immagine prodotta.
     */
    svgToImage(svgElement: SVGGraphicsElement | SVGElement | HTMLElement, call?: (canvas: HTMLCanvasElement) => void): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlGraphicService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PlGraphicService>;
}
