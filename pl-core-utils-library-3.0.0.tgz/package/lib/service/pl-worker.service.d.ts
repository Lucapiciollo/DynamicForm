import * as i0 from "@angular/core";
export declare class PLWorkerService {
    /** @ignore */
    private readonly workerFunctionToUrlMap;
    /** @ignore */
    private readonly promiseToWorkerMap;
    /**
     * Funzionalità per la virtualizzazione di un codice elaborato.
     * Il codice viene eseguito in un thread separato dal main thread.
     *
     * Nota: workerFunction e initProcess non devono essere arrow function
     * se vuoi serializzarle correttamente dentro il worker.
     *
     * @param workerFunction Promise/funzione da virtualizzare in un thread separato.
     * @param nameThred Nome da assegnare al thread, utile per i log.
     * @param initProcess Funzione richiamata per i log di start/end processo.
     * @param data Oggetto contenente i parametri da passare alla funzione workerFunction.
     * @param singolInstance Se true crea un nuovo worker URL anche se la funzione era già mappata.
    * @returns Promise con il risultato prodotto dal worker.
     */
    /**
     * Esegue una funzione asincrona o sincrona in un Web Worker (thread separato) se supportato, altrimenti fallback su main thread.
     * Utile per virtualizzare task pesanti senza bloccare l’UI.
     * Nota: workerFunction e initProcess non devono essere arrow function se vuoi serializzarle correttamente dentro il worker.
     * @param workerFunction Funzione/Promise da virtualizzare in thread separato.
     * @param nameThred Nome thread (per log/debug).
     * @param initProcess Funzione richiamata per log di start/end processo.
     * @param data Parametri da passare alla funzione workerFunction.
     * @param singolInstance Se true forza nuovo worker URL anche se già mappata.
     * @returns Promise con il risultato prodotto dal worker.
     * @example
     * service.run(async (input) => { return await heavyTask(input); }, 'HeavyTask', console.log, { foo: 1 });
     */
    run<T = any>(workerFunction: (input: any) => Promise<T> | T, nameThred: string, initProcess?: (message: string) => void, data?: any, singolInstance?: boolean): Promise<T>;
    /**
     * Funzionalità di esecuzione di uno script in formato blob/url.
     *
     * @param url URL del worker.
     * @param data Dati da inviare al worker.
      * @returns Promise con il payload di risposta del worker.
     */
    /**
     * Esegue uno script worker da URL/blob URL.
     * @param url URL del worker.
     * @param data Dati da inviare al worker.
     * @returns Promise con il payload di risposta del worker.
     * @example
     * service.runUrl('worker.js', { foo: 1 }).then(res => ...);
     */
    runUrl<T = any>(url: string, data?: any): Promise<T>;
    /**
     * Recupera il worker associato a una Promise.
     *
     * @param promise Promise restituita da run/runUrl.
      * @returns Istanza worker associata oppure `undefined`.
     */
    /**
     * Recupera il worker associato a una Promise restituita da run/runUrl.
     * @param promise Promise restituita da run/runUrl.
     * @returns Istanza worker associata oppure `undefined`.
     * @example
     * const worker = service.getWorker(promise);
     */
    getWorker<T = any>(promise: Promise<T>): Worker | undefined;
    /**
     * Termina il worker associato a una Promise.
     *
     * @param promise Promise restituita da run/runUrl.
     */
    /**
     * Termina il worker associato a una Promise restituita da run/runUrl.
     * @param promise Promise restituita da run/runUrl.
     * @example
     * service.terminateWorker(promise);
     */
    terminateWorker<T = any>(promise: Promise<T>): void;
    private isWorkerSupported;
    private createWorker;
    private runInMainThread;
    /** @ignore */
    private removePromise;
    /** @ignore */
    private createPromiseCleaner;
    /** @ignore */
    private createPromiseForWorker;
    /** @ignore */
    private normalizeWorkerError;
    /** @ignore */
    private createWorkerUrl;
    /** @ignore */
    private getOrCreateWorkerUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<PLWorkerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PLWorkerService>;
}
