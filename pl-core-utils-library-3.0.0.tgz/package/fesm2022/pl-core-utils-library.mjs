import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1$1 from '@angular/common/http';
import { HttpHeaders, HttpParams, HttpEventType, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import * as i0 from '@angular/core';
import { ViewChild, Component, Injectable, InjectionToken, Optional, Inject, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import * as i3 from '@angular/router';
import { Router, ActivatedRoute, NavigationStart } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Subject, Observable, forkJoin, of, fromEvent, ReplaySubject } from 'rxjs';
import { takeUntil, finalize, debounceTime, startWith, map, distinctUntilChanged, filter } from 'rxjs/operators';
import { __decorate } from 'tslib';
import { Log } from 'pl-decorator';
import * as htmlToImage from 'html-to-image';
import html2canvas from 'html2canvas';

/**
 * Utility runtime per estendere `Array.prototype` con API reattive e asincrone:
 * - `toReactiveArray()`
 * - `onArrayChange()`
 * - `toAsyncIterator()`
 *
 * ⚠️ Nota importante:
 * questo file deve essere importato almeno una volta in runtime
 * (es. da `public-api.ts` o da un modulo bootstrap) per applicare il patch al prototipo.
 */
const ARRAY_CHANGE_LISTENERS = Symbol('ARRAY_CHANGE_LISTENERS');
function getListeners(array) {
    const target = array;
    if (!target[ARRAY_CHANGE_LISTENERS]) {
        Object.defineProperty(target, ARRAY_CHANGE_LISTENERS, {
            value: new Set(),
            enumerable: false,
            configurable: false,
        });
    }
    return target[ARRAY_CHANGE_LISTENERS];
}
function notify(array, change) {
    const fullChange = {
        ...change,
        array,
    };
    getListeners(array).forEach((listener) => listener(fullChange));
}
function isArrayIndex(property) {
    if (typeof property !== 'string')
        return false;
    const index = Number(property);
    return Number.isInteger(index) && index >= 0;
}
/**
 * Registra un listener per tutte le mutazioni dell’array (push, set, splice, ...).
 * @template T
 * @param this Array su cui registrare il listener
 * @param listener Funzione che riceve un oggetto ArrayChange<T> ad ogni mutazione
 * @returns Funzione di unsubscribe per rimuovere il listener
 * @example
 *   const arr = [1,2,3].toReactiveArray();
 *   const unsub = arr.onArrayChange(change => console.log(change));
 *   arr.push(4); // notifica il listener
 *   unsub();
 */
if (!Array.prototype.onArrayChange) {
    Array.prototype.onArrayChange = function (listener) {
        const listeners = getListeners(this);
        listeners.add(listener);
        return () => {
            listeners.delete(listener);
        };
    };
}
/**
 * Restituisce un Proxy dell’array che notifica ogni mutazione ai listener registrati tramite onArrayChange.
 * Intercetta sia le assegnazioni per indice che tutti i metodi mutanti (push, pop, shift, unshift, splice, sort, reverse).
 * @template T
 * @param this Array da rendere reattivo
 * @returns Proxy reattivo dell’array
 * @example
 *   const arr = [1,2,3].toReactiveArray();
 *   arr[0] = 99; // notifica 'set'
 *   arr.push(4); // notifica 'push'
 */
if (!Array.prototype.toReactiveArray) {
    Array.prototype.toReactiveArray = function () {
        const source = this;
        return new Proxy(source, {
            set(target, property, value, receiver) {
                const oldValue = Reflect.get(target, property, receiver);
                const result = Reflect.set(target, property, value, receiver);
                if (property !== 'length' && oldValue !== value) {
                    notify(target, {
                        type: 'set',
                        property,
                        value,
                        oldValue,
                        index: isArrayIndex(property) ? Number(property) : undefined,
                    });
                }
                return result;
            },
            get(target, property, receiver) {
                const original = Reflect.get(target, property, receiver);
                if (typeof property === 'string' &&
                    ['push', 'pop', 'shift', 'unshift', 'splice', 'sort', 'reverse'].includes(property)) {
                    return (...args) => {
                        const result = original.apply(target, args);
                        notify(target, {
                            type: property,
                            args,
                        });
                        return result;
                    };
                }
                return original;
            },
        });
    };
}
/**
 * Itera elementi e/o eventi di mutazione dell’array in modo asincrono.
 * Permette di ascoltare sia i valori iniziali che tutte le mutazioni future, con opzioni avanzate (delay, abort, callback, ...).
 * @template T
 * @param this Array da iterare
 * @param options Opzioni di iterazione (delayMs, live, emitInitial, emitChanges, signal, onChange, onComplete, onAbort)
 * @returns AsyncIterableIterator<T | ArrayChange<T>>
 * @example
 *   for await (const item of arr.toAsyncIterator({ delayMs: 100, live: true })) {
 *     console.log(item);
 *   }
 * @example
 *   // Solo valori iniziali:
 *   for await (const item of arr.toAsyncIterator({ live: false, emitInitial: false })) {
 *     ...
 *   }
 * @example
 *   // Abort:
 *   const controller = new AbortController();
 *   for await (const item of arr.toAsyncIterator({ signal: controller.signal })) { ... }
 */
if (!Array.prototype.toAsyncIterator) {
    Array.prototype.toAsyncIterator = function (options = {}) {
        const { delayMs = 0, live = true, emitInitial = true, emitChanges = true, signal, onChange, onComplete, onAbort, } = options;
        return (async function* () {
            let index = 0;
            let wake = null;
            const queue = [];
            const wait = () => new Promise((resolve) => {
                wake = resolve;
            });
            const unsubscribe = live
                ? this.onArrayChange((change) => {
                    onChange?.(change);
                    if (emitChanges) {
                        queue.push(change);
                    }
                    wake?.();
                    wake = null;
                })
                : undefined;
            try {
                if (emitInitial) {
                    for (let i = 0; i < this.length; i++) {
                        if (delayMs > 0) {
                            await delay(delayMs, signal);
                        }
                        yield {
                            type: 'set',
                            property: String(i),
                            value: this[i],
                            index: i,
                            array: this,
                        };
                    }
                }
                while (true) {
                    if (signal?.aborted) {
                        onAbort?.();
                        return;
                    }
                    if (emitChanges && queue.length > 0) {
                        yield queue.shift();
                        continue;
                    }
                    if (!emitInitial && index < this.length) {
                        if (delayMs > 0) {
                            await delay(delayMs, signal);
                        }
                        yield this[index];
                        index++;
                        continue;
                    }
                    if (!live) {
                        onComplete?.();
                        return;
                    }
                    await wait();
                }
            }
            catch (error) {
                if (error instanceof DOMException && error.name === 'AbortError') {
                    onAbort?.();
                    return;
                }
                throw error;
            }
            finally {
                unsubscribe?.();
            }
        }).call(this);
    };
}
function delay(ms, signal) {
    return new Promise((resolve, reject) => {
        if (signal?.aborted) {
            reject(new DOMException('Aborted', 'AbortError'));
            return;
        }
        const timeoutId = setTimeout(resolve, ms);
        signal?.addEventListener('abort', () => {
            clearTimeout(timeoutId);
            reject(new DOMException('Aborted', 'AbortError'));
        }, { once: true });
    });
}

/**
 * Classe di utilità.
 * Permette di accedere alla lista delle progressbar e alla gestione eventi.
 */
class PlCoreUtils {
    /**
     * Variabile contenente le progress di ajax download/upload.
     */
    /**
     * Mappa globale delle progress bar attive (download/upload ajax).
     * @type {progressBarsInterface}
     * @example
     * PlCoreUtils.progressBars['uuid']?.percent
     */
    static progressBars = {};
    /**
     * Metodi per lancio, registrazione e cancellazione eventi.
      * @returns API broadcast con funzioni di publish/subscribe/unsubscribe.
     */
    /**
     * API broadcast per publish/subscribe/unsubscribe eventi custom su document (browser).
     * Permette di lanciare, ascoltare e rimuovere eventi custom tipizzati.
     * @returns API broadcast con funzioni di execEvent, listenEvent, removeListenEvent.
     * @example
     * const api = PlCoreUtils.Broadcast();
     * api.listenEvent('MY_EVENT', (e) => ...);
     * api.execEvent('MY_EVENT', { foo: 1 });
     * api.removeListenEvent('MY_EVENT', callback);
     */
    static Broadcast() {
        const removeEvent = (event, callBack) => {
            if (typeof document === 'undefined') {
                return;
            }
            document.removeEventListener(event, callBack, false);
        };
        return {
            execEvent(event, object) {
                if (typeof document === 'undefined') {
                    return;
                }
                document.dispatchEvent(new CustomEvent(event, {
                    detail: object
                }));
            },
            listenEvent(event, callBack) {
                if (typeof document === 'undefined') {
                    return;
                }
                document.addEventListener(event, callBack);
            },
            removeListenEvent: removeEvent,
            removeLlistenEvent: removeEvent
        };
    }
}

/**
 * Componente grafico per la visualizzazione dell'alert.
 */
class AlertComponent {
    /**
     * Contenitore di messaggi.
     */
    queueMessageInfo = [];
    /**
     * Messaggio corrente processato dalla coda.
     */
    messageInfo = null;
    /**
     * Riferimento al modale html.
     */
    dialog;
    infoServiceDialogListener = message => {
        const detail = message.detail;
        if (!detail?.body) {
            return;
        }
        this.queueMessageInfo.push({
            title: detail.title ?? null,
            body: detail.body
        });
    };
    constructor() { }
    /** Registra il listener broadcast e inizializza la coda con push intercettato. */
    ngOnInit() {
        this.push();
        PlCoreUtils.Broadcast().listenEvent('CORE:INFO_SERVICE_DIALOG', this.infoServiceDialogListener);
    }
    /** Rimuove il listener broadcast alla distruzione del componente. */
    ngOnDestroy() {
        PlCoreUtils.Broadcast().removeListenEvent('CORE:INFO_SERVICE_DIALOG', this.infoServiceDialogListener);
    }
    /**
     * Funzionalità per la chiusura della modale.
     */
    closeDialog() {
        this.messageInfo = null;
        setTimeout(() => {
            if (this.queueMessageInfo.length > 0) {
                this.openDialog();
            }
        }, 500);
    }
    /** Apre il prossimo messaggio disponibile in coda. */
    openDialog() {
        const nextMessage = this.queueMessageInfo.splice(0, 1)[0];
        if (!nextMessage) {
            return;
        }
        this.messageInfo = {
            ...nextMessage,
            type: 'alert-info'
        };
    }
    /** Intercetta push della coda per aprire automaticamente il dialog quando libero. */
    push() {
        const component = this;
        const originalPush = this.queueMessageInfo.push;
        this.queueMessageInfo.push = function (...items) {
            const result = originalPush.apply(this, items);
            if (component.messageInfo == null) {
                component.openDialog();
            }
            return result;
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: AlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.22", type: AlertComponent, isStandalone: false, selector: "app-alert", viewQueries: [{ propertyName: "dialog", first: true, predicate: ["dialog"], descendants: true }], ngImport: i0, template: "<div  #dialog  *ngIf=\"messageInfo!=null\" \r\n        data-backdrop=\"static\" \r\n        data-keyboard=\"false\"  \r\n        class=\"modal\"\r\n        [style.background]=\"messageInfo!=null ? 'rgba(0,0,0,0.4)' :''\" \r\n        [style.display]=\"messageInfo!=null ? 'block':'none'\"\r\n        [class.modal-open]=\"messageInfo!=null ? 'modal-open':'fade-in'\"\r\n        >\r\n  <div class=\"modal-dialog\" role=\"document\">\r\n    <div class=\"modal-content\">\r\n      <div class=\"modal-header\">\r\n        <h4 class=\"modal-title w-80\" id=\"myModalLabel\">{{messageInfo.title || 'Message!'}}</h4>\r\n        <button (click)=\"closeDialog()\" type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n          <span aria-hidden=\"true\"></span>\r\n        </button>\r\n      </div>\r\n      <div class=\"modal-body\" [innerHTML]=\"messageInfo.body\">\r\n          \r\n      </div>\r\n      <div class=\"modal-footer\">\r\n        <button type=\"button\" class=\"btn btn-primary\" data-dismiss=\"modal\" (click)=\"closeDialog()\">Ok</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>", styles: [""], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: AlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-alert', standalone: false, template: "<div  #dialog  *ngIf=\"messageInfo!=null\" \r\n        data-backdrop=\"static\" \r\n        data-keyboard=\"false\"  \r\n        class=\"modal\"\r\n        [style.background]=\"messageInfo!=null ? 'rgba(0,0,0,0.4)' :''\" \r\n        [style.display]=\"messageInfo!=null ? 'block':'none'\"\r\n        [class.modal-open]=\"messageInfo!=null ? 'modal-open':'fade-in'\"\r\n        >\r\n  <div class=\"modal-dialog\" role=\"document\">\r\n    <div class=\"modal-content\">\r\n      <div class=\"modal-header\">\r\n        <h4 class=\"modal-title w-80\" id=\"myModalLabel\">{{messageInfo.title || 'Message!'}}</h4>\r\n        <button (click)=\"closeDialog()\" type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n          <span aria-hidden=\"true\"></span>\r\n        </button>\r\n      </div>\r\n      <div class=\"modal-body\" [innerHTML]=\"messageInfo.body\">\r\n          \r\n      </div>\r\n      <div class=\"modal-footer\">\r\n        <button type=\"button\" class=\"btn btn-primary\" data-dismiss=\"modal\" (click)=\"closeDialog()\">Ok</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>" }]
        }], ctorParameters: () => [], propDecorators: { dialog: [{
                type: ViewChild,
                args: ['dialog']
            }] } });

/**
 * Modello richiesta HTTP tipizzato usato da PlHttpService.
 * Permette di costruire richieste fortemente tipizzate e di utilizzare factory statiche per ogni metodo.
 * @example
 * // GET
 * const req = PlHttpRequest.get({ url: '/api/data', queryParams: { id: 1 } });
 * // POST
 * const req = PlHttpRequest.post({ url: '/api/data', body: { foo: 'bar' } });
 * // Uso diretto
 * const req = new PlHttpRequest({ url: '/api/data', method: 'PATCH', body: { ... } });
 */
class PlHttpRequest {
    url;
    method;
    body;
    queryParams;
    httpHeaders;
    mocked;
    /**
     * Crea una richiesta HTTP tipizzata.
     * @param data Configurazione iniziale della richiesta.
     * @example
     * const req = new PlHttpRequest({ url: '/api', method: 'GET' });
     */
    constructor(data = {}) {
        this.url = data.url ?? '';
        this.method = PlHttpRequest.normalizeMethod(data.method);
        this.body = data.body;
        this.queryParams = data.queryParams ?? null;
        this.httpHeaders = data.httpHeaders ?? null;
        this.mocked = data.mocked ?? false;
    }
    /**
     * Factory per richiesta GET.
     * @param config Configurazione della richiesta senza metodo.
     * @returns Nuova istanza `PlHttpRequest` con metodo `GET`.
     * @example
     * const req = PlHttpRequest.get({ url: '/api/data', queryParams: { id: 1 } });
     */
    static get(config = {}) {
        return new PlHttpRequest({
            ...config,
            method: 'GET'
        });
    }
    /**
     * Factory per richiesta POST.
     * @param config Configurazione della richiesta senza metodo.
     * @returns Nuova istanza `PlHttpRequest` con metodo `POST`.
     * @example
     * const req = PlHttpRequest.post({ url: '/api/data', body: { foo: 'bar' } });
     */
    static post(config = {}) {
        return new PlHttpRequest({
            ...config,
            method: 'POST'
        });
    }
    /**
     * Factory per richiesta PATCH.
     * @param config Configurazione della richiesta senza metodo.
     * @returns Nuova istanza `PlHttpRequest` con metodo `PATCH`.
     * @example
     * const req = PlHttpRequest.patch({ url: '/api/data', body: { foo: 'bar' } });
     */
    static patch(config = {}) {
        return new PlHttpRequest({
            ...config,
            method: 'PATCH'
        });
    }
    /**
     * Factory per richiesta PUT.
     * @param config Configurazione della richiesta senza metodo.
     * @returns Nuova istanza `PlHttpRequest` con metodo `PUT`.
     * @example
     * const req = PlHttpRequest.put({ url: '/api/data', body: { foo: 'bar' } });
     */
    static put(config = {}) {
        return new PlHttpRequest({
            ...config,
            method: 'PUT'
        });
    }
    /**
     * Factory per richiesta DELETE.
     * @param config Configurazione della richiesta senza metodo.
     * @returns Nuova istanza `PlHttpRequest` con metodo `DELETE`.
     */
    static delete(config = {}) {
        return new PlHttpRequest({
            ...config,
            method: 'DELETE'
        });
    }
    /**
     * Normalizza e valida il metodo HTTP.
     * @param method Metodo HTTP in ingresso.
     * @returns Metodo HTTP valido; fallback a `GET` se non valido.
     */
    static normalizeMethod(method) {
        const normalizedMethod = String(method ?? 'GET').trim().toUpperCase();
        if (PlHttpRequest.isValidMethod(normalizedMethod)) {
            return normalizedMethod;
        }
        return 'GET';
    }
    /**
     * Verifica se il metodo passato è supportato.
     * @param method Metodo da validare.
     * @returns `true` se il metodo è valido.
     */
    static isValidMethod(method) {
        return ['GET', 'POST', 'PATCH', 'PUT', 'DELETE'].includes(method);
    }
    /**
     * Clona la richiesta sovrascrivendo i campi specificati.
     * @param config Proprietà da sovrascrivere nella clone.
     * @returns Nuova istanza `PlHttpRequest`.
     */
    clone(config = {}) {
        return new PlHttpRequest({
            url: config.url ?? this.url,
            method: config.method ?? this.method,
            body: config.body ?? this.body,
            queryParams: config.queryParams ?? this.queryParams,
            httpHeaders: config.httpHeaders ?? this.httpHeaders,
            mocked: config.mocked ?? this.mocked
        });
    }
    /**
     * Restituisce una clone con header aggiornati.
     * @param httpHeaders Header HTTP da impostare.
     * @returns Nuova istanza `PlHttpRequest`.
     */
    withHeaders(httpHeaders) {
        return this.clone({
            httpHeaders
        });
    }
    /**
     * Restituisce una clone con query params aggiornati.
     * @param queryParams Query params da impostare.
     * @returns Nuova istanza `PlHttpRequest`.
     */
    withQueryParams(queryParams) {
        return this.clone({
            queryParams
        });
    }
    /**
     * Restituisce una clone con body aggiornato.
     * @param body Payload da impostare.
     * @returns Nuova istanza `PlHttpRequest`.
     */
    withBody(body) {
        return this.clone({
            body
        });
    }
    /**
     * Restituisce una clone con flag mock aggiornato.
     * @param mocked Flag mock da applicare.
     * @returns Nuova istanza `PlHttpRequest`.
     */
    withMocked(mocked = true) {
        return this.clone({
            mocked
        });
    }
}

/**
 * Genera un UUID v4.
 *
 * Usa crypto.randomUUID() quando disponibile.
 * In fallback usa una generazione compatibile browser.
 */
function createPlUuid() {
    const cryptoRef = getCrypto();
    if (cryptoRef?.randomUUID) {
        return cryptoRef.randomUUID();
    }
    return createFallbackUuid();
}
function getCrypto() {
    if (typeof crypto !== 'undefined') {
        return crypto;
    }
    if (typeof globalThis !== 'undefined' && 'crypto' in globalThis) {
        return globalThis.crypto;
    }
    return null;
}
function createFallbackUuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, char => {
        const random = Math.floor(Math.random() * 16);
        const value = char === 'x' ? random : (random & 0x3) | 0x8;
        return value.toString(16);
    });
}

/** eventi registrati per PLlibrary */
var TYPE_EVENT_NETWORK;
(function (TYPE_EVENT_NETWORK) {
    TYPE_EVENT_NETWORK["PL_BREACK_NET"] = "PL:BREACK_NET";
})(TYPE_EVENT_NETWORK || (TYPE_EVENT_NETWORK = {}));
/**
 * Tipologica per identificare il tipo di chiamata http che si sta facendo.
 * Mantiene le chiavi storiche con trattino per retrocompatibilità.
 */
var RESPONSE_TYPE;
(function (RESPONSE_TYPE) {
    RESPONSE_TYPE["TEXT"] = "application/text";
    RESPONSE_TYPE["ARRAYBUFFER"] = "arraybuffer";
    RESPONSE_TYPE["BLOB"] = "blob";
    RESPONSE_TYPE["MS_STREAM"] = "ms-stream";
    RESPONSE_TYPE["JAVA-ARCHIVE"] = "application/java-archive";
    RESPONSE_TYPE["EDI-X12"] = "application/EDI-X12";
    RESPONSE_TYPE["EDIFACT"] = "application/EDIFACT";
    RESPONSE_TYPE["JAVASCRIPT"] = "application/javascript";
    RESPONSE_TYPE["OCTET-STREAM"] = "application/octet-stream";
    RESPONSE_TYPE["OGG"] = "application/ogg";
    RESPONSE_TYPE["PDF"] = "application/pdf";
    RESPONSE_TYPE["XHTML+XML"] = "application/xhtml+xml";
    RESPONSE_TYPE["X-SHOCKWAVE-FLASH"] = "application/x-shockwave-flash";
    RESPONSE_TYPE["JSON"] = "application/json";
    RESPONSE_TYPE["LD+JSON"] = "application/ld+json";
    RESPONSE_TYPE["XML"] = "application/xml";
    RESPONSE_TYPE["ZIP"] = "application/zip";
    RESPONSE_TYPE["X-WWW-FORM-URLENCODED"] = "application/x-www-form-urlencoded";
    RESPONSE_TYPE["MPEG"] = "audio/mpeg";
    RESPONSE_TYPE["X-MS-WMA"] = "audio/x-ms-wma";
    RESPONSE_TYPE["VND.RN-REALAUDIO"] = "audio/vnd.rn-realaudio";
    RESPONSE_TYPE["X-WAV"] = "audio/x-wav";
    RESPONSE_TYPE["GIF"] = "image/gif";
    RESPONSE_TYPE["JPEG"] = "image/jpeg";
    RESPONSE_TYPE["PNG"] = "image/png";
    RESPONSE_TYPE["TIFF"] = "image/tiff";
    RESPONSE_TYPE["VND.MICROSOFT.ICON"] = "image/vnd.microsoft.icon";
    RESPONSE_TYPE["X-ICON"] = "image/x-icon";
    RESPONSE_TYPE["VND.DJVU"] = "image/vnd.djvu";
    RESPONSE_TYPE["SVG+XML"] = "image/svg+xml";
    RESPONSE_TYPE["MIXED"] = "multipart/mixed";
    RESPONSE_TYPE["ALTERNATIVE"] = "multipart/alternative";
    RESPONSE_TYPE["RELATED"] = "multipart/related";
    RESPONSE_TYPE["FORM-DATA"] = "multipart/form-data; boundary=something";
    RESPONSE_TYPE["CSS"] = "text/css";
    RESPONSE_TYPE["CSV"] = "text/csv";
    RESPONSE_TYPE["HTML"] = "text/html";
    RESPONSE_TYPE["PLAIN"] = "text/plain";
    RESPONSE_TYPE["MP4"] = "video/mp4";
    RESPONSE_TYPE["QUICKTIME"] = "video/quicktime";
    RESPONSE_TYPE["X-MS-WMV"] = "video/x-ms-wmv";
    RESPONSE_TYPE["X-MSVIDEO"] = "video/x-msvideo";
    RESPONSE_TYPE["X-FLV"] = "video/x-flv";
    RESPONSE_TYPE["WEBM"] = "video/webm";
    RESPONSE_TYPE["VND.ANDROID.PACKAGE-ARCHIVE"] = "application/vnd.android.package-archive";
    RESPONSE_TYPE["VND.OASIS.OPENDOCUMENT.TEXT"] = "application/vnd.oasis.opendocument.text";
    RESPONSE_TYPE["VND.OASIS.OPENDOCUMENT.SPREADSHEET"] = "application/vnd.oasis.opendocument.spreadsheet";
    RESPONSE_TYPE["VND.OASIS.OPENDOCUMENT.PRESENTATION"] = "application/vnd.oasis.opendocument.presentation";
    RESPONSE_TYPE["VND.OASIS.OPENDOCUMENT.GRAPHICS"] = "application/vnd.oasis.opendocument.graphics";
    RESPONSE_TYPE["VND.MS-EXCEL"] = "application/vnd.ms-excel";
    RESPONSE_TYPE["VND.OPENXMLFORMATS-OFFICEDOCUMENT.SPREADSHEETML.SHEET"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    RESPONSE_TYPE["VND.MS-POWERPOINT"] = "application/vnd.ms-powerpoint";
    RESPONSE_TYPE["VND.OPENXMLFORMATS-OFFICEDOCUMENT.PRESENTATIONML.PRESENTATION"] = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
    RESPONSE_TYPE["MSWORD"] = "application/msword";
    RESPONSE_TYPE["VND.OPENXMLFORMATS-OFFICEDOCUMENT.WORDPROCESSINGML.DOCUMENT"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    RESPONSE_TYPE["VND.MOZILLA.XUL+XML"] = "application/vnd.mozilla.xul+xml";
})(RESPONSE_TYPE || (RESPONSE_TYPE = {}));
/**
 * Tipologica per identificare il tipo di contenuto http che si sta chiedendo.
 * Mantiene le chiavi storiche con trattino per retrocompatibilità.
 */
var CONTENT_TYPE;
(function (CONTENT_TYPE) {
    CONTENT_TYPE["TEXT"] = "application/text";
    CONTENT_TYPE["ARRAYBUFFER"] = "arraybuffer";
    CONTENT_TYPE["BLOB"] = "blob";
    CONTENT_TYPE["MS_STREAM"] = "ms-stream";
    CONTENT_TYPE["JAVA-ARCHIVE"] = "application/java-archive";
    CONTENT_TYPE["EDI-X12"] = "application/EDI-X12";
    CONTENT_TYPE["EDIFACT"] = "application/EDIFACT";
    CONTENT_TYPE["JAVASCRIPT"] = "application/javascript";
    CONTENT_TYPE["OCTET-STREAM"] = "application/octet-stream";
    CONTENT_TYPE["OGG"] = "application/ogg";
    CONTENT_TYPE["PDF"] = "application/pdf";
    CONTENT_TYPE["XHTML+XML"] = "application/xhtml+xml";
    CONTENT_TYPE["X-SHOCKWAVE-FLASH"] = "application/x-shockwave-flash";
    CONTENT_TYPE["JSON"] = "application/json";
    CONTENT_TYPE["LD+JSON"] = "application/ld+json";
    CONTENT_TYPE["XML"] = "application/xml";
    CONTENT_TYPE["ZIP"] = "application/zip";
    CONTENT_TYPE["X-WWW-FORM-URLENCODED"] = "application/x-www-form-urlencoded";
    CONTENT_TYPE["MPEG"] = "audio/mpeg";
    CONTENT_TYPE["X-MS-WMA"] = "audio/x-ms-wma";
    CONTENT_TYPE["VND.RN-REALAUDIO"] = "audio/vnd.rn-realaudio";
    CONTENT_TYPE["X-WAV"] = "audio/x-wav";
    CONTENT_TYPE["GIF"] = "image/gif";
    CONTENT_TYPE["JPEG"] = "image/jpeg";
    CONTENT_TYPE["PNG"] = "image/png";
    CONTENT_TYPE["TIFF"] = "image/tiff";
    CONTENT_TYPE["VND.MICROSOFT.ICON"] = "image/vnd.microsoft.icon";
    CONTENT_TYPE["X-ICON"] = "image/x-icon";
    CONTENT_TYPE["VND.DJVU"] = "image/vnd.djvu";
    CONTENT_TYPE["SVG+XML"] = "image/svg+xml";
    CONTENT_TYPE["MIXED"] = "multipart/mixed";
    CONTENT_TYPE["ALTERNATIVE"] = "multipart/alternative";
    CONTENT_TYPE["RELATED"] = "multipart/related";
    CONTENT_TYPE["FORM-DATA"] = "multipart/form-data; boundary=something";
    CONTENT_TYPE["CSS"] = "text/css";
    CONTENT_TYPE["CSV"] = "text/csv";
    CONTENT_TYPE["HTML"] = "text/html";
    CONTENT_TYPE["PLAIN"] = "text/plain";
    CONTENT_TYPE["MP4"] = "video/mp4";
    CONTENT_TYPE["QUICKTIME"] = "video/quicktime";
    CONTENT_TYPE["X-MS-WMV"] = "video/x-ms-wmv";
    CONTENT_TYPE["X-MSVIDEO"] = "video/x-msvideo";
    CONTENT_TYPE["X-FLV"] = "video/x-flv";
    CONTENT_TYPE["WEBM"] = "video/webm";
    CONTENT_TYPE["VND.ANDROID.PACKAGE-ARCHIVE"] = "application/vnd.android.package-archive";
    CONTENT_TYPE["VND.OASIS.OPENDOCUMENT.TEXT"] = "application/vnd.oasis.opendocument.text";
    CONTENT_TYPE["VND.OASIS.OPENDOCUMENT.SPREADSHEET"] = "application/vnd.oasis.opendocument.spreadsheet";
    CONTENT_TYPE["VND.OASIS.OPENDOCUMENT.PRESENTATION"] = "application/vnd.oasis.opendocument.presentation";
    CONTENT_TYPE["VND.OASIS.OPENDOCUMENT.GRAPHICS"] = "application/vnd.oasis.opendocument.graphics";
    CONTENT_TYPE["VND.MS-EXCEL"] = "application/vnd.ms-excel";
    CONTENT_TYPE["VND.OPENXMLFORMATS-OFFICEDOCUMENT.SPREADSHEETML.SHEET"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    CONTENT_TYPE["VND.MS-POWERPOINT"] = "application/vnd.ms-powerpoint";
    CONTENT_TYPE["VND.OPENXMLFORMATS-OFFICEDOCUMENT.PRESENTATIONML.PRESENTATION"] = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
    CONTENT_TYPE["MSWORD"] = "application/msword";
    CONTENT_TYPE["VND.OPENXMLFORMATS-OFFICEDOCUMENT.WORDPROCESSINGML.DOCUMENT"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    CONTENT_TYPE["VND.MOZILLA.XUL+XML"] = "application/vnd.mozilla.xul+xml";
})(CONTENT_TYPE || (CONTENT_TYPE = {}));
class PlHttpService {
    http;
    level = 0;
    partialItem = '';
    decoder = new TextDecoder();
    JTOKEN_START_OBJECT = '{';
    JTOKEN_END_OBJECT = '}';
    constructor(http) {
        this.http = http;
    }
    /**
     * Converte un oggetto headers generico o HttpHeaders in un oggetto HttpHeaders.
     * @param headers Oggetto headers (HttpHeaders o Record<string, any>).
     * @returns Oggetto HttpHeaders pronto per l’uso nelle chiamate Angular HttpClient.
     * @example
     * const headers = service.toHttpHeaders({ Authorization: 'Bearer token' });
     */
    toHttpHeaders(headers) {
        if (!headers) {
            return new HttpHeaders();
        }
        if (headers instanceof HttpHeaders) {
            return headers;
        }
        let httpHeaders = new HttpHeaders();
        Object.keys(headers).forEach(key => {
            const value = headers[key];
            if (value !== undefined && value !== null) {
                httpHeaders = httpHeaders.set(key, String(value));
            }
        });
        return httpHeaders;
    }
    /**
     * Crea una nuova progress bar associata a una richiesta HTTP.
     * @param uuid Identificativo univoco della progress bar.
     */
    createProgressBar(uuid) {
        PlCoreUtils.progressBars[uuid] = {
            uuid,
            totalbyte: 0,
            byte: 0,
            changed: new Subject(),
            blocked: false,
            url: '',
            loaded: '0',
            speed: 0,
            percent: 0,
            size: '0',
            interrupt: new Subject()
        };
    }
    /**
     * Completa e rimuove la progress bar associata a una richiesta HTTP.
     * @param uuid Identificativo progress bar.
     * @param remove Se true rimuove la progress bar, altrimenti la completa soltanto.
     */
    completeProgressBar(uuid, remove = true) {
        const progressBar = PlCoreUtils.progressBars[uuid];
        if (!progressBar) {
            return;
        }
        progressBar.changed.complete();
        progressBar.interrupt.complete();
        if (remove) {
            delete PlCoreUtils.progressBars[uuid];
            PlCoreUtils.progressBars = { ...PlCoreUtils.progressBars };
        }
    }
    /**
     * Completa la progress bar con un ritardo opzionale (default 3s).
     * @param uuid Identificativo progress bar.
     * @param delayMs Millisecondi di ritardo prima della rimozione.
     */
    completeProgressBarDelayed(uuid, delayMs = 3000) {
        this.completeProgressBar(uuid, false);
        setTimeout(() => {
            this.completeProgressBar(uuid, true);
        }, delayMs);
    }
    /** @ignore */
    /**
     * Costruisce le opzioni per una richiesta HTTP Angular (headers, params, responseType, ecc).
     * @param params Parametri query string.
     * @param header Headers HTTP.
     * @param responseType Tipo di risposta atteso.
     * @param contentType Content-Type esplicito.
     * @returns Oggetto opzioni per HttpClient.
     * @example
     * const options = service.requestOption({ id: 1 }, null, RESPONSE_TYPE.JSON, CONTENT_TYPE.JSON);
     */
    requestOption(params, header, responseType, contentType) {
        let search = new HttpParams();
        const safeParams = params ?? {};
        Object.keys(safeParams).forEach(key => {
            const value = safeParams[key];
            if (value !== undefined && value !== null) {
                search = search.append(key, value);
            }
        });
        let headers = header ?? new HttpHeaders();
        if (contentType) {
            headers = headers.set('Content-Type', contentType);
        }
        else {
            headers = headers.delete('Content-Type');
        }
        const options = {
            headers,
            params: search
        };
        if (responseType) {
            options.observe = 'events';
            options.responseType = responseType;
            options.reportProgress = true;
        }
        return options;
    }
    /**
     * Aggiorna lo stato della progress bar associata a una richiesta HTTP.
     * @param uuid Identificativo progress bar.
     * @param event Evento di progresso HTTP.
     * @returns Subject che emette lo stato aggiornato della progress bar.
     */
    refreshProgress(uuid, event) {
        const progressBar = PlCoreUtils.progressBars[uuid];
        if (!progressBar) {
            return new Subject();
        }
        if (event != null) {
            progressBar.byte = event.loaded ?? 0;
            progressBar.totalbyte = event.total ?? event.loaded ?? 0;
            progressBar.percent = Math.round(100 * (event.loaded ?? 0) / (event.total || event.loaded || 1));
            progressBar.loaded = ((event.loaded ?? 0) / 1024 / 1000).toFixed(3) + 'MB';
            progressBar.size = ((event.total || event.loaded || 0) / 1024 / 1000).toFixed(3) + 'MB';
            progressBar.changed.next(progressBar);
        }
        return progressBar.changed;
    }
    /**
     * Gestisce i vari eventi HTTP (progress, risposta, errore) e aggiorna la progress bar.
     * @param event Evento HTTP.
     * @param uuid Identificativo progress bar.
     * @param observer Observer RxJS per la risposta.
     */
    checkEventHttp(event, uuid, observer) {
        try {
            switch (event.type) {
                case HttpEventType.Sent:
                case HttpEventType.ResponseHeader:
                    break;
                case HttpEventType.DownloadProgress:
                case HttpEventType.UploadProgress:
                    this.refreshProgress(uuid, event);
                    break;
                case HttpEventType.Response:
                    observer.next(event);
                    observer.complete();
                    break;
                default:
                    observer.next(event);
                    observer.complete();
                    break;
            }
        }
        catch {
            observer.next(event);
            observer.complete();
        }
    }
    /**
     * Normalizza una URL decodificandola e sostituendo i caratteri speciali.
     * @param url URL da normalizzare.
     * @returns URL normalizzata.
     */
    normalizeUrl(url) {
        return decodeURIComponent(url).replace(/\*/g, '%2A');
    }
    /**
     * Crea una URL con i parametri query forniti.
     * @param url URL base.
     * @param queryParams Parametri query string.
     * @returns URL completa di query string.
     */
    createUrlWithQueryParams(url, queryParams) {
        const parsedUrl = this.createUrl(url);
        if (queryParams != null) {
            Object.keys(queryParams).forEach(key => {
                const value = queryParams[key];
                if (value !== undefined && value !== null) {
                    parsedUrl.searchParams.set(key, value);
                }
            });
        }
        return this.normalizeUrl(parsedUrl.toString());
    }
    /**
     * Crea un oggetto URL robusto anche in ambienti non-browser.
     * @param url Stringa URL.
     * @returns Oggetto URL.
     */
    createUrl(url) {
        try {
            return new URL(url);
        }
        catch {
            const baseUrl = typeof window !== 'undefined' && window.location?.origin
                ? window.location.origin
                : 'http://localhost';
            return new URL(url, baseUrl);
        }
    }
    /**
     * Normalizza il metodo HTTP in uno dei valori accettati.
     * @param method Metodo HTTP (stringa).
     * @returns Metodo normalizzato o null se non valido.
     */
    normalizeMethod(method) {
        const normalizedMethod = String(method ?? '').trim().toUpperCase();
        if (['GET', 'POST', 'PATCH', 'PUT', 'DELETE'].includes(normalizedMethod)) {
            return normalizedMethod;
        }
        return null;
    }
    /**
     * Applica gli header HTTP a una richiesta XMLHttpRequest.
     * @param xhr Oggetto XMLHttpRequest.
     * @param headers Headers da applicare.
     */
    applyXhrHeaders(xhr, headers) {
        if (!headers) {
            return;
        }
        if (headers instanceof HttpHeaders) {
            headers.keys().forEach(key => {
                const value = headers.get(key);
                if (value !== null) {
                    xhr.setRequestHeader(key, value);
                }
            });
            return;
        }
        Object.keys(headers).forEach(key => {
            const value = headers[key];
            if (value !== undefined && value !== null) {
                xhr.setRequestHeader(key, String(value));
            }
        });
    }
    /**
     * Esegue una richiesta HTTP tramite Angular HttpClient con gestione avanzata di progress, interrupt e callback.
     * @param method Metodo HTTP (GET, POST, ecc).
     * @param plHttpRequest Oggetto richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress bar.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.requestWithAngularHttp('GET', new PlHttpRequest({ url: '/api/data' }), RESPONSE_TYPE.JSON)
     *   .subscribe(res => console.log(res));
     */
    requestWithAngularHttp(method, plHttpRequest, responseType, interrupt, contentType, callBack) {
        const uuid = createPlUuid();
        responseType = responseType ?? RESPONSE_TYPE.JSON;
        interrupt = interrupt ?? new Subject();
        this.createProgressBar(uuid);
        if (callBack) {
            callBack(uuid);
        }
        return new Observable(observer => {
            try {
                let header = this.toHttpHeaders(plHttpRequest.httpHeaders);
                if (plHttpRequest.mocked) {
                    header = header.append('mocked', 'true');
                }
                const options = this.requestOption(plHttpRequest.queryParams, header, responseType, contentType);
                PlCoreUtils.progressBars[uuid].url = plHttpRequest.url;
                const url = method === 'GET' || method === 'DELETE'
                    ? this.normalizeUrl(plHttpRequest.url)
                    : plHttpRequest.url;
                let request$;
                switch (method) {
                    case 'GET':
                        request$ = this.http.get(url, options);
                        break;
                    case 'POST':
                        request$ = this.http.post(url, plHttpRequest.body, options);
                        break;
                    case 'PATCH':
                        request$ = this.http.patch(url, plHttpRequest.body, options);
                        break;
                    case 'PUT':
                        request$ = this.http.put(url, plHttpRequest.body, options);
                        break;
                    case 'DELETE':
                        request$ = this.http.delete(url, options);
                        break;
                }
                const subscription = request$
                    .pipe(takeUntil(PlCoreUtils.progressBars[uuid].interrupt), takeUntil(interrupt), finalize(() => {
                    this.completeProgressBarDelayed(uuid);
                }))
                    .subscribe({
                    next: event => {
                        this.checkEventHttp(event, uuid, observer);
                    },
                    error: err => {
                        observer.error(err);
                    }
                });
                return () => {
                    subscription.unsubscribe();
                };
            }
            catch (error) {
                observer.error(error);
                this.completeProgressBarDelayed(uuid);
                return () => { };
            }
        });
    }
    /**
     * Crea un blob URL da uno stream binario.
     * @param streamData Contenuto binario da trasformare in blob.
     * @param applicationType MIME type da associare al blob.
     * @returns Promise con blob URL creato.
     */
    /**
     * Crea un blob URL da uno stream binario (es. per download file).
     * @param streamData Contenuto binario da trasformare in blob.
     * @param applicationType MIME type da associare al blob.
     * @returns Promise con blob URL creato.
     * @example
     * service.CREATEBLOB(arrayBuffer, CONTENT_TYPE.PDF).then(url => ...);
     */
    CREATEBLOB(streamData, applicationType = CONTENT_TYPE.PDF) {
        return new Promise((resolve, reject) => {
            try {
                if (typeof window === 'undefined' || !window.URL) {
                    reject(new Error('CREATEBLOB is available only in browser environments'));
                    return;
                }
                const jsEscape = '\uFEFF';
                const blob = applicationType === CONTENT_TYPE.TEXT
                    ? new Blob([jsEscape + streamData], { type: applicationType })
                    : new Blob([streamData], { type: applicationType });
                resolve(window.URL.createObjectURL(blob));
            }
            catch (error) {
                reject(error);
            }
        });
    }
    /**
     * Elimina blob URL dalla memoria.
      * @param blobUrl Blob URL da revocare.
      * @returns Promise `true` se l'operazione completa senza errori.
     */
    /**
     * Elimina un blob URL dalla memoria del browser.
     * @param blobUrl Blob URL da revocare.
     * @returns Promise `true` se l'operazione completa senza errori.
     * @example
     * service.DESTROYBLOB(url).then(() => ...);
     */
    DESTROYBLOB(blobUrl) {
        return new Promise((resolve, reject) => {
            try {
                this.revokeURL(blobUrl);
                resolve(true);
            }
            catch (error) {
                reject(error);
            }
        });
    }
    /**
     * Effettua il download di uno stream dati come file.
      * @param streamData Dato binario da scaricare.
      * @param contentType Content type del file.
      * @param fileName Nome file di destinazione.
      * @returns Promise `true` a download avviato.
     */
    /**
     * Effettua il download di uno stream dati come file locale.
     * @param streamData Dato binario da scaricare.
     * @param contentType Content type del file.
     * @param fileName Nome file di destinazione.
     * @returns Promise `true` a download avviato.
     * @example
     * service.DOWNLOAD(arrayBuffer, CONTENT_TYPE.PDF, 'file.pdf');
     */
    DOWNLOAD(streamData, contentType, fileName = 'download_temp') {
        return new Promise((resolve, reject) => {
            try {
                this.CREATEBLOB(streamData, contentType)
                    .then(blobUrl => {
                    this.DOWNLOADURL(blobUrl, fileName);
                    resolve(true);
                })
                    .catch(error => {
                    reject(error);
                });
            }
            catch (error) {
                reject(error);
            }
        });
    }
    /**
     * Download di un file da URL/blob URL.
      * @param url URL o blob URL sorgente.
      * @param filename Nome file di download.
     */
    /**
     * Download di un file da URL/blob URL (browser only).
     * @param url URL o blob URL sorgente.
     * @param filename Nome file di download.
     * @example
     * service.DOWNLOADURL(blobUrl, 'file.pdf');
     */
    DOWNLOADURL(url, filename = 'download_temp') {
        if (typeof document === 'undefined' || typeof window === 'undefined') {
            throw new Error('DOWNLOADURL is available only in browser environments');
        }
        const link = document.createElement('a');
        if (typeof link.download === 'string') {
            link.href = url;
            link.download = filename;
            link.style.display = 'none';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            this.revokeURL(url);
            return;
        }
        window.open(url);
    }
    /** @ignore */
    revokeURL(url) {
        try {
            if (typeof URL !== 'undefined') {
                URL.revokeObjectURL(url);
            }
        }
        catch { }
    }
    /**
     * Decodifica incrementale di chunk JSON per streaming.
     * @param value Chunk binario.
     * @param decodedItemCallback Callback per ogni item decodificato.
     */
    decodeChunk(value, decodedItemCallback) {
        const chunk = this.decoder.decode(value);
        let itemStart = 0;
        for (let i = 0; i < chunk.length; i++) {
            if (chunk[i] === this.JTOKEN_START_OBJECT) {
                if (this.level === 0) {
                    itemStart = i;
                }
                this.level++;
            }
            if (chunk[i] === this.JTOKEN_END_OBJECT) {
                this.level--;
                if (this.level === 0) {
                    let item = chunk.substring(itemStart, i + 1);
                    if (this.partialItem) {
                        item = this.partialItem + item;
                        this.partialItem = '';
                    }
                    decodedItemCallback(JSON.parse(item));
                }
            }
        }
        if (this.level !== 0) {
            this.partialItem = chunk.substring(itemStart);
        }
    }
    /**
     * Converte headers generici in Record<string, string> per fetch/streaming.
     * @param headers Headers da convertire.
     * @returns Record<string, string>.
     */
    toHeaderRecord(headers) {
        if (!headers) {
            return {};
        }
        if (headers instanceof HttpHeaders) {
            return headers.keys().reduce((acc, key) => {
                const value = headers.get(key);
                if (value !== null) {
                    acc[key] = value;
                }
                return acc;
            }, {});
        }
        return Object.keys(headers).reduce((acc, key) => {
            const value = headers[key];
            if (value !== undefined && value !== null) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
    }
    /**
     * Esegue una richiesta fetch in streaming e emette gli item decodificati chunk-by-chunk.
     * Se `decodeChunk` non è fornito, usa il decoder JSON incrementale interno.
      * @param plttpRequest Richiesta HTTP da eseguire in streaming.
      * @param interrupt Segnale di abort esterno opzionale.
      * @param decodeChunk Decoder custom opzionale per il chunk.
      * @returns Observable che emette gli item decodificati.
     */
    /**
     * Esegue una richiesta fetch in streaming e emette gli item decodificati chunk-by-chunk.
     * Se `decodeChunk` non è fornito, usa il decoder JSON incrementale interno.
     * @param plttpRequest Richiesta HTTP da eseguire in streaming.
     * @param interrupt Segnale di abort esterno opzionale.
     * @param decodeChunk Decoder custom opzionale per il chunk.
     * @returns Observable che emette gli item decodificati.
     * @example
     * service.STREAM(new PlHttpRequest({ url: '/api/stream' })).subscribe(item => ...);
     */
    STREAM(plttpRequest, interrupt, decodeChunk) {
        return new Observable(observer => {
            const controller = new AbortController();
            let reader = null;
            const url = this.createUrl(plttpRequest.url);
            if (plttpRequest.queryParams != null) {
                Object.keys(plttpRequest.queryParams).forEach(key => {
                    const value = plttpRequest.queryParams[key];
                    if (value !== undefined && value !== null) {
                        url.searchParams.set(key, value);
                    }
                });
            }
            const headersObj = this.toHeaderRecord(plttpRequest.httpHeaders);
            (async () => {
                try {
                    const method = String(plttpRequest.method ?? 'GET').trim().toUpperCase();
                    const hasBody = !['GET', 'DELETE'].includes(method);
                    const response = await fetch(url.toString(), {
                        method,
                        headers: { ...(headersObj || {}) },
                        body: hasBody && plttpRequest.body ? JSON.stringify(plttpRequest.body) : undefined,
                        signal: interrupt ?? controller.signal
                    });
                    if (!response.ok || !response.body) {
                        observer.error(new Error(`HTTP error! status: ${response.status}`));
                        return;
                    }
                    reader = response.body.getReader();
                    while (true) {
                        const { done, value } = await reader.read();
                        if (done) {
                            break;
                        }
                        if (decodeChunk) {
                            decodeChunk(value, item => observer.next(item));
                        }
                        else {
                            this.decodeChunk(value, item => observer.next(item));
                        }
                    }
                    observer.complete();
                }
                catch (err) {
                    if (err?.name === 'AbortError') {
                        observer.error(new Error('STREAM aborted'));
                        return;
                    }
                    observer.error(err);
                }
            })();
            return () => {
                try {
                    controller.abort();
                    reader?.cancel();
                }
                catch { }
            };
        });
    }
    /**
     * Esegue la request con XMLHttpRequest (fallback compatibilità/browser legacy).
     * Supporta interrupt esterno e progressbar interna.
      * @param plHttpRequest Richiesta HTTP da eseguire.
      * @param responseType Tipo risposta XMLHttpRequest.
      * @param interrupt Subject per interrompere la richiesta.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback invocata con id progress bar.
      * @returns Observable con risposta raw XHR.
     */
    /**
     * Esegue la request con XMLHttpRequest (fallback compatibilità/browser legacy).
     * Supporta interrupt esterno e progressbar interna.
     * @param plHttpRequest Richiesta HTTP da eseguire.
     * @param responseType Tipo risposta XMLHttpRequest.
     * @param interrupt Subject per interrompere la richiesta.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback invocata con id progress bar.
     * @returns Observable con risposta raw XHR.
     * @example
     * service.nativeHttp(new PlHttpRequest({ url: '/api/data' }), 'json').subscribe(res => ...);
     */
    nativeHttp(plHttpRequest, responseType, interrupt, contentType, callBack) {
        const uuid = createPlUuid();
        this.createProgressBar(uuid);
        if (callBack) {
            callBack(uuid);
        }
        return new Observable(observer => {
            const xhr = new XMLHttpRequest();
            const requestInterrupt = interrupt ?? new Subject();
            const externalInterruptSub = requestInterrupt.subscribe(() => {
                xhr.abort();
            });
            const progressInterruptSub = PlCoreUtils.progressBars[uuid].interrupt.subscribe(() => {
                xhr.abort();
            });
            PlCoreUtils.progressBars[uuid].url = plHttpRequest.url;
            const method = this.normalizeMethod(plHttpRequest.method);
            if (!method) {
                observer.error('Method not valid : POST|GET|PATCH|DELETE|PUT');
                this.completeProgressBarDelayed(uuid);
                return () => {
                    externalInterruptSub.unsubscribe();
                    progressInterruptSub.unsubscribe();
                };
            }
            const url = this.createUrlWithQueryParams(plHttpRequest.url, plHttpRequest.queryParams);
            xhr.open(method, url);
            this.applyXhrHeaders(xhr, plHttpRequest.httpHeaders);
            if (responseType != null) {
                xhr.responseType = responseType;
            }
            if (contentType != null) {
                xhr.setRequestHeader('Content-Type', contentType);
            }
            xhr.upload.onprogress = event => {
                if (event.lengthComputable) {
                    this.refreshProgress(uuid, event);
                }
            };
            xhr.onprogress = event => {
                if (event.lengthComputable) {
                    this.refreshProgress(uuid, event);
                }
            };
            xhr.onload = () => {
                if (xhr.status < 200 || xhr.status >= 300) {
                    observer.error(`Error ${xhr.status}: ${xhr.statusText}`);
                    this.completeProgressBarDelayed(uuid);
                    return;
                }
                observer.next(xhr.response);
                observer.complete();
                this.completeProgressBarDelayed(uuid);
            };
            xhr.onerror = e => {
                observer.error(e);
                this.completeProgressBarDelayed(uuid);
            };
            xhr.onabort = () => {
                observer.error(new Error('Request aborted'));
                this.completeProgressBarDelayed(uuid);
            };
            if (plHttpRequest.body instanceof FormData) {
                xhr.send(plHttpRequest.body);
            }
            else {
                xhr.send(typeof plHttpRequest.body === 'string'
                    ? plHttpRequest.body
                    : JSON.stringify(plHttpRequest.body ?? {}));
            }
            return () => {
                externalInterruptSub.unsubscribe();
                progressInterruptSub.unsubscribe();
                if (xhr.readyState !== XMLHttpRequest.DONE) {
                    xhr.abort();
                }
            };
        });
    }
    /**
     * Servizio GET.
      * @param plHttpRequest Configurazione richiesta.
      * @param responseType Tipo risposta atteso.
      * @param interrupt Subject di interruzione.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback con id progress.
      * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Servizio GET (shortcut per REQUEST con method GET).
     * @param plHttpRequest Configurazione richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.GET(new PlHttpRequest({ url: '/api/data' })).subscribe(res => ...);
     */
    GET(plHttpRequest, responseType, interrupt, contentType, callBack) {
        return this.REQUEST(new PlHttpRequest({
            ...plHttpRequest,
            method: 'GET'
        }), responseType, interrupt, contentType, callBack);
    }
    /**
     * Servizio POST.
      * @param plHttpRequest Configurazione richiesta.
      * @param responseType Tipo risposta atteso.
      * @param interrupt Subject di interruzione.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback con id progress.
      * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Servizio POST (shortcut per REQUEST con method POST).
     * @param plHttpRequest Configurazione richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.POST(new PlHttpRequest({ url: '/api/data', body: { foo: 'bar' } })).subscribe(res => ...);
     */
    POST(plHttpRequest, responseType, interrupt, contentType, callBack) {
        return this.REQUEST(new PlHttpRequest({
            ...plHttpRequest,
            method: 'POST'
        }), responseType, interrupt, contentType, callBack);
    }
    /**
     * Servizio PATCH.
      * @param plHttpRequest Configurazione richiesta.
      * @param responseType Tipo risposta atteso.
      * @param interrupt Subject di interruzione.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback con id progress.
      * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Servizio PATCH (shortcut per REQUEST con method PATCH).
     * @param plHttpRequest Configurazione richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.PATCH(new PlHttpRequest({ url: '/api/data', body: { foo: 'bar' } })).subscribe(res => ...);
     */
    PATCH(plHttpRequest, responseType, interrupt, contentType, callBack) {
        return this.REQUEST(new PlHttpRequest({
            ...plHttpRequest,
            method: 'PATCH'
        }), responseType, interrupt, contentType, callBack);
    }
    /**
     * Servizio PUT.
      * @param plHttpRequest Configurazione richiesta.
      * @param responseType Tipo risposta atteso.
      * @param interrupt Subject di interruzione.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback con id progress.
      * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Servizio PUT (shortcut per REQUEST con method PUT).
     * @param plHttpRequest Configurazione richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.PUT(new PlHttpRequest({ url: '/api/data', body: { foo: 'bar' } })).subscribe(res => ...);
     */
    PUT(plHttpRequest, responseType, interrupt, contentType, callBack) {
        return this.REQUEST(new PlHttpRequest({
            ...plHttpRequest,
            method: 'PUT'
        }), responseType, interrupt, contentType, callBack);
    }
    /**
     * Servizio DELETE.
      * @param plHttpRequest Configurazione richiesta.
      * @param responseType Tipo risposta atteso.
      * @param interrupt Subject di interruzione.
      * @param contentType Content-Type esplicito.
      * @param callBack Callback con id progress.
      * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Servizio DELETE (shortcut per REQUEST con method DELETE).
     * @param plHttpRequest Configurazione richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.DELETE(new PlHttpRequest({ url: '/api/data' })).subscribe(res => ...);
     */
    DELETE(plHttpRequest, responseType, interrupt, contentType, callBack) {
        return this.REQUEST(new PlHttpRequest({
            ...plHttpRequest,
            method: 'DELETE'
        }), responseType, interrupt, contentType, callBack);
    }
    /**
     * Esegue più chiamate GET in parallelo e restituisce il risultato aggregato.
     * @param plHttpRequest Lista richieste GET da eseguire.
     * @param interrupt Subject opzionale di interruzione globale.
     * @returns Observable con array di risposte HTTP.
     */
    /**
     * Esegue più chiamate GET in parallelo e restituisce il risultato aggregato.
     * @param plHttpRequest Lista richieste GET da eseguire.
     * @param interrupt Subject opzionale di interruzione globale.
     * @returns Observable con array di risposte HTTP.
     * @example
     * service.FORKJOIN([
     *   new PlHttpRequest({ url: '/api/1' }),
     *   new PlHttpRequest({ url: '/api/2' })
     * ]).subscribe(responses => ...);
     */
    FORKJOIN(plHttpRequest, interrupt) {
        return new Observable(observer => {
            const requestInterrupt = interrupt ?? new Subject();
            const serviceRequests = plHttpRequest.map(request => this.GET(request, undefined, requestInterrupt, undefined, undefined));
            const subscription = forkJoin(serviceRequests)
                .pipe(takeUntil(requestInterrupt))
                .subscribe({
                next: res => {
                    observer.next(res);
                    observer.complete();
                },
                error: err => {
                    observer.error(err);
                }
            });
            return () => {
                subscription.unsubscribe();
                if (!requestInterrupt.closed) {
                    requestInterrupt.next(true);
                    requestInterrupt.complete();
                }
            };
        });
    }
    /**
     * Metodo generico per eseguire una richiesta HTTP in base al method del `PlHttpRequest`.
     * @param plHttpRequest Configurazione completa richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     */
    /**
     * Metodo generico per eseguire una richiesta HTTP in base al method del `PlHttpRequest`.
     * @param plHttpRequest Configurazione completa richiesta.
     * @param responseType Tipo risposta atteso.
     * @param interrupt Subject di interruzione.
     * @param contentType Content-Type esplicito.
     * @param callBack Callback con id progress.
     * @returns Observable con evento di risposta HTTP.
     * @example
     * service.REQUEST(new PlHttpRequest({ url: '/api/data', method: 'POST', body: { foo: 'bar' } }))
     *   .subscribe(res => ...);
     */
    REQUEST(plHttpRequest, responseType, interrupt, contentType, callBack) {
        const method = PlHttpRequest.normalizeMethod(plHttpRequest.method);
        return this.requestWithAngularHttp(method, plHttpRequest, responseType, interrupt, contentType, callBack);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlHttpService, deps: [{ token: i1$1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlHttpService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlHttpService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$1.HttpClient }] });

/**
 * Classe di servizio per utility grafiche.
 */
class PlGraphicService {
    plHttpService;
    constructor(plHttpService) {
        this.plHttpService = plHttpService;
    }
    /**
     * Converte un'immagine SVG caricata da URL in base64.
     *
     * Nota: usa XMLHttpRequest sincrono per retrocompatibilità con il comportamento storico.
      * @param imageUrl URL immagine SVG da convertire.
      * @returns Promise con data URL base64 dell'immagine.
     */
    /**
     * Converte un'immagine SVG caricata da URL in una stringa base64 (data URL).
     * Usa XMLHttpRequest sincrono per retrocompatibilità.
     * @param imageUrl URL immagine SVG da convertire.
     * @returns Promise con data URL base64 dell'immagine.
     * @example
     * service.image2base64('/assets/logo.svg').then(base64 => ...);
     */
    image2base64(imageUrl) {
        return new Promise((resolve, reject) => {
            try {
                if (typeof XMLHttpRequest === 'undefined' || typeof window === 'undefined') {
                    reject(new Error('image2base64 is available only in browser environments'));
                    return;
                }
                const xhr = new XMLHttpRequest();
                xhr.open('GET', imageUrl, false);
                xhr.overrideMimeType('image/svg+xml');
                xhr.send('');
                if (!xhr.responseXML?.documentElement) {
                    reject(new Error('Invalid SVG response'));
                    return;
                }
                const serializedSvg = new XMLSerializer().serializeToString(xhr.responseXML.documentElement);
                resolve('data:image/svg+xml;base64,' + window.btoa(serializedSvg));
            }
            catch (error) {
                reject(error);
            }
        });
    }
    /**
     * Esporta un elemento SVG in un file .svg.
      * @param elementSVG Elemento SVG/HTML da serializzare.
      * @param nameFile Nome file da scaricare.
      * @returns Observable che emette `true` a completamento download.
     */
    /**
     * Esporta un elemento SVG/HTML in un file .svg scaricabile (browser only).
     * @param elementSVG Elemento SVG/HTML da serializzare.
     * @param nameFile Nome file da scaricare.
     * @returns Observable che emette `true` a completamento download.
     * @example
     * service.svg2File(document.getElementById('mysvg'), 'export.svg').subscribe();
     */
    svg2File(elementSVG, nameFile) {
        return new Observable(observer => {
            try {
                if (typeof XMLSerializer === 'undefined' || typeof URL === 'undefined') {
                    observer.error(new Error('svg2File is available only in browser environments'));
                    return;
                }
                let source = new XMLSerializer().serializeToString(elementSVG);
                if (!source.match(/^<svg[^>]+xmlns="http:\/\/www\.w3\.org\/2000\/svg"/)) {
                    source = source.replace(/^<svg/, '<svg xmlns="http://www.w3.org/2000/svg"');
                }
                if (!source.match(/^<svg[^>]+xmlns:xlink="http:\/\/www\.w3\.org\/1999\/xlink"/)) {
                    source = source.replace(/^<svg/, '<svg xmlns:xlink="http://www.w3.org/1999/xlink"');
                }
                source = '<?xml version="1.0" standalone="no"?>\r\n' + source;
                const svgBlob = new Blob([source], {
                    type: CONTENT_TYPE['SVG+XML']
                });
                const url = URL.createObjectURL(svgBlob);
                this.plHttpService.DOWNLOADURL(url, nameFile);
                observer.next(true);
                observer.complete();
            }
            catch (error) {
                observer.error(error);
            }
        });
    }
    /**
     * Converte un elemento SVG/HTML in JPEG tramite html-to-image.
      * @param elementSVG Elemento sorgente da convertire.
      * @returns Observable con data URL JPEG.
     */
    svgToJpeg(elementSVG) {
        return new Observable(observer => {
            htmlToImage
                .toJpeg(elementSVG, {
                quality: 1,
                backgroundColor: 'white'
            })
                .then(dataUrl => {
                observer.next(dataUrl);
                observer.complete();
            })
                .catch(error => {
                observer.error(error);
            });
        });
    }
    /**
     * Crea un canvas a partire da un elemento DOM.
     *
     * Restituisce l'URL blob del canvas e passa il canvas alla callback, se presente.
      * @param elementoDom Elemento DOM da renderizzare su canvas.
      * @param call Callback opzionale con il canvas creato.
      * @returns Observable con blob URL del canvas.
     */
    domToCanvas(elementoDom, call) {
        return new Observable(observer => {
            if (typeof window === 'undefined' || typeof URL === 'undefined') {
                observer.error(new Error('domToCanvas is available only in browser environments'));
                return;
            }
            html2canvas(elementoDom, {
                allowTaint: true,
                useCORS: true
            })
                .then(canvas => {
                canvas.toBlob(blob => {
                    if (!blob) {
                        observer.error(new Error('Unable to create canvas blob'));
                        return;
                    }
                    const url = URL.createObjectURL(blob);
                    observer.next(url);
                    observer.complete();
                    if (call) {
                        call(canvas);
                    }
                });
            })
                .catch(error => {
                observer.error(error);
            });
        });
    }
    /**
     * Crea un URL blob a partire da un canvas.
      * @param canvas Canvas da convertire in blob URL.
      * @returns Observable con blob URL dell'immagine.
     */
    canvasToImg(canvas) {
        return new Observable(observer => {
            try {
                if (typeof URL === 'undefined') {
                    observer.error(new Error('canvasToImg is available only in browser environments'));
                    return;
                }
                canvas.toBlob(blob => {
                    if (!blob) {
                        observer.error(new Error('Unable to create canvas blob'));
                        return;
                    }
                    const url = URL.createObjectURL(blob);
                    observer.next(url);
                    observer.complete();
                });
            }
            catch (error) {
                observer.error(error);
            }
        });
    }
    /**
     * Crea una immagine dataURL a partire da un SVG.
     * Restituisce il dataURL e passa il canvas alla callback, se presente.
      * @param svgElement Elemento SVG/DOM da convertire.
      * @param call Callback opzionale con canvas risultante.
      * @returns Observable con dataURL dell'immagine prodotta.
     */
    svgToImage(svgElement, call) {
        return new Observable(observer => {
            try {
                if (typeof document === 'undefined' || typeof URL === 'undefined') {
                    observer.error(new Error('svgToImage is available only in browser environments'));
                    return;
                }
                const canvas = document.createElement('canvas');
                const rect = svgElement.getBoundingClientRect();
                const width = svgElement.scrollWidth || rect.width || 300;
                const height = svgElement.scrollHeight || rect.height || 150;
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    observer.error(new Error('Unable to get canvas 2D context'));
                    return;
                }
                const svgString = new XMLSerializer().serializeToString(svgElement);
                const svgBlob = new Blob([svgString], {
                    type: 'image/svg+xml;charset=utf-8'
                });
                const img = new Image();
                const url = URL.createObjectURL(svgBlob);
                img.onload = () => {
                    try {
                        ctx.drawImage(img, 0, 0, width, height);
                        const dataURL = canvas.toDataURL();
                        observer.next(dataURL);
                        observer.complete();
                        if (call) {
                            call(canvas);
                        }
                    }
                    catch (error) {
                        observer.error(error);
                    }
                    finally {
                        URL.revokeObjectURL(url);
                    }
                };
                img.onerror = error => {
                    URL.revokeObjectURL(url);
                    observer.error(error);
                };
                img.src = url;
            }
            catch (error) {
                observer.error(error);
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlGraphicService, deps: [{ token: PlHttpService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlGraphicService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlGraphicService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: PlHttpService }] });

class PlNetworkService {
    constructor() { }
    /**
     * Ritorna gli header della richiesta corrente e i query params della URL.
     *
     * Nota:
     * la lettura degli header tramite XMLHttpRequest sincrona è mantenuta
     * per retrocompatibilità, ma può non funzionare in tutti gli ambienti.
      * @returns Promise con header e query params correnti.
     */
    /**
     * Restituisce headers HTTP e query params della pagina corrente.
     * Utile per debug, diagnostica o per propagare info di contesto lato client.
     * Nota: la lettura degli header tramite XMLHttpRequest sincrona è mantenuta per retrocompatibilità, ma può non funzionare in tutti gli ambienti.
     * @returns Promise con header e query params correnti.
     * @example
     * service.getLocalHttpHeaders().then(({ headers, params }) => console.log(headers, params));
     */
    getLocalHttpHeaders() {
        return new Promise((resolve, reject) => {
            try {
                if (typeof document === 'undefined' || typeof location === 'undefined') {
                    resolve({
                        headers: {},
                        params: {}
                    });
                    return;
                }
                const headers = this.readCurrentDocumentHeaders();
                const params = this.parseQueryParams(location.search);
                resolve({
                    headers,
                    params
                });
            }
            catch (error) {
                reject(error);
            }
        });
    }
    /**
     * Legge gli header HTTP del documento corrente tramite chiamata locale sincrona.
     * @returns Record con header HTTP della pagina.
     */
    readCurrentDocumentHeaders() {
        try {
            const req = new XMLHttpRequest();
            req.open('GET', document.location.href, false);
            req.send(null);
            return this.parseHttpHeaders(req.getAllResponseHeaders());
        }
        catch {
            return {};
        }
    }
    /**
     * Effettua il parse dei query param della URL corrente in un record key/value.
     * @param search Stringa query (es: location.search).
     * @returns Record con i parametri query.
     */
    parseQueryParams(search) {
        const params = {};
        const query = search.startsWith('?') ? search.substring(1) : search;
        if (!query) {
            return params;
        }
        query.split('&').forEach(item => {
            if (!item) {
                return;
            }
            const [rawKey, rawValue = ''] = item.split('=');
            const key = decodeURIComponent(rawKey).toLowerCase();
            const value = decodeURIComponent(rawValue);
            params[key] = value;
        });
        return params;
    }
    /**
     * Effettua il parse di una stringa header HTTP in un record key/value.
     * @param httpHeaders Stringa header HTTP (formato raw).
     * @returns Record con header HTTP.
     * @example
     * const headers = service['parseHttpHeaders']('X-Token: abc\nX-Id: 123');
     */
    parseHttpHeaders(httpHeaders) {
        if (!httpHeaders) {
            return {};
        }
        return httpHeaders
            .split('\n')
            .map(header => header.trim())
            .filter(Boolean)
            .map(header => header.split(/: */, 2))
            .filter(([key]) => !!key)
            .reduce((acc, [key, value]) => {
            acc[key] = value ?? '';
            return acc;
        }, {});
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlNetworkService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlNetworkService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlNetworkService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

/**
 * Classe di servizio che espone metodi di utilità.
 */
class PlUtilsService {
    traceSizeWindowOBS = null;
    constructor() { }
    /**
     * Ricerca dicotomica asincrona di un elemento in un array ordinato.
     *
     * @param input Oggetto `{ arr, searchElement }` dove `arr` è l'array ordinato e `searchElement` il valore da cercare.
     * @returns Promise che risolve con l'indice dell'elemento trovato, o `-1` se non presente.
     *
     * @example
     * const idx = await utils.binaryFind({ arr: [1, 2, 3, 4], searchElement: 3 }); // idx = 2
     *
     * // Con oggetti custom:
     * const arr = [{id: 1}, {id: 2}];
     * const idx = await utils.binaryFind({ arr, searchElement: {id: 2} });
     */
    binaryFind(input) {
        return new Promise(resolve => {
            let minIndex = 0;
            let maxIndex = input.arr.length - 1;
            while (minIndex <= maxIndex) {
                const currentIndex = Math.floor((minIndex + maxIndex) / 2);
                const currentElement = input.arr[currentIndex];
                if (currentElement < input.searchElement) {
                    minIndex = currentIndex + 1;
                    continue;
                }
                if (currentElement > input.searchElement) {
                    maxIndex = currentIndex - 1;
                    continue;
                }
                resolve(currentIndex);
                return;
            }
            resolve(-1);
        });
    }
    /**
     * Ricerca dicotomica sincrona di un elemento in un array ordinato.
     *
     * @param input Oggetto `{ arr, searchElement }` come per `binaryFind`.
     * @returns Indice dell'elemento trovato, o `-1` se non presente.
     *
     * @example
     * const idx = utils.binaryFindSync({ arr: [10, 20, 30], searchElement: 20 }); // idx = 1
     */
    binaryFindSync(input) {
        let minIndex = 0;
        let maxIndex = input.arr.length - 1;
        while (minIndex <= maxIndex) {
            const currentIndex = Math.floor((minIndex + maxIndex) / 2);
            const currentElement = input.arr[currentIndex];
            if (currentElement < input.searchElement) {
                minIndex = currentIndex + 1;
                continue;
            }
            if (currentElement > input.searchElement) {
                maxIndex = currentIndex - 1;
                continue;
            }
            return currentIndex;
        }
        return -1;
    }
    /**
     * Osserva le dimensioni della finestra browser in tempo reale.
     *
     * @returns Observable che emette `{ W, h }` a ogni resize.
     *
     * @example
     * utils.traceSizeWindow().subscribe(size => console.log(size.W, size.h));
     */
    traceSizeWindow() {
        if (typeof window === 'undefined') {
            return of({
                W: 0,
                h: 0
            });
        }
        return fromEvent(window, 'resize').pipe(debounceTime(200), startWith(null), map(() => this.getWindowSize()), distinctUntilChanged((prev, curr) => prev.W === curr.W && prev.h === curr.h));
    }
    /**
     * Avvia il trace delle dimensioni finestra con callback custom.
     * Mantiene la subscription internamente (utile per componenti singleton).
     *
     * @param callback Funzione chiamata a ogni resize con `{ W, h }`.
     * @returns Subscription attiva (puoi chiamare `.unsubscribe()` per fermare).
     *
     * @example
     * const sub = utils.startTraceSizeWindow(size => console.log(size));
     * // ...
     * sub.unsubscribe();
     */
    startTraceSizeWindow(callback) {
        this.stopTraceSizeWindow();
        this.traceSizeWindowOBS = this.traceSizeWindow().subscribe(callback);
        return this.traceSizeWindowOBS;
    }
    /**
     * Ferma il trace delle dimensioni finestra avviato con `startTraceSizeWindow`.
     *
     * @example
     * utils.stopTraceSizeWindow();
     */
    stopTraceSizeWindow() {
        this.traceSizeWindowOBS?.unsubscribe();
        this.traceSizeWindowOBS = null;
    }
    getWindowSize() {
        if (typeof window === 'undefined') {
            return {
                W: 0,
                h: 0
            };
        }
        return {
            W: window.innerWidth,
            h: window.innerHeight
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlUtilsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlUtilsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlUtilsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class PLWorkerService {
    /** @ignore */
    workerFunctionToUrlMap = new WeakMap();
    /** @ignore */
    promiseToWorkerMap = new WeakMap();
    /**
     * Funzionalità per la virtualizzazione di un codice elaborato.
     * Il codice viene eseguito in un thread separato dal main thread.
     *
     * Nota: workerFunction e initProcess non devono essere arrow function
     * se vuoi serializzarle correttamente dentro il worker.
     *
     * @param workerFunction Promise/funzione da virtualizzare in un thread separato.
     * @param nameThred Nome da assegnare al thread, utile per i log.
     * @param initProcess Funzione richiamata per i log di start/end processo.
     * @param data Oggetto contenente i parametri da passare alla funzione workerFunction.
     * @param singolInstance Se true crea un nuovo worker URL anche se la funzione era già mappata.
    * @returns Promise con il risultato prodotto dal worker.
     */
    /**
     * Esegue una funzione asincrona o sincrona in un Web Worker (thread separato) se supportato, altrimenti fallback su main thread.
     * Utile per virtualizzare task pesanti senza bloccare l’UI.
     * Nota: workerFunction e initProcess non devono essere arrow function se vuoi serializzarle correttamente dentro il worker.
     * @param workerFunction Funzione/Promise da virtualizzare in thread separato.
     * @param nameThred Nome thread (per log/debug).
     * @param initProcess Funzione richiamata per log di start/end processo.
     * @param data Parametri da passare alla funzione workerFunction.
     * @param singolInstance Se true forza nuovo worker URL anche se già mappata.
     * @returns Promise con il risultato prodotto dal worker.
     * @example
     * service.run(async (input) => { return await heavyTask(input); }, 'HeavyTask', console.log, { foo: 1 });
     */
    run(workerFunction, nameThred, initProcess = () => { }, data, singolInstance = false) {
        if (this.isWorkerSupported()) {
            const url = this.getOrCreateWorkerUrl(workerFunction, initProcess, nameThred, singolInstance);
            return this.runUrl(url, data);
        }
        return this.runInMainThread(workerFunction, nameThred, initProcess, data);
    }
    /**
     * Funzionalità di esecuzione di uno script in formato blob/url.
     *
     * @param url URL del worker.
     * @param data Dati da inviare al worker.
      * @returns Promise con il payload di risposta del worker.
     */
    /**
     * Esegue uno script worker da URL/blob URL.
     * @param url URL del worker.
     * @param data Dati da inviare al worker.
     * @returns Promise con il payload di risposta del worker.
     * @example
     * service.runUrl('worker.js', { foo: 1 }).then(res => ...);
     */
    runUrl(url, data) {
        if (!this.isWorkerSupported()) {
            return Promise.reject(new Error("Can't run worker in this environment"));
        }
        const worker = this.createWorker(url);
        const promise = this.createPromiseForWorker(worker, data);
        const promiseCleaner = this.createPromiseCleaner(promise);
        this.promiseToWorkerMap.set(promise, worker);
        promise.then(promiseCleaner).catch(promiseCleaner);
        return promise;
    }
    /**
     * Recupera il worker associato a una Promise.
     *
     * @param promise Promise restituita da run/runUrl.
      * @returns Istanza worker associata oppure `undefined`.
     */
    /**
     * Recupera il worker associato a una Promise restituita da run/runUrl.
     * @param promise Promise restituita da run/runUrl.
     * @returns Istanza worker associata oppure `undefined`.
     * @example
     * const worker = service.getWorker(promise);
     */
    getWorker(promise) {
        return this.promiseToWorkerMap.get(promise);
    }
    /**
     * Termina il worker associato a una Promise.
     *
     * @param promise Promise restituita da run/runUrl.
     */
    /**
     * Termina il worker associato a una Promise restituita da run/runUrl.
     * @param promise Promise restituita da run/runUrl.
     * @example
     * service.terminateWorker(promise);
     */
    terminateWorker(promise) {
        this.removePromise(promise);
    }
    isWorkerSupported() {
        return typeof Worker !== 'undefined';
    }
    createWorker(url) {
        if (!this.isWorkerSupported()) {
            throw new Error('Web Worker is not supported in this environment');
        }
        return new Worker(url);
    }
    runInMainThread(workerFunction, nameThred, initProcess, data) {
        const uuid = createPlUuid();
        const initTime = new Date().getTime();
        try {
            initProcess(`START WORK: ${nameThred} ID: ${uuid}`);
            return Promise.resolve(workerFunction(data)).then(response => {
                const elapsed = ((new Date().getTime() - initTime) / 1000).toString();
                initProcess(`END WORK: ${nameThred} ID: ${uuid} in : ** ${elapsed}s **`);
                return response;
            });
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
    /** @ignore */
    removePromise(promise) {
        const worker = this.promiseToWorkerMap.get(promise);
        if (worker) {
            try {
                worker.terminate();
            }
            catch { }
        }
        this.promiseToWorkerMap.delete(promise);
        return promise;
    }
    /** @ignore */
    createPromiseCleaner(promise) {
        return event => {
            this.removePromise(promise);
            return event;
        };
    }
    /** @ignore */
    createPromiseForWorker(worker, data) {
        return new Promise((resolve, reject) => {
            const cleanup = () => {
                worker.removeEventListener('message', onMessage);
                worker.removeEventListener('error', onError);
                worker.removeEventListener('messageerror', onMessageError);
            };
            const onMessage = (event) => {
                const payload = event.data;
                cleanup();
                if (payload?.__plWorkerError) {
                    reject(this.normalizeWorkerError(payload.error));
                    return;
                }
                if (payload?.__plWorkerSuccess) {
                    resolve(payload.data);
                    return;
                }
                resolve(payload);
            };
            const onError = (error) => {
                cleanup();
                reject(error);
            };
            const onMessageError = (error) => {
                cleanup();
                reject(error);
            };
            worker.addEventListener('message', onMessage);
            worker.addEventListener('error', onError);
            worker.addEventListener('messageerror', onMessageError);
            try {
                worker.postMessage(data);
            }
            catch (error) {
                cleanup();
                reject(error);
            }
        });
    }
    /** @ignore */
    normalizeWorkerError(error) {
        if (error instanceof Error) {
            return error;
        }
        if (typeof error === 'string') {
            return new Error(error);
        }
        return new Error(error?.message ?? 'Worker execution error');
    }
    /** @ignore */
    createWorkerUrl(resolve, init, nameThred) {
        const resolveString = resolve.toString();
        const initString = init.toString();
        const uuid = createPlUuid();
        const webWorkerTemplate = `
      const __plWorkerInit = ${initString};
      const __plWorkerResolve = ${resolveString};

      self.addEventListener('message', function (e) {
        const initProcess = new Date().getTime();

        try {
          __plWorkerInit('START WORK: ${nameThred} ID: ${uuid}');

          Promise.resolve(__plWorkerResolve(e.data))
            .then(function (response) {
              self.postMessage({
                __plWorkerSuccess: true,
                data: response
              });

              __plWorkerInit(
                'END WORK: ${nameThred} ID: ${uuid} in : ** '
                  .concat(((new Date().getTime()) - initProcess) / 1000)
                  .concat('s **')
              );
            })
            .catch(function (error) {
              self.postMessage({
                __plWorkerError: true,
                error: {
                  message: error && error.message ? error.message : String(error),
                  stack: error && error.stack ? error.stack : null
                }
              });
            });
        } catch (error) {
          self.postMessage({
            __plWorkerError: true,
            error: {
              message: error && error.message ? error.message : String(error),
              stack: error && error.stack ? error.stack : null
            }
          });
        }
      });
    `;
        const blob = new Blob([webWorkerTemplate], {
            type: 'text/javascript'
        });
        return URL.createObjectURL(blob);
    }
    /** @ignore */
    getOrCreateWorkerUrl(fn, init, nameThred, singolInstance) {
        if (!this.workerFunctionToUrlMap.has(fn) || singolInstance) {
            const url = this.createWorkerUrl(fn, init, nameThred);
            this.workerFunctionToUrlMap.set(fn, url);
            return url;
        }
        return this.workerFunctionToUrlMap.get(fn);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PLWorkerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PLWorkerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PLWorkerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class PlBaseComponent {
    injector;
    graphicService;
    httpService;
    networkService;
    utilsService;
    workerService;
    queryParams = new ReplaySubject(1);
    params = new ReplaySubject(1);
    data = new ReplaySubject(1);
    queryParamsObs = null;
    paramsObs = null;
    dataObs = null;
    router;
    route;
    constructor(injector) {
        this.injector = injector;
        this.router = this.injector.get(Router);
        this.route = this.injector.get(ActivatedRoute);
        this.graphicService = this.injector.get(PlGraphicService);
        this.httpService = this.injector.get(PlHttpService);
        this.networkService = this.injector.get(PlNetworkService);
        this.utilsService = this.injector.get(PlUtilsService);
        this.workerService = this.injector.get(PLWorkerService);
        this.paramsObs = this.route.params.subscribe(param => {
            this.params.next(param);
        });
        this.queryParamsObs = this.route.queryParams.subscribe(param => {
            this.queryParams.next(param);
        });
        this.dataObs = this.route.data.subscribe(param => {
            this.data.next(param);
        });
    }
    /**
     * Funzione che si occupa di navigare verso una pagina
     * e di passare eventuali query params.
     *
     * È possibile preservare alcuni query params già presenti nella rotta corrente.
     */
    goToPage(pageUrl, extras = {}, queryParams = {}, preservedQueryParams = []) {
        const safeQueryParams = queryParams ?? {};
        const safeExtras = extras ?? {};
        const currentQueryParams = this.route.snapshot.queryParams ?? {};
        preservedQueryParams.forEach(key => {
            if (!Object.prototype.hasOwnProperty.call(safeQueryParams, key)) {
                safeQueryParams[key] = currentQueryParams[key] ?? null;
            }
        });
        this.router.navigate([pageUrl], {
            ...safeExtras,
            queryParams: safeQueryParams
        });
    }
    /** Inizializza il componente esteso. */
    ngOnInit() { }
    /** Hook post-inizializzazione del content projection. */
    ngAfterContentInit() { }
    /** Rilascia subscription e subject usati dalla base class. */
    ngOnDestroy() {
        this.queryParamsObs?.unsubscribe();
        this.paramsObs?.unsubscribe();
        this.dataObs?.unsubscribe();
        this.queryParamsObs = null;
        this.paramsObs = null;
        this.dataObs = null;
        this.queryParams.complete();
        this.params.complete();
        this.data.complete();
    }
    /** Hook post-inizializzazione della view. */
    ngAfterViewInit() { }
    /** Hook eseguito dopo ogni check della view. */
    ngAfterViewChecked() { }
    /** Hook eseguito dopo ogni check del contenuto proiettato. */
    ngAfterContentChecked() { }
    /** Hook di change detection custom. */
    ngDoCheck() { }
    /** Hook chiamato al cambio degli input. */
    ngOnChanges(changes) { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlBaseComponent, deps: [{ token: i0.Injector }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.22", type: PlBaseComponent, isStandalone: false, selector: "ng-component", usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
__decorate([
    Log('debug')
    /** Inizializza il componente esteso. */
], PlBaseComponent.prototype, "ngOnInit", null);
__decorate([
    Log('debug')
    /** Hook post-inizializzazione del content projection. */
], PlBaseComponent.prototype, "ngAfterContentInit", null);
__decorate([
    Log('debug')
    /** Rilascia subscription e subject usati dalla base class. */
], PlBaseComponent.prototype, "ngOnDestroy", null);
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlBaseComponent, decorators: [{
            type: Component,
            args: [{
                    template: '',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.Injector }], propDecorators: { 
        /** Inizializza il componente esteso. */
        ngOnInit: [], 
        /** Hook post-inizializzazione del content projection. */
        ngAfterContentInit: [], 
        /** Rilascia subscription e subject usati dalla base class. */
        ngOnDestroy: [] } });

/**
 * Token per identificare il tag usato nelle chiamate cacheabili.
 */
const CACHE_TAG = new InjectionToken('CACHE_TAG');
/**
 * Token per identificare il tempo massimo di validità cache.
 */
const MAX_CACHE_AGE = new InjectionToken('MAX_CACHE_AGE');
class PlCacheMapService {
    maxCacheAge;
    cacheTag;
    cache = new Map();
    constructor(maxCacheAge, cacheTag) {
        this.maxCacheAge = maxCacheAge;
        this.cacheTag = cacheTag;
    }
    /**
     * Restituisce il tag cache configurato.
      * @returns Tag cache corrente.
     */
    getCacheTag() {
        return this.cacheTag ?? '@cachable@';
    }
    /**
     * Restituisce il tempo massimo cache configurato.
      * @returns Durata massima cache in millisecondi.
     */
    getMaxCacheAge() {
        return this.maxCacheAge ?? 300000;
    }
    /**
     * Verifica se una URL contiene il tag cache.
      * @param url URL da verificare.
      * @returns `true` se la URL contiene il tag cache.
     */
    hasCacheTag(url) {
        return url.includes(this.getCacheTag());
    }
    /**
     * Rimuove il tag cache da una URL.
      * @param url URL da normalizzare.
      * @returns URL senza cache tag.
     */
    removeCacheTag(url) {
        return url.replace(this.getCacheTag(), '');
    }
    /**
     * Salva un valore in cache.
      * @param key Chiave cache.
      * @param value Valore da memorizzare.
      * @param maxAge Durata elemento cache in millisecondi.
     */
    set(key, value, maxAge = this.getMaxCacheAge()) {
        this.cache.set(key, {
            value,
            timestamp: Date.now(),
            maxAge
        });
    }
    /**
     * Recupera un valore dalla cache.
      * @param key Chiave cache.
      * @returns Valore trovato oppure `null` se assente/scaduto.
     */
    /**
     * Recupera un valore dalla cache, se presente e non scaduto.
     * @param key Chiave cache.
     * @returns Valore trovato oppure `null` se assente/scaduto.
     * @example
     * const value = service.get('myKey');
     */
    get(key) {
        const item = this.cache.get(key);
        if (!item) {
            return null;
        }
        if (this.isExpired(item)) {
            this.cache.delete(key);
            return null;
        }
        return item.value;
    }
    /**
     * Verifica se una chiave è presente ed è ancora valida.
      * @param key Chiave cache.
      * @returns `true` se esiste un elemento non scaduto.
     */
    /**
     * Verifica se una chiave è presente ed è ancora valida.
     * @param key Chiave cache.
     * @returns `true` se esiste un elemento non scaduto.
     * @example
     * if (service.has('myKey')) { ... }
     */
    has(key) {
        const item = this.cache.get(key);
        if (!item) {
            return false;
        }
        if (this.isExpired(item)) {
            this.cache.delete(key);
            return false;
        }
        return true;
    }
    /**
     * Rimuove una chiave dalla cache.
      * @param key Chiave cache da eliminare.
      * @returns `true` se la chiave è stata rimossa.
     */
    /**
     * Rimuove una chiave dalla cache.
     * @param key Chiave cache da eliminare.
     * @returns `true` se la chiave è stata rimossa.
     * @example
     * service.delete('myKey');
     */
    delete(key) {
        return this.cache.delete(key);
    }
    /**
     * Pulisce tutta la cache.
     */
    /**
     * Pulisce tutta la cache.
     * @example
     * service.clear();
     */
    clear() {
        this.cache.clear();
    }
    /**
     * Restituisce tutte le chiavi presenti.
      * @returns Lista delle chiavi cache.
     */
    /**
     * Restituisce tutte le chiavi presenti in cache.
     * @returns Lista delle chiavi cache.
     * @example
     * const allKeys = service.keys();
     */
    keys() {
        return Array.from(this.cache.keys());
    }
    /**
     * Restituisce la dimensione della cache.
      * @returns Numero elementi presenti in cache.
     */
    /**
     * Restituisce la dimensione della cache (numero di elementi).
     * @returns Numero elementi presenti in cache.
     * @example
     * const n = service.size();
     */
    size() {
        return this.cache.size;
    }
    /**
     * Verifica se un elemento cache è scaduto.
     * @param item Oggetto cache.
     * @returns `true` se scaduto.
     */
    isExpired(item) {
        return Date.now() - item.timestamp > item.maxAge;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlCacheMapService, deps: [{ token: MAX_CACHE_AGE, optional: true }, { token: CACHE_TAG, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlCacheMapService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlCacheMapService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [MAX_CACHE_AGE]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CACHE_TAG]
                }] }] });

/**
 * Token per la valorizzazione del path di default
 * usato per risalire ai JSON di mock.
 */
const DEFAULT_PATH_MOCK = new InjectionToken('Default path for retrieve mock json');
class PlHttpInterceptorMockService {
    pathMock;
    tagCache;
    constructor(pathMock, tagCache) {
        this.pathMock = pathMock;
        this.tagCache = tagCache;
    }
    /**
     * Se la request contiene header mocked=true, la chiamata viene trasformata
     * in una GET verso il file JSON corrispondente:
     *
     * /assets/{pathMock}/{url-path}/{method}.json
     *
     * Esempio:
     *
     * GET /api/users con mocked=true
     * diventa:
     * /assets/public/mock/api/users/get.json
     */
    intercept(request, next) {
        const mocked = request.headers.get('mocked');
        if (mocked?.toLowerCase() !== 'true') {
            return next.handle(request);
        }
        const mockRequest = this.createMockRequest(request);
        return next.handle(mockRequest);
    }
    createMockRequest(request) {
        const tagCache = this.tagCache ?? '';
        const cleanUrl = tagCache
            ? request.url.replace(tagCache, '')
            : request.url;
        const parsedUrl = this.createUrl(cleanUrl);
        const pathMock = this.normalizePath(this.pathMock ?? 'public/mock');
        const methodFile = `${request.method.toLowerCase()}.json`;
        let newUrl = [
            '/assets',
            pathMock,
            this.normalizePath(parsedUrl.pathname),
            methodFile
        ]
            .filter(Boolean)
            .join('/');
        if (parsedUrl.search) {
            newUrl = `${newUrl}${parsedUrl.search}`;
        }
        if (tagCache && request.url.includes(tagCache)) {
            newUrl = `${tagCache}${newUrl}`;
        }
        return request.clone({
            method: 'GET',
            url: newUrl,
            headers: request.headers.delete('mocked')
        });
    }
    createUrl(url) {
        try {
            return new URL(url);
        }
        catch {
            const baseUrl = typeof window !== 'undefined' && window.location?.origin
                ? window.location.origin
                : 'http://localhost';
            return new URL(url, baseUrl);
        }
    }
    normalizePath(path) {
        return path
            .replace(/^\/+/, '')
            .replace(/\/+$/, '');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlHttpInterceptorMockService, deps: [{ token: DEFAULT_PATH_MOCK, optional: true }, { token: CACHE_TAG, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlHttpInterceptorMockService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlHttpInterceptorMockService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DEFAULT_PATH_MOCK]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CACHE_TAG]
                }] }] });

/**
 * @ignore
 */
const template = '<div style="  margin-top: 5%; text-align: center; color: blue;  ">                                  ' +
    '  <div>                                                                                             ' +
    '    <img src="#ico" style=" width: 100px " />                                                       ' +
    '    <h3  >Ooooops !!!</h3>                                                                          ' +
    '  </div>                                                                                            ' +
    '  <h4  >Il tuo browser #0 sembra non essere al momento compatibile</h4>' +
    '  <h4  >Si raccomanda di utilizzare un altro browser</h4>                                           ' +
    ' </div>                                                                                             ';
/**
 * @author l.piciollo
 * Mappa dei browser name
 */
var BROWSER;
(function (BROWSER) {
    BROWSER["EDGE"] = "edge";
    BROWSER["OPERA"] = "opera";
    BROWSER["CHROME"] = "chrome";
    BROWSER["IE"] = "ie";
    BROWSER["FIREFOX"] = "firefox";
    BROWSER["SAFARI"] = "safari";
    BROWSER["OTHER"] = "other";
    BROWSER["ALL"] = "all";
})(BROWSER || (BROWSER = {}));
/**
 * @author l.piciollo
 * token per identificare quali browser sono supportati
 * @example { provide: BROWSER_VALID, useValue: [BROWSER.ALL] }
 */
const BROWSER_VALID = new InjectionToken('browser validi');
/**
* @author l.piciollo
* token per identificare se disabilitare o meno la console.log, valido in un contesto produzione
* @example { provide: DISABLE_LOG, useValue: true }
*/
const DISABLE_LOG = new InjectionToken('disabilita log');
/**
 * @author l.piciollo
 * Servizio per identificare e settare funzionalità in base al browser o a preferenze runtime.
 * Permette di bloccare browser, disabilitare log, patchare estensioni prototype e altro.
 * Invocare il metodo detect() all’inizializzazione del sistema per abilitare patch runtime e comportamenti custom.
 * @example
 * // In app.module.ts
 * { provide: APP_INITIALIZER, useFactory: AmbientModeProviderFactory, deps: [PlAmbientModeLoaderService], multi: true }
 * // In main.ts
 * PlAmbientModeLoaderService.detect();
 */
class PlAmbientModeLoaderService {
    httpService;
    injector;
    /**
     * Mappa delle icone base64 per i browser supportati.
     * @ignore
     */
    mapIcons = Object.freeze({
        chrome: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAgAElEQVR4Xu1deXxU1fX/nvsSIGQS1LovBLVCFQUVkrjVal2TmQkuJAFqQDQJXfxZa1tb60a1+2Zray1JUFkUyIBKZhLUtpa6JwEFFAWxQsAFtyqZLGR59/w+L4gFDMnM3DfLm7nv8+kflXu+53u+9+XMe/fdew5BX45W4F2vd3jvcHkcCT5aMg4hFocwyYPB4hAQHwLgEMnIIsJQYgwFYaiUcigEhgLW/4QQEr1SyF4hRY8UskeAOqRJrcKQrWC0ShI7DOADCX4fhO0E8T5LeocMuTnn4fpPHC1gipOnFI/fEeGvqpyQftCOI04SwMkEPl4KPl4wHQ+J4yBwRJyD2EHgLZD8FhvGRrB8DYJeSw+K14/0+zvizE27H0QBnQAS7BaxftG7XTxegE8D43SGPA0QY3f9WjvnkgADeAvAamJeBaZVJne9dLzvHzucE0XyM9UJIM5zvOkbBdnppviqAM4zwV8D+HQBYcSZVlTc9yUFxqsEPCOAZ0DG0yMX170bFWcaNCQFdAIISSb7Bm0qKBg67AA63wQuIqavSchTk/UPPhTVGHiDGE8w4Ykh7eJf+rUhFNXsG6MTgH1a7hfp7emXf8ns6nET8SQJXEyAKwZuneiii4mfAeMxwxSPHeMLvOPEIJzEWSeAKM3WtmLPUSxQapK8DOCzUvlXPhKJrdcFAW4G41GWxpJRPv/mSHC0zcAK6ARg4x3yQXGxq1N0XgHi6VLK84UQwkb4VId6nggPpUHUHrnI/1Gqi2FX/DoBKCrJs2eLba+vupCJy6TE5UIgUxFSmw+kgEQPE9fDENU5oyc+TrNnSy1Y5AroBBChdi3T3Acy4xpi/g5Ax0YIo80UFCDIrQy6X5iiRq8XRCakTgBh6ra11H2ySfL/AFwlIIaHaa6HR0MB66lAYKlgcffIJf7maLhIVkydAEKc2ZbSQg8Rf58hzgvRRA+LiwLyBSb6fc6YvEf168HgE6ATwAAaMUAtUwuvIEm3gnDq4HLqEQmkwOsg/Hrke+0P0cqVvQnEK6Go6ATQz3T0LextbCo1e+kWYcDahqsv5yqwBcAvR25vv18ngi9Ook4Ae2hi/eJvK3WXSsJPCRjt3HteM99XAQn8h5juyDlx4iL9avA/dXQC+EyLrVPcX2Xw7wDK038+yauAZLxChJtHLa6vT94oQ48s5RPAtmmeE0xT/oaILgtdNj3S+QrwkyDjxpxF/vXOjyXyCFI2AVjf8WHip2B8EwLpkUuoLZ2qgIQ0BajaGDL01qPnP/qxU+NQ4Z2SCWBLqecbxPgDBB+qIp62TQ4FJOTHBPGjnMX199OuOgYpc6VUAmiZ5j4Oku8D6OKUmWEdaDgKPEeMb45cUv9qOEZOHpsSCcAqqXVo6+E/NCFvFRAZTp4wzT26CjDQK0C/CpoZd431+bqj6y3+6EmfALZNLRpn9vYuIIPGxV9uzcApClhfC4SBmTkP1692CudIeCZtArA287RsaL6RgJ85rZ5eJBOpbexXYPfTwDHb236arJuIkjIB/KfYMzLdMOfpffv2/1GkJiI3CTPtG8f46t5MtviTLgFsmVI4jUB/BTAi2SZLxxM/BRhoE0zXj1wSeCB+LOz3nDQJYPPV5w0zdmb+hYFr7ZdJI2oFPlOA8NDQtJ5Zhy94sj0ZNEmKBLB5yqWjBGgZIE5PhknRMSS2AtLEeqSJyccu8m9IbKaDs3N8AthSWlDAJBYK4KDBw9UjtAL2KGC9EhDxtTmLGmrtQYwPimMTgLXKv3XDqtulNG/TxTfjc/Nor5YC/MuRixtuceoOQkcmgL6GmBm9C1mIy/VNqBWItwJSyrqunelXfaWuLhhvLuH6d1wCeGtq0WHEvX4Byg03WD1eKxAtBRjyVSnIc9zDDS3R8hENXEclgC2l7hOJ0ABgVDTE0JhaASUFJN5jId2jFq94WQknhsaOSQBbStznE8lHQOKAGOqjXWkFwlKgb7+AwOSRD9c/EZZhnAY7IgFsneIpZckL9Ln9ON0l2m1YClhbiInp2pwlgflhGcZhcMIngK2lnpkmmzV6pT8Od4d2GbECVm9DYrp+1JLAXyIGiYFhQieALaWe65j4HgEkNM8YzJN24VAFiHHryCX1P09U+gn7h9Uy1XMTmH+dqMJpXlqBkBUg+lXOosDNIY+P4cCETAAtUzyzAb4jhjpoV1qBqCrAwC9GLa6/JapOIgBPuASwdYr7Jwwk7CNTBBprE61AnwIE3DVycf3tiSRHQiUA652fiP+cSAJpLloBOxVg4PZRi+vvshNTBSthEkBLqWe6JH5QL/ipTKe2dYQChOtzFtUnxA9dQiSALVM8lzNMn4AwHDGBmqRWQEGBvk+E4KtGLW54WAHGFtO4J4Bd23vlGkAMsSUiDaIVcIAC1mYhCJo06uGAtbU9blfcEwCfd17a1sMz1wE4MW4qaMdagTgoICXaicS5o5b4X4qD+90Lk/Fy/T+/26YWXiqZVsSfiWagFYixAhLvpYm0/KMWL98WY8+JkwAsJi2l7noQCuMhgvapFYinAmzyup1daefEo55A3F8Bdgv/VvGlYwwyXtEHfuJ5K2rfcVNAon7kSblFNHu2jCWHhEkAu54CCu4GiRtiKYD2pRVIFAWY8PNRi+pvjSWfhEoAm6++7ADq6NpEQhwcSxG0L61AIijQ93mQuHjUooZlseKTUAnACnprqftbTLAae+hLK5ByCvRVGzZlfo5vxWuxCD7hEgAXFxtbRMfLgnBKLATQPrQCCacA4bX0NpF7pN/fEW1uCZcArIC3TC34OrH4Z7SD1/hagcRVQM7LWbzi6mjzS8gE0JcESgsfJaLLoi2AxtcKJKoCBJ45cnHDg9Hkl7AJYGtpwfFMeE1vEY7m9GvsRFbA2imYxsap0exKnLAJwJqYltLCX4PopkSeJM1NKxBNBQj04jFmxjnk85nR8JPQCWBDUVFWxrCeTRDisGgErzG1Ao5QgHFHzpL6O6PBNSoJILeuKlfItPbGy65R/pSxZYr7WgJqohG8xtQKOEEB6+SgAJ85cnHDKrv52p4AJqyak268jZdA4p2mSRWXqhLe1QS0sVm3/lZVUts7WQHJeOXjEdsnTKxa3WNnHLYngPy6mtuZ+Kd9JIk8TZ7yelXCLVM954D5GVUcba8VcLQCUXgVsDUB5D92/0ls9Lz8+cq9xBvmUfLk1RNnKWetzVPcSwRQ4ugJ1OS1AkoKyG6YOM3OXYK2JoA8f80zAJ+zd4z8/SZv5R+U4gbw1rTCHKOXNkBgmCqWttcKOFiB50curj+HALYjBtsSQH5dTRkTf7EXGmNHT5pxwsuF13yoSnjrFM9dDI7paSlVztpeK2C3AsR0zcglgQfswLUlAeQ3LMzmns6NEDi8P1LMsqq5aNYsVcLbyy7O7Owy3hBCHKmKpe21Ak5VgIEPeVj66GMffOxT1RhsSQC5ddV3E2Ggc/zSWsVv8l67VpVwy5TCMoASvuuqapzaXiswkAIE/GXk4vr/U1VJOQFMXD53DCBfFQJpA5Fh5pXNRZXnqxJmgFqK3S+QgXxVLG2vFXCqAhLSFJQ2PmeRf71KDMoJIC9Q/RgYk0IhQcyTG4sqlYsdbC4tOAMkntdNREJRXY9JWgUYDTlL6t0q8SklgPy6OecwiZC/z0tg86dG54lvFl7fpULasm2Z4l4A4CpVHG2vFXC2AnRhzuJAxEfnlRJAnr/mRYDDehQn0E8aveW/VBV9W7HnqF7ijUIgUxVL22sFHKsAY83IE3MnRFpMNOIEkBuovoIYkTzOt5npcvTqS2e9pyr6linu2wiIyiEJVW7aXisQKwWIMXXkkvrFkfiLLAEwU26gZi0h4rJd85q8FcrVTrYVF2ew0baBIUZGEry20QokhQLMG0aemDc2kqeAiBJAXqCmGMy1EYsnJTNRfnNRZXPEGJ8Zbp3iKWVwRNlP1be21wokjAKEspxF9QvD5RN+Apg9W+RNOMrq5Tc2XGf7jH+hyVtxliJGn/mWKe5nCNhnC7IdyMmJYR0vJaAdEh0gdCdnlKkVFQvelLOo4eJwtwiHnQCUf/33mhf6RpO3XLlFcss09wQp0aw/C+4SV0r5LoBVZNCbBNoCyZshjM0g+W5bz/D2sT6f/qNPrfyw32jDTgC5ddWriDDBDv2kxNss5JjV3lnK5Y+3TC28n5hm2sHLSRhWMwmAVxmgf0viF9MENx790Iq3nRSD5ho/BcJKALn+mgsI/A876TLxnc2eyjtUMd+aWnSYgZ5NYJGliuUA+y4w/gnBdcRp/pGL66xffH1pBcJWIKwEMNFf9YQAXRy2lwEMJNDJLL+yumjWVlXclinuHwH4lSpOwtqb9DIZqOoyzIdPeGhFa8Ly1MQco0DICSB/efU4FlA+zNOfMgxa3Owtn6qq2qaCgqFp2XhNkDhOFSth7CV2QmABgauiURMuYeLUROKiQMgJIM9fXQ2gPFosieVXG4tmPauKv2WK53ICP6KKE3d7iZ3S4DlkmL8etfAJ5U1TcY9HE0hIBUJKAKc++sABQ9J63wEwPFpRMGN1s7c8F0TKlU5aprqfAkP55GG0Yh0Et0sS/03/4cdJ/RRzG1ICyKur+R6Ilct6DaYtAdc0eiuUK51sm1o0rpd7XhIQxmA+E+rfWT4hZPp10ewEk1DxajJxV2DwBMBME+rmbjQEnxB1thLb0yFGPzfp2qCqr5ZS999AUK5CpMojFHuWeBsG3xDLvvCh8NJjkl+BQRNAfmDu+czyqZhJwfTrpqLyH6v6e3eq9+Ae2bsJJA5QxYqmPQFzh5nDbzjU52uLph+NrRXoT4FBE8DE5dXzhMD0mMkn0cWGcVKz55q3VH1unVL4PQZF/dUlQp47QFyZs6gh8jMVETrWZlqB3QoMmADOq73X1TE0bTuEiOmZewl+bJW38nLVaVpVOSH9kOARr4B5jCqWnfZWw0cTvVOPXfz4FjtxNZZWIFwFBkwA+f7qmQzcHy6oLeMZFzQVVSi/emyZ4nYTELCFkw0gknh+R29mhd6Pb4OYGkJZgQETwER/1VMCFJfPaQy8MqpzxGm+khLltsgtpQWPg8QlymopAFh79gl8+6jFDT9TgNGmWgFbFdhvAshfXn0YC1h7zIWtHsMAY8K3mz0V94Vh0u/QLaXuE0FYRxi4crGqnwHsu4hxdaRVW6LIS0OnuAL7TQC5gepvEeOvcdbno+7etBPWXD5TuQFCS6n7HhCU66iHr4fsZmFcPurhQEP4tlG2mLMqvc/DrInKvRujwZTnTEjHkCxn7eWIhhCqmN1Bk2b131V4vwkgno//e8bLjD82F1V8T1WDbcWXHNRrpG0SwEGqWKHby24wXZmzpCEuaxAZ89YclQYxkYUcB2CMBI0i4EgJebAh4YIQe85/B9j8mGG8R0xbYMg3wHjFMI3VO64+5T+hx2zfyB1LC/OFyX+HSIkTnvYJty8Sy5eySlb0e4S/3wRw1iP3HdqdLt5NkJ10PSbkuNXeWRtUFdpS6rmOiP+sihOavewGGZNzFgX8oY1XH3Xw3A1ZO4fsLGBCATF9HYBNtRJ5O0ArGVhhDE0LtJaM/a8629AQgssKzzUlP25AZIRmoUf1p4DRmzZy+NTl2/b9t34TQFxX//thT6AVjd7yQtWp5eJiYws61gpDuZzZoFSY6apRSwIPDTpQdUBtrZG1c0whk1UMRRYAFO3uyT0E+Q9m44G2zu7HYvH60OornMTgRwRE3NajVKcp7vbE12VNbrg3pASQ669ZSuAr4056DwKSuXBVUeUKVU4tUwsvAtOTqjgD2RNw18jF9bdH08eBtatG9HalVzKb/wcyjommr/1im/J9GHQvyaF/Dc448eNocgguLbweTH+Kpo9kxmamFdklgS/8iH7hCWDCqjnp9A59JARlJ5IgBGzoPUKOWz1xlvKC1ebSwjpB5I1OfLxk5OKGqeEWZwyVyyG1612dO80bJPH3BZAQ25yllG2CxJ/Sh/X89pOSiTtCjSXccUGfpxrgqB1JD5ePk8ZLYGc2Dz+ISnyde/L+QgLIq6v+OggRtxqKpihE+F6jp+KPqj62TfOcIKX5KiCGqGLtY79aDms/59gHV+60GbcPLnPB2ukk6VcQfEQ08G3A/ICAW4JXjZtrx7HufflwQ8HQ9nZ6mkF5NnBNOQhiLnCVNDw+YALIDVT9lph+kJjqyE9N4ITV3lkfqfLbWur+HRO+r4qz215KtKcTn370koY37MLcjTPiwVeON4WsBjmjxgGb5jOCRHlwxqm2a9FR6xlpsrkWIrEPedl9D9iBx8R/yJ7csNc9/4UngFx/9WoCTrfDYZQw/tbkrfiWKvZ/ii8cYRhDNxFwiCqWZc9A+ajF9XPtwNoTI2vhmmtMk/8khHDZjR1lvA4CfS9YNq7Kbj/BWs9kEPvsxk12PGZel13SMH6/TwDnBP56YDenW7+uCbvaavVFTxc47QX3rFdUJ6xlirsSwBxVHDAty1kSmKyMsydA7fMZWd2Zc5hRZituzMH4obaO3krMmqhc+n1P6q2+ggcJYkbMw3GwQynBlD7kkOwrHv18wXavJ4D8uupJTHgs0WNk4Klmb8UFqjx59myxbUPTSwzaKyuGg8tSfmSwHHOM7wnbvo1nPrD+cJHWE2CQLf0XwoknKmNN8yVpSE9H2UTbaht++pD7QBoiXxcQh0WFc5KCMtMV2SWBR3eHt1cCyK2rvpsINzgjdr6iyVv5eSCRct421fs1yXJlpPZMXDFqUUNNpPb72mXNWzMaoCdZIMcuzATB2UqSL7JzXSDocxcD0PUUwpjgfdcB9koAeXXVzSBMDAMvfkOlfOu/6V0nvVl4fZcqiZZSz1JQ+Pse2ERjjq/+TLs++bkeXDMW4H/CSNJfNWvfgBAXtk0f/6rqnO2231Hr/ocgKD8N2sUn0XEI3OQqbsj/whPAlxvuGXqQmWHV4tt1QMQJF/GPmzyVv1aluqXYeywZ8nUAQ0PFklJKorTcUUv8L4VqM9A465efBf4N0OF24CUshinfJ6Jz7XoSCC71jpWmXCNE3E56JqzU/RGTQE92psyiwhV9P5yfPwHk11WfwYQXnBSNhAySGDK62T1zuyrvlimFvwDo5tBx5LycxSuuDn38/kf2vfOL3heT8LG/36BJokXKtDPaZ45VnjfLgd4gFN5dKIU8c8SVK17cOwH4q77LIOVNNuFRUR/NkA80e2ddo4r0QXGxq5M63oDAoJtsrC8RaWb6V2wp322t9ncNfyZpFvxCnAhiag6aWedi5rHKm6Y6Fk06pkf0bhIi9Ce4EGkm67Drs4rr+w7Fff4EkLe8eiEEvuG4iKVkMkRuo6ditSr3rVMKr2ZQKH0JFuYsrrfl81zWwrXznf+pLzLlGfxAe9mpysl711OA+x4gHvUeIos9nlZEeNA1ub6vk/b/EoC/2lqYGRtPYpH6JuLnGj2V50Rqv9uOAWopdjeRsf+FUOvdn5lPOs73+EZVf9YmH2ayffOQKq9Y2jMwo71s/HxVn53LCnO6e+lNvRYwuJLMvDa7pOHUzxOAdQDIeE+0O2oBcJ84iXhqo6dy8eDhDzxiyxT3WQQ8t99RNm36sbb39lDvGgfu8FOVeC97EzI4tBfjPp15mnKF5OBSz0NgnmYrwSQE61sI/O/2TKtKUN8TwMRAzcmCWXlnXXy1ktuMzvYxL5TcuNdpp0g4bZnifpiAfrsVE9MlI5cElI8Tu+avfcope/sj0TA8G3qyrWycctHW1lrPmUT8fHi+U3Q0iZOzJvvX9yWA/EDVFGZalARSzG7yVvxUNY53pkw6phvdGwTEPs1QefPIxQ3Hq3737zvVB8xT5ZlM9gxMay8br3wPfupzrzOAU5JJm6jEQlyaNbmhdlcC8FffycBtUXEUW9AOMjCmsbDibVW3LVM8swG+Y08c66jryMX1v1DB7jvP32m+kcBHelXCi9yWzW1tw3aOQclZSk9wQZ/bKvxqLQjqayAFGHdkldTf2ZcA8gLVD4P7f+R1oIoPN3krlL9mvOv1Du/OkBtJ4GhLg76NP0Pk0aMWPqG0n901f92tIL7LgbpGnTIBNwXLxv9WxVHbw0WHmek97yRIPUuVUKJt+1BWcf1Vu54A6qoamZKnyAITn93sqVR+F9wypXAagXbX9XsuZ3G90pcGq4xXV1f6lkSp5BPtOyxcfCnxUWZG2rEfloxVapS6o7bw74LownD9p9L43VuCdz0B+Ks/BHBw0gjAWNXkLc+zoypNy5SC5wFxJoh+lLMo8BsVjbIWrP0hA0oYKv4dYcv4btv08UqP8EFf4SyA/uaIeONH8sOs4vpDKb9hYTabnVGr4xav+Jh5ZnNR5YOq/reWenNNko0gcdKxi/yRlyavrTVcO7+8OW4FPFWFiJE9A5vbrxp3vEry7qsaRNwSI8qOddPJw7PozPo5p5hSrHNsFPsn/t7wzu7RK0u+o/Q4acFvneL+ieriX9b8tV4m1CWhzraHxBAXt5ed8ncV4E9rC14xSJysgpH0tiZOorxA1SVg2qtQYLIEzuBfNnsrf5II8bgWrHsEYOWW54kQS9Q5MB5umz5eaSE3uNT9ZzCuizpXBzsg5ospL1AzA8zKj8oJqYNEFwgnNhVVbI4nv8869nwQg6Yd8QzTNt9WmfGOjM5DVT4JBpcWloBpiW2kkhCICFdbTwA/AtOvkjC+vpCI5SONRbPi2uTEtWBNCaBvxnDuMQImBcvGR/zK1FHrOcokVt4PEg5np41l4MeU66/5I4G/6zTy4fAVwPkveisiLvsVjq/+xmYuXPMAMdlSO0CVi1PsJXBfR9n4b6vwDfrcH8Cmqs8qPBLVloG7Kc9fbX3nTuoDFKbktcd1HTDBV1JixmMyXAvWWivSNjXqjEcEsffJwBvtZePHqHjW+wEGVo+JFtBEf1VAgNwqQjvClumbTUXl6iXAwww2Y+Haow3GF7qyhgmTmsN7zEPbrjnd2qMS0RX0FdwNCIcUuY0oRCUjAuopd3n10yTwVSUkJxhL+aE5HCesvmhWTPc8ZM1bN4kFJ3yp9UScQgYK2svGR/yFSp8LGGRWGc/RRP+ctQJiXCLeALZzIr67yVN5o+24AwC6Fqy5DaA7Y+kzWXypng1o9RV6CORPFj3sjsPqFEQTAjWbDeZRdoMnKF6PlOKUVZOuVa7mE2p8rgVrFgKk9E07VF/JNo6Bue1l4yPuBty2tGgcW30E9dWvAgTeTHnL53wAIWzpj+cEnSW4fpW30hMrrsMXrH1WAGfHyl+S+XmqrWx8xDX/2xcVHSnTzHeSTBPbwpGQ71Oef84nQGp1WmVBBc3u8ojfLcOZgcwFa98i4NhwbPTYXQqYzBs6p596YqR6cG3xkDbqUG4cE6l/B9jtsJ4A2iBEpgPI2kZRsnzdlfXeuJXnz+61DXQ/QBkLXm41ILKi7ScZ8a3jwR0zxis9nX7qK+gwIDKSUR/VmCSwk/KWV+9ECtZTZ+C7zd4KpWOnoUyAa97LEkJ8oQ17KLZ6jOxqKzttmIoOwSUFn0Ck1hNuqHpZxUGtjUDW5piEbQceajDhjmOJT8gcckLTFTM+b5UcLsag4+esSncNT+8edJwe0L8CUnLbjNOU7s0dvoLtuoPwfuSFlNYrQMr+QhHRXxs95d+J2t+fTgDK0rZdNU6o1AbYscT9rgih25MyUQcCyL4E4J/TBYghDuSvTNlq8QUyTl3lKbetW+2+pFwL1rIy0dQF6GkrG690bwZ9BR8CInmqXdl4L5iQndYrgNUR2GUjrtOg/tnkrYha/TjXgrVWw5V9yos7TaL48JVSftIx47SDVLwHfe5Uv78Hkm8HTayb87EgoSSyygQlgi0xLmssqlgeDS6u+S9t1WXAIlNWgt/sKDv1hMisAa4tNtqoI+pfeiLlF287KekDayuwXiSBfLO988Cx60tKbF+wy5y/tpEIefGebCf6Z9N8pv3q08+NlHuwtuAQkLCOBOurHwUk8TbrFUAfVe0Th37U5C23vWKva966JRBcou/A8BUgYH6wbPyM8C13WQQfcZ8MEw5veRdp9CHYEf5DEwJV6w2mk0IYntRDJGTQkOKExkkV79sZqGvhmrvAdKudmCmDxXRb2/RxP4s03nZfQYGEaIjUPgXsXqP8QNWzzKT3qlvdfwhzV3kqIj580t8No8uBRf5nRJIuC84YF/HaTHCp55tgvi9yBkluaR0HzvNXW8clY3Y4JsEllQIy90XvrJfs4mm1ATcN+aZdeKmEYxKO6bxqfMR1/XRBkMHuFllHef6q+QCVDTY0df6dnm3ylttaIMX14MvbYYjDUkdD9UhJoiU4Y7zSMfVgbeETILpYnU1yIhBwP+XVVd8DgtVRVV+fKcDMpc1FlbV2CeJasNZqez3FLrxUwGHwA+1lp16jEuuOJZ73heBDVTCS2ZbAv7FeAawW2LOTOdCwYzNli9HdfuILJTcqtare7TdzwdrpBMwLm0cqGzCVtE0f54tUgo5lBUebUuhajAMIyKAfUa6/qoJAVZEKnax2TLi92VNhSxvv7Nr1B8mu3u0A0pNVL3vj4p3Duocd+tG1X7F28UV0BWs9pSBeHJFxihgx4VrKra+5lCSvSJGYQw9TynZDyDEveL9lS0WZrAUvNzBEQegEUnekJDzScdV4pWYuO3yevwhw9A56JcH0CCI3TQzUnCyY9WaJ/iZU4qGmSRVX2THXrvnrikFs27qCHZwSFYMYRcHp45WKeQZ9ng0AK/UVSFR9bONlNQed8Pc5I4yd4lPbQJMJSEomEmc1FlW8qByWdTR4qLFNfw0YVMl32oZuzIFCE5dPFl06Ki3NiGs/yEGjTIABLh4+vK9SzUT/nFahy1b1OyXE3NTorThD5Uz6bmBdInzwu56YfhScPk5pS7buBzC4zlZB0BHFKw7vSwC5/up1BJwyuFnKjpjR5K2Yrxp91rzXv2Ri5xYhRMr6c5IAABo/SURBVCofv96vjBL4dOjQnlGflExUat4SrHX/G4SIDxGpzrMj7JlezCoJnNmXAPL81da7abEjiMeBJEO+2zUkY/S6S6ZbZ/uVLtf8tT8D4RYlkGQ1Vtz7b8lidQXuIXOrgFAqJZasEu+OS0IuHlG8YmpfAsj3V9/JwG3JHrRSfISfN3kqlA/1HFi7akRPV/obAPQGlT0nRNJ7GRnG6A9LxrapzFOrz3MzgX+hgpEitr/IKq6/5bMngJppAFtdgvW1HwWklDvTpDzxxcu/tUVVpKwFa8sZqFbFSSZ7JlzdftV4pc1SzKC2JQUbYYiIi4gkk6YDxULE01yTGxb1JYAz/HNOlxCrUyX4iOOUWNo0qUL9VYmZMue9/G8yDFvPHEQcV7wNGf9qmz7+66o02nyeixn8hCpOStiTODlrsn99XwIY98T8zGE7O4O6fv3gU8+CvtbsLn968JEDj8iat2Y0C3o51esFMtBuIO3U1rKxyicmW2vd9UQoVJ2bZLeXkN3ZB3dm0vkrez9vWJG3vHojBEYne/DK8UmsaXr5nQmYPVuqYmUtWFfJ4DmqOE62J+Jrg1eder9qDMGl3rHSlK8IAd2EZRAxmXltdknDqdaw/yWAQPXDYExVnYhUsGdwZbO30pZ3eNf8tQ+BMC0VdNs3RtWSX3vi7VhauFgwlaaijuHGzEQLsicHpu+dAPxVNwL0+3DBUnE8Ax8II+OExsKrWpXjn7NquGuoeAaGcboyloMACLw6OLTjqyg5S/nEpVX7T5pyrf70F9oNQMAPXcX1v9srAeTWVX2NiFaGBqFHEeP3jUUVP7BDieELVh0hkG5tNx5pB54DMLZyb1p++8yx1glJ5avN5w4w4FYGShEABs7NLq5/Zq8EcPbyuVk96N2hFwJDvQtkN5CW1+S9dm2oFgONy1qwdgwD1uJisu8P+ICAc4Nl4zfaoZte+Q9Pxb4FwLbOETRz5c69EoD1f/Iem/MKDHFyeJCpO9qUtGlHescpbxZeb0sPetf8tSdDyn8k8YGhD1iKi9pnnLLOjruG/3VeWtvHmevAONEOvJTA+GwL8O5Y91oxzfVX/4UAfYY6jDuBmO5oLCq/MwyTAYdanwcBepIFcuzCTBCcrQRcbNcvvxVTcGnh9WD6U4LE5wgaDPwuu7j+h/0mgLxATTFYn1kPZyatHYKcjpNXF876Tzh2A43NfGD94cIw65g41y7MeOJYC34mer0dZRPfs4tH6yOXf4nMnZsAcaBdmKmAwyQuz57sf6zfBHDWI/cd2pueZmtjjJQQlXll80vvXmDH3oDP9Xpg87DM9B33EdPVTtaw71Pf0PZv2rHav6cOQZ/7XgDfdrI2ceHO8tCskhUf9psArP84sW7Oa4KEfqcKe3ai01rMKigqIf9iOKxeg7XDTxBfb8cmn32n4rPPfmsEhBH2NKWwgcny1QNKVux17P8Lu6byAzX3MrPOrGHfKLJbSuOMVZPKre29tl4HPPDyqN40Yw7Azqhxz/iXoLRKO7b39ifkjlr3PwThAltFTgEwIvqta3Lgpj1D/UICyKur8oBIqR5bCmi5nxDlm0PIzHvW8+1PoqFB5oK1U4nNXydsu3FJ77HBN6ue6htIu1Zf4SQCff4OGw2dkxZT4OtZV9b/a8AEcGbtHzJ6MrI+FkBG0goRzcAknsjpGuH2KdS0G5Be7fMZWV2Z15kSNwmBg6MZSqjYViUfwfT7jGHGH1XP8w/kk2uLh7RRx3oAXw6Vmx73mQJSBl2ffvAlmrW6Z8AEYP1jXl1VPYj0qaoI7x4m/l2zp/LzTy0Rwgxodkjtelfnzt5rmHADAcdGw0cImO8Q0z1pw7rnqJbxCsEXWmsLf0hESvUCQ/GTlGOYH8sqabh839j6PTmVW1f1bSKyVln1FaECDHy32VtxT4TmoZtZtQUWvnohyd6ZEvBGv94g75REDYbEg8FhGxtUqveGHiTQ9nDRYZxuWpWUssOx02M/U4AxK6uk/gsNgPpNAGfV1+T0SlaufJPS4kvJLKis2VsZu0pLu14PLjKBSwm4gGDP8W6rUacU/BSxWDGsZ8jjKh17Ir0n2pa6a5hxbaT2qWwnIWVab/oxmVPr3g3pCWDXa0B1MwgTU1k41dilRK9BmNxYVBFxj3sVDq77XzqE040JAjhFAmOsVwWT+UhiOlgImQWJIZ+d/eiRUrZB0MdkyveEYWxmpk3EeKXX4NUqLbpV+O+2bV9acFovY5U+7Rehmoyns0rqv9af9X6LJ+TX1fyAiX8boUtt9pkCfUnA4LJGT2Vi9qljJjt6HkRzwoO1hU+DSJdPi1zk72QV1/81rASQ+9j9xxD1tOjTgZGrvoelBKOyqahiri1oKQQSXFpYAqYlKRSyraFKSFMY5pFZVzz5QVgJoO81wF/9HICzbGWUwmAE3NXoKb8j0X9xE2WK+IHzhgUzMjeQkXQHo2ImMYOeyi4O7HfT1ID10/L8NdcB/OeYsU0NRz6jMzjjhZIblSvhJLtcQV/hrQDZ0qI92bXab3z7Wf3fPX7ABHBaw/2HpJs9bwNiSMoKGIXAGXgpTVLpC5PKlSvhRoFeQkBaHX4k8UYGMhOCkANJSGAnd+PIA75Rv9+dqYNWUM1bXu2DwGQHxp/QlCVkkEDfiulnwoRWZG9yrT73AgJsac3uoLBtpcrAwuzi+rKBQAdNALn1NZeS5BW2MtNgeyjAC4x0ccMLl5b/V8uyS4EdSwvzYdILusS34h0h+GtZVzYM2MNi0ASA2bNF3oSjrF7rqVKwUlH18M2tKsPEuKGpqGJR+NbJZWG192r3uV9gQn5yRRbraGhjVnHgK4N5HTwB7PoaMBvAHYOB6X9XVIDxOEnj+42XXfOaIpJjzdtqC8uYSLkVu2MFsIn4nqW/lV4BLOMz/fcdZSLNegpIt4mfhtmPAtZ3W5B4cKgpbn9u0rVf2LqZzMJtn39xZkaG8YaAODKZ44x2bFblX8E4es/KP/vzGdITgGWc56+29rSnZAebaE/YfvA7wJibZtDvn3eXt8SJQ0zdBn2euwBWbsEeU9IJ6Iwh52UXrwiplFzICSC3riqXiJoSMN6kpmRtJRbAEib+U3NRZXOyBtu5rDCnW9IGAQxL1hhjFpeBU7KuqH81FH8hJwALLD9Q9SwznR0KsB5jvwISch1BzE1Lp4XJ9tUg6HPXAlBvvW6/7M5CZPlEVsmKS0MlHV4CqKu6komWhgqux0VNgR4C/g3gMYHex17wfuudqHmKAXBwWeG5kGTFoy9FBQh0oas48M9QYcJKALs+CR7xGiDGhOpAj4uyAn11B8SrgugZQD6TZhpPR2vx8JzAXw/cKdPOIMJXBYkRjZ5y5SYyPHu2aD1p1SpBfFqUlUp6eMn08oiSQFhNZsNLALsWA622wvOSXk0nByjlh0y0ngivMtFrBvgdSca7ptH7TtbQ9z5cef7s3n7DY6Zz6u87oJONwwTR0SQpB6ATmHCiJIwzmEfttmPis5s9lc+rytTqKywnkC2t1lW5ON2eiKe5JjeEtZck7ARw3r9mp3W0HbUBwPFOFyxV+VsLixCykyA6AdkLiDSGzBASrpCOfxMWNXkqlL8IfbywIDst3dgkBCd7Q9So32qSsT77tdxxNHu2DMdZ2AnAAs+rq74WhJpwHOmxSaNABxkY01hY8bZqRK0+928JsKXFuioXx9szFWeVBMJen4soAUxYNScd24039nwkdLyAOoCQFGDC7c2eCuUjujtqi74M6lkv9EnTkHQfaBAzr80qbjiNCBwuWEQJoO8pQK8FhKu188ebsmX4iCFfWXn+zL7e8ipX0FewHBBFKhjadpcCzJiUXVJfF4keESeAvi8Cpx21GgKnRuJY2zhPAQKKG70VYT9m7htp2zL3hSzxd+cpkHiMCdzkKm6I+OBU5AnA2hhUN/diJvlE4smiGdmtAFsdkIsqz1fF5dpioxUdawVhrCqWtrcUoPOzigMrI9VCKQFYTnMDVU8S00WREtB2ia+AdUDJkOL0xkkV61TZBpcWfgdMf1HF0fbWsz8tyyoJKBXrUU4Aef654wH5EgChJyVpFfhbk7fiW6rRffqQ+0AjTW6CEF9SxUp1+75yXyxOOqDEb53SjfhSTgCW5zx/tVVzXPkGiTgKbRg1BVjiEynk6NXeWR+pOgn63FartP9TxdH2fQr8Iqu4/hZVLWxJANYW0W7T2AghDlElpO0TSwG7ehwGawtOkizWCoG0xIrQeWykxHtdNHz0oSW+NlX2tiQAi0S+v3omA/erEtL2iaOASfxaVua74/e7dTgMqsHagsdB4pIwTPTQ/ShAhDLX5PqFdghkWwIAM+UFap7VjUTsmJbEwCAWlzQWXfukKpsdtW63IARUcbS9tfAX3nHfwTSzLwFYpcPq55xiSrFalw4bTPbE/3cG1TV7yyepMuU5E9LbvnT4q2B7OhWr8nGyPQHthuCxGVc22FYhytYEYImb56+2iodaRUT15VgFZLdp4KTVhbP+oxpCW63nRib+vSqOtgcI+J6ruP6PdmphewLoOyfwDjUbgsbbSVRjxU4BCf7NKm/lj1Q9BmsLDgGJTQBGqGKlur214y9zfd6Z4Z72G0w32xOA5XDi8prTAG7SK76DyZ+A/y6xPR1i9HOTrg2qsgsuLZgDFpWqOKlub1X5NZgmukoaXrFbi6gkAItkvr/6TgZus5uwxouuAsw8s7mo8kFVL22PeMabpvmSgNAbxBTFtI5Mu4rro/IaFbUEsKtwyNHPAhzxQQVF3bR5mAoQc1Ojt+IMO9qXt9YW/ItInBcmBT38iwr83TW5/pJIjvqGImbUEoDlPDdw/3Fs9r4sBGWHQkaPiaMCUjKROKuxqOJFVRbBpYVXgnXxWFUdIeXHIk2eknnlE+8pY+0HIKoJwPKZ56+ZBrDVVERfCawAsVzYWDRrwE6yodDnhoKh7e30OoOODWW8HrN/BZjE5dmT/Y9FU6OoJwCL/MTl1fOEgFVMVF+JqUBbuhRj7Kgm3Orz3EzgXyRmmE5ixX/LKm6I+vmamCSA82rvdXVkDLEeLfUZ8ES8Bwm3NHkqlP9o25ddcoSUaW8AcCVimE7hxMzNWS7+KhWu6Io255gkgL5Xgfqq0TCpCaS/CUd7UsPBl8DmT43OE98svF75Zmv1FTxIEDPC8a/HfkGBD43etAnDpy7fFgttYpYArGDOCFQVSZMfC6n0dCyi1z6szeVXNHkrH1WVon2ZN7e3VzYKYW1Y01ckCliFVwTj4qySFU9FYh+JTcwnK99fcxfrDrCRzFU0bP7Z5K240A7gYK37ORDOsgMrVTGY+abskobfxjL+mCcAq5ho7oSjHyWwrggby5nex5f1awMyTl3lKQ+pi+xAVNtqC6cxkf7SozCfknjJiMkNUxQgIjKNfQIAMO6J+ZlDu7ueJiCsPmYRRaiN+lWAgXubvRXXqcrDfu/wYIfcSAJHq2KlrD3jOVd7+4U0c6VyufVwNYxLArBITnh8zhFGDxoBcUy4pPV4NQUky/+mDzFOsKPFeNDnmQ2wdQJUX5Ep8CYbQ87IvuLRjyMzV7OKWwKwaOcvrx5nCvmsgMhSC0Nbh6MAAdc1eivuDcemv7EdiyYd053WvdGAyFDFSkl7KT+WhnHmiMkB68RkXK64JoC+JLCrt4BVLSY9LgqkmlNTvprTfeCpvpISUzX0Hb6CRQIi5u+tqrwTwV5KdFGavCD7yhXPxZNP3BOAFXxuXVUJEVltjfXJsWjfDYwLmooqlD8ztS4rOJuksErA6StMBazuzGSI4mhv8w2FVkIkAItonr+mHGDdJz6UWYt0jMSjTZMqrojUfLcdMyjoczcRYaIqVqrZS0hpwJjuKg4kxFeThEkAu14Han7AxDH9DpoyN6BEFwgnNhVVKDWSsPRq9XlmElhXgI7g5mGiyuzJgYT5oUuoBLDrSUDXFIzgvhrUhMG/bPZW/mTQgYMM+HB5UdaQbvMNARyuipVq9tGo6aeqYcIlgL41gUD1bcS4UzU4bb9LAYZ8N7Ozd8zKku8oN5JoW+r5JTP/WGsbngIM3JJdXK984Co8r4OPTsgE0Pc64K+5mfWx0sFnMIQRxDS9sah8QQhDBxzy6TL3cdSL14TAUFWsVLIn4htdkxvuTsSYEzYBfPY68EMAv0lE4ZzCiYEXmz3lZ9lR5ivoK3gEEJc7JfZ487QW/IiMbybSO/++miR0AtiVBKq+CZC1aUV/Igz3jpaSpTDOWOUtbwrXdN/xwWXu8yGh/PlQlYdT7K1PfYagqxNltX9/uiV8Auh7HairupKZHoJ+9Az3/p/X5K24OlyjfcdzbbERRPtLRDROFSsV7Ps2+RBNzS4JKB+zjrZejkgAlgi5dVVfI9ByXVAktFtCQgZJDBnd7J65PTSL/Y8KLvV8E8z3qeKkhL2UHzMZl2WXBByxScoxCaDvSWB59bheoMEQOColbiaVIIl/3OSp/LUKhGX7yaOXHZDW27UJEAerYqWA/ZuSqDCee/vD1dhRCcAK7uzlc4/sEdKqlJobbrCpM16+2d554Nj1JSXdqjG3+tx/sL5fq+IkvT3jOe4Vl2VP83/kpFgdlwAscc+s/UOGzMh8gCFKnSR2rLgK4kkveirrVP211l46hsl4ReiDWgNKaRXzyB7OM2JRxFN1Tve1d2QC2B1E34YhU/5U1xj837RK8JOrvJWX2HGjtNa664lQaAdWMmJYVZWI6eZYl/GyU0tHJwBLiL5Co8zzAHGAncI4Eavv0xMb4xsvu+Y1Vf5ttYWXMtEKVZwktv8QLKfEsoBnNLR0fAKwRMmrqz6WCUtTvcQYAfc0eiu+q3qj8L/OS2v7OHMdGCeqYiWjvVW3P81MvzJWpbujqWFSJABLoC833DP0IDnsT2CaFU3BEhj7o+7etBPWXD7zU1WObbWe7zLxH1VxktOe/+bK5Buc+L7f33wkTQLYHVxeXfVUAPel2n4BJny72VOh/K2+9ZHLv0TmTuuz34HJ+QccYVTW930jrTwRinhEGEG/ZkmXAKwoJ9TNGSlA84goJdpTS8h1x3YeeLodZb6CPre17frbdt5kSYD1dyF6Z0SzS2+8NErKBNAn5uzZIv/0o29kMn8OiCHxEjgWfgVw/oveipWqvoKPuE+WplwjIAxVrGSwl5DdBhs3ZxYH7iYCJ0NM+8aQvAngs0it3YNS4IGkXSCUWNo0qaLYjptzR637H4JwgR1YTscgcBMY5a6ShlecHstA/JM+AVjBF9fWGluHtX6PiX8KYHiyTKiUcueQNOMrz7vLW1RjavUVTiJQVHvRq3KMhT0B7QBuzVyfew/Nni1j4TOePlIiAewWODdw/3GCzTkM2NIPL54TZ/km0M8aveW3qfLg2uIhbdSx3vqYoorlaHuWT6QZNCvjygblhOoUHVIqAfwvEVRfRdxXaOQIp0zUvjylxNss5JjV3lkdqjG0+jw3EVj54JAqj3jZS8h3DRg3JfrZ/Wjok5IJwBLyvNp7Xe0Z6T8hSTc6s84AfaPJW/6w6k3R9nDRYWz0bIJIve5MEtgpgD+0d/b84vDpT1qP/il3pWwC2D3TExrmHG9I8XswJjll9on4uUZP5Tl28G1b6q5hxrV2YDkKg2lZr9n7gwOnPr7FUbxtJpvyCeDz14L6mnNJ8i+BhO9xL4mQ1+ipWK16L7Qv857eK3ubBUTKlFuztvESiZuyigPKn01V9U8Ee50A9pmFvECN2zTlzw1B4xNhgr7Ige9v8lba8osd9LmfAWDLk0RiavU/VhJYQ0S3Z08O+BOdayz56QTQn9rMlOevmWIKvtVgOimWEzKQLym51QCNbpxU8b4qp+DSwhIwLVHFcYD9a2C6w1UcWJasm3lU5kAngIHUY6Z8f00RE90McL6K0HbYEtMPG4vKf6eKxbXFGUHZ8ToZyFHFSlR7yfSyIeRvM1/NW5IK3/MjnQedAEJULj8w93wJ82ZiuihEE3uHSbxhHiVPXj1xVo8qcNDntvYOJGXnJQYeF6DfuYoD/1TVKRXsdQIIc5bzH7v/JDbM6wCUAXCFaR75cCJPk6e8PnKAXZYdtZ6jJPFGBjJVsRLF3tqzT8AiwfT7ZN+6a7fmOgFEqGh+w8JsaXZeTRLfgcDoCGFCMiPQikZvuS2luVp97gUEXBWS44QfRBsJXMMs52WVrPgw4ekmIEGdAFQnxVowrK85RwIzYHKxEJStCrmPfY8JOW61d9YGVdwdywrOQK94Xgg4dt6tzTsELCXB1VlXNjytqkmq2zv2RkjEibOqFZsZ2ZdLyBkAX2DLsVriu5s8lTeqxssMal9a+CKD8lSxYm3fV3wTxr+JeYnZA98B36j/JNYcktWfTgBRmtnTGu4/JN2Uk8B8JXYdsU0P25WUH5rDccLqi2btCNt2H4O22sIyJpqvihMre6uxpmDxLAhLqMdY5ppWp/zpM1bcneRHJ4AYzNaEv88ZIbqElxhFLHEhCYRUbosIsxo9FVWqFLfPvzgzI8N4Q0AcqYoVVXspgyD6J0ArhGkEMqfWvRtVfxrcue+CTp27XbUJduQCdDETXyIh8/t/VZAvN61+byJsOJMeXOr+GRi3JKJmJstX04SxgolXuD7a/izNWq38mTMR40xUTvoJIM4zc/byuVm9kGewwNkEnM3AGX2fFwnnNnkqrK26Stcniy4dJdKM1wUwTAnIBmPrc51g4yUmfhYkniPZ+5xevbdBWAUInQAUxIuGqfWE8FbGJyfYsepv8Qv63LVWUaRocB0Is+/bPNPrEGKdYF4ngcastvZmmrlyZ6y5aH/7V0AngCS+O4LLCs+FpH9HM0QJ+b5gY7Mkc4uAeIuIX2UY61xfCm6k81f2RtO3xlZXQCcAdQ0TFiHoc1sLiOdLwCWADBNyCEGkAdLYfQTYWm1noMuA6JaSumDILgHqBqMLjE9A8mOC+AjgjyTExyD+yABtl7282SWGb6ESX2fCCqCJDarA/wMfiZ/uqTpmtwAAAABJRU5ErkJggg==",
        edge: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAgAElEQVR4XuzdeZhbZdk/8O/9nFk6k5Mu7Cig7GBpMoW6ga+AGwqCuFCETlJ2FGXxdccN19cVFVdUaCdJi85PEBQFESmKIkplkpQKiCy+LKIo0CaZdjo5z/27UsS3wEwny0lycvKd6/Lyj3me+7nvz3Po3Dk5i4A/FKAABShAAQp0nYB0XcUsmAIUoAAFKEABsAHgQUABClCAAhToQgE2AF246SyZAhSgAAUowAaAxwAFKEABClCgCwXYAHThprNkClCAAhSgABsAHgMUoAAFKECBLhRgA9CFm86SKUABClCAAmwAeAxQgAIUoAAFulCADUAXbjpLpgAFKEABCrAB4DFAAQpQgAIU6EIBNgBduOksmQIUoAAFKMAGgMcABShAAQpQoAsF2AB04aazZApQgAIUoAAbAB4DFKAABShAgS4UYAPQhZvOkilAAQp0pICqQEQ7MvcAJs0GIICbwpQoQAEKhEpAVdxlY9up07szHG8nQHY2Vna0otsJdA5U5sBgLjydY43MMUAEnu23gj4xpk+APgC9T5pYC4syjClbi0kAk8ZgHOqts+Ksc4D1au06a8wTBvo3ETxkLR6CMQ87fc5D6xfPfyxUtg0UwwagATxOpQAFKEABAKoysCL/XEdkD1XdXRS7C7C79bzdxeD5UGdnGPQEwcpaWe8Ye7eq3AWjdwG4Sz3njtJu//wTDj+8HIQcW5UDG4BWSXMdClCAAp0uMDrqRDfssyeMeQGgLwBkf/XKL1DH2Vcqn9o7+kc3wiILg9UKudU48ofCibE7O7qkGZJnAxDm3WVtFKAABeoVGL15YPbGSMxCFwJyoAgWKvQAQGbVG7Lz5ukjULlBjP5yUuwvNy458K+dV8P0GbMBCNNushYKUIAC9QiMjjqRiRccIFp+qYi8xPPkhUZ0Xxg49YQL6xwL/YsDuVIEl69fEvt9p1+QyAYgrEcq66IABSgwjcCcFfl5ar2DrZqXQvBSa+2LjDEuwWoQsPZBGLlSLH5QWDr0mxpmBmYoG4DAbAUToQAFKNAcgbnLxuZ6PeblgB6mkMMBGwOMac5q3RfVs/auHnEuVejyYjL+j04RYAPQKTvFPClAAQpUKzB688DgJvcwR/EqhVb+4Mf5B79avIbGTVrBT4yVi4rJ2K8aitSCyWwAWoDMJShAAQo0W8Bdnp2vPXitKI4A8F/ddbFes3Vrj6/A743o5wpL4lcG9VoBNgC17ytnUIACFGi7wI6pXKQEPUJFjhRrj4Axu7Q9KSbwLIHK1wPGmM+U7ollcIHYIBGxAQjSbjAXClCAAlsRGBjJPtcRHC2ixyjwCsD0E6xTBDSngveVhoeuC0rGbACCshPMgwIUoMAUApFMfoGovgmedwwc50AidbqA/kKt857S0gX5dlfCBqDdO8D1KUABCjxDILJibEg88xYVHCfAPgQKmYBFWQ2+XOovfQyLD97QrurYALRLnutSgAIU2EJgMJ2rPG3vLfDwFjHYmzjhF6g8WMgYnFFcMrSqHdWyAWiHOtekAAUoACA6kt1HxSyxYk80kL2I0q0C+p1i//h5rT4bwAagW4831k0BCrRFILJyzY7w7FsNMKzAorYkwUWDKHA71CwuJhfc0ark2AC0SprrUIACXStQuWWvCH2TiBmG1VfyGftdeyhstXAFShC8ozQcH2mFEBuAVihzDQpQoCsFopmxQ6yaky3sYgcm2pUILLp2AcG3i313vROLF3u1T65+BhuA6q04kgIUoMCMAoPp1Ts70rO07OlJjjH7zjiBAygwhYAAP5vV33P8o4vnF5sFxAagWbKMSwEKdI/AqlU90YfmHQ2V09TiCJ7i756tb3KlY7bHe/34CQc+3Ix12AA0Q5UxKUCBrhAYuGzNrk5ZT4fVU2HwnK4omkW2WuB/HSOHr1sSu9fvhdkA+C3KeBSgQLgFLlAT3St3pLVypihex0/74d7ugFT3v47isHXJ+H1+5sMGwE9NxqIABUIr4KZyOwByBkRPB7BbaAtlYYEUEIu/OtYe9sTJC+/3K0E2AH5JMg4FKBBKgcHUmkWOseeoZ4+HMX2hLJJFdYRApQkoO3jZhuH4g34kzAbAD0XGoAAFwiVw8ereyGDvW0RwNhQvDVdxrKazBTQ30N/7Mj/uDmAD0NlHArOnAAV8FHAvvW179Jq3wcrbeFGfj7AM5auAqvy0NOvONzT6nAA2AL5uC4NRgAKdKBBdmd9Py/rfEE0AMqsTa2DOXSag8rViMnZOI1WzAWhEj3MpQIGOFnBT+UMV+h5RexSM4b+HHb2b3Ze8AKcXEvHv1Vs5D/h65TiPAhToTIHRUcfduO9xIng3X8bTmVvIrJ8S0I1qnReXli7I12PCBqAeNc6hAAU6T2D05gF30+BpCvlvUTy/8wpgxhR4toACfx7Y1L/on6fuV6jVhw1ArWIcTwEKdJTAvNHVc8oTve9Q4FwAO3RU8kyWAlUIKHBJKRE/rYqhTxvCBqBWMY6nAAWmF1h236zBnn/N68FAxKrtVZE+Ve11BH2Kcp+ip9fZ/P9Oryp6AXVgVAHxxJNJz8EmI3ajlM1GCyn1iC1Y7VtfGFjzRK1XPFce3KMG56mHs4zBHG4bBcIsoMDrSon4tbXUyAagFi2OpUA3CaiKm85vbwW7OFZ2VcEu//4EPU8E86xinoqdB8g8A50HYG4zr6D3YAs91jwGg0cB+6iFPAKRR0TlYQEe9AwecGTTXycnZw32mPJ7YaXyfP6Bbtoy1trVAg/1lO0BT5y88IlqFdgAVCvFcRQIm4CqzF2efd5kj9lPVPZUsbuKVv7Q211EsQsEzwVMf9jKZj2BEpiEZx+zcP4lKP9LRB6HmMrrb0ub/6d2HMbxALWAelCj2Hw2yfYZoE9FBuDZOWIwV8XMVQ/bKezOxhg3UFW2KhnRbxSHh95Z7XJsAKqV4jgKdKjAjqlcpCDYV4B9RWU/KPaDsfvCyj78hNyhm9opaXv27+gx90L1XgjuEyv3e0YeFk8eMr0TDxdOXPTPZpSy/ehad2Jy086eyu4C2UtU97Iqe4sgFur3OFh42mMXlZYszFbjygagGiWOoUCHCERXrt7OlnsOEiOLoHKQWD1QYXfjPe4dsoEdmmblGfXWIA+VtRC9Q8XeMTgxcGc9V6Y3m2DOivw8z0NMRF+k0IMt5BADbN/sdVsV3wK/HU/EX1bNemwAqlHiGAoEUOCZf+wBPSjUn24CuAddl5K16onc1SPyBxVdDTG5nk1evpbvnYNo9u8nQb5GBEcocBiAwSDmWUNObykm4pfPNJ4NwExC/D0FAiIwcNmaXY3nHSqeHqowh4rB3gFJjWmEVMBarHOMvRkwv7GC3/f1Ta5+fPGidSEt98mylt03K2oKR6ixx1lrjjZGZ3davZ7qnRtm/fmAme6cYQPQaTvLfLtGYE4qt7uFHGqNPRQqhwqwe9cUz0LbImAt/gljbzTq3KgqN5XuO+B2XCC2LckEYdGL7u5355XeAJhTAe9VgDFBSKuaHET01MLw0KVbG8sGoBpJjqFACwQqD6yZnOg5QiBHqnqvgDi7tmBZLtHdAuMC3Gihv4TRG0onDuUgot1NMnX1s0Zu380x5bMUcqbZfMtrsH8UuK/Uf9feWzsLwAYg2HvI7EIu4C7PzhdjjrLiHSXWHAyDnpCXzPLaLSBYKyo/t5BrS4/P+jXO2Xui3Sl10vqVOww2bCyfArXvhTGVZ2ME90dxQjEZ//50CbIBCO7WMbMwCozePDC40T0cokc5FkepwfPCWCZrCpCAtZtg5FeA+XHZlH+yccmBfw1Qdp2bSuXrgW1KZ0BxPiA7BbIQz7uteNKBlYuDp/xhAxDIXWNSoRJYdt8s11l3JCCLVfB6ASKhqo/FBE6g8tREx+JqGLmyTzZe+9jwS9YHLsmwJHTx6kF3oO/9UH1vMJ+rYQ8vJhbeOBU3G4CwHISsI1gCo2v7ohvLR6jo8R70GAcmGqwEmU3YBKy1jzvG/BiKywtPDF7HU/ut3eFZK257nlHnQqN4U2tXnmE1xQ+Kyfhb2QAEaleYTOgEVq3qiTww75UQHK+QN3bChUKh24MuK8haWzRGrjLQy9aPe9fhzEWTXUYQuHLdTO4tUHwjMG+erHwF5OkuxVMOfPSZWDwDELjDhwl1moCbue0Foj2netBEmJ4o1mn70E35Vq7wFtEPFvvGf4zFB2/opto7odbKQ7o8r/fbBnhzEPIV4H2FRPwLbACCsBvMoeMFKlcCb9xYPl5VT4ORl3R8QSyg4wQU+LNRuUShy4vJ+D86roAuSNhN598JeF9s/0u1bL6YWBhnA9AFBx1LbJ5ANL3mYKt6qqq3uGvfONY8XkauT2DSCn4i0ItLS+K/4H389SE2a9bgivxBxiv/qO3P9RBvfnH4wD9tWSe/AmjWrjNuaAS2ydwyewIDp6jiDAPsH5rCWEjoBNTibjj4Zu+kXd7pz+cP0+ZElq3dCU75KhG8qG11iX6qODz0ETYAbdsBLtxJAnOWr9nT67HneGpP5lX8nbRzzFWBkkBXQOVrxWT8dooEQGD05gF3wl0B6Bvbkc3m9wMkh572AYZnANqxE1wz0AJueuwwWLwLBq/vpGd/BxqVybVRQK5TsV8qDQ9d18YkuHRFYHTUiU7se6kCyXaAOEb2XLckdu9Ta7MBaMcucM3gCWy+b987UUXPBTAUvASZEQUaFrhdIBcW+p0VWDx/U8PRGKA+AVUZzOS/YYC31xeggVmi5xSHh77GBqABQ04Nj8B2l9wZnejf+A4t63lwzI7hqYyVUGBagYdU5UulDZsuxpmLxunUBgFViazIXSoqJ7V0dcHPi8Px17IBaKk6FwuawNxlY3PLvXKOtXquEbNN0PJjPhRotkDl1b/G6EU9Zf0aLxhstvYU8UdHncGJfX/Q4mcFjBfHJ+c+9cAofgXQhn3nku0TiI7csa06E+dZT842BnPalwlXpkAwBKyV9caxFzliLly3JPZ4MLLqkixG1/YNTpRvMMAhrarYCF66fjh+S2U9NgCtUuc6bRVwU7kd1Oi71dOzeP9+W7eCiwdUwFqsMyJf7fG8L/OMQOs2yb30tu21z/mDKJ7filUF8oFCIvY5NgCt0OYabRWYPbp2G91YPl9l8wU3g21NhotToAMELPCEgV440N/75UcXzy92QModn6Kbyh1g1f6uFR9OVHF1KRk/mg1Axx82LGBagdGbB6KbBs/1PPkAT/XzOKFAXQL/QOXhMX29F/Ougbr8aprkZrLHQ+X7NU2qZ7CVvxWXxp7DBqAePM4JtsAFaqJ7rlmq1vsEjNkl2MkyOwoEX6Dy4iGIfrS0JL6Cjxlu7n65I2NfgTGVW5Gb+mMx+ZzxxKK/8RqApjIzeCsFZqfHjrIwnwVwQCvX5VoU6AoBz7sNjry7mFh4Y1fU244iR9f2uRObbgVMrJnLi+jRheGhq9kANFOZsVsiMJgZe6GxzuchelhLFuQiFOhmAcFVRux71y9ZeHc3MzSrdnd5dj4crAZkVrPWgODDxeH4p9kANE2YgZst8OTVs+bz4ulSGMNjudngjE+B/xOYFOjXe/rLH3988aJ1hPFXIJrKfVAFn/E36v9FE0imkIgl+I9ms4QZt3kCo6OOO7Hf2y30kwaY27yFGJkCFNiqgGf/rj3m/aUlsRSvD/DxWFm1qsd9cO4fm/VVgACrC4n4C9kA+LhnDNV8gWh6zcEK+w0+r7/51lyBAtUKWOjNsHjn+NKhsWrncNzWBaIj+Zeq0Zub4eTBFjYkFs5mA9AMXcb0XaDyIB8RfF6tTfJ0v++8DEgBHwSshTrfmDXZ96F/nrpfwYeAXR/CTeVWQHBiMyDEmdyeDUAzZBnTP4EL1Lh7rjmLp/v9I2UkCjRZ4CGonlNMDl3R5HVCH34gk9vFUb27GRcEWqsHsgEI/SHUuQVGV+b3U6uXQvHSzq2CmVOgSwWs/bHX1/PODScseKBLBXwpO5rOXqiQd/kSbIsgYuVYNgB+qzJe4wKjo050477vU7EfA0x/4wEZgQIUaIdA5btmB+b9xeHYt3mRYH07sPlup17nPgEi9UWYbpaczQbAX1FGa1AgkskvMGqXKeSgBkNxOgUoEBQBxSrHkdPWLYndG5SUOimPppwFEP0UG4BOOgrCnOvFq3vdwd7zAXwIQG+YS2VtFOhSgXEFzi8Nxy7i2YDajoCBy9bs6pTtPX7+22iBb7EBqG0fOLoJAoPp3IEGdlmz7nltQsoMSQEK1CugcmNZzdKNSw/433pDdOM8N53NALLEt9qtjLIB8E2TgWoWqLy4Z4/8+1XwcT8725rz4AQKUKClAtbKenH0nNJwfKSlC3fwYv9+BspvfSvB6i/ZAPimyUC1CAyMZJ/rGEkBeEUt8ziWAhQIj4AVXOF4fWcUlu7/r/BU1bxK3PRYzq8zpaJyKxuA5u0VI08jEE3nj/Xgfc/AbEskClCgywUsHkaPDheXDK3qcokZy49kcueJ4sszDqxuwO1sAKqD4ig/BEZvHnAn3C8DeqYf4RiDAhQIi4C1KuZzpec+9lEcfng5LFX5XUdk5ZodZdI+BAOn4dhq72UD0LAiA1QjEEnfHld4lxlg/2rGcwwFKNCFAlZv6bF6whMnL7y/C6uvquRoOneNAq+tavBWB+kjbAAaV2SEGQTcTO4sqL2QD/XhoUIBCswkYIEnHGBpIRH/8Uxju/H30Uz+dFX9TqO1W9h/sQFoVJHzpxcYvXkguilysSoSZKIABShQtYC1qsZ8sbTLY+fzK4Gnq23+GsArPwwYU7XnFAPZADSix7lbFZizIr+HZ/VyvraXBwoFKFCvgHreTdqPt46fcODD9cYI4zx3JPs7GHlJI7VZtY/xDEAjgpw7pcBgJv86eN4KY8w8ElGAAhRoSMCzfxeRtxSWDv2moTghmuym858A9CONlGStfZwNQCOCnPt0AVVxV+Q+AtXKS3waOj1FWgpQgAJbCExC5V3FZOwbVAGimbFDVE1DDZG1+CcbAB5NvgjMXTY2d9IxaRG83peADEIBClDgGQIKXVZ6PPJ2nLP3RFfjVN6dMqt3HQwGGnB4iA1AA3qc+qRAdCS7j4VcLQZ704QCFKBAMwVU8QeVyWPHE4v+1sx1gh47ks7dKMCh9eZpYe9hA1CvHudtFnBT+UMtvCuMmG1IQgEKUKAlAtY+aCHHjC8dGmvJegFcxB0Z+zSMqbxBta4f68mf2ADURcdJmz/5p/InqWy+H5Wv7+UhQQEKtFpgHKqJYnLoilYvHIT1opnsG1Wl7toF+kc2AEHYyU7LQVUiK/KfFsUHOy115ksBCoRIoPIEYTEfKiTj/xOiqqoqZdaK257XY536n5jItwFW5cxBWwosu2+W27s+BcVxhKEABSgQCAHFd4u7PnZWtz00aDA19q96v361wOU8AxCIo7czkqg8gQqevUqAF3dGxsySAhToFgGBvWZWf9/iRxfPL3ZLzYPp7G8N5OC66rX2e2wA6pLrvkmz02v38qT8C1E8v/uqZ8UUoECHCIxZTB7VLXcIRNK5yh/xU+vZGwG+yAagHrkum1N5k594kz+HY3bsstJZLgUo0GECKrjfEfua9UsW3t1hqdecbiSde48AX6h5IgAB3scGoB65LpoTHcm+zINcbQzmdFHZLJUCFOhsgX9Y4HXjifhtnV3G1rN3M7m3QPH/6qlRVZNsAOqR65I5g6n8kUb1hw0+bapLtFgmBSgQJAFrZb3psccWlwytClJefuYymBl7oVHzh3piKsxr2ADUI9cFcyKZ/Imiupz3+HfBZrNECoRWwE4InLcWErErw1jik68Gto/UU5uKxNgA1CMX8jluKv8OqPc1GMPjI+R7zfIoEHoBizIEiWIy/v3Q1XqBGnf3/CYYOLXW5hjZhv/A16oW8vHRdO58BT4d8jJZHgUo0FUC1gqc0wqJ2LKwle2mc38HsEMtdXmwhQ2JhbPZANSiFvKxbir/YYh+MuRlsjwKUKAbBaxVOOadxeH4N8NUvpvOrQFwQI013V5MxBewAahRLazD+ck/rDvLuihAgacJKM4tJuMXhUVlMJ27yQAvq6UeVVxdSsaPZgNQi1pIx0Yz2Q+oStc9Szuk28myKECBmQREzykOD31tpmGd8PtoOvdTBY6sLVf9ejExdDYbgNrUQjc6ms6/X6GfDV1hLIgCFKDAVgXk7GIi9vVOR3JHxlbCmBNqquPfDRAbgJrUwjU4ms69V4HPh6sqVkMBClCgSgGVdxaTsW9UOTqQwyKZ7DJROamW5FT0iNLw0HVsAGpRC9HYSCb7blH5YohKYikUoAAFahOovE7YkdMKw0OX1jYxOKPddP7bgJ5ZS0Y9Zbv7EycvvJ8NQC1qIRnrZnJnQdHRXW9ItoJlUIACbRewFiInFoeHftD2VOpIwE3lL4Lo2dVP1Y3Fe+IRXCCWDUD1aqEY6aaziwG9DDAmFAWxCApQgAKNC0yK4s2FZPwnjYdqbQQ3k/sqFOdUv6rmiomhocp4NgDVq3X8yMhI/lUC76cwpq/ji2EBFKAABXwVsBNQc2QxGb/B17BNDlbrGQARpAvD8SQbgCZvTJDCD6bWLIKWVxlj3CDlxVwoQAEKBEWg8oQ8gTmsk94i6KazXwPkndUaquh7SsNDX2IDUK1Yh4+LpnP7eha/MQbbdXgpTJ8CFKBAswX+YdBzyPrE/L80eyE/4td6EWDlLYClxIJfsAHwQz/gMQZGss/tgfxWDZ4X8FSZHgUoQIFgCKi9V72+Q0onz6/rTXutLCKazi1XYGm1a6pjdiqduKDy/gBeA1AtWieOm7MiP89TvQmK+Z2YP3OmAAUo0EaB7EB/z389unh+sY05zLi0O5L/AYwunnHgkwMeKibiuzw1lhcBVqnWccNG1/ZFJjb9QmBe3nG5M2EKUIACARAQ2GsK/XcfjcWLvQCkM2UKkXTuxwIcXV1+emUxMfRGNgDVaXXsqHqeDtWxxTJxClCAAk0TkIuLidjbmha+wcCR9Nivqv2gJ8CHCon4Z9gANIge5OnRVP59Kvq5IOfI3ChAAQp0ioCovL+QjAXyseluOpsFJF6N5ZYXAFbG8yuAatQ6aEw0nT9W4V3OB/100KYxVQpQINgC1iqMOa6YiF8etESjI7n7q7rI21p1epxt1y2JPc4zAEHbRR/yGRzJLhQjNwkQ8SFc2ELcbq3sZozODlthrIcCFGiJwLgae0hpycJsS1archE3nSsBGJxxuGBtcTh+wJbjeAZgRrXOGDCYXr2zQe+tAJ7bGRm3Kkt9RAUp8UwCRndu1apchwIUCKGAeg9oT+8Ln7qNrt0V7pjKRUqCKu9S0O8UE0NPe2kQG4B276Af64/ePBCdiPxagUV+hAtFjM2n7JzvKPRmAN/kWZFQ7CqLoED7BQS/Kz42eDjO2Xui3cnMXTb2/HKPua+aPFQ1WUoOpXkGoBqtDhrjjoythDEndFDKTU3VevInx5HTLewLBfZCXg/RVG4Gp0DXCajo8tLw0MntLjyaGTtE1fymmjwcI3uuWxK7lw1ANVodMsbNZM+GykUdkm5z07QoA/bzxY3ep92Bvs/W9orM5qbG6BSgQOgEziom4t9qZ1VuJns8VL5fRQ5PewDQU+P5FUAVckEdMjuTe4lV/BpAb1BzbGFet1sjJ0U9vbMIfF8Er2/h2lyKAhToPoFJsXJoYWnsd+0qPZLJvltUvjjT+gLJFBKxxDPHsQGYSS6gv3cvvW17OHIbjPnPYx0Dmmpz06p86nf0s8W+3k8OTmzY1njmajjOgc1dlNEpQAEKALB4WG3PQe16Z4CbyX0VinNm2gsRPbUwPHQpG4CZpDrh96Ojjjux73UAXtEJ6TYvR5u3MCdXXt0ZyeQXiC3/FOLs2rz1GJkCFKDA0wXU824qDf7l8HY8LjiSyl8tokfNtCdl4z1/45ID/8oGYCapDvh9JJP7jCg+2AGpNilFa1Wdz5dmOR/D4vmbIuk1r1arP+Q9/k3iZlgKUGCrAqry2VIy1vJ/kwfTuT8ZYP+tJafAfaVEfI+pxvArgA47sKOp3NGq9ioY0517p/ZeMUgWhhf+trJ10XTuNLX4Fgx6OmwrmS4FKBAWAWvVOs5R48Oxa1pWkqq4qXwJBgNbX/PZ9/8/Nb47/4i0bIf8XWhOKrf7pOA2A8z1N3KHRLP2ewMDfe/a/HpOVYmk13xGRD/QIdkzTQpQIMQCFvZfKmZow3D8wVaUOWvFbc/rsc79M60lom8qDA/9iGcAZpIK8u9HR53BiX1+bSAHBznNpuTm2b+LMacXkvGfbI5/0d397tzxEQiOb8p6DEoBClCgDgEL/Ha8/65DW3E9QCSVPUJErp0hzclZm/q3/eep+xXYANSxoUGZ4mayH4XKx4OST+vy0Csxac8onnLgo5U1oyN3bOuZTVcZ4JDW5cCVKEABClQpoPKJYjL2sSpH1z0sks6dK8BXthZAgV+VEvHDphvDrwDq5m/dxM33+3u4qcu+5x4X4NxCIv69p6Rnp9fu5dnyz8Rg79bpcyUKUIACNQhYeAI9rLB0qKon9NUQ+WlD3XT2YkDO2Np8Ef1gYXjos2wA6lVu87ztR9e6pYlNWQOzZ5tTaeXyYwKcUEjE73pq0Wh6zcGetVcZg+1amQjXogAFKFCrgFj8tWdgMv744kXrap1b7fhIOneLAC/e6njFgmIyfjsbgGpVAzYukskuE5WTApZWc9KxVkXMhYVZPedXbu97ahE3lT8OYlOAzGrOwozaGgHdaKElY80ExG60YiZUVYxIv1j0W7GzjMKFMX2tyYerUKCpAt8vJuLNeUfLBWrcPfOV7/Wnfw2w2nuLyYVb/eDIrwCauv+NBX/yD5+ONhalU2Zvfm3v0tLwUOUBR//5iaZz71VrP9e1tz12yvZV8rT2QUDugjF/UehfDOQvIvqIiPyjd2Pfo9NdiPTMEueNrp7jTU79CGMAACAASURBVDo7qGIHhdlZoHtZa/aGeHsJzH4AdugkFubaxQKKE4rJeDXP6q8JKTqS3UeN/OcM6ZSTFV8pJuPv2lpgNgA1sbdu8EAmt4t4Nm+Mmde6VduzkiqulrJ3ylMX+m3OotLh7rHmK3yhT3v2ZKZVrdrHjDE3AbhVFX80zuTqwomL/jnTPD9+PzCSfW6PkYNU5SARfZFn7cuMMa4fsRmDAn4KVP47gXgHjCcW/c3PuJF07gQBVm41ptFXFJcMrWID4Kd8i2K56ex1gLy6Rcu1aRk7AZH3FoeHvva0BEbX9rkbyyne5tembZlyWTshMKss8EsFbhi/J5bFBWIDkeGqVT3RB7d7kaq+QsV7tVhzCAycQOTGJLpeQGCvKSQWHuknRDSV+6IK3j1dTGvt4+O7PbEDDj+8zAbAT/kWxIqm8ycr9FkvbmjB0i1bQi3uVujx40uHxrZcdLtL7oxu7Nn4Ixh5ZcuS4UJT/8m3tmjg/AyOvWLWxKyfVXsKv92c0ZWrt4PtOcZaeaOIfTVg+tudE9fvbgEROaMwHPuuXwqRdO5GAQ6dLp4AqUIivnSm9fgVwExCLf59ZNnandRs+lO4T/3rioH+3rdtfqLfFj9uKrcDrHcN3+bX4oNuy+WsVUBuUAfLS6XyFThz0Xgbs2l46bnLxuaWHXmripw04xXTDa/GABSYWsCDLaCnZ/6GExY80LDRBWoG9sw+4cBEp20ARI8uDA9dPdNabABmEmrx7wczucuN4k0tXrZVy40L5J2FRGzZMxecsyK/x6S1PzeQvVqVDNd5msA/oPLtsppLNi494H/DaOOm1uwP2DOsyil8cVQYdzjYNfn1VUBkZE1MjM1NV621sn58wNl+yzuptnKmINho3ZSdm8q+CSKXh7Jm9dYAvccXkwvueGZ9kRVjQzKJa+GYHUNZe5CLUm+NGPOVwmORFThn74kgp+pXbttkbpk9gYFTxNqzIWbKt6T5tRbjUGBLAVVNlpJD6UZU3FT2bRD51vQxdEUxMTRczRo8A1CNUgvGbD5V2SN3ALJTC5Zr8RL6nWL/+HlYfPCGZy7srsgebsvmSn4ia+2WqOIPCvn4eDL2s9auHKDVLlAT2TN/vAIfmemVqgHKmql0sEDlhUFGzQuKyfg/6i0jms6NKJCc/lO9vLGQiF1ZTXw2ANUotWBMJJ29VCAnt2Cpli1hKxeRiTl9uvtgn3zOgZfmRVot2xLwD/8U1mwEWncAciVA8YNiMv7Weiki6dy9Auw+1XxrsW583eCO1Z7NYwNQ7y74OC8ykn+VGP2FjyHbH6pyalmc47Z8nO+WSbmZ3FlQ+zXAmPYnG/4MFLhPVN5fTMb+X/irrbPC0VHHndjnNEA+wYcN1WnIaVUJqOprS8mhn1c1eItBlefDOIppLyRU6LJSYuiUauOyAahWqlnjLrq7f3Be6fYwXfymostLfeNnTXXKv8LoZrKfhMqHm0XKuP8nUPlE4Bh8uvD44EXVfirodr/KragbejedL2LP4+Onu/1oaE79Fvae8fLcA3Dy7htrWSGSzi8RaGa6OWrl1aWlseurjckGoFqpJo1zM7kPQfGpJoVvbViLDWLkHVNd5b85kconrI37fguC01ubWJeupviBej3nlU6e/0iXCjRU9pzla/b0euy3oXhVQ4E4mQJTCYh+qjg89JFacNxU7jvT//upjxT7/7wLFi/2qo3JBqBaqSaMG7hsza5O2d651Rc6NGHdZoRU4M8QeUtpOLZmyvija/sGN5UvC/Etjs1grStm5U1knshZXX2BX11yU0+KpLIJVbmQb6L0EZWhKu/O2CTGxKb7mnQqoq19/w/BRcXh+Lm10LIBqEXL57FuJjcKxXE+h219OMUPZk32nz7tk+IuXj3oDvb9CNDXtD657lrRAt+KKt7792S81F2VN7fa6Mgd23pm47cNzFuauxKjd5eAXFdMxI6opubKs1I8q/dMN9YaWTS+JPbHamI9NYYNQC1aPo51U7lXQPBLH0O2I9QkIP9dTMS+Pt3im++5LvddLY7zX+1IsGvW9OzfrXFO4af+5u54JJ1LqpWv8bbV5jp3U3SxcmxhaeyqmWp209kzAfn2NONuLybiC2aK8czfswGoVcyP8atW9Qz+dduccfQFfoRrSwxrHzSOOW79cPyW6davfGqC2XStAovakmO3LGrtj6XXO7VVb+PrFtbp6py7bOz5m3pMxgCHdLsF6/dBQO29xSfcF8x0ke5gOvdDA7x5qhUVeG8pEf9irdmwAahVzIfxkVT+XSJ6oQ+h2hXiBkx6b33a63ufkUnlnQbSW74eivntSjL061p4YvDBQiL+hdDXGrQCK28gfGCbz27tjWxBS5n5BFdAgA8VEvHPTJth5UPj/27zT2Mw51ljLDy1PbvUc7EvG4AWHxORlWt21En9c0eeQrRWVZzPlWbd+eGtXWk6a8VtzzPWXB+mWxtbfJhUsZw+AmOOLy6J/bqKwRzSJAE3nXuztXJpR/733CQThq1dQIGS9nj7jJ9w4MNTzXZX5F8Oq7+a6ncC/KyQiB9V+6oAG4B61BqYs/XbOBoI3OSpm+8nhyyd6buq6Eh2HxV7PcTZtckpdW34zU/zk8ljxxOL/ta1CAEqvHLMWyM/EWCfAKXFVDpMQFUuLSVjp06VdiSV/x8R/cCUJam+uZgcuqKectkA1KNW55zoyvx+Oqm3w8CpM0R7pqm3xjjy5vVLFt69tQQ2v6VKy9fxpT5N3CYro0UbXVrrA0SamBFDA5izIj/P83AFRA8jCAXqE7BWxRma6lZqN52r3F59wLPievbvxQlvV5y5aLKeNdkA1KNW55zOfNWvriiOl8+Y6b3ws1O5F5fVXmOMmVcnD6fNKCCfLA4v+BhEdMahHNB6gYtX90YGe78lwJSf4lqfEFfsPIFn3xY4J5Xb3RPcO1UtCv1cKTE09ZmBKopnA1AFkh9DKn8grWDaK+b9WMPXGBZlNXhPKRH/6kxx3fTYYdbiJ8YYd6ax/H0dApWL/QRnFpLxS+qYzSktFnAz2Y9C5eMtXpbLhUTgme8JiKRz5wrwlWeVZ60a07fP+sT8v9RbOhuAeuVqnBdJ524U4NAap7Vr+D+gsriYjE150cmWSQ2m8kca1R/CYKBdyYZ7XTsBlRPr/Y4v3DbBrc5N5d8B9b4GY/hvbHC3KaiZZYvDsQOfOtPnjmSvh5FXPitZxapiMv6KRorgwdmIXpVzBzP51xnVjnjvugCryz3mTRtOWDDtG6eeKrtyBTSAywD0VknBYTUIeLAFR82xxWT8hhqmcWhABCLp3AkCjPC/j4BsSCelIfrW4vDQD2aPrt3Gbij/HQY9z0r/32MaKYsNQCN61cy9QI27Z3YMMLFqhrdzzOZXSZbnnFXNBWZuOrsYVlZMeWC2s4iQrF35499jnSMKS2O/C0lJXVlGdCT/BjVaeQUzm+SuPALqK7rybpVS/10viG7cL6Giy54dRR8pjpd3q/fiv6fisQGob3+qnhXJZIdFJV31hPYMnITgvOJw/JvVLO+mcm+FItNxdzNUU1wAxlhri47pOaKQWHBzANJhCg0KRNP5YxU6yiagQcgumy6K0yxwrAhe/+zS5ZPFROyjjZKwAWhUcGvzV63qiTy4zZ8F2L2ZyzQWWx8Ri+MKS4d+U02cSCZ/onia4h//arRqH7P5jz/kddXuR+0rcEY7BKKZ7BtV5QdsAtqh36FrWvsgDLYHTP/TKrAoe9Dnb1g69FCjlbEBaFRwK/Oj6fzJCr20iUs0FFqB32uP96bpnj71zOCbz2Z4spx//Bti38pkOwEjrysuGVrVrBUYt30Cm782g14GGNO+LLhypwtYwRXjw/Ep3wlQa21sAGoVq3b8BWoie+bvCOrTwSoXJxUeHzxzphdQPFVu5S1oAruM/3hVewDUOK5yq5+jxxWGh35U40wO7yCBzXcHiE779swOKoWptkvA6Cv8+pDABqBJm7j5e3LZfIV8sH4qL45w8J7ScPzZ95VOk2k0lT9JxbuEf/ybt5UCnF5IxL/XvBUYOSgCbir/cYg2/P1tUOphHq0UsPliYmHcrxXZAPgluWUcVXHTYzmIU/P7mZuRzlMxrdrHRJ3jS0tj11e7TjSTPUVVv8s//tWK1TFO5SPFZOxTdczklA4VcNPZiwE5o0PTZ9ptEhDRUwvDQ759rcwGoAkb+e+rfoN1Klew1imbN6w7acE91ZYcTedOU2u/w4eZVCtW+zgRpAvD8WTtMzmjowVWrepxH9rmGihe1dF1MPmWCVjg0fHHB3et9mvbahJjA1CNUo1jouncrQosqnFaE4frlQP9vYlHF88vVrtINJ0/Q633bf7xr1as9nEW+M14f88rsXj+ptpnc0anC8xdNjZ3wpHfOSL7dXotzL8FAqKfKg4PfcTPldgA+KkJIJLOvVaAa3wOW184axXifLKYWHBBLS+QcVPZt0H1m/zjXx97NbMUuM84ky8qnLjon9WM55hwCsxZvmbPSaf8ewOzbTgrZFW+CRg5tLgk9mvf4gFgA+CnJoDBdO4mA7zM57D1hBsHkCwm4pfXMtnN5M6CZ7/OP/61qNU41mKDGuelpcQBuRpncngIBSLpNa8WlK/ldTYh3FwfSxIgVUjEl/oYkg2An5izM7mXWEX7H91q7YMWcsz40qGxWuqLZvKnq+ddzD/+tajVPlaBpaVEPFX7TM4Iq4CbyX0ICl4IGtYN9qeuSU+wx4bh+IP+hOMZAL8cN8dxR8ZWwpgTfA1aYzBV/AFezxtKJ89/pJapkVQ2IaLL+SmkFrU6xgq+XRyOv72OmZwSZgFViWTyVwlwdJjLZG2NCQjwxUIi/t7GovzfbH4F4JPk4GW3PceUnfvb+qhPay8r2rmnVPMyny3L/veLfVbyCX8+HQzThKm8abHQ33MIL/prrnOnRq9cFDjZa8ZE8fxOrYF5N1fAWqyLDPTsUssF3VvLiA2AT/vlpnKfguBDPoWrLUzlYj/HfKQ4HP90bROBaDp3jFpczrf61SpX2/jKM/57TN/C9Yn5f6ltJkd3k0A0veZgtfbXbMa7addrrFVxbjEZv6jGWVMOZwPgh+Ky+2YNmvUPGIPt/AhXSwwFSqKaLCaHrqhlXmVsJJU9QkSvetbLJmoNxPEzCgjklEIiNsVrPWecygFdJuCmcx8DcEGXlc1yqxSw0L+MD8f3qeXOrulCswGoEn1rw558Wp5c4kOo2kKo94A6ckxpycJsbRMBd0X2cJTlpzAYqHUux9coIPh/xeH44hpncXi3CoyOOoMT+94YkLuJunUXAl23gX39+sTCnzaaJBuARgUrF/+ls1lAfHs+czUpicqt1nOOqfViv0rsymlGz5Z/boxxq1mLYxoQsHjY6ZED1i2JPd5AFE7tMoG5y8aev8lgDf8b7bKNr7Zcwc+Lw/HXVjucZwAalZpmvpvKHwrRG5sUfsqwFrh8vL+UwOKDN9S67uCK/EEo6y+NwZxa53J87QIienRheOjq2mdyRrcLbH4mh+Ib3e7A+qcQsFaN6dun0WuKeAagwaNrMJO73Cje1GCYqqer6OdLS+IfqOf7n8jImphKeZURs03VC3Jg3QICyRQSsUTdATixuwU2v1RszQ0QPay7IVj9VAKi+FIhGX9PIzpsABrQi6xcs6NM2gdbdAX9pABn1fvKWDe1Zn+IrZyp2KGBkjm1agF9xPT3zl+/eP5jVU/hQAo8Q6DyqGDPsfnKQ0aJQ4EtBSpvdx335j631tu+t4zBBqCBYyqSzr1HgC80EKKqqRZ4wijeXEzGb6hqwlT/iMjmW4ueU898zqlHQI8vJoZG65nJORTYUqBV/85QvfMEVGRJaTi2st7M2QDUK/fkc///ZID9Gwgx81S190qPc1ThxNidMw9+9oiBy9bs6pTtbwDsVs98zqlHQK4rJmJH1DOTcyjwLIEnXx2chWI+dSiwpYACvyol4nV/RcQGoM7jKTqSf6kavbnO6VVNs9CbHaf8hnrfGBdduXq7crnnJr5utCpunwbZCWOwYP2ShXf7FJBhKAB3Rf7lsPorUlDgmQLG2H3q/feGDUCdx5M7MvZdGHNandNnnmZltLhuIIlz9p6YefCzR2w/utbduNG7QUVfWM98zqlToAnv7K4zE04LmUA0k0upgheVhmxfGy1HBf9TGo6fX08cNgB1qO2YykXWi/2bAxOtY/qMUzZf3ZmIvbeeK/03Bx9d2+dumPwZjLxyxsU4wD8B9R4oztq4bz23Z/qXBCOFVaBy0bH1ync369+dsLp1QV0PFfvveh4WL/ZqrZUNQK1ilQfppPInqWgTHutqLeCcW0zEvl5HWk9OuUDN4J75UQO8ue4YnFiXgIomSsNDmbomcxIFqhDga4OrQOrCISp6RGl46LpaS2cDUKtY5Rn6y2/7tTjOf9UxdWtTxgU4oZCI/7iRuE3/aqKR5EI8d/Ob/oZjL6r7rE2IbViajwKjNw+4Gwb+DGN28TEqQ3W4QL3PHGEDUOPG//u+XL/f6PYPY/To9UuG/lBjOk8bHklnPyuQ9zcSg3PrFDByaHFJ7Nd1zuY0ClQtEEllEyKSqnoCB4ZeoPJSuMH+np1qfU0wG4AaD41oOne+AjW/dne6ZRT4c4+R161bEru3xlSe8ce/Nc8kaCTHsM5V4CelRPyYsNbHugImUHlCYCZ/G4ChgGXGdNooUM9XkGwAatwwP1/8s/k2P9t/TGHp/v+qMY2nDY+m8ycr9NJGYnBunQLWqprehaXEAbk6I3AaBWoWiKZyR6ugoa8La16UEwItILDXFBILj6wlSTYANWhFR7L7qJG7apgy/VDBVcW+0gmNXjEeHcm/QaGXw8DxJS8GqUnAwv5wPLHwuJomcTAFfBCIpHO3CPBiH0IxRBgELMrSO7lzLc+NYQNQw8a7qfyHIfrJGqZMPVTx3eKsu95ez20bWwZ002OVJ0BdC5j+hnNigDoErIXoguLwgX+qYzKnUKAhgUgm+xpR+XlDQTg5VAIickZhOPbdaotiA1CtFAA3dVse4iyoYcqzh6p8opiMfayhGE8+hvhAhb2R9wQ3KtnAfGsvKy5deGIDETiVAg0JDKZzNxngZQ0F4eTwCAiuLw7HX11tQWwAqpSKrszvp57eUeXwKYZV7vGXs4qJoYvrj/HkzDmp3O6etb+DY3ZsNBbn1ylgrUJMrJiM315nBE6jQMMCg6n8kUb0pw0HYoBwCFh40ju5U7VfA7ABqHLb3Uz2o1D5eJXDnzFMN4rgxMLw0I/qm/9/s2aPrt1mcsOmmx1j9m00FufXL6AqPy0lY6+vPwJnUsAfATc9lgNMzJ9ojNLpAiJ6amF4qKqLwtkAVLnbbiZ3ez1v46q8ytcBjikk4jdVudT0w5bdN2uwZ/31Bjik4VgM0JCAWP2vwtKhylsW+UOBtgpEMvkTRXVFW5Pg4oERUMXVpWT86GoSYgNQhVLdp/8tHobgCF9OE/MRv1XsVGuGWOA344m430+CbE3yXCV8AqOjTmRi37sF2D18xbGi2gXsxEB/33bVPBSIDUAVupF07Q/ZsbD39Kp59bpk/L4qlphxiDsy9hUYc+6MAzmg6QICeWMhEbuy6QtxAQpUKeCmcudA8NUqh3NY2AVU31xMDl0xU5lsAGYS2nz1f34VRCu33FX3o94a9fpfUzp5/iPVTdj6qEgq/y4RvdCPWIzRmIAK7i/13bVXo7dwNpYFZ1Pg6QLbZG6ZvdHrf8gY49KGAgKMFBLxk2aSYAMwg1DlP6xNOvBPAL0zYW7+veB3jshR65bEHq9q/AyD3FT+OKj3AxjDvfIDtMEYAryvkIh/ocEwnE4B3wXcTPbrUHmH74EZsOMELPDo+D2xnXCB2K0lzz8qM/0BTucqr9X9YXVHgP4iovLGvyfjperGb31UdCT7MjV6PR/044emDzEsNpiBnl3WL57/mA/RGIICvgpsvlZp0vsTPyz4ytqxwYziJeuT8d+zAWhgCyOp/CUiespMISxw+Xh/z4lYPH/TTGOr+X3lP2av7P3WiNmmmvEc03wBBS4pJeKnNX8lrkCB+gTcdPY6QKp+EEx9q3BWRwhU8dA5ngGY6QzASP5hGN15a8NU5dLSrDvP8Ot74ciytTuht/w7UTy/Iw60Lkmymo66SyhYZkAFNn9lKDoa0PSYVgsFROXWQjL2Ip4BqBN9cCS70BipvHZz+h/BRcXhuG9X528/utbdODF5o0IOqjNtTmuGgGBtcTh+QDNCMyYFfBMYXds3uKH8kDHYzreYDNShAtaa/r7tt/aVJc8AbGVr3UzuQ1B8arohCnyhlIi/z7ejY3TUiU7s+2MFanqlo2/rM9C0Aqry36Vk7MskokDQBdxU7ssQnBf0PJlfKwT0+GJiaNozQmwAtrIHg+ncb6Z/6p58spiIfdTPLeS9/n5q+hjL2k2CWc8pLN3/Xz5GZSgKNEXAXZ6dD0f4joqm6HZY0MqbZ5PxM6bLmg3ANDI7pnKRkqByK9+zb/8TfLg4HP+0n4eCm8q+DSLf8jMmY/kjYAVXjA/HK3eD8IcCHSEQTeduVWBRRyTLJJsnoPbeYnLhnmwAaiSOjORfJUZ/8cxpCn13KTHk60N5Nq8FvQYGPTWmyeGtEBAcVxyOV3kraCsS4hoU2LoAHx7GI+QpgbLxnr9xyYF/nUqEZwCmOU7cdP4TgH7kP7+uvP7VMe8sDse/6eehFU3n9vWAWwww18+4jOWPgAdb2FCeuwNO3n2jPxEZhQLNFxi87LbnmLI8ABjT/NW4QpAFROXkQjK2nA1ADbsUSeduFODQzVMqf/yNvL2YGLq4hhAzDq282rc8Mfl7A9lrxsEc0BYBEaQLw/FkWxbnohRoQMBN5W6A4PAGQnBqCARUdHlpeOhkNgDVbubo2j53YnIdILM2TxG8w+9P/rh4dW9ksPcX/2kyqs2N41oqoMDrSon4tS1dlItRwAeBaDp3mgLf9SEUQ3SywFauA+BXAFNs7JOP4JWbKr9S4LxSIu77W7Yi6dz3BDi1k4+rsOdugSfGxyd3wJmLJsNeK+sLn0B05ertdLL3ERg44auOFdUiYHu8546fcODDz5zDBmCqBiCdO1+BT6voe0rDQ1+qBbqasZFM9t2i8sVqxnJMGwUUK4vJ+JI2ZsClKdCQQCQ99iuBeXlDQTi58wVUFheTsf/HBqCKrXQzuWtFZVUhEftcFcNrGhJN5Y5WsVfy4pya2NozeJr/aNqTDFelQO0CvBugdrNQzpjmibU8A/DM3R4ddSIT+76zOaf9b4+rnfwN39ndCf+J2YmB/r7tHl08v9gJ2TJHCkwlMGdFfg/P6j3U6W4BVfyhlIy/mGcAZjoOVAUiOtOwWn8fWblmR/HsHwDsVutcjm+9gAA/KyTiR7V+Za5IAX8F3PRYDjAxf6MyWkcJWLupuM6djXP2ntgyb54BaMUuVl7QMTG5ykAObsVyXMMPATm7mIh93Y9IjEGBdgpE0tnPCuT97cyBa7dfYKq3mbIBaMG+uOn8twE9swVLcQmfBIyx+6xfsvBun8IxDAXaJuCmcq+A4JdtS4ALB0Tg2R9q2AA0eWuimfzpqvqdJi/D8D4KKHBfKRHfw8eQDEWB9gmMru2LTJQfEyDSviS4crsFpnogEBuAJu5KdCT/UoV3I4zpa+IyDO27gFxcTMTe5ntYBqRAmwSi6dxP+ZrxNuEHZ9nbi4n4gi3TYQPQpM0ZTK/e2di+P8Lozk1agmGbJaD65mJy6IpmhWdcCrRawE3lzoHA9weatboOrteAgEW5aGdHt3yvCRuABjynnVp5lPCm8o1QvLQZ4RmziQLWqmDW9oWl+/+riaswNAVaKhAZWRMTY3MtXZSLBU7AqnnheHLB6qcSYwPQhC1y09mLATmjCaEZsskC1pM/jZ8Um9/kZRieAq0VuEDN4O7Zfxpj5rV2Ya4WJAEBTi8k4t9jA9CkXYmm82co1Ne3BjYpVYadSkDw7eJw/O3EoUDYBCKp3E9E8Pqw1cV6ahB4xhMBeQagBruZhkbTaw5WW17Fi/5mkgru71VkSWk4tjK4GTIzCtQnEE3l36eivj/evL5sOKtNAjcUE/FX8gyAz/q86M9n0DaF83rMbhtOWPBAm5bnshRomsDmu5KM3ty0BRg48AIWeHQ8Ed+BDYCfW8WL/vzUbF8sK38rLo09p30JcGUKNFHgorv73XnjBQC9TVyFoQMuILZvu6cucuZXAD5sFi/68wExCCGs/XFx6cI3BCEV5kCBZghE09nVCjmoGbEZszMExOp/FZYO/aaSLRuABvcsmsqfpKLLGgzD6YEQ0I8WE0OfDEQqTIICTRBwM7lvQcGHXDXBtlNCbnknABuABnYtkskvEE9/D4OBBsJwakAErMiR48OxawKSDtOggO8C0VTuVBX85zYw3xdgwMALKPCFUiL+Pp4BaGCrtrvkzuiGvonVAuzTQBhODZCAxeRzxncpPBqglJgKBXwVGPzfeQuMkdt8DcpgHSagVxYTQ29kA9DAtrkj+R/A6OIGQnAqBShAAQpQoLUCgrXF4fgBbADqZHcz2bOhclGd0zmNAhSgAAUo0B4Biw3FpfFBNgB18M9O5V5s1f6aD/upA49TKEABClCg7QJa7tm5dPL8R3gRYA1bMXt07TZ2ojwGYLcapnEoBShAAQpQIDACYuXgwtLY79gAVLslqhLN5K/mO7WrBeM4ClCAAhQIooACJ5YS8cvYAFS5O24m9yEoPlXlcA6jAAUoQAEKBFJAIB8oJGKfYwNQxfa4K7KHoyy/gIFTxXAOoQAFKEABCgRWwALfHE/E38EGYIYt2vySH88Zg2N2DOxuMjEKUIACFKBAtQL/fuw5G4CtgV2gxt1jzS8heli1rhxHAQpQgAIUCLKAAKsLifgL2QBsZZfcVP7DEOWz4YN8JDM3ClCAAhSoTcDi4eLS+HPZAEzDFk2vpXL/mwAAIABJREFUOVit/RUMemqT5WgKUIACFKBAgAUsysVkrI8NwBR7NG909Zzyht6cGjwvwFvI1ChAAQpQgAJ1CYgzuT0bgCno+Jz/uo4nTqIABShAgU4R8PQANgDP2KxoJnuKqlzSKXvIPClAAQpQgAK1C9jD2QBsoRZN5/a1wB8FiNSOyRkUoAAFKECBjhF4CxuAp/ZqdG2fO1G+BcDCjtk+JkoBClCAAhSoQ0AgZ7IB+Decm8p9GYLz6nDkFApQgAIUoEBHCYjoB9kAABjM5F9nPO+nMIYeHXUIM1kKUIACFKhHQKF8F0Bk2dqdpKecA7BDPYicQwEKUIACFOg8Abm4uz/xqoqbWXMtoK/pvM1jxhSgAAUoQIG6Bb7f1Q1AJJ07V4Cv1M3HiRSgAAUoQIEOFFDF1V3bAERX5vfTSb0NBgMduHdMmQIUoAAFKFC/gMqN3dkArFrVE31g25tV9IX163EmBShAAQpQoDMFROXWrmwA3Ez2o1D5eGduG7OmAAUoQAEKNCxwe9c1AIPp3IEGqDzwp7dhPgagAAUoQAEKdKCAhb2nuxqAZffNGpTCH42jL+jA/WLKFKAABShAAb8EHuqqBiCazn9Jof/tlx7jUIACFKAABTpRwAKPdk0D4K7IvxzWWwUY04mbxZwpQAEKUIACfglY4ImuaAC2u+TO6Ia+iZwAu/uFxzgUoAAFKECBThVQoNQVDYA7MvZdGHNap24U86YABShAAQr4K6AbQ98AzE6PHWVhrvYXjtEoQAEKUIACHSxg7aZQNwCzR9duYycm1wKyUwdvE1OnAAUoQAEK+CtgUQ51AxBN50YUSPqrxmgUoAAFKECBjheYDG0DEElljxCRazt+i1gABShAAQpQwG+BsH4FsP3oWnfjhvLtavA8v80YjwIUoAAFKBACgfFQngFwU/mLIHp2CDaIJVCAAhSgAAV8F7BW1oeuAYim1xysKN/EB/74frwwIAUoQAEKhEQgfE8CvOju/sF542MG2D8ke8QyKEABClCAAs0QCNe7ANxU7lMQfKgZUoxJAQpQgAIUCItAqN4GGEnfHhd4t/I1v2E5PFkHBShAAQo0TUCwNhzXAIyOOtGJfX6vkIOahsXAFKAABShAgZAIiMqtoWgAoqn8+1T0cyHZF5ZBAQpQgAIUaK6AYlXHNwCz02v3srach8FAc7UYnQIUoAAFKBAOAQV+0vENgDuSvR5GXhmOLWEVFKAABShAgRYIKFZ2dAMQSedOEGBlC6i4BAUoQAEKUCA0Ahb4Vsc2ANtkbpm9yRu8E0Z3Ds2OsBAKUIACFKBACwRU8D8d2wC4mdxXoTinBU5cggIUoAAFKBAqAQHe15ENQGTF2JCUzWoYOKHaERZDAQpQgAIUaIGAAKd3XgOgKm4qdzOMvKQFRlyCAhSgAAUoEDoBEX1TxzUA0Uz+dFX9Tuh2gwVRgAIUoAAFWiQgwMs7qgGIrly9nVd27jJitmmREZehAAUoQAEKhE5AHNm/oxqASDp7qUBODt1OsCAKUIACFKBACwVMf8+2HdMARDNjh6iHm2BMx+Tcwr3kUhSgAAUoQIHqBKzdVEwOzeqMP6arVvW4D8y5DeIsqK46jqIABShAAQpQYEoB9R4oJg/crSMagEgmd54ovsytpAAFKEABClCgMQFV/KGUjL848A3A5gv/vN67DTC3sZI5mwIUoAAFKEABCK4qDsePDXwDMJjOfdMAb+eWUYACFKAABSjQuIAFvjmeiL8j0A2Auzw7HyI5PvGv8Q1nBApQgAIUoEBFQBTnF5LxYL8LwE1nrwPk1dwyClCAAhSgAAX8EVDRRGl4KBPYMwDRTPb1qvITf8plFApQgAIUoAAFNguoHFZMxn4VzAbg4tW9A7OcNY4x+3K7KEABClCAAhTwT8BR7LEuGb8vkA0Ab/vzb6MZiQIUoAAFKPB/AtYWd3miH4cfXg5cAxAduWNbDxvvNsbM45ZRgAIUoAAFKOCjwL8fAlSJGLgGYDCd+4YBzvKxXIaiQFUC1mJdVQM5iAIUoECHCjjG3lxILDwycA0Ab/vr0CMqJGlbTD5nPLHobyEph2VQgAIU2KpAoM4AuJnctVAcwT2jQDsERHFMIRnnnSftwOeaFKBAywUC0wBEMrlXiuL6lgtwQQo8JaDyiWIy9jGCUIACFOgGgcA0ANFU/g8q+sJuQGeNwRQQ2Gue+m4smBkyKwpQgAL+CQSiAXDTuTcD+KF/ZTESBeoS+EcxEd+xrpmcRAEKUKDDBNrfAIyOOgMb97ndEdmvw+yYbggFHCN7rlsSuzeEpbEkClCAAk8TaHsDEE3lTlXB97gvFAiCgApOKg3HR4KQC3OgAAUo0EyB9jYAy+6b5TqP/xni7NrMIhmbAtUKqMqlpWTs1GrHcxwFKECBThVoawMQyWTfLSpf7FQ85h0+AbW4u7Q0vk/4KmNFFKAABZ4u0LYGYJvMLbM3av+9BmZbbgoFgiSgjtmpdOKCvwcpJ+ZCAQpQwG+BtjUAbib7Sah82O+CGI8CDQsoTigm499vOA4DUIACFAiwQFsagMjKNTvCs/cIEAmwDVPrUgEVXV4aHjq5S8tn2RSgQJcItKUBcNPZrwHyzi4xZpmdJ/BQMRHfpfPSZsYUoAAFqhdoeQMwkMnt4nj2HhjTV32aLRpprVrH/Mgo3tSiFblMUAU8PaB40tDaoKbHvChAAQo0KtDyBiDIn/4rt4AJdAUEv2wUlvM7W0Ch7y4lhi7s7CqYPQUoQIHpBVraAAymV+9s0HMvILOCtimVd8EbwT6zJvs3bOzb8ARgTNByZD4tFLD6y+LSoVe1cEUuRQEKUKClAi1tAKLp7IUKeVdLK6xysS0/8bmZ3O1QzK9yKoeFUcCi3GPt9k+cvPCJMJbHmihAAQq0rAFwU7kdILgPwGDQ2D3VOzdsKMdw5qLJSm6RVP4SET0laHkyn9YKqGiiNDyUae2qXI0CFKBAawRa1gBE0rnPC/De1pRV2yoKvK6UiF/71KxoOn+GQi+uLQpHh03Awv5wPLHwuLDVxXooQAEKVARa0gBER+7Y1sPG+40xbuDYBT8vDsdfu2Vebip3AARrApcrE2qpgLW2OL7O3Q7n7D3R0oW5GAUoQIEWCLSkAXBHxj4NY85vQT21LWHhQTBUTMZvf9pEVRnMZB/lY4pr4wzjaIG8sZCIXRnG2lgTBSjQ3QJNbwDmrMjPmyzjfmN0duCoFd8tJuNnTJWXm85fAegbA5czE2qtgJXR4tLY8a1dlKtRgAIUaL5A0xsAN527AMDHml9KbSt4sAXj9Ow93UtfIpnceaL4cm1ROTp0AhYbBgZ6dnh08fxi6GpjQRSgQFcLNLUBePKNfwN/NcDcwCkLPlwcjn96urwGR7ILjZHbApc3E2q5gEKGS4nYipYvzAUpQAEKNFGgqQ1ANJV/n4p+ron51xfa4uHixsm9ceai8WkDXKBmcM/8vwLZvNRXNWfVKSDAzwqJ+FF1Tuc0ClCAAoEUaF4DcPHqXnewt3Lf/3ODVrlAziwkYt+ZKS83k7sSijfMNI6/D7mAhWf7vN3GTzjw4ZBXyvIoQIEuEmhaAxBJZRMikgqapWftXRsG7p6PxYu9mXJzM7mzoPjGTOP4+/ALiOL8QjL+P+GvlBVSgALdItC0BsBNZ7OAxAMI+ZZiIn55NXnNTq/dy6J8dzVjOSbcAhb6l/Hh+D4Q0XBXyuooQIFuEWhKAxDJ5F4piuuDhqjA70uJ+EtqyctNjd0DMXvUModjQyqgclgxGftVSKtjWRSgQJcJNKUBiKZz1yjwtKfrBcJV8cpiMn5DLbkMpnPfNMDba5nDsSEVUKwsJuNLQlody6IABbpMwPcGwF2enQ9Hnv5kvSCgKlYVk/FX1JpKNJ0/VqE/qnUex4dQwNpN2tuz23TPjghhxSyJAhQIsYDvDUBQ36QnYl9WGF7421r3crtL7oxu7NnwTxjTV+tcjg+hgOjHisNDnwhhZSyJAhToMgFfG4DIsrU7Sc+m+wHTHyjHKV74U0t+biZ3LRRH1DKHY0MqYOVvxY2bnvfUq6NDWiXL6jCB2ZncS8pq+erqDtu3pqUrztnjw7FrZorvawPgpnKfguBDMy3a6t9bsS8aH154a73r8nbAeuXCOU+BE0uJ+GXhrI5VdaLAYDr3QwO8uRNzZ84+C1i7qXfA2+HxxYvWzRTZvwbg4tWDgwPOA0bMNjMt2srfK/CTUiJ+TCNrDmRyuziKBxqJwbnhERDoHwuJoUXhqYiVdLLAnBX5PTzr3Q0Y08l1MHd/BAS4tpCIv66aaL41ANF07jQFvlvNoq0cY9W8cDy5YHWja7rLb/sjHOfARuNwfjgEFOY1pcSCX4SjGlbRyQJuJvdVKM7p5BqYu38C1T7ptrKijw1AdrVCDvKvjMYjCew1hcTCIxuPBLjpXOWNhpU3G/KHAhWBG4qJ+CtJQYF2CriX3rY9ep37AQy2Mw+uHRQBa9XpeU61dyr50gAMptYsMmLr/o69WXRG8NL1w/Fb/IjvpnIHQLDGj1iMEQ6BRq8tCYcCq2inQCST+4woPtjOHLh2cAQs8NvxRPxl1WbkSwMQSee+J8Cp1S7aknGC64vD8Vf7udZgOvcnA+zvZ0zG6mABwVXF4fixHVwBU+9ggXmjq+dMbOj9qzGY08FlMHUfBVT0PaXhoS9VG7LhBqByEE5O9FbekhasU1BGDi0uif26Wohqxrmp/Mch+tFqxnJMdwhYI4vGl8T+2B3VssogCbiZ7Eeh8vEg5cRc2ivgKPZYl4xX3sJb1U/DDYCbyZ4NlYuqWq1Fgyz05vHE0CF+LxfYpxz6XSjjVS0gwM8KifhRVU/gQAr4IDBnRX7eZFnv46d/HzBDE0JzxcTQUC3l+NAA5G6HYn4tizZ7rABvKCTiP27GOoPL82uNoy9oRmzG7EwBP6816UwBZt1qAX7332rx4K8nKu8vJGOfryXThhqAaPr/t3fmcW5XVf//nPvNzHQmSTdAEBBkbbF0Mq1FEOSBIrLIrlhtO5mhuOCKiuL687E+6OPzKIggKhWhncm04AiCqOzYHypla5kkpWxlU/attE0yW/I953llWLR22kky+SY335z+w0vn3nM+n/f9zuTkfu+SOFyAsk6zFyN+tLbs0oP9nTMP9OraVp12G+8I+bA/y+3pzrajfehMLVlIINSdeJsQniAgaKE8lVQVAswumT0H2iPPFJN+XAVAqDuxHIQFxST0ui0JLUp1tC7zKs/E2Lp9Gbn1XsXXuLVJgIk+WMjRm7XpTlXbREBvKLVpNKzRUtK25JILgJH9pw49Y9klOc+m+7N7eX1Oe0ssfqcBHWrN0KuQqhMYmXlqebgV8+a5VRejAnxLILwiOV2yshYGAd+aVGNFEyDQmalo69JiO5ZcAARjia8S8ONiE3rZvpR3IKXoCcXiZwF0aSl9tY+fCcin09G2JX52qN6qSyDU1fd7GDOuo82r60Czl50AY2BCrmnnVz4+PVVs7JILgFAskT8U58BiE3rVXoBMQ45337ho1kavcrwZd/LSvsm5AF6w7tZDr41r/LEIvNRIA/ttaD9k81gN9edKoFgCwdjaDxD4lmL7aXvfE7gqHY3ML8VlSQVAcHlfG7HpKyWhV30Y+EV/NPI5r+L/e9yWWN9vDczplcqneWqEgOCn6Y7Il2tErcqsFQJLVjc0NweSDtH0WpGsOitDwIBP3Byd9adSspVUAIRjyQsEck4pCT3pwywEmp7qbHvUk/ijBA33xE8UoT9UKp/mqRECDFeM8+5M9MBEjShWmTVAIBxLnCtAUVu8asCWShw/gZfSu2/YDXPn5koJVXwB0NvrhIb2fwagXUpJ6EUfEfpTpqP1RC9ibzNmnsPAfk/BmN0rmleTWU9g5CCq9sj7vNqKaj0AFVhWAs1Xrn0HDeceNMaEyhpYg9U8AYJcmIq2lfxlvOgCINgdP5aIbrKJnJAcm2lvq/i7MT0a2KanwC4tJPhEqiNyuV2qVE0tEgjGEtcTcFItalfNHhIow8x30QVAKBbvAWihh7aKCs2Qx/rbI/tX49tWvjJ3hvlJGDhFidbGvifAzK/BuDP6o3Oe971ZNegZgVBP4nQIfutZAg1cuwTKcABZUQXAzt2JYJrwok0nUBV7+1G5RzvYnfwjkehZ8OUG64d4zNenO2ed4gcr6qHyBCb2rpvKA+4DMPL2ymfXjDVA4PR0NHLNeHQWVQAEu+NRIuoeT8Ly9pVB09Sw2+Z5MzaUN27h0cKxxMkC/L7wHtqynggI0cJMe+uKevKsXstDwMaTVsvjTKOMmwDT8+k9Xt2j1MV/b+YvqgAIxeK3APSBcYsvUwACulLRyBllCldamJFFkdOeALBHaQG0l58JMPhVcgIzMgtmvuhnn+qtvARC3fEPgWhc3+7Kq0ij2UWAzktHW8d9NX3BBUDLlffvanL0NGCMLSCI6dBUZ+td1dYTjiW/LpD/qbYOzW8nAQLfmGpvO6Ea61TsJKKqtkcguGLtzuRyEsDblJQS2IoAw3UdvLPYi39GI1lwARCMJb5IwE9tGY6Rs9fPaLXiGuKRd3VDuacBtNjCR3XYRUCAL2WikYvsUqVqrCMgQqHlyRshONY6bSrIDgKE36fbI6eWQ0wxBcD/J+CIciQtRwyBfCUTbftJOWKVI0YoFl8C0KfKEUtj+JEADwkH3pPpnJn/Zqf/lMCoBILdyS8TiTV/13SY7CNQzm3vBRUA4RWrd5RswwvWbHdjHqYGd7fUgjmv2DI8oWXxGXDoAVv0qA77CORnrcJG3vNiRyRjnzpVVG0CLcuT7zbs3ql3jFR7JGzOz8l0dFakXAoLKwBiyUUCuaJcSccbh8FX90dnfWS8ccrdP9STuBWCo8sdV+P5iIBgRbojYs05Gj4iW9NW8q8R3eHcGhK8s6aNqHhPCYhIR6ajLVauJAUVALadRMVCJ/R3tN5QLgjlihOMJY4j4MZyxdM4fiVAX0hHWy/xqzv1VSQBEQrG1v5BzxMpklu9NWd+Jj3o7o2z5mTLZX3MAmCn3nWhgaHsywBNKFfSccYZ1+UH48w9ZvdQLB4HqGxTNGMm1Aa1SCBLTEfYsIOlFuH5TXMolvgugMV+86V+yktAgHMz0cj55Yw6ZgFg3VGUQj9Ld7SeXU4I5YwV7EkuIJHl5YypsXxIgOl515H3lGMrjw/p1I2lkf3+IlfDmDH/FtcNFDW6FQFm2jzB6X/HhvZDNpcTz5gPnW2nURkjB29e2HZvOSGUNVZvrxMcnvaYvssrK1W/BusLCg7XRYF+Hd7t+wp2rW2F4VU2Ha1enyNhv2sBfpyJRr5WbqXbLwCWrG5oaWl4yQCTy524lHgCPJqJRqaV0reSfUKx5OcB+Vklc2quWiUg16XbI/lT36RWHaju4gk0d8V3cyB363XixbOrwx5Zl2Wvgc62Z8vtfbsFQLAnfgwJ3VzupOOI9710NGL/u7LeVc2hoeBTepLXOEa6jroScH4qGjm3jizXtdUdL384PNg4+FddK1TXj0HB5oVkWaa9bVHBHYpouN0CINQTvwRCnysinrdNXTkwfUbbOm+TlCd6OJY4V4AflSeaRvE7gWrfaul3vtb4W7K6IdTS+EdAjrFGkwqxlwAjZ0zggM3RGY95IXL7MwCxxCME7O9F4mJjMvBQfzTyrmL7Va39ktUtLS0NTxlgp6pp0MS1Q4BZxJgzMtGIRbdt1g6+mlC6WExo7+QKED5aE3pVZNUJCGRpJtp2pldCtlkATOh6YI+Acf/uVeLi45bn9qPi85beQ2cBSmdXlz0ZOXLktFR72x/r0r/PTYdiyUsBOcvnNtVe+QhkHcG0TR2RJ8sXcstI2ywAwj3xM0Xocq8SFxtXiFoz7a1ri+1X1fY6C1BV/LWZnIcE5tRMNHJTbepX1aMRCHcnzhfCV5SOEiiYAPOv052zPllw+xIabrMACMUSVwL4WAkxy96FIY/1R9v2K3vgCgQMxhJfJeDHFUilKXxDgIdE6JRMR5tNC3B9Q7fSRvTDv9LEfZCPeTgXkP0HF872dBZ+9AIgfyVlT/IFW1axE+TCVLTtnJoc1vyOgIHgYzDYtSb1q+gqEZBBIZySaW+7pUoCNG0ZCIRjyQsEUpt/u8rgX0OUSIBwabo98pkSexfcbdQCIBh7IEJw4wVH8bqhkaPSC9tWep3Gq/ihWPwsgC71Kr7G9SsBHiKi+an2tmv96tC3vl5f8HcpCJ5O4fqWX10b4yE3ENhvYP7Mp73GsI0CwJ5pawY29u++YSfMnZvzGoZn8VeuDASfmbrOlh0VnvnUwOUnwHDJkU+l2tusuY2z/CZ9FjG/1a+5Iaar/X02rpWyU8Hj7kctAEI9iZsgOLZSfsfIc1U6GplviZaSZYS6kx8BSW/JAbRjXRMg4GupaETXklj+FLxxyM81AH3Acqkqz0ICzNjkNGT3TS2Y80ol5G1dAFy8vik0pX8DgJZKCBgrhwCdvtgbLULhnuS9AswZy7P+XAmMRoCBX/Q3PXI25s1zlZB9BEaO9zX4k57wZ9/Y1IoiEvp6qqO1YgfIbVUAhGOJwwX4iy3AGNld+6NznrdFz3h0hJbH54Lpz+OJoX3rnADh5obG7EdfmzdnU52TsMp+Sywx2zD/Xs/2t2pYakqMEJ7KbGiZjrP3G6qU8NEKAJuOsH0gHY3MrBSMSuQJ9SSug+CUSuTSHP4kwC492AA6edMZMx/3p8PachXqTnwMgitg0FxbylWtVQQE89MdkasqqWmrAqAllrjaAB+upIht5SLQT1LRVl8dnjExtm5f5uF1MKbRBsaqoTYJ5BfHOkBnKhq5vjYd+EB1/urvof1/QKCv+8CNWqgiAQHuyUQjh1RawlYFQKir72lbprFE5Dg/HoaiB4NU+jH3ab6R+wPoR5mmR7+t6wIqO8YtV96/Kw3hKnKcwyubWbP5kQDBHJaKzlxVaW9bFAD5h9rknLLfOVySKYbb3ByY/PK8GemS+lvcaUrv6klDQw3r9aIgiwephqQJ+C8uN0QHOw/8Rw3JrlmpLT3J4yHSpb+/NTuEVgln8NX90VkfqYaoLQqAcE/8NBH6XTWE/HtOAlanopGDbNDihYZwLPkpgSzxIrbGrD8C+e1D5MjnM+1tPfXnvkKOe1c1twwFLzCA5ye0VciRpqk2AcaAQ5jh5YU/27O4RQEQjMX/x5b3WX58/7/FQCwWE9577d1C4tsip9q/W3WZn6mX0PDZVOcBr9alf49Mh7uS783BXeoYM82jFBq2HgkIfSfd0fr9alnfogAIdSdXguTIaon517wEOi0Vbb3OBi1eaWhZnny3YfdewBivcmjc+iPAjFfI4Cu+OD+jysO3U++60MCg+98g93P6e1rlwfBZepf5kYHmxlbMmzFcLWv/LAAWi2nZK77JGBOqlpgt8mbdt6XPnP2yFVo8FNESS/xCpxQ9BFzPoQm3OTnzad0uWNpDEOqOf4iEfiIGe5YWQXspgW0TEMLRmfbI7dVk9FYBEOxJziSRZDXFvJlbgCcz0cjeNmjxWsOk5ckpWZZHdEGR16TrNT4PCdFFTRj8wYb2QzbXK4VifIdjiWkCuhiQY4rpp22VQBEErDji/p8FQCzRQUBXEQa8a8rUm+5s/ah3CeyKHOxJdJJgmV2qVI3PCLwEke+mJzx6mW4ZHH1kgyvW7iwuf9cwPgmDgM/GX+1YQoCZNsMMT7fhhNt/FgDdyR8SyTdsYCTAuZlo5HwbtFRKQ6gncSsER1cqn+apTwL5947Goe9nHouswGLi+qSwpev8LJzL+DKz+2VrXoHqwPiXgOCL6Y7IxTYYfKsACMXi1wJ0qg2iIHRkuqP1Diu0VEjEpO7EXi7hAVsuYaqQbU1TJQIjhYBxzss0PXxVvc4IhLse2kEweA7D+bwxMrFKQ6Fp64tAX7rpkYNs+Z17qwBo7up72JYtLo00MKke31cGY/FzCHRBff0+qNtqEiDG39ngksam7GX1csHQyDt+wpcg6NCCu5pPX93lzgqcgzLRAxO2OH+9AFiyuiE0oaHfivde4j6d7pi9hy2AKqqjt9cJD06/S88GqCh1TQaAmdPGoS6RwGU2/YEq2+CsXBkIP7PDiYD7KWEcB2O2vgq9bMk0kBIYlcDidDTyPZvYjPwShLrXHgDiB20QRuAbU9FZH7RBSzU0vLEbYw2Ahmrk15xKAEBcgGXGyS5PLZjzSi0TCXatbQXJfBJ0wsjba9mLaq9pAvF0f/Y9OGtO1iYXbxQA8Q+B6BobhAnw40w08jUbtFRLQ6gn8W0IqnY6VLV8a17LCDBygNwBMte6wtcNdLbZcU/IGJiCy/vaSOhkzpmPGkfeZRlVlVN/BKyb+n9zCF4vACz6wBGgs+5PMMtfMzo4bRUR3lN/vyvq2EoCzELGrGHI7YBze6Yp9TfMO3TABq3hFat3FG7In2D6frB7Ash5hw26VIMSeIOAdVP/WxQA4VgyJpB2G4aLmA5NdbbeZYOWamoYWajE6INBczV1aG4lMCoB5mERucc4ZjXDrDEO1qTmz3wEROIpsSWrG4ItE95l4B4kkIMg/F4IHajv9D2lrsFLJ2Dl1P+WBUB38l5rFp4Jdk53RF4qnbd/egZjiS8S8FP/OFInfiYgQIYgjzFkPYnzmIE8RsQv5AgvMclLgw2DL401azC15+6JnG2aOhwwUx1gdwHtIcTvIMH+LssBDsw+VixW9vNAqrdyEbB26n/LVwBdyedsWCDjglMD0Vm6H/fN0RGhUE/yNgBHleuJ1DhKoLoEmMFmiA2GDGQQrhATGsmYRmJMgIFTXX2aXQmUhwAJvpXqiPywPNG8iUJYLCa0V3LYkl+8eDoameWN1dqM2twV342MJAzMDrXpQFUrASWgBOqMAMvt6Scjx9h+2iYFl67bhQK55+0YHrkuHW07zQ4t9qgIdyVPESO+vhrZHtqqRAlplr7EAAAbFUlEQVQoASVQOgEGXgayERvO+h/LBbV0xWcZQ/eP1bASP2fgl/3RyGcrkavWcui1wbU2YqpXCSiBuiPALEzOif0drTfUgndq6U5+0JD8yQqxQt9Jd7Tq/vfRBmPpkxNCgc33ATjQirFSEUpACSgBJbAlAeaL0p2zvlQrWCgcS3xCgMtsEEwkH0+1t11hgxYbNYSWxWeA6D7dGmjj6KgmJaAE6pxAX7opcAjmzRiuFQ4UisW/A9B/2SCYhU6olamTavEK9iQ6SbCsWvk1rxJQAkpACWxJIL8F1rDMTnW2PVpLbMimd8t6CFBhj04wlvg1AR8vrLW2UgJKQAkoAS8JCEk0097W42UOL2JTKJb8HSB2rLwX8650x8yHvDDqq5ivrwfIn5bY5itfakYJKAElUHME5JJ0tO0LNScbAIW64rfB0PttEM/I7loLWydsYDVp2dp9ssRrjMEkG/SoBiWgBJRAvRFg4M7+/uxc2275K3Qc8q8A/maAwwrt4GW7dFOmZayjQr3MX2uxw7HEycJ8nZ6DXmsjp3qVgBKoeQJMz7MZfnctf2ml0LL718BxZtswGOn2VuP5ZSI2GC2jhlBP/D8h9L0yhtRQSkAJKAElsH0CWSKem2qfdWctg6KWZcl1VtyZzXDTnZFALcOsivaR+wLWXmPNOo6qQNCkSkAJKIFKEqAvpKOtl1Qyoxe5KBhLPEHAXl4ELy6mDKajbXr1bXHQRlrv1LsuNDCUyy8K1EOCSuCnXZSAElAChRIgoDsVjXQW2t7mdhTSmwBtHp+CtU1antw767r3GTJTC+6kDZWAElACSqBgAiK4NzMhc6Rf1qrlFwG+ZoDJBRPwqGH+IIVMNBLyKHxdhA0tj88F080AGurCsJpUAkpACVSIADH+zg3m4MyCmS9WKKXnafInAQ4ANMHzTGMlYB5Od85qGquZ/nz7BMLdyTOEZKlyUgJKQAkogfIQYMYmI3JY+oy2deWJaEcUCnX1sRXbyJgl3TnL2IGltlUEexL/TYJv1rYLVa8ElIASsIAAIyeOnJBpb7vFAjVllWDPDACAdH+2sVYPVCjrqIw3WH5nQPfaq2Bk3nhDaX8loASUQH0TkE+no21L/MiAWrr6NhhjpthgLpDjKRsXzdpog5aa15A/Lrhh858heG/Ne1EDSkAJKIEqECDBBamOyFerkLoiKSkUSzwDYLeKZBsjiSPYe1NH5EkbtPhBQ7jroR1yNPQ3h2i6H/yoByWgBJRA5QjIdenHIx/GYuLK5axsJgp2JR4lg/0qm3b0bGxoTv/C1jU2aPGLhgldD+wRMO4qW4o8v3BVH0pACfiXgID/kslNPhaL9hr0r8v8ZUCxeBygiA0mhekDmc7W22zQ4icNoe7EgUz4qw3bPf3EVb0oASXgSwLxhqbska/Nm7PJl+7+xVT+NsC7YOgQG4wKqD0TbV1ugxa/aQjHEocL5BYrtnz6Da76UQJKwBcEhLGeCO9Ld0Re8oWhMUzk1wDcDuAoG8yS4FupjsgPbdDiRw3hnviJIvQ7PSjIj6OrnpSAEhgngWdzxj1scOHsv48zTs10p2B34g9EONEKxYRL0+2Rz1ihxaciQrH4PECuBIyeueDTMVZbSkAJFEeAhTcYpv/w20E/Y1GgcCyxTAArLjYg4IZUNHLCWKL15+MjEI4lFwm7l1txANT4rGhvJaAElMC4CDBzOkDm6M0dkXvGFagGO1OoJ34ehP6fDdoFeDQTjUyzQYvfNYRiyc8D8jO/+1R/SkAJKIFtEmAMiIOTMu2R/KvwuvtH4Z7kJ0XkV1Y4Z7jpTS1BnL3fkBV6fC4iHEucK8CPfG5T7SkBJaAEtiZQ5x/+eSAU7I4fS0Q32fJ8CJy2TPTAhC16/K5DiwC/j7D6UwJKYCsC+uE/giR/ZvwBIH7QlkdEiBZm2ltX2KKnHnQEe+JfIaHz68GrelQCSqDOCeiH/1sPAO3cnQhmCGlbHgmCXJiKtp1ji5560RGMxc8h0AX14ld9KgElUJcE+iE4Kd0R+XNduv8305T/3y3dfa8aMlOtAMJyd7qzTS+wqcJgBGOJLxLw0yqk1pRKQAkoAa8J6If/aAVAKJboA9DmNf2C4jMPpzeFJupCwIJolb3R64tC3Uv1nICyo9WASkAJVIlAfqufCdDJ6YVtK6skwcq0IzMAoa7kb2y6O55gDktFZ+YvsNF/VSAQ6k58DIRuPTGwCvA1pRJQAmUlwOBXA4Y+uHlh271lDeyDYCMFQLg7+TUh+V+L/HwvHY0stkhP3UmZGOs7gUFX690BdTf0algJ+InAsyD3mHT7bGsWutsE9/UZgOXxuWCyZlGEAPdkohErLiiyabAqrSUU6zvSBa53YMKVzq35lIASUALjIZA/WM417jH1dLZ/sbxGCoCpPXdPHHabNtpzNCyzaWrcafO8GRuKNaTty0sguLyvjZhuBGiX8kbWaEpACSgBjwi47v1gHJc+c/bLHmXwRdiRAiD/r7mr72HHGGuO4RWSaKa9rccXlGvcxOSlfe8cMrjJpuejxpGqfCWgBDwiIMAdTTRw8ob2QzZ7lMI3Yd8qAMKxZEwg7bY4E8EfMx2Rk2zRU+86wl0P7SDO8B8g0C2a9f4wqH8lYC0BujadCy/Aor0GrZVokbC3CoBQd+JsEC6yRhvzsBNwdtm0sPU1azTVu5DeVc2h4eCVEJxS7yjUvxJQAnYRIOD81OOtX8diYruU2avmnzMAXcn3ihGrtt6R4BOpjsjl9uKrQ2WLxYT3WftjgehpjXU4/GpZCVhHgJEjhz6bam+9zDptlgt6qwDAktUNLRMaXzFGJtqiWXcD2DISW+sIx5KfEpafwyBgr0pVpgSUgJ8JMLCRmD6S6Wy9zc8+vfL2zwLAwgOB8qaZZXZ/Z1v+pEL9ZxmBYE/i/SK42gCTLZOmcpSAEvA5AQGeJDEnpDtmPuRzq57Z26IACPYkF5DIcs+ylRKY+dfpzlmfLKWr9vGeQDiWmMaMP5DBft5n0wxKQAkoAYAhq0yWT9VtfuN7GrYoACYv7ZucM+Zly6Z1+5F136kDPb6B9rJ3/rlxA2a5AB/0Mo/GVgJKQAkIybJMdtJndKX/+J+FLQqAfLhQd+LPIMwdf+jyRRDCDzPtkW+VL6JGKjuBxWJCe8XPgzE6TmWHqwGVgBIA8zCM+VI6Gvml0igPga0KgGBP4kskuLA84csThZk2N7K758ZFszaWJ6JG8YpAKJb4MDMvM8aEvMqhcZWAEqgzAoznCHR6qrP1rjpz7qndrQqAScuTe7ssj3uatbTgekFQadwq3iu0LD7DNbjaIZpe8eSaUAkoAV8REPBf4ATmZRbMfNFXxiwws1UBkNcUjiXuE2COBfrekiBARpDdrz8653mbdKmW0Qns1LsuNDCYWwLCAmWkBJSAEiiJAPNF6T02fhVz5+ZK6q+dtktgGwVAcpFArrCNnUCWZqJtZ9qmS/Vsm0AoFj8LkIsA06SclIASUAKFEMh/4QPorEy01a5daYWIr6E2oxYAWPrkhJbAxmcMzA52eWFmmIP6o5H77dKlarZHoKUrPgtGfmtg9lFSSkAJKIHtEnDd+4nM/FRn26NKylsCoxcAAIKxxI8IONfb9MVHJ8iaVNOjB2PePLf43tqjWgR2vPzh8FDT0M9FEK2WBs2rBJSAxQSYhYxzYarJ+SbmzRi2WKlvpG2zAMhfAZsL4HHAGNvcEugbqWjr/9qmS/WMTSAYS8wXxi+NwaSxW2sLJaAE6oKAyy+Koc5MR9vNdeHXEpPbLADy+oKxxPUEWHglrwwSI6JTRJY8RUXKyBeXwwHTY4DDiuyqzZWAEvAZAQJuYsecoav8Kz+w2y8AuuPHEtFNlZdVUMa+9Gst78XZ+w0V1Fob2UWgt9cJDe3/LYC+A6DBLnGqRgkoAc8JMA+LoW9m2iMXgkg8z6cJtiKw3QIAIhTq6lsNx5ltJzu5JB1t+4Kd2lRVIQTyCwQNcRfImVlIe22jBJRA7RMgYLW4ckb6jLZ1te+mdh1svwB4/Wjgo0C43WKLp6ejkWss1qfSxiLQu64xNDD8XcB8HQbOWM3150pACdQoAeZhMuZ7qd03/Ej39ld/DMcsAPISw7HEn2y96GXkgCCWw/XK4Oo/TONV0NLTdxDEdBnggPHG0v5KQAnYRUC/9ds1Hnk1BRUAoZ773wXXSVr87exZl+Xggc62Z+1DrIqKIpCfDRjKfQvM34QxjUX11cZKQAnYRyD/rZ/M4tSER36k27ftGp6CCoC85FAsvgSgT9klfws18Yam7JGvzZuzyWKNKq1AAvmik8VcZkCHFthFmykBJWAZARK6T5gX6bt+ywbmDTkFFwDBpet2ETO83upb3gh3NTcGjnl53oy0nbhVVVEE8otQe5KfZqb/MUYmFtVXGysBJVA1AgxsNIRvpx9rvRSLiasmRBNvl0DBBcDILEBP4tsQfN9mpgLckWnKHI95hw7YrFO1FU6g5cr7dzU55wIAHyu8l7ZUAkqgGgSIEBPGV9MdkZeqkV9zFk6gqAIAK1cGgs9M/RsBBxeeovItxXX/2tjCJ+nrgMqz9zJjKNZ3JLvOz40j7/Iyj8ZWAkqgeALs0oPG4LPpjtY7iu+tPapBoLgCAMDE2Lp9czzcZ/WrgBGSkpBcw3GZRTNeqAZYzekRgXwR+uyUL7LIdx2YsEdZNKwSUAIFEsjvxDJC/5UaGL4QZ83JFthNm1lAoOgCIK853BM/U4Qut0D/9iUIPwEjJ6XbZz9ovVYVWBSBltjqtxMCPyBIp433VRRlRhsrgVolIPhNTpyvDXYe+I9atVDPuksqAPLAWmJ9+etdT7cdngtOBWDaU9HI9bZrVX3FEwgu72sjNvn1AUcV31t7KAElUAoBhqwKCJ2zuSNyTyn9tY8dBEouACYtT05xc24Sxuxuh5XtqGAWGPO99OOt5+mKVOtHqySB4VjiZAZ+TMD+JQXQTkpACYxNYGRW1Xw93R65euzG2sJ2AiUXAHljoeXxucjRrRYfELQFfwH/hQOB9oH5M5+2fWBUXxEELl7fFJ6a+aAIOgA6tYie2lQJKIECCDDza0TOeZkJzs8xb8ZwAV20SQ0QGFcBMFIEdCc/B5JLasDriMSRB9mYz2WikStrRbPqHIXAYjHBvdYeBcMLhOlDxmCSclICSqDcBHgIYn5pJgTO2zxvxoZyR9d41SUw7gLgjSLgYpDU1K18BNyQZeczunilug9gUdnzVwgPTjuCCacbyGkA7VJUf22sBJRAYQSYh9mYXwvLf+sR64Uhq8VWZSkA0NvrhIemXW/rhUHbGhhmTudvpso0BS7WaS1LH9+Rsyd2nEvCH2HCqQbYqWClI2s/nFsFfDNAZ+n6gILJacP6JZAF6Ao3QD/QV6X+fwjKUwAA2Lk7EUyzeyM5zuE1hy2/sAXON9Idrb+tOe0+FDy15+6Jw5hwPFw5hY053gCTi7HJjE0GvIxAv0h1tj060jdfpA5Ojwrc74DM3sXE07ZKoA4IZCFYlnPcHwwunP33OvCrFgu9DbBQUjte/nB4MDB4CwwdUmgfm9oJcI8I/Vd/R+sNNumqBy35A6aYssdDcBJARwJoKNq3uGtB5udBoZ4XOyKZUfuvXBkIP71Du0v8bQPat+gc2kEJ+IkA87CQ0xOAfH9TR+RJP1lTL2MTKNsMwJuppvSunpQbarhNgDljp7ezBUHWAOb7qcdnXq/bBj0ao95VzS3DoSMN43gmPr70D2MZBHANgZakopG/Fqy2t9cJDk3/GEG+AeDAgvtpQyXgAwL5WTJyZIk4fFH//NnP+cCSWiiBQNkLgLyGfBEwPNTwewKOKEGTPV2EnxBDvwiQuWLTwtbX7BFWg0p6e52Jg9PmCOH9wnIUDA4DaEKpTvLnjlNALnMaA93jWp0sQuFY8kSX5Bt69XCpo6H9aoYA8zPi0E+bMHjZhvZDNteMbhXqCQFPCoARpRevb2qZku6phdMCCyDbT8BvmRDLPNa6UmcFCiC2cmVg4nNTZruM9xHLEQxzxLi36jEGyMHVcOVXqc62vxWgoqgm4djaQwXyVcA9RY8XLgqdNradgLhrhZzzM/3ZK/W8ftsHq3L6vCsA8h4WiwntvfantbZFcLv4X6+gVzigazcvbL0HRFK54bI30+SlfZOzgcBBBD4ULIeLoUMICJZDcX5tBoksC7hy1cZFszaWI+b2YkxatnYfl3JfcA3O1AuHvKat8b0jwCzi3Jg/pyUTjdzkXR6NXKsEvC0A3qAS7kl+UsT9GWCaahXUqLqZnofB9UT8x6ahCXe88vHpKV/525aZ3lXNE7MtM9k1BxHJe3LMBzv5I3iNKd/zxHhOjMSMY5alFrQ+XA2uI4taG4c7XeHPOUTTq6FBcyqBogm4/CIIl+cC8itd0V80vbrqUL4/2GNga+leO8cRvloM9vQlYUYODu4D5HYRutNpCtw7rnfTlkCa0PXAHg7lDgDRTBLMYsIsw/kPezhll8gYgMHvBejKND1yK+bNc8ueo8SAwZ7E+0XwGcM4BQaBEsNoNyXgGQEB7iCSX6Yzud/pNL9nmH0VuGIFQJ5auOuhHWCGu2vtwKBSR5whj5mR6WuTJHLXDRt5YHDBrH/Y9togvGL1jpRr2Mcl7E1C+5CR/SE4wGWebowJleq/oH6MHBncxiIrWiY0XPvyvBnpgvpVqVFw6bpdjJNbJOBP6HkCVRoETfsWgfzR5sYxMbC5NN0x8yFFowSKIVDRAuBNYeFY4hM58E/q8f1q/vRBY+hxED0FRn7f7ZMweI4EL4LlxUBz7sXX5s3ZVMwgjtp2sZjw/mumAo07Iss7wpgdQdhJGLsLyW5E2B2C3ZhpD2Nk4rjzFRuAcBeEVkCkN90ReanY7lVvL0KhnvgRROZMEXw4f0N21TWpgPogwDwMQzdAEEtPaPijnmJaH8PuhcuqFAB5IxOW379ngJ0r9B73UYaV4TKQNuAUG5NygIyw5NhQzgiyIMkB5Ag4IKAACQWI0MjgsIEJ5+9oAnNzWd/Jj/fpyx/LC7pHDF3TkOOrNy6a9dR4Q9rSf6fedaH+4dyHyZUojMzVHQS2jIzPdIwUzYiZpsBv/PB60WejU5N2qlYAjNASoeDyZAfl+H/hmJ1rkqCK3g4BZoZZRcDVTLhmoD3yjN9xtVx5/66UDXzUAPOF5CC/+1V/3hJg8OMGpscg0LM5OuMxb7Np9HojUN0C4A3a+bPfs9z8n0I4u6QjYOtt1Kz2y0MEs1KA6xnZ6/qjc563Wq6H4vLbCdmR0wE5vZZPxvQQkYYelQAnAXOtsPldpnNmUiEpAa8IWFEAvGkuHEtME8J5cPl0q6avvaLvk7jMeMUxuCH/od/cFLjZ9oV81cA+eWnfO7MN5lQIn0ZsDvNkF0U1jGnO8RNgFjZ0F4GuDbjm2k1nzHx8/EE1ghIYm4BVBcCbcoM9yZkCWWxcPk0LgbEHseItRq7ZNXERutmQ3JBqemSVTVv2Ks6jyIT5XRecCxxPYk5kyLHjPiGxyPzavPoEBMgY4A4R+YO4DddlFs14ofqqVEG9EbCyAHirEIg9EDHkfkVc/iiMaay3wbHJb/5bviHcIpCbEHBuySyY+aJN+mpWy8qVgdBzOxwqIseR4Dgwt2nRW7OjuW3h+aJZpE9M4BZy+JZ0Q8Odunrfh+NcY5asLgDeKgSWrtuFArlPw+VP62LByjxh+e2KjsFfAbPSNfTn/vUz+/QOBO/Z52cHxA0cBaGjmfgoA7OP91k1g0cEnhWSWyF0i3Gyt6YWzHnFozwaVgmURKAmCoC3nPWuawwN504WQQcBx+mCwZLGfNRO+SlJYrmbDP0ZTCtTe7x6H+bOzZUvg0YqhUBzT2J3AzmSmP6DCe8zzNN1hqAUkh73yX/Dd8yDELlTiFY5ErhTV+17zFzDj5tAbRUA/2J35JsSB+YDNB8uH6J/FIt8FsR9GuTcCZJVTGZV/66vJvQDv0iGVWg+sXfdVBnOHirAwQAdwi4O0jUEVRgIxoAY3EvMdzI5dzY4uEuvDK/COGjKcRGo2QLgX10HV6zd2bh8EgMnE+NoGDSPi4rPOr9xXOgaEVlDRKtd4O562JPvs2Ec3Y4IhbsT+7Fj5hjBu0VkFoMjhszUuvBfAZMjvz/kJACJC6EPbOKZwaGH9Lz9CsDXFJ4S8EUBsAWh3lXNwYHQYURyJJPMNaD8YSwNnlK0Kbi4TxPRAwxKkpg1joM1mxa2PmGTRNXiPYH8JU4NTq4VwIEQM0MgMwBM0yOLt8OeedglesIhPAxQnJji2UAurjfqef+8aobqEPBfAfDvHJesbgkGG95rhOYIybtZeHbtL6wa2Yf3dwKtB/hRAA8QnLWBpqF1ZblHoDrPomb1moAITehe9w7HyU0nNvsBsq8A+wrT3saRd9ZFccDIsZGnHMh6IbMeQutFeH0A9OimCY/8Q7ezev0QanybCPi/ABiF9uSlfZNzjhMhGvlGNI1l5Pa7aQTsZcVVr6/vs3+ZIE8L8DTEPC3ETxmh9QjQ+lTAeUK3ENn0a+QPLaHuxNvY8J6G6R0A7S6E3Q3o7cL8dji0CwvvYoAptt51kF/ICsZzRPQsIM8J4VkAz5LQyP/n5HLPbRx2n9Wpe388r+pi/ATqsgDYJrbFYoJ7Pvg2aXR3c1h2E2A3kOyK/B89pilEmCyEKZyjSeRIMzGaGGgUw00O0Ag2Dgy7ApMTJhfk5kDGdRj9YpACSxoOpSGSJtBmgF4B8ctgehlCr8DQy8bIC5tebX4WZ+83NP7h1QhKoMwEenudUHrfqQg07EgmNxWgKcyYQmQmkUiYDcL5/wqomZhb4JgWEjQJ8pdVoZGABgM44roGjmMI4gojK0aGiSlLhrLCPMzGZA3zMBmTFcEQETYJYSOYNub/a4g3wcVGIdroGmwMNQY26gmUZR5rDed7AloA+H6I1aASUAJKQAkoga0JaAGgT4USUAJKQAkogTokoAVAHQ66WlYCSkAJKAEloAWAPgNKQAkoASWgBOqQgBYAdTjoalkJKAEloASUgBYA+gwoASWgBJSAEqhDAloA1OGgq2UloASUgBJQAloA6DOgBJSAElACSqAOCWgBUIeDrpaVgBJQAkpACWgBoM+AElACSkAJKIE6JKAFQB0OulpWAkpACSgBJaAFgD4DSkAJKAEloATqkIAWAHU46GpZCSgBJaAElIAWAPoMKAEloASUgBKoQwJaANThoKtlJaAElIASUAJaAOgzoASUgBJQAkqgDgn8H1L1Kizb/n74AAAAAElFTkSuQmCC",
        opera: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAgAElEQVR4XuydeZwcVdX+z7k9k51dQoBMV3cgPwERUEBEXCKi0F2dsPZ0dVjdcFfU15VXib6IO7yiqKAiW9LVM6xJVzeLaFwBAcUlgCyZrh4gbEGW7DN9z+/TccPXkMxMd9e5VXXmH/6g7nme8713Jk9XV92LID9CQAgYT2DojON27F2/aWZTqZlEsCug3gUId1SAOxDRDlrRDopwB9C4HajmVCA1FRRORWpO1aCmoobJpEAR6IQCSGiAhAKV0FprBWoTAGwi0JsIYJNSavN/qQkjCnATAW2iBG1ChI2qSS8QJlYD6GdAqdXU+q/GZxJKrQbVfIaaPas3Pjeyem6tttF4qGJQCMScAMa8f2lfCLASoEWL1MoVd82e1INpDboPCPZEgNmaaDYh7AlAeyiAXQHUJFaj4xTXoNcrwKcBcJgAfET0kcDX1PRRgz95StOfdeXNa8dZVi4XAkKggwQkAHQQppQSAlsiQAC4Mp/r6+2lfamJ+yDBXA20FyiYgwAWAEyOIzkN8Ixqok9K+6TATwA+gKBWwOimP/UN3vRMHJlIz0IgSAISAIKkLVqRJ7CyuGC3HmweRBoOAoRXAul9tVYvVwqmR775zjb4OCH9GTX9mVD9OQH058nN6StmDg6u6ayMVBMC8SUgASC+cy+dt0ngUefYvhEaPRQVHgqkXw2aDgSldmuzrAx/CQIagBSAD4B/RoB7NNDtiebobXK3QJaMEJgYAQkAE+Mmo2JGYDifn9rEda9VCg5van2YAnUoKNg9ZhiMa3dzKEB8AIhuA4DbkOA3ffseei8uWqSNMyuGhIBhBCQAGDYhYscMAsP5o3emRM/rAeANAPh60nQwKOg1w5242CoBDc9rgDuUwt+gots2or5t7uLa80JNCAiBfycgAUBWhBAAgNYnfN2z9vWg4ShAOkprOEgppQRO+AkQwCgC3EEANylSN/bte/Ddcocg/PMqHbRPQAJA+wylQkgJ1Av2vgCUQ1LHgKIj4vo0fkinb8K2SeunQalbEOEmPUo3pQerj0+4mAwUAiEmIAEgxJMn1sdH4MFMZvKUHfHNRGgTkA2A6fFVkKujRqD1DEEC6I9EcBMR3vj0jo//6pBL7h6JWp/SjxDYEgEJALIuIk3gyXx+xvqetVlNeKJCnQFS20W6YWmuLQJa679iAq8HTYNP7/DkTyQMtIVTBhtOQAKA4RMk9sZP4MGTM9tPGk0cp0GfpAjfCgqmjL+KjIg7gdZGRQmA60HBQN9ja2/F5ctH485E+o8WAQkA0ZrP2HbTur3fuyPmFOFC0pCVf/RjuxS60rgGvVpR4jpQeiA5Ov2nODjY7IqQFBUCARKQABAgbJHqLIHWFruPFOe/sQnN05HwBADYobMKUk0I/CcBAngKCa5VCby0b0nlt8JICISVgASAsM5cjH1v3oEPRk4nwDMUwF4xRiGtMxNAoD9ogB80m5uu2mvwJ88x2xF5ITAuAhIAxoVLLuYiQPPm9fi7TzsWCc7Umo6Sd/S5ZkJ0t0SgdfohIA6qJl1iDdR+LZSEQBgISAAIwyzF2ONwPrenTsC7tW6+Wym1R4xRSOthIYBwLxL9EJvNy+WcgrBMWjx9SgCI57wb3/Vwcf6btKYPEdKxCNBjvGExKAT+k8BGArg2AfStPrd6hwASAqYRkABg2ozE2M9dZx7cu+vzuznQVB+FBL0qxiik9YgR0EC/VKi+nixVKghAEWtP2gkpAQkAIZ24KNnefPCO6nkfEXxATtiL0sxKL1sgcB8BfHNtc9qVrxgc3CSEhAAnAQkAnPRjrt1wFuyhcfTjQHgmAsyIOQ5pP04ENKwCpAv11EnfT192/bNxal16NYeABABz5iI2ThqFzF6E6lMAcJocwBObaZdGt0QA9QsE+INe6v3fPd0bhgWSEAiSgASAIGnHXGs4v2BvndCf19BcqEAlYo5D2hcC/yKgYUQr/eOeZuKLfYOVRwWNEAiCgASAICjHXKOen5/Gzf/w61PlH/6YLwZpf+sENGxAhIvU5Elfnn3FdasFlxDoJgEJAN2kG/Paj5ycmd1sqs8TwNvlVb6YLwZpf3wENDwPis5fv67n/H2WLn1hfIPlaiEwNgISAMbGSa4aB4GH80ft0JOY/BkN+sMK1NRxDJVLhYAQeBEB0vppSKiv0OS1F6UvW75B4AiBThKQANBJmjGv1TqRb/L2iQ80kc5WADvHHIe0LwQ6RoA0PIIK/if5+NpL5VjijmGNfSEJALFfAp0B4BfsPCB8DQBSnakoVYSAEPi/BAjgASB9VqpcqwkdIdAuAQkA7RKM+fihhdmDFOG3gOCNMUch7QuBwAhorZci9ZyVGlw2FJioCEWOgASAyE1pMA2tymd23ZRQX9Jav1NO5guGuagIgX8joGEDKPyqnrLmK/J8gKyNiRCQADARajEeQ4sWqeH77zqTqPllQLVjjFFI60LAEAI0hAQfTZarNxhiSGyEhIAEgJBMlAk2W7f7cQS/jwk4zAQ/4kEICIF/EUDAGjbVh/sGlz4kXITAWAhIABgLpZhf82Q+P2Ntz9pzgeiDspFPzBeDtG86gdYRxN9MNKed2zc4uN50s+KPl4AEAF7+xqs3FtpHg9aXEKik8WbFoBAQApsJbH5bAPGMVKlymyARAi9FQAKArI0tEvAX2juB1hcAqNMFkRAQAuEjoLXWCVQXNKeu/W95SDB88xeEYwkAQVAOmUbdyR2PQN8FgFkhsy52hYAQ+L8EiO5XCGf0udU7BI4QeDEBCQCyHv5J4O9b+H4HAE4RLEJACESHgAbdVKC+sek5fc7cWm1jdDqTTtohIAGgHXoRGlsvZo5EwssAsC9CbUkrQkAIvIiAbsKKRILOSLrVuwSMEJAAEPM1MHTGvClq/dQva1QfUQCyHmK+HqT96BMggFEA+NrT2z++6JBL7h6JfsfS4UsRkD/4MV4b9YK9L2hyMYEHxBiDtC4EYkqAfttU0D9nSdWPKYDYty0BIKZLoF7MvouIvqVATYspAmlbCMSegNb6rwmlzki63tLYw4ghAAkAMZv01oN+KjH5EgXQH7PWpV0hIAReggAhnf/0dk98Wr4SiNcSkQAQo/lubeULTbpGoZoTo7alVSEgBMZAAAFvH2lCYa/BSmMMl8slESAgASACkziWFuqO/Q7UcBEomDKW6+UaISAE4kdAAzyDAKelXM+LX/fx61gCQMTnvPWUf2LD9O8QwDsj3qq0JwSEQAcIaABSiN9IrlrzWVy+vPXGgPxElIAEgIhObKutR51j+0Zh9DoAODjCbUprQkAIdIfAr5uYOHFOaekT3SkvVbkJSADgnoEu6fvF3OuhCdeAopldkpCyQkAIRJwAgm4g9s7vKy39Y8RbjWV7EgAiOO2tV/yQ6CIANSmC7UlLQkAIBEiAANYgUdEqVysByopUAAQkAAQAOSgJmjevZ3jW9AsI4INBaYqOWQQ27/lO6hFQsBIJhoBgpUYaAqWeTRCuJQ3rSI+ubfbi2imUWIujo7ghQdNVE6eh6pneRJqOQNMRYSciSCPAHECYA0RprWlPpZQyq2NxEwSB1smCmFCfTJW8bwahJxrBEJAAEAznrqvcv2DBdlOnjgwCqqO7LiYCRhBoPawFTbhXJeA3CPSbJiZuX73dYw93613uFfn8pBk9G+YSNA8HgNchqNcB0cuNgCEmgiFA+MOndlj1/m6tsWCaEJV/EJAAEIG18MjJmdmjm9CTLX0jMJnbaEEDPKwQr1Wgfzo6edLt6cuuf5az60dOO36X5saNhwPQWxDhBAKV5PQj2t0ngKCXY1Of2Dd40zPdVxOFbhKQANBNugHU3ry5j6aKArVnAHIiwUEA8S8EdDUhXZ1eUr2Hw8JYNYcX5l6jm/pEjXiiAthrrOPkunARIICHdLOZmzN441/C5VzcvpiABIAQr4fGQvtoreFqBJgR4jbE+pYIoH4BmokfI9IPkmXvz2GEVHcyr0JS79GoT5UzJ8I4g9vwTPpZpXqO6yst+3kEu4tFSxIAQjrNdSe7EDVeBgp6Q9qC2N4CgdYnKwT69vp1PT/eZ+nSF6IAyV9o70RNehcCfgAQrCj0JD38nYCGDYCUlzcEwrkiJACEcN78Qu4jGukCBSDzF8L525JlAvgVAHzFcr0qth7ui+AP5fMJX607FjR8BhNwSARbjGVLBDCqkE5LlqqlWAIIcdPyD0jIJs93sucB4GdCZlvsvjSB+xDg03E6jpUAcNjJ9TepeZ4cTBWNX43Wa4IJlfhA0q18PxodxaMLCQAhmefWH82Gk/0uAL43JJbF5tYIaFgFCs9JNqdeioODzTjCuuvMg3t3fX6395Gmz6FSL4sjgwj2/GnL9b4awb4i2ZIEgBBMa+vWab1n7aWK8LQQ2BWLWyHQul0KCF+dtEadt8eyZesEFsCDJ2e279V4DjXpLNloKBIr4quW6306Ep1EvAkJAIZPcGt3v/qs6YsVQL/hVsXeNghQk/4ICToj5dZ+L7D+k0C9mDscAX4smwtFYXXQ95P7vOYDuGiRjkI3Ue1BAoDBM7t557XEugEAONZgm2JtWwQ0jEACvvzUdo+fKzuobR1W6/hqtXHGF3Wz+XG5G7CthWX2/0fAJX2PrzldjhQ2d54kABg6N5v/8cd114IC21CLYmsMBHQTVkAvnWL6Bj5jaCXQS4YKmdcCwBUK1dxAhUWsswQ0XJ2kaU5cn3PpLMzOV5MA0HmmbVdsPRy1y7Mzr1ZKLWi7mBRgI6ABBqb2jrxj1pU3r2UzEWLhh/NH7aDUpCsV4vwQtyHWAa9MupXTo/p6a5gnWAKAYbO3+US/mVMHSKnjDbMmdsZIoHUiH4L6dMr1vjHGIXLZSxD4+9svn9eA58i+FyFeJgQXW2VP3mAybAolABg0Ia2n/Rs960pAkDfIllgZBwHS+mlUCcdyK7eOY5hcug0Cdce2kfRVgGpHgRVOAqThgtSA97Fwuo+mawkAhszr3z7p5C4HoFMNsSQ2xk/gvqaizJwlVX/8Q2XEtggM5xfsPZpo3iiHDG2LlLn/HwHPTbqVz5nrMF7OJAAYMt9+f+5boOjDhtgRG+MkoIHu7J00OTP7iutWj3OoXD4OAkP57CxQeLNCeOU4hsmlJhFA/KxVqnzZJEtx9SIBwICZ953cIgA6xwArYmEiBBB+tn5t4tioHN4zEQRBjmkdLgRaewDq8CB1RauDBAjPssqVb3WwopSaAAEJABOA1skhvpP9MADKL0InoQZb64ZNz+nC3FptY7Cy8VZ7/NS3Td840nMtAL4t3iTC2b0GIEQ6M1Wq/jCcHUTDtQQAxnlsFLPFJmFrlz+ZB8Z5mLA0wuLk6LTT5R3nCRNsa2Brr4zpam0ZEY9rq5AMZiHQOkAIVeKklFu5jsWAiMo/PFxroF7MHIkENQA1icuD6E6cgNZ6aerJ9SfKLmcTZ9iJkQ9mMpN7d8QKEh7ViXpSI1gCGvS6BPXMS5aX3Rmssqi1CMgnT4Z1MHxy9pW6ib8EgB0Y5EWyTQIIenlzyvpM+rLlG9osJcM7QODJfH7G+sTaWwHwNR0oJyWCJqD1E80ePEzengkavASAwIk/6hzbtwk23aZA7Rm4uAh2gsDd69cl3iwP/HUCZedqDOeP3nkUen6hEvCKzlWVSkERaG2ZrWHjEXsN/uS5oDRFRwJAoGvg/gULtpsybeQ3CGr/QIVFrDMEEP8yabT5ht0Ha091pqBU6SSBhrNgD4LmrwEg1cm6UisYAoT0E2vVuox8rRYM75aKfAUQEOvNu/ypdUsBIRuQpMh0kEBrhz9SdGjavbHewbJSqsMEVuaPeXkikbhDvl7rMNiAyiHAj5Ku966A5GIvIwEgoCXgFzIXAKqzApITmQ4SIIBRAnxr2q0s72BZKdUlAq1tg0nrpXKccJcAd7usbBTUbcL/rC8BIADUvmOfCQAXByAlEt0ggPBhq+R9uxulpWZ3CDQK9tmEcG53qkvVbhJo7RGQACwm3Uq5mzpSW74C6PoaGHJy85Smm0FBb9fFRKDjBAjpx6lS9R0dLywFu07A77cHQcFJXRcSgc4T0LBBo35zuly7vfPFpeI/CMgdgC6uhYfzuWQiQXchwK5dlJHSXSJATbhjZI1+k+zy1yXAXS7b2i1w/abe2+TcgC6D7lJ50vDIZNKvloduuwRYHgLsHtihM+ZNURum/woADu6eilTuFgGt9V97e+GA2Ytrj3RLQ+p2n0DrBMFmovl7BJjRfTVR6AKBW5P7HPo2XLRId6F27EvKHYAuLQHfyVwGoE7vUnkp220CBP1W2RvstozU7z6BumO/EwFkz/nuo+6KAgGcl3K9s7tSPOZFJQB0YQHUC7kPIpI8NNYFtsGU1Jdbbu2MYLREJQgCDce+hgBOCEJLNDpLoPVQoCJaYJWrlc5WlmoSADq8Boad7GFa4y/lob8Ogw2onCa9cuP63oNkp7+AgAcks3mnQFR/UkrtEZCkyHSSAOlnSfe8OjW4bKiTZeNeSwJAB1fA5nPKm/B7QLA6WFZKBURAg24iqDemXO83AUmKTIAE/H77KK3gZjl9M0DonZRq4u/19DWvkzM4OgdVAkDnWMJQIbtUIc7vYEkpFSABQvhSquT9d4CSIhUwAdmQK2DgHZZDgEuTrvfODpeNbTkJAB2a+nrR/jgSfKND5aRMwAQI4IGR5/QB8spfwOADlmu9GrhpJHEvgUoGLC1yHSJAAO9Kud6POlQu1mUkAHRg+uV7/w5AZC5BGo5MDXg/Y7Yh8gEQ8AvZHCAuC0BKJLpBQMOGJuJr55Qrf+hG+TjVlADQ5my3TvibPHXkHoVqTpulZDgTAY10RbpUlVc2mfhzyMpbARzUO6fZOj54dI0+WO7YtcdUAkB7/GComL1cEZ7WZhkZzkRAg149GXv22aO07GkmCyLLQGDz0cG6eR8o2J5BXiQ7QICQzk+Vqh/vQKnYlpAA0MbUNwq2QwilNkrIUGYCSPiOZLnyY2YbIs9AwC/aHwKCCxmkRbIDBFr7A6CGt8hXdxOHKQFgguxa+/z3qOYfANWOEywhw/gJ/Npyvdfz2xAHHARo0SLVWHHXXZCgV3Hoi2b7BBB0Y6Q5csBegz95rv1q8asgAWACc04AOOxkfkqg5k1guAwxhIACem2fW73DEDtig4FAvZg5EkndyiAtkh0jgFdabkW+hp0ATwkAE4DmO9kPA+C3JjBUhhhCQAMMpF2vYIgdscFIwC/YHiBkGS2IdNsEMG+5lavbLhOzAhIAxjnhwwtzc0d18x4Fato4h8rlxhDQm6jZs49sK2rMhLAa8YvzX6Fp9A8KVILViIhPmEDrYV5o4v7pwerjEy4Sw4ESAMYx6Zu/M7z/zl8CwOvGMUwuNYwAabggNeB9zDBbYoeRgF/I/QCQ3sVoQaTbJICAtaRbkTs54+AoAWAcsGS3v3HAMvVS0s8qrffqG7zpGVMtiq/gCQzls7MA8SGlYHrw6qLYKQJI8P5k2ftep+pFvY4EgDHO8HB+wd4am38CBVPGOEQuM5EA4qesUuVrJloTT7wE/KL9BSD4PK8LUW+HAAGs6UnofWcvrj3STp24jJUAMMaZ9vtzt4KiI8d4uVxmIAHS+ukpk5upWVfevNZAe2KJmcDQGcftqNaN+LI5EPNEtCmPWl+XHKid0GaZWAyXADCGaW4Ucm8npEvHcKlcYjIBxM9apcqXTbYo3ngJ1B37SwjwWV4Xot42AcQFVqki5z1sA6QEgG0AWllcsBtS814FsHPbi1IKsBHQAM9sXJdI7bN06QtsJkTYeAKPnHb8LqObNtURYIbxZsXgSxJobRA0qbe5n9zt2/oikQCwjV8i38m6ACjvi4f9jw3BOVbZ+2LY2xD/3SfgF7JfBcRPdl9JFLpJAAG+kXS9T3RTI+y1JQBsZQb9YvatQHhz2CdZ/MNzo82NlmwXKithLAQeOvVtMxMjiSHZ62MstMy9hgBGE5g4uK+09I/muuR1JgHgJfivyOcnzehZ/0cgejnvFIl6uwQQ8NykW/lcu3VkfHwI1Pvt81HBR+PTcVQ71bcl3doRCEBR7bCdviQAvAQ9v5j7DBCd1w5cGWsAAQ0behOqT477NWAuQmRhOJ/bs5mg1rMAPSGyLVa3RADpvVaperHA+U8CEgC2sCpaJ/2pRPM+uQUY/l8ZBPhR0vVkh7fwT2XgHdSLmRKScgIXFsHOEiD9bFP17jOntPSJzhYOfzUJAFuYQ7+QuxqQTgz/9EoHKkEH9C2u/klICIHxEhhemHuN1iSnRY4XnIHXI+CSpFs52UBrrJYkAPwf/HI8KOt67Ky4xp9aA5W3dLaoVIsTgYaTu42AXhunnqPaqyZ9eLpcuz2q/U2kLwkAL6LWOuzHX/Hb32MCD5gITBljFgEEODbpekvNciVuwkSgUbAdQiiFybN4fUkCv7Zc7/XC518EJAC8aDX4jn0mAMjDIhH4DdEAD6f2OfT/4aJFOgLtSAtMBGjevB5/5vQhVDCbyYLIdpAAIZ2UKlWv6WDJUJeSAPD36Xvw5Mz2k0YSD4KimaGeUTH/NwKEZ1nlyrcEhxBol4Dv2J8CgK+0W0fG8xMggIee3v7x/Q655O4Rfjf8DiQA/H0OZPcv/sXYKQca9HrdHNldNv7pFNF411mVz+y6CdWjoKA33iSi0j19xHKrF0alm3b6kAAAAK3X/noS9AAATG4Hpow1hsBVluudaowbMRJ6AvJmUOin8J8NaNCrdXNkL/mAACABAAB8J3MZgDo9Oks83p0oVPP6Sst+Hm8K0n0nCdQLmQyiqnayptRiJED0NatcbX21E+uf2AeARsHev0n6D0opFeuVEJHmNekH0+Xa/4tIO9KGIQQ2vyF0752+PAxoyIS0a0PDhmYP7TNnSdVvt1SYx8c+APhObhkA5cI8ieL9RQSIPmOVq/LAliyKjhNoOPYXCUDOlOg4WaaCCIutkncKk7oRsrEOAA3HfgMB/MKImRATbRNonf4FPaPJ1FU3rWq7mBQQAv+HQD0/P00J/bCSr04jsTY0ACkFh1pLvLsj0dAEmoh1ABhysr9QgG+YADcZYiABrfXS9EDtWAOtiaWIEPAd+ycAILtLRmQ+Aehmy60eHZl2xtlIbAOA328fBQpuGScvudxgAkRwYqrsXWuwRbEWcgJ+0T4FCK4MeRti/0UElMLD+pZUfhtHKPENAI79awB4XRwnPZI9a3heT1u7W/qy5Rsi2Z80ZQSB+xcs2G7qlOaToGCKEYbERPsENHjWgBfL58BiGQAaC+2jScON7a8cqWAKAY10RbpUlVc5TZmQCPuQPQGiN7lE6uBUednvotfZ1juKZQCo5+3bMQGHxW2yo9wvkc6myrValHuU3swg4Du5kwBo0Aw34qITBFDr65IDtRM6UStMNWIXAIaL2WM0ofxDEaZVug2vrZ29Uo+vn4XLl49GqC1pxVACw/n8VN2z5gkgtZ2hFsXWOAm03gjoSdCBfYurfxrn0FBfHrsAIE/+h3q9btG8Bn1J2q29J3qdSUemEvCL9lVAcLKp/sTX+AlogIG06xXGPzK8I2IVAPz+zBGg1K/CO13ifEsESMORqQHvZ0JHCARFwC9kc4C4LCg90ek+Aa21RlT7p8refd1XM0MhXgGgYHuAkDUDvbjoCAENq5L7HTobFy3SHaknRYTAGAjcdebBvbs8P+txBbDzGC6XS8JCIGa7A8YmAKws5A5MIN0TlnUoPsdIgOBiq+y9d4xXy2VCoGMEfMdu7QcQ661kOwbTkEIadLNHJfbtW1J50BBLXbURmwBQL2ZKSMrpKk0pHjgBefo/cOQi+HcC8jZAZJfCZZbrvT2y3b2osVgEgJULsxZqeliBSsRhUuPSIwGsGXlOv2xurbYxLj1Ln+YQeDKfn7E+se5pAJhsjitx0jYBDSM0adSKw5kisQgA9X77fFTw0bYXhhQwiwDhNVa5cpJZpsRNnAj4hcyNgCq2e8lHdq4RvmiVvHMi29/fG4t8AHjw5Mz2k0bUMCjYPuqTGbv+CE+3ypUrYte3NGwMgUbBfh8hfNcYQ2KkMwS0fmINzUi+YnBwU2cKmlkl8gGgUch9jJC+aSZ+cTVRAq2HdXonTdlt9hXXrZ5oDRknBNolMJzP7akT9Ei7dWS8gQRi8AEj0gGA8vlEQ617GBAsA5eXWGqHAMIvrJL3pnZKyFgh0AkCvpO5G0C9uhO1pIY5BKgJd6UGvUPNcdR5J5EOAPKUbucXjCkVCeG/UiVP7uyYMiEx9uE72XMAcFGMEUS2dQI4IuV6v4lqg5EOAHUnuxwB5VNiBFcvErwyWfb+HMHWpKWQERgqZF6rUN0WMttidwwEor49cGQDgF+c/wogLf9AjGGRh+4SDausAW+P0PkWw5Ek8LevGtc8Dah2jGSDMW6KAEYTTUz1DVYejSKGyAaAesG+CBHeH8VJi3tPGumKdKl6etw5SP/mEGg49jUEELvjZM2Zge45IYDzUq53dvcU+CpHMgDcv2DBdlOnjzwqx3XyLayuKiOcapW8q7qqIcWFwDgI+MXse4Dw++MYIpeGhABp/TRNW9+Xvmz5hpBYHrPNSAaARtF+PxFcNGYKcmFoCLTO7YYm7ZEerD4eGtNiNPIE6vn5aUzolZFvNKYNEsA7U653adTaj2QAqOezf8AEHhC1yZJ+AKhJf0wNVg8UFkLANAJDjv2QAtjLNF/ip30CGujOtFt9TfuVzKoQuQDQKMw/lFD/1izM4qZTBJDgm8my91+dqid1hECnCPhO9nsAKCdTdgqoaXWa+hXWYO1e02y14ydyAWDIyVysQJ3ZDhQZay4BVHBMcol3k7kOxVlcCdSd3PEIdG1c+49834hft0qVT0apz0gFgMfmz582MlWvkn3/o7RE/9VL65WcKb0jO8668ua10exQugozgUdOO36XkU2bnlIAkfq7GuY56ah3DauSNK0PB+8yTCoAACAASURBVAebHa3LWCxSC7XhZM8gwB8z8hTpLhKI6vdwXUQmpQMm4BftFUCwX8CyIhcQAQLIpVzPC0iu6zKRCgB1x/4lAry+69REgIWAfP/Pgl1Ex0HAL9jfB4T3jGOIXBomAhqutga8fJgsb81rZAKAv9CeAxoejsrESB//SQCJjkuWqzcIGyFgKoG6k12IgItN9Se+2iawUTVH9+gbvOmZtisZUCA6AaBgfx4QvmAAU7HQBQKt9/97mqMvi8ovXhcQSUkDCDzqHNs3CqMNA6yIhS4RIKAPptxqJPaZiUwAGCpkHlCo5nZpzqUsMwHdhBXpQW9/ZhsiLwS2ScAv2HU5gnybmEJ7QZSOCY5EABh2sodpwNtDu6LE+DYJEMD3Uq4nZztsk5RcwE3Ad+wrAeAUbh+i3z0CUTmNNBIBoNGf+w4p+kD3plsqcxNApIXJUrXE7UP0hcC2CPiO3dqH5OJtXSf/P7wEovJAcugDAM2b1+PPnLoKlXpZeJeTON8WgdEmWnsNVuS71W2Bkv/PTsDPZ/aDhFrBbkQMdI+A1k8kacaeYd8TIPQBYLiYPUYT1ro301LZAAKPW663uwE+xIIQ2CYBWrRINf5yx7NyGuk2UYX6Ag345rRbWR7mJkIfAOrF7KVI+PYwT4J43zoBTbQsXa4uEE5CICwEGk7mZwRqXlj8is/xE0CA7yRd70PjH2nOiFAHgLvOPLh3l2dnPqGU2skcpOKk0wQI4PMp1/ufTteVekKgWwT8QvargBipfeO7xSqsdTXoR1NurQ9bR5SH9CfUAaDu2DYCVELKXmyPkYAcADRGUHKZMQTqxeyJSHi1MYbESFcIaNKHp8u10L6BFuoAMFTMXq4IT+vKzEpRcwgo2Nla4v3VHEPiRAhsnYBsCBSPFYIA30i63ifC2m1oA8CKfH7SjMS6JwFgh7DCF9/bJkAAD6VcTzZ42jYqucIwAr5jrwKAWYbZEjsdJUBDllud09GSARYLbQCQp/8DXCWMUgi4JOlWTma0INJCYEIEhgrZpQpx/oQGy6DQECDQr065td+HxvCLjIY2AMipW2FcbhPwjPBRq+T97wRGyhAhwEqgUbDPJoRzWU2IeNcJIOC5Sbfyua4LdUEglAGAALDRbz8KCuTd8C4sCpNKoqY3JQeqvzDJk3gRAmMhUF+Yy6KmyJwdP5aeY3rNfZbr7RfG3kMZAGTv/zAutYl51lN6d0pfdv2zExsto4QAH4HhfG5PnaBH+ByIclAEiGC/VNm7Lyi9TumEMgD4xdyXgejTnYIgdQwlQOBbZS9lqDuxJQS2SWDIyTytQO2yzQvlglATIKDPpdxq6L7uCWkAsFcAQShvuYR6lQdsXmu9ND1QOzZgWZETAh0j4PfnbgVFR3asoBQyk0ATf28NVl5tprmXdhW6AFDPz09jQq8MG2jxOwECCF+0St45ExgpQ4SAEQTq/fb5qOCjRpgRE10joFu7ATZpj/Rg9fGuiXShcOgCQKNov58ILuoCCylpGAEiODFV9q41zJbYEQJjJuAX7dOB4LIxD5ALQ0yATrPc6pVhaiB0AcB3cssAKBcmyOJ1YgSQ9N7Jcu3hiY2WUUKAn8DQwuxBSmMo3xHnpxc6B1dZrndqmFyHKgA8mMlM7tkBnlGgpoUJsnidAAHULyRLtR3CfNDGBLqWIREjsHnHUly3BhT0Rqw1aec/CTyedL09wvQ3K1QBoFHIvY2QbpKVFwcC+jbLrb0uDp1Kj9EmMFSw/6gQXhntLqW7FoEm4UFzypU/hIVGqAKAX8hcAKjOCgtc8dkGAcIfWuXKu9uoIEOFgBEE6sVMCUk5RpgRE90lgPgpq1T5WndFOlc9VAFgKG//WSXgFZ1rXyqZSgAJP54sV8431Z/4EgJjJeA72XMAcNFYr5frQk3gVsv1jgpLB6EJAEP57CyVwNbpWvITAwKk0E4tqVRj0Kq0GHECfjHbD4TliLcp7f2NwEbVnLZT3+Dg+jAACU0AqDvZhQi4OAxQxWP7BKip5qQGlw21X0kqCAFeAsMnZ1+pm/hHXheiHhQBhZTpK1VvDEqvHZ3QBICGY/+IAN7RTrMyNhwENOj1qX0Om4GLFulwOBaXQuClCfz97aW1ClRCOEWfAGm4IDXgfSwMnYYmAPgFuw4IVhigisf2CCDQH5Ju9aD2qshoIWAOgSHHfkgB7GWOI3HSLQK6CSvSg97+3arfybqhCACNQmYvQvVQJxuXWiYToLLlVuWpaZOnSLyNi4BsYDYuXKG/WDVxdt9g5VHTGwlFAKg79jsR4IemwxR/nSJAiyy3+oVOVZM6QoCbgF/MfQ2IPsHtQ/QDIoBwqlXyrgpIbcIyoQgAQ8Xs5YrwtAl3KQPDRQCpYJWqA+EyLW6FwEsTaBRybyekS4VRPAgQwPdSrvd+07sNRQDwnexKAEybDlP8dYaAVvSq9JLqPZ2pJlWEAD8Bvz9zBCj1K34n4iAIAmF5jsn4ADCcz+2pE/RIEJMmGmYQWL8usf0+S5e+YIYbcSEE2idQP+Xo3XG057H2K0mFMBDQoJsb1/XuZPrfMeMDQKNgO4RQCsOki8f2CRDAUynXm9l+JakgBMwiMORkWq8CykFmZk1L99wgvc0qVW/pnkD7lY0PAHXH/i4CvK/9VqVCGAgg4O1Jt3J4GLyKRyEwHgKylfl4aEXhWvMfZjY+AMhJWlH4RRhHDwiLrZJ3yjhGyKVCIBQEhvozNyilFoTCrJjsAAG62XKrR3egUNdKGB0A7l+wYLvJU0aeVUqprhGQwmYRQPiiVfLOMcuUuBEC7ROo99vno4KPtl9JKoSEwHPJfQ7d2eQdTY0OAPV++82o4KchmWyx2QkCCGdYJe/yTpSSGkLAJAL1Qu6DiPRtkzyJl+4SUAk6oG9x9U/dVZl4daMDgF/IfhoQvzzx9mRk6AggvsEqVeR1qdBNnBjeFoF6IZNBVHLC5bZARen/I73XKlUvNrUlowNAvZC9DhGPMxWe+Oo8AeoZ3SN11U1y7HPn0UpFZgIr88e8PJFI3M9sQ+QDJYBXWm7F2E3sjA4Afr/9GCjYPdD5EjE2Aq1TANNuTV6TYpsBEe4mgRX5/KRpuGa9PNPUTcpm1dYAD6ddb2+zXP3LjbEB4FHn2L5RGG2YCk58dYEA4l+sUmWfLlSWkkLACALyocaIaQjUxEjvyG57X3nzk4GKjlHM2ABQd3LHI9C1Y+xDLosAAUL6SapUfWsEWpEWhMAWCfhO9g4AfI3giQ8BUminllSMfPbD2ADQcHL/Q0D/HZ9lIp0S0o9Tpeo7hIQQiCoBv5C7GpBOjGp/0tcWCBB9xipXv2IiG2MDgN9vV0CBbSI08dQlArIHQJfASllTCPiFzAWA6ixT/IiP7hMg1G6qVCt2X2n8CsYGgKH+zKNKqT3G35KMCCsBQnp3qlT9YVj9i28hsC0CDSf7UQI8f1vXyf+PFIH7LNfbz8SOjAwAK4sLdktQ83ETgYmn7hFABcckl3g3dU9BKgsBXgK+kzsJgAZ5XYh6kARaJwPClPUz0pct3xCk7li0jAwAw8XsMZqwNpYG5JoIEWjqV1iDtXsj1JG0IgT+jcCwkz1MA94uWGJGQMEh1hLvbtO6NjIAyA6Api2TYPxMbU7bbubg4Jpg1ERFCARPoOEs2IOg+WjwyqLISYAA3plyvUs5PWxJ28gAUHfsJQhg5EMTpk1gZPyQftYq13aKTD/SiBDYAgFatEg17r1zAyjoFUDxIaCRvpUuVY17+NPMAJDP/gETeEB8lod0qpuwIj3o7S8khEDUCfgFuw4IVtT7lP7+RQBBL0+6tTebxsS4AEDz5vU0Zk1v3QaebBos8dNVArdarndUVxWkuBAwgIBsBmTAJARsQQM8k3a9XQKW3aaccQGgXrD3RQR5EGybUxexCxAWWyXvlIh1Je0Igf8gMNSfuUEptUDQxItAIqH7Zi+uPWJS18YFAHlNxqTlEZwXJPhmsuz9V3CKoiQEeAgMOZmLFagzedRFlYsAAeRSrudx6W9J18QAsAiAzjEJknjpPgEC+ETK9b7RfSVREAK8BPyi/QUg+DyvC1EPmgACnJ10vfOC1t2annkBoGgPAEHeJEjiJQACCKdaJe+qAJREQgiwEmgU7PcRwndZTYh44AQQcEnSrZwcuPBWBI0LAHV5A8Ck9RGgFzzKciu3BigoUkKAhUCjOP84In0di7iIMhKg31pu9TBGA/8hbVQAIACsO5k1CtQ0kyCJlwAIoNrfKi1bEYCSSAgBVgJDhcxrFarbWE2IeOAETHwTwKgA8KhzbN8ojDYCnxkRZCeQmDTpZbOvuG41uxExIAS6TGDIOSalIDHUZRkpbyABPaV3p/Rl1z9rijWjAoDfbx8FCm4xBY74CIqA3pR0a1MQgIJSFB0hwEVg6Ix5U9SG6eu59EWXjwACHZp0q3fxOfh3ZaMCQKNov58ILjIFjvgIhoDW+rH0QG3PYNRERQjwE/D77edAwfb8TsRBkAQQ0Em6lXKQmlvTMioADBWz/6sIP2IKHPERDAFN8Kd02ZOtn4PBLSoGEPCd7EoATBtgRSwESAAJ/jtZ9r4UoORWpYwKAH6/XQEFtilwxEcwBEzdJzuY7kUljgTqeftOTMAhcew95j1fZrne201hYFYAKNorgGA/U+CIj4AIEF5jlSsnBaQmMkKAnYBfyNwIqI5mNyIGAiWggX6ZdqtvDFR0K2JGBYAhJ7NWXgE0ZWkE50ODviTt1t4TnKIoCQFeAg0nt5iAFvK6EPXACWhYZQ14ewSu+xKCxgSAh05928zekd4nTAEjPoIjQADnpVzv7OAURUkI8BLwC/aFgPAhXheizkGgd62avseyZes4tP+vpjEBYNjJHqYBbzcBingIlgASfjxZrpwfrKqoCQE+An7B/jwgfIHPgShzEVAJOqBvcfVPXPov1jUmADQKtkMIJROgiIeACSCcYZW8ywNWFTkhwEag7mQ/gIDfYTMgwmwECPCElFsxYitoYwKAX8x9BoiMOimJbYXETZhovlWuVuLWtvQbXwLygSe+c2/SyafmBAAn+z0AfG98l0V8OyfE16VKFdkbPb5LIHad+8XsW4Hw5tg1Lg0DaLzQGqgYsd+NMQFgqJBdqhDny/qIHwGNat90adn98etcOo4rgXph/qsR9d1x7T/WfSMMWiWv3wQGxgQAP5/7HSToVSZAEQ/BEqCe0T1SV920KlhVURMCfASGF+bmak0P8DkQZS4CBPCrlOu9gUv/xbrmBID+3BOgaKYJUMRDsAQm947MmHXlzWuDVRU1IcBHQF575mPPrawBHk673t7cPlr6RgSAFfn8pGmJdRuUIX5MmJi4eCCA0ZTr9calX+lTCLQIyImA8V0HGvS6tFubbgIBIwKAnI9twlLg8aC1/mt6oLYzj7qoCgE+Ar6T2QigJvE5EGUuApsSeoe5i2vPc+n/Q9eIAOD3Z44ApX7FDUP0WQjULdeTU9FY0IsoJ4F6f+YpVOplnB5Em4dAs9ncZ87gjX/hUf+XqhkBwMmdBECD3DBEP3gC1KQ/pgarBwavLIpCgJfAkGM/pAD24nUh6hwENOCb025lOYf2izWNCACyKxb3MuDTN+10LD4Sohw3AvLmU9xm/EWfvJEWJktV9p1vjQgAftH+AhB8Pr7LIcada/CsAS8XYwLSekwJ1J3scgR8U0zbj3Xbppx/YkYAkF0AY/vLgIBLkm7l5NgCkMZjS2CoP3ODUmpBbAHEuHEE+EbS9T7BjcCIANDoz1xLSh3PDUP0OQjQ9y23+j4OZdEUApwEfMe+EgBO4fQg2kwEEBZbJY997o0IAL5jt94AOIJpKkSWkQAhnZ8qVT/OaEGkhQALgSEnc7ECdSaLuIjyEtD4U2ug8hZeE4ZsvDNUyDygUM3lhiH6wRNAwHOTbuVzwSuLohDgJeAXMhcAqrN4XYg6E4H7LNfbj0n7n7JG3AEY6s88o5TaiRuG6DMQQPysVap8mUFZJIUAK4G6Y38JAT7LakLEeQhofNIaqOzGI/4vVfYAQABY78+MKqUUNwzRZyBAeJZVrnyLQVkkhQArgYZjf5YAvsRqQsS5CGy0XG8Kl/g/dNkDwNAZx+2oNoz8lRuE6HMRwDMtt/IDLnXRFQJcBPyifRYQXMClL7q8BDY9p6fMrdU2crpgDwD1/Pw0JvRKTgiizUeACE9JlSuL+RyIshDgIeA7dusBwIt51EWVm8Ckpp65+2DtKU4f7AHAX2gfDBru4oQg2nwECPCElFu5js+BKAsBHgJ+0T4FCFqvAspPDAmoZmJu3+DShzhb5w8A/fZRoOAWTgiizUcAFRyTXOLdxOdAlIUAD4F6wT4BEa7hURdVdgIKDrGWeHdz+uAPAAU7DwgDnBBEm48AArwx6Xq/5HMgykKAh8BwMXuMJqzxqIsqNwFC/ZZUqfZTTh/sAaBezL4LCeUhMM5VwKhNpA5OlZf9jtGCSAsBFgINx34DAfyCRVxE2QkgquOTpWXXcxphDwANJ/tRAjyfE4JoMxJAtb9VWraC0YFICwEWAsMLc6/Rmu5gERdRfgIIZ1gl73JOI+wBoO7Yn0OAL3JCEG0+Akrh/+tbUnmQz4EoCwEeAkMLswcpjb/nURdVfgL0EcutXsjpgz0A+MXc14CI/VQkzkmIs3ZTUWrOkqofZwbSezwJ+PnMfpBQcvcrntMPBPD5lOv9D2f77AGg7tjfRQA5DY5zFTBqU8/oHqmrblrFaEGkhQALgeH8gr11oil3v1jo84uacCQwewDwndwVAHQq/3SIAw4CiUmTXjb7iutWc2iLphDgJPBwPpfsSZDc/eKcBF7tH1iux3oaJHsAaPRnriWljuedB1HnIrB+XWL7fZYufYFLX3SFABeBoXx2lkqg3P3imgBmXQ0wkHa9AqcN9gDgO9mbAPBtnBBEm4+ACfth83UvynEmMJw/emed6JG7XzFdBAhYS7qVLGf7/AGgaP8cCN7ICUG0+QgkXU8htJ6HkR8hEC8CT+bzM9Yn1sndr3hN+z+7JaSfpErVt3K2zx8AnOwdAPgaTgiizUOAAEZTrtfLoy6qQoCXwIp8ftKMxDrW0+B4CcRbnYB+nnKr8zgpsAeAhpO9hwAP5IQg2jwENOh1abc2nUddVIUAPwHfseXuF/80cDn4jeV6R3CJt3TZA4BfyN4HiPtwQhBtNgLPWa63I5u6CAsBZgJ+v70JFMhdMOZ54JDXQHem3Srr3W/+AODYQwCQ4pgA0eQloLX+a3qgtjOvC1EXAnwEfMfeAACT+RyIMhsBgnussvcqNn0j7gD024+Bgt05IYg2DwENenXarb2MR11UhQA/gSEns06BmsrvRBwETUA3YUV60Ns/aN0X67HfARhy7NUKQD4Fcq4CJm0CeCrlejOZ5EVWCLATGOq31ygF8hwM+0wEb4AAHki53suDV/6XInsA8Pvt50DB9pwQRJuJgNZPWAO1WUzqIisE2An4xczzQGo7diNigIEADVludQ6D8D8l2QNA3bFfQIAZnBBEm4mAhlXWgLcHk7rICgF2Ar5jPwsAO7AbEQOBEyANj6QGvL7AhV8kyB4A5Dswzunn1dagH027tdm8LkRdCPARGOrPPKOU2onPgSizETDgDih7AJCnYNmWnwHCNGy51aQBRsSCEGAhMORknlagdmERF1FWAhrgmbTrsc49fwCQ92BZFyGrOIFvlT15BZR1EkSck0DdsZ9EgF05PYg2EwHUL1ilGuvzb+wBYMjJjCpQCaYpEFleAnXL9dK8FkRdCPAR8Pszj4NSu/E5EGU2Aho2WAMe6yug7AFAtsJkW37swpr0ynS5the7ETEgBJgI+LIPChN5flkTzkJhDwBDjq2VAVsS8y+H+DnQAA+nXW/v+HUuHQuBvxEYcjKPKFB7Co/4EdAAlHY9xdk5ewCQvbA5p59bm/89WG4Coh9vAr5jrwIA2QsjlstAb7LcGus20OwBYMjJrFWgpsVy/uPetDwEGPcVEPv+/f7cE6BIdsOM4UrQGtamBzzWPXDYA4BshBHDlf/PluU1wDjPvvQOUO/PPIVKyXkYcVwMpJ+1yjXWPSDYA4C8BxvHlf+3nk3YCSu+9KVzEwjIWSgmzAKPBxPOQmEPAPIdGM/iM0FVa/1YeqAmD0CZMBnigYWAX8j8FVDtyCIuoqwETPj7Z0AAyDYAkHU/ZNZVEG/xxy3Xk6Og470GYt29HIYW4+k34Bko9gAwVMg8rFCxnogU4yXI27rGJ62BimyCwjsLos5IQA5DY4TPLE0AD6Vcby6nDfYA4Bdz9wMR65nInBMQZ23S+unUQE22QY3zIoh573IYWqwXwH2W6+3HSYA9ANSdzJ8Q1P6cEESbh4AJh2HwdC6qQuBvBOQwtPiuBGrSH1OD1QM5CbAHAL9g/x4QDuKEINpMBAx4DYapc5EVAn8PAJmNAGqS4Iglgbst1zuEs3P2ADDkZH+rAA/lhCDaPAQIYE3K9bbjURdVIcBPYKg/01RKsW4Hy08hng4Q8PakWzmcs3v2AOA79q8B4HWcEESbiwD/VphcnYuuEKB583oas6aPCIl4EtBAv0y71Tdyds8eAOpOdjkCvokTgmjzEDDhMAyezkVVCAA8Nn/+tJHpeq2wiCkBjT+1Bipv4eyePwAUs7cg4VGcEESbj8BT2z8+6ZBL7pZPQXxTIMpMBIbOOG5HtWHkr0zyIstNgPRNVrl2DKcN9gAwVMguVYjzOSGINh+Byb0jM2ZdebN8CuKbAlFmIvDQqW+b2TvS+wSTvMgyEyCi61Pl6vGcNtgDgO/YVwLAKZwQRJuRgIKdrSWefApinAKR5iHwyMmZ2c2mGuZRF1V+Avpyy62dwemDPQA0+nPfIUUf4IQg2nwEmpiYNae0VD4F8U2BKDMR8Bfac0DDw0zyIstNQOOF1kDlI5w22ANA3bG/hACf5YQg2nwEeqAnuad7g3wK4psCUWYiMFScv48ifR+TvMgyE0CA/0m63uc5bbAHAL+Y+yQQfZUTgmjzEUDSeyfLNfkUxDcFosxEYLi44ABNzT8wyYssMwFC+K9Uyfsmpw32ANBwcu8loO9xQhBtPgJEsF+q7MmnIL4pEGUmAg0newgB3skkL7LsBPBMy638gNMGfwAoZotEuIQTgmjzEWgSHjSnXJFPQXxTIMpMBOqO/ToEaG2EJj9xJIBUsErVAc7W2QNAfWEui5o8TgiizUeAEF+XKlVu43MgykKAh4Dfbx8FCm7hURdVbgKo4JjkEu8mTh/sAcDvzxwBSv2KE4JocxLAoyy3ciunA9EWAhwEGo69gABu4NAWTX4CmvTh6XLtdk4n7AGgUbD3J4Q/cUIQbUYCiAusUmUZowORFgIsBBoF2yGEEou4iLITMOH5J/YA8HA+l+xJkM8+G2KAhQACOkm3UmYRF1EhwEig7tjvRIAfMloQaUYCqomz+wYrjzJaAAMCwFE79CQmP8sJQbT5CCDhO5Llyo/5HIiyEOAh4BftDwHBhTzqospNYGpz2nYzBwfXcPpgDwC0aJGq33/nqAL+MMI5EXHVJsIPpcqV78S1f+k7vgR8x/4UAHwlvgTi27kG3Uy7tR5uAuwBoAXA77efAwXbc8MQfQYCiJ+ySpWvMSiLpBBgJeAX7S8AAetOcKwAYiyutf5reqC2MzcCMwJAwa4DgsUNQ/Q5COAXLLeyiENZNIUAJ4GGY3+dAP6L04NocxGgIcutzuFS/4euEQGgnrdvxwQcxg1D9BkIIH7dKlU+yaAskkKAlUDdsb+LAO9jNSHiXAR+Y7neEVziZgWAQvY6RDyOG4boB08ANV6UHKh8MHhlURQCvAR8x249/Mp6HCwvgRirE15jlSsncRMw4w6AJGHudcCmr5GuSJeqp7MZEGEhwESg4djXEMAJTPIiy0gAAb6TdL0PMVrYLG1KAPgcAnyRG4boB0+AiK5PlavHB68sikKAl0C9mL0FCY/idSHqHAQQ4Oyk653Hof1iTTMCQDH7LiRkPRWJeyJiq4/wM6vkHRnb/qXx2BIYcrK/VYCHxhZAjBs3Zf8TIwKAX8jmAFG2g43nL8TdlusdEs/Wpes4E/CLufuB6OVxZhDX3hVSpq9UvZG7fzMCwEL7YNBwFzcM0Q+eAAE8lHK9ucEri6IQ4CXgO/YqAJjF60LUOQiYcgy6EQGg4SzYg6DJuicyxyIQTQACeCrlejOFhRCIG4EhJ7NWgZoWt76lX4CR3pHd9r7y5ie5WRgRACifT9RxzSallOIGIvqBE9houd6UwFVFUAgwEqB583oas6aPMFoQaSYCBDBqud4k3Pz5h/fHiADQQuD3Zx4HpXbjxSHqHAQ2PaenzK3VNnJoi6YQ4CAwnD96Z53oWc2hLZq8BDToR9NubTavi7+pmxMACvbvAeEgE6CIh2AJTGrqmbsP1p4KVlXUhAAfgSHnmJSCxBCfA1HmIkBNuCs16Bnx9ocxAaDh5KoElOGaFNHlI6Caibl9g0sf4nMgykIgWAIrC7kDE0j3BKsqaiYQ0ETL0uXqAhO8GBQA7B8RwDtMgCIegiWAQIcm3aq8BRIsdlFjJDBcnP8mTXo5owWRZiKgQV+SdmvvYZL/N1mTAsAXCeBzJkARD8ESQAXHJJd4NwWrKmpCgI9AvZg9EQmv5nMgymwECM6xyp4RO98aEwD8on06EFzGNikizEaAgE5OudUlbAZEWAgETMB37DMB4OKAZUXOAAJEeEqqXFlsgBWDHgIs5l4PRL80AYp4CJgAwoetkvftgFVFTgiwEfCLuc8AEfte8GwAYiysSR+eLtduNwGBMXcAhvLZWSqBrZ2x5CduBBC+aJW8c+LWtvQbXwL1YvabSPix+BKIb+e9qHbdo7TsaRMIGBMAWjDqjv0CAswwAYx4CI4AarwoOVD5YHCKoiQEeAn4TuYyACXHYPNOA4f6c5br7cghvCVNswJAPvsHDRcsOwAAIABJREFUTOABpsARH8EQINRuqlQrBqMmKkKAn4Dv5JYBUI7fiTgIloD+neXWDg5W86XVjAoADce+hgBOMAWO+AiGgNZwS3rAe1swaqIiBPgJNJzcbQT0Wn4n4iBIAhpgIO16hSA1t6ZlVADwC9mvAuInTYEjPoIiYFYqDqpr0YkvgaFC5gGFSk7BjNkSIIDzUq53tiltmxUA5NUYU9ZFsD4IfKvspYIVFTUhwEdgyLFXK4Cd+RyIMgcBAnhnyvUu5dDekqZRAaBezByJpG41BY74CIaABr0u7damB6MmKkKAl0DrJMD6rOmblEFnsfASiY86anpTcqD6C1M6NioAPJzPJXsS5JsCR3wER2BTQu8wd3Ht+eAURUkI8BAYzuf21Al6hEddVDkJICT2TLpLH+P08GJtowIALVqkGvffuQ4AJpsCSHwEQyBB9PLZ5eoDwaiJihDgI+AvtA8GDXL2Bd8UsCi37nSm3NoMBCAWA1sQNSoAtPz5hex9gLiPKYDERzAETLs1FkzXohJHAnXHthGgEsfe49wzgf5zyq290iQG5gUAeT/WpPURnBekglWqDgQnKEpCgIdA3bHfiQA/5FEXVS4CRHR9qlw9nkt/S7rmBYBi7mtA9AmTIImXIAjQRyy3emEQSqIhBDgJNAr22YRwLqcH0eYgQF+23OpnOZRfStPAAGCfAgRXmgRJvARBwLxfjiC6Fo34EWg49rcJQLa+jtnUI0ExWfZck9o2LgAMn5x9pW7iH02CJF4CIXCZ5XpvD0RJRIQAIwG/kLsakE5ktCDSDASIYL9U2buPQfolJY0LAHedeXDvrs/PXAOgJpkESrx0lwBpuDE14GW6qyLVhQA/Ad+xfwUAR/A7EQeBEdCwIUnTZuDgYDMwzTEIGRcAWp4bTvYeAjxwDP7lkqgQILjHKnuviko70ocQeCkCdcd+EAH2FkLxIUBNuCs16B1qWsdGBoChYvZyRXiaabDETxcJaHzSGqjs1kUFKS0EjCAw5GTWKVBTjTAjJgIhgAA/SrreuwIRG4eIkQGgXrQ/jgTfGEcfcmnICejW5hhT1k5LX7Z8Q8hbEftC4CUJPFac/7IR0k8JorgRMPMtJyMDgN9vHwUKbonbEol7v6qZmNs3uPShuHOQ/qNLoO5kXoWgfhfdDqWzLRFQqOb1lZb93DQ6RgaAVfnMrpsS6knTYImf7hIgDUemBryfdVdFqgsBPgINx15AADfwORBlDgJ6Su9O6cuuf5ZDe2uaRgaAlmHfsVcBwCzTgImfLhIgPN0qV67oooKUFgKsBOqF3AcR6dusJkQ8UAIIupF0a1agomMUMzcAFDI3Aqqjx9iHXBYBAkjw38my96UItCItCIEtEvAL2a8C4icFT3wIaKJl6XJ1gYkdGxwA5BfFxAXTTU8a9CVpt/aebmpIbSHASaDu2EsQoMjpQbSDJUAIX0qVvP8OVnVsasYGgHohdzIiXTW2NuSqKBBAwFrSrWSj0Iv0IAS2REA2AYrhuiDot8reoImdGxwA7H0R4V4ToYmn7hAw8bjM7nQqVeNKoOFkfAKVjGv/cewbSe+dLNceNrF3YwMAAWC9P7NaKbWTieDEUxcIaHjeGvB26EJlKSkE2AlQPp/wE+s2IEAPuxkxEAwBrZ+wBmrGPsxubABozY5fsD1AkFvCwSxVI1RUc3SXvsGbnjHCjJgQAh0kMOQck1KQGOpgSSllOAEiuj5Vrh5vqk2jA4Ccm23qsumeLyT1mmR52Z3dU5DKQoCHgO/k3gJAP+FRF1UOAkT0yVS5+nUO7bFoGh0A6v32m1HBT8fSiFwTDQImnpkdDbLSBTcB37HPBICLuX2IfnAECOCIlOv9JjjF8SkZHQAemz9/2qbp+jn5zmx8kxrmq2UvgDDPnnjfGgHfsb8CAJ8SSrEhsHHTc3qHubXaRlM7NjoAtKD5jn0XABxsKkDx1VkChPTjVKn6js5WlWpCgJ+A328PgoKT+J2Ig2AI6Nsst/a6YLQmpmJ+ACjYFwLChybWnowKHQGEX1gl702h8y2GhcA2CPj53O8gQa8SUPEggADfSLreJ0zu1vgA0CjYDiGUTIYo3jpHQIN+NO3WZneuolQSAmYQ8B27dRiMvOZqxnR03QUBnpByK9d1XagNAeMDwMP5XLInQX4bPcrQEBHQAART1k5LX7Z8Q4hsi1UhsFUCj5x2/C7NTZueFkzxIdDExKw5paVPmNyx8QGgBa/ebw+jAvlUaPJK6qS3pn6FNViTXSA7yVRqsRIYXph7jdZ0B6sJEQ+MgCa9Ml2u7RWY4ASFQhEAhhy7rAD6J9ijDAsZAUR1fLK07PqQ2Ra7QuAlCcjZJnFbHHil5VZOM73rUAQAv5D7CCD9r+kwxV+HCBB9xipXW69MyY8QiASBetE+FwnOjkQz0sQ2CSDg+5Ju5fvbvJD5glAEgJWF3IEJpHuYWYl8QAQ00hXpUvX0gORERgh0nUDDsa8hgBO6LiQCRhAggv1SZe8+I8xsxUQoAkDrYKBGf2YVKLWb6UDFX/sENNCdabf6mvYrSQUhYAYBv2ivAIL9zHAjLrpLgIYttxqKEx9DEQBak+U79pUAcEp3J06qG0FATgU0YhrERGcI0Lx5PY2Z09eBgt7OVJQqJhNAgB8lXe9dJnv8h7cQBYDsqQB4RRigisf2Cagmzu4brDzafiWpIAR4CazMH/PyRCJxP68LUQ+MAFLBKlUHAtNrQyg0AWBlccFuSM1VCiA0ntuYFxmq4a3WgCcnp8lKCD2BRnH+cUTa6A1hQg/ZkAa01rqH9K5hOdI8VP+YNpzsPQR4oCFzLTa6SIAIP5QqV77TRQkpLQQCIeAXc58BovMCERMRZgL0W8utHsZsYszyoQoAfiH7VUD85Ji7kwtDS4AIvpsqex8IbQNiXAj8nYDv5K4AoFMFSPQJIOC5SbfyubB0Gq4A4OTeAkByWzgsq6sNnwT085RbnddGCRkqBIwgICeaGjENgZhAgDcmXe+XgYh1QCRUAeDBTGZyzw7wjAI1rQO9SwmDCWit/5oeqO1ssEWxJgS2SYDy+UQD160BBVO2ebFcEG4CGp5PPrl2F1y+fDQsjYQqALSgNpxclYAyYQEsPidOoAd6knu6NwxPvIKMFAK8BPx8Zj9IqBW8LkQ9IAI3WK53XEBaHZEJXQDwi/ZZQHBBR7qXImYTQFxglSrLzDYp7oTASxNoFLNFIlwijKJPABE+kCx53w1Tp+ELAJKow7S+2vJKQJ9LudVz2yoig4UAIwHfsVtnWnyK0YJIB0QASe+dLNceDkiuIzKhCwCtrhtOxidQodhqsSOzFNciGq62Brx8XNuXvsNPoN5v11DBMeHvRDrYGgECeCjlenPDRimUAWComP1fRfiRsMEWv+MjoEk/mC7X/t/4RsnVQsAcAn6//Rgo2N0cR+KkKwQQv26VKqF7RT2UAaDh2G8ggF90ZSKlqDEEWrtqTZ3c3H7WlTevNcaUGBECYySwKp/ZdVNCPTnGy+WyEBNQQK/tc6t3hK2FUAYAWrRINe694zE5HTBsy238fjXpw9Pl2u3jHykjhAAvAb/fPgoU3MLrQtS7TYA0PGINeEkEoG5rdbp+KANAC4LvZL8HgO/tNBCpZxaBMD5ZaxZBccNFoF7IfgIRv8alL7oBESD4tlX2PhyQWkdlwhsAJF13dCGYW0xfbrm1M8z1J86EwJYJ+IXc1YB0ovCJNgGFal5fadnPw9hlaANA64zt+qzpTygA2S0ujCtvrJ4R7rVK3ivGerlcJwRMIeA72QYA9pniR3x0gYDGJ5P7HbI7Llqku1C96yVDGwBaZOrF7KVI+PauUxIBNgKtBwE3bujdcZ+lS19gMyHCQmCcBIby2VkqgavGOUwuDxkBDfqStFt7T8hs/9NuuAOAY9sIUAkrfPE9NgKk4cjUgPezsV0tVwkBfgINx15AADfwOxEH3SSAhEcny5Wbu6nRzdqhDgAr8vlJM3DdU6Bg+25CktrsBD5tud5X2V2IASEwRgL1on0uEpw9xsvlshASaB1YtnrHJ3c75JK7R0Jof7PlUAeAVgMNJ7eYgBaGdQLE97YJIMC1SdeTh6m2jUquMITAUL99s1LwVkPsiI0uENBIV6RL1dO7UDqwkqEPAPWCfQIiXBMYMREKnEDrPdvUgCcPUwVOXgQnQoAAsN6fWa2U2mki42VMOAggwLFJ11saDrdbdhn6ADCcz09tJtY9iQAzwjwR4n3rBKhndI/UVTfJQ1WyUIwnMLwwN1dresB4o2Jw4gQ0PK+nrd0tfdnyDRMvwj8y9AGghdB37B8DgLwrzr+euuaAkE5Klapyp6drhKVwpwg0nOwZBNj6myQ/USVA+EOrXHl32NuLRAAYLs5/kya9POyTIf63QkDjhdZARQ6AkkViPIGGY/+IAN5hvFExOHECWr/eGqj9euIFzBgZiQCw+Tu3QuYhhWqOGVjFRccJNPH31mDl1R2vKwWFQIcJ1B37QQTYu8NlpZwhBAjggZTrvdwQO23ZiEQAaBHwnew5ALioLRoy2FgCrQ2BRnthp7mLa88ba1KMxZ6AbAAU/SWAAGcnXe+8KHQamQAw5ByTAkisVBF4tTEKC6sbPRDpbKpcq3WjttQUAp0g4BfsPCAMdKKW1DCPQOuDSG8vWLMX1x4xz934HUUmAGy+C1C0fwoEbx4/BhkRCgKIX7FKlc+EwquYjCWBhmN/mwA+GMvmY9E03Wy51aOj0mq0AkAhdxogXR6VyZE+/oPAbyzXO0K4CAFTCTSc7D0EeKCp/sRXewSQoJgse257VcwZHakA8Nj8+dNGZow+DqS2MwexOOkcAb1JT1m/Q9jfve0cD6lkEoGH80ftoLD3GaWUMsmXeOkQAdLP6qnrd4/S359IBYDWNMsrOB1a7IaWkYOBDJ0YsQV+IZsDxGWCIqIECC62yt57o9RdFAPAGwjgF1GaJOnlxQToy5Zb/awwEQKmEfAL9oWA8CHTfImfzhBQQK/tc6t3dKaaGVUiFwBaWIcc+yEFsJcZiMVFhwncbbneIR2uKeWEQNsE/EL2PkDcp+1CUsBEAvdZrreficba8RTJAOAXc58EIjk+tp2VYejYza/hTJkyc/YV16021KLYiiGBR51j+0ZhtBHD1mPRMgJ9LOlWL4has5EMAMP5o3ceTahhBWpa1CZM+mlt9IBO0q2UhYUQMIVA3bHfiQA/NMWP+OgcAQJY02xunL3X4E+e61xVMypFMgC00PqOfQkAhP6wBjOWiVkuEOBHSdd7l1muxE2cCfhO1gXAQpwZRLV31HhRcqASyb0dIhsAGgV7f0L4U1QXZZz7QtCNpFuz4sxAejeHAC1apOr33/GkArWLOa7ESScIaADqJdpndrkayeOdIxsANt8F6M/dCoqO7MRCkBpmEdCo9k2Xlt1vlitxE0cC/kL7YNBwVxx7j3rPCFhLupVsVPuMdABoOPYCArghqpMX777oI5ZbvTDeDKR7Ewg0HPuzBPAlE7yIh84SUEiZvlL1xs5WNadapAPA5ltz993xoBwTbM6C66CTWy3XO6qD9aSUEJgQgXrevh0TcNiEBssgcwkg/iVZquyLAGSuyfacRToAtNA0CrmPEdI328Mko40joGFklDbuGsUnc41jLYZekkDr+F9I4GNyCmn0FgkBfTDlVi+KXmf/6ijyAaC1P3ciMfkRBJgR5YmMY2+ItDBZqpbi2Lv0bAYB38m9G4BabxzJT7QIPDe1OW32zMHBNdFq69+7iXwAaLVbL9gXIcL7ozyR8eyNypZbdeLZu3RtAgHfyS0DoJwJXsRD5wiQhgtSA97HOlfRzEqxCAAr88e8HBOJ++Q2nZmLsA1Xzz21/eO7HnLJ3SNt1JChQmBCBDafPjpVrwYFUyZUQAYZSaC12yhSz96pwWVDRhrsoKlYBIAWL0nqHVw1JpVCeptVqt5ikiXxEg8CjeL844j0dfHoNj5dIsC1Sdc7MQ4d///2zjw+qvLc47/nPVmEgFhQVGpmBtS61rbXfamXuoDJBFzqkAmKoq21q8ut2u2qqdprrXpta1u9al0rmWGqqMlMxFpFrahFrfXjWpRkJi4IgqImkGTO+9zPBK/VWySZzNnPwz/+4fv+nt/zfU7gl5lzzhuaANCTbNxfgx4Pw1DD1CMBv4mksnICW5iG7pFe88n4TQDme8SO2LCIgFb8pakLcs9YJOdpmdAEgI2fAjQuBmiGpyci5soiwBqvRRdmI0F+VKcsILLYEQI8fXpVfvKYN0mprR0pKEUcIaCZ26emc7MdKeaBIuEKAHMaDoZSf/EAd7FgJQGiL0fbOmSuVjIVrc0SKMyNz2SNwL4gJqzjJ/C+kVQuNG91DFUAGPoUoCX+ABhfCesFHsS+mfG7WDr7nSD2Jj15k0A+2XAzoE72pjtxNRoCpUAXW5htGM1ev+4JXQDoSjZNV+AH/Tow8b0JAppWRXjMFMpkTOEjBOwmsLyhobZmgnoLwAS7a4m+cwQ06wOnpjtDdZ9Y6AJA6XLqSjY+rEBfdu7Skkq2E5CnAWxHLAU2EpC7/4N3JTDx/bG23JHB62zzHYUyAORbGo8E031hG3aQ+2Xim2JtuVOD3KP05g0CXcl4WgFzvOFGXFhBgIBDI6nsI1Zo+UkjlAGgNKB8smEpoA7007DE62YIsH73Az1u2z0ymQHhJATsIrBy3oy69YPGKgU11q4aoussAQY/FEvlpjtb1RvVQhsAupsbGohUzhtjEBdWECDmYyLpnBz/bAVM0dgkgUJLYwszLRA8wSHApA+PtXU+EJyORt5JaANACVF3Ir6MDOwzclyy0ssESOtFkYWdx3nZo3jzN4F8c8O9IDXT312I+48RWBpNZQ8OK5FQBwC5FyBgl73G4GDt4A473XbfqoB1Ju14gMCriaaIIrNLKaU8YEcsWEBAkZpe39b+kAVSvpQIdQAoTUwSvS+v2081zcznxdK5y4PVlXTjBQL5ZOOFALV6wYt4qJyA1vqeqQs7j65cyb8KoQ8APSc0fr44yM9IqvfvRfwJ50QvR9s6dg1IN9KGRwhwa6sqvLhsBQhRj1gSGxUQYKDIpD4/ta39pQpkfL819AGgNMFCMv57BuQRMt9fzh82IK8GDsokPdOHfF3omVFYYoSBa2Kp7LctEfOxiASAoQAwe4qpzX8ohTofz1Ks/5PAzdFU9hQBIgSsIpBPNqYAarZKT3RcJKDxXg3rnbbPdK520YUnSksA+HAM+Zb4T8G4wBNTERMVEdAavcVqPWXn2zvfq0hINgsBAK+ddOwkc2DgdQC1AsT/BAj4SSSV/S//d1J5BxIAPmS4KpEYt97oWw5gu8qxioLbBBj83Vgq91u3fUh9/xPoTsbPIUBuLPX/KFE6PtzgsZ+rz2TWB6CdiluQAPAxhPlk/BsA/qdiqiLgOgEG/hFNZXclgF03IwZ8S4ATCaOg+l6Vm/98O8JPGifMj7ZlbwlINxW3IQHgYwiHftir+p4FY/eKyYqA6wQYaIqlslnXjYgB3xLIN8cTICz0bQNi/J8EGM9Edtt3b2pt1YJlIwEJAP/vSuhOxuMEdMgF4n8CYT3hy/+T804H+WT8UQAHeceROBk9AToimur48+j3B2+nBIBNzFReDhSgC53UntG29ucD1JG04hCBQvOsfZn0Xx0qJ2VsJKCZ26emc7NtLOFLaQkAmxhboblhR2b1HBS28OVUxfTHCVwfTWVL93bIHyFQFoFCsul2Bs8ta5Ms9hyB0lNBmmn3HTMdBc+Zc9mQBIBPGUChOf4TJlzi8nykfIUENPT66pot6ne4ddGaCqVke4gIlN4NwtrshkJ1iNoOZKsMnBtLZa8IZHMVNiUB4FMAPp9I1Iwz+p4BsFuFjGW72wQIF0Xbshe6bUPq+4dAoTl+BRO+7x/H4nRTBNjkZ6Or+/amJUuKQuhfCUgA2MxVUZjTeKipaImSmyX9/bPD+t2iHoztmLl/nb8bEfdOEHgz0bDNBlJd8mZQJ2jbV0NrrUE4eGq683H7qvhbWQLAMPPLJ+M3AZjv7zGLewafH0vl5CsduRSGJZBPxn8O4AfDLpQFniYg7/sffjwSAIZh9EbLrK37ufiSgpo0PE5Z4VUCGlhbZ46NTs5kPvCqR/HlPoHSa3+LAwPdBIxz3404qIDAyqLZv6t86rd5ghIARnCFFZqbTmHiG0ewVJZ4mQDzj6LpXOm3O/kjBDZJoJBsupjB/yl4/E2AGC2RdDbl7y7sdy8BYISM8y3xh8A4dITLZZkHCTCwuqZXxaa0t/d50J5YcplA1/xjtlIbBrsBTHDZipSviADfF03lZlYkEZLNEgBGOOju5vhuRPoZQNWMcIss8yABZj4vls7JwS4enI3blvLJplaA5WkRtwdRSX2NDUR6z0i689VKZMKyVwJAGZPuTsbPJ+CiMrbIUo8R0Fq/o6rUjtEF2Xc8Zk3suEigK9G4HYhekTv/XRyCBaXlmf/yIEoAKINX6bCgPPoeJQP7l7FNlnqMAGtcFVuY/Q+P2RI7LhLIJ+PXATjNRQtSukICDH4ouut+h8lhPyMHKQFg5KyGVvbMbdq5WOS/yW8KZYLz1HI9AKV2iy7IrvCULTHjCoF8y6w9NBf/rqAMVwxI0coJaLxnVvFe0xbk8pWLhUdBAsAoZl1INn2TwdeMYqts8QwBTkdTuaRn7IgR1wjkm+NZEBpdMyCFKydAmB9ty95SuVC4FCQAjHLe8pfGKMF5aJsCH1Cfyj3hIUtixWEC+WTT4QDf73BZKWclAaY7oumO462UDIuWBIBRTnropiGDn5MXBI0SoDe2PRpNZQ/xhhVx4TQBbm1VheeffBIGf8np2lLPMgIrjZqaPeWwr9HxlAAwOm5Du7qb48cR4Y4KJGSrywSI6dRIuqP0umf5EzIC+Zb498D4dcjaDlS7zLoxlu7sDFRTDjYjAaBC2F0tjbcoppMqlJHtLhHQ0GtqqWrXKW3tb7tkQcq6QKAn0fRZTfwCFLZ0obyUtIQAXxtN5b5liVRIRSQAVDj45Sc0bFlTVM+CEK1QSra7REAT3zq1LXeyS+WlrAsECsn4HQwc50JpKWkBAc16eW1f1RflrZ6VwZQAUBm/od0bjw3mB+QxIgtguiTBGofFFmYfdKm8lHWQQL6laRaY73GwpJSykoDGoKqiQ+oXdPzVStkwakkAsGjq+ebGH4LoUovkRMZhAgz8Y3Cd3mvnzs5+h0tLOQcJrJw3o25g0HiBoSIOlpVSlhLgM6OpnNy7YQFTCQAWQCxJMECFZHwRgKMtkhQZhwkw4WextqycBOcwdyfL5ZsbrgKps5ysKbWsI8CkU7G2zhbrFMOtJAHAwvm/mjhigmHUPknAThbKipRDBDS0SVCHxlLZpQ6VlDIOEsi3NB6pmRYrQP7ec5C7ZaUIL9RWDe633W339VqmGXIh+UGw+ALoaZm9V5EHH1dQYyyWFjlHCHDXgMFf3Pn2zvccKSdFHCHw2knHThrcsOFZpdQURwpKEWsJkH5fo2q/qW3tL1krHG41CQA2zD/f3HQSiOW1lDawdUJSngpwgrKzNbqbGxcR0THOVpVqlhFgzImmsxnL9ERoiIAEAJsuhHxz/FoQTrdJXmRtJkCgZCTVkba5jMg7QKC7pfHrxHS9A6WkhB0EWP8ymu482w7psGtKALDpClje0FBbNYEeUaB9bSohsnYSYP1uFdXs9dnU3T12lhFtewnI6Z328rVbnYG/RFf2foWWLCnaXSuM+hIAbJz6irmNUdL8lJwXYCNkG6U1eBm26Dt06s1LNthYRqRtIrAqkRjXi77HlYE9bCohsnYS0PotUtX/Fknd84adZcKsLQHA5ukXmptmmGTm5CVBNoO2SV7uB7AJrM2ypcdye+Y03MFKHWtzKZG3g0DpZT+GOrK+rf0hO+RFcyMBCQAOXAmFZNM3GXyNA6WkhB0ECGdH27K/tENaNO0hkG+OXwDCT+1RF1XbCRDmR9uyciO1zaAlANgM+P/kC8n45Qyc41A5KWMhgdL7ARSMmdFUx58tlBUpmwgUkvHZJnCXPO9vE2CbZQl0SSTVcb7NZURePgFw7hoYelNgc1MGxF91rqpUsoqABtYqhX2jC7IrrNIUHesJdDfHdyOlnwCr8dari6LdBAi0IJLqOMHuOqK/kYB8AuDgldCTSIwx0fcgGdjfwbJSyiICpRPIzBrzkJ1uu2+VRZIiYyGB15NH15sY+Iu8599CqA5KafAjxXV8pJzH4Rx0CQDOsR6q9Mq8GZOrB6seB2iqw6WlnBUEGM8Udf/0HTP3r7NCTjSsIfBGy6ytB7X5CIh2tUZRVJwkUArX1bVbHLjDrYvWOFk37LUkALhwBQx9TAm9FKS2cqG8lKyQQOnZZMMcO6M+k1lfoZRst4DAS7Nnjx8z1iwd5by3BXIi4TABDb2myqw+oD5zzysOlw59OQkALl0C3XPiXyFgMRSqXbIgZSshwMitnrDymH2ue2qwEhnZWxmBrvnTtzA2jOlkqOmVKclulwj0Q+vDows7H3WpfqjLSgBwcfxyZoCL8C0pzenIyr4T5S1llsAsW6T0ts2aCcYfAW4qe7NscJ2ABthgzI2ksynXzYTUgAQAlwffnYyfQ8DlLtuQ8qMmQB3KHDNHvg4YNcBRbSy95W89rb8big8blYBs8gABPjOayv3aA0ZCa0ECgAdGn082XghQqwesiIXRECA8PKD0LDlCeDTwyt8zdLTvQH+nnLNRPjsP7fhhNJW9zEN+QmlFAoBHxp5vbrwMROd5xI7YKJeASX+rgTlz+0zn6nK3yvqREygkZ09hMv8Exu4j3yUrvUSAgIsjqewFXvIUVi8SADw0+UIyfjUD3/WQJbFSDgGil7lIDbFMe1c522TtyAisSBy1i2EY9wKIjWyHrPIaAQKuiKSy53rNV1j9SADw0OSHDjBJxm9g4FQP2RIR+9/PAAAN6UlEQVQrZRDQWr9jVKmWyILs4jK2ydJhCBRaZh3Dpr4FClsKLH8SYMbvYunsd/zpPpiuJQB4bK7c2qryLy37AwEtHrMmdkZIQGutDaXOr09lLyWAR7hNlm2CwNDPw8vLLmLGj+Xd/v69RJj4pmhb7mvy8+CtGUoA8NY8htzw9OlVPZPHLJSjTD04nDIskdaL+jZUn7zrPfe8X8Y2Wfohgfzc+Ge4iAWkcJRA8S8BJp2K7rL/CdTaqv3bRTCdSwDw6FyfTyRqxhvr72Jwg0ctiq2RECB6mTTNi6Tbl41kuazZSKCQjH+ZwbfIK7N9f0XcHVnZe7y8K8Obc5QA4M25DLkqveikajwWKqVme9imWBuGwMbjhNUVA+v0hXLQyeZhvTFr1tjBsfrnmvBd+cjf5z9ahMzq8StPkLdleneOEgC8O5uPvg4obFd3E4ATPW5V7A1P4EUFPqU+lXti+KXhW9HTMuvfi6x/r4Adw9d9wDpmuiGy2z6ny8f+3p6rBABvz2djCCg9HTCn6WpWLHfQ+mBem7NY+jTAgLqq39AXy4uDNpLqScycyFR9kan42/Jbv88v8NIZ84wrI+nsOf7vJPgdSADw0Yy7k/GfEfBjH1kWq59CgLV+mxRdvHrLt64J60ekpYN8VP+4M6DNH8nJmMH4UWHw+bFU7pJgdBP8LiQA+GzG3c2N5xLRL3xmW+x+CgENvKqIfxxtyy0MC6TSo32Fl5fNA/PFANWHpe8g91k62IeYzoilO34T5D6D1psEAB9ONJ9sOk1r81qllPKhfbG8CQIavIwIl0WLdXdRJmMGEdKT39i7euv3tk0o4DwGfSGIPYaxJwaKBD41msrdFsb+/dyzBACfTq+QbGpmzbdBodqnLYjtTRFg5Bn8WzLohuiC7DtBgPRmomGbfoNOZ83fUkpNCUJP0sNHBPqJuTmSzt0tTPxHQAKA/2b2kePu5oYGkFpIwDgftyHWN/mJgO5TrG5jqOti6fan/QapdONqd3PD/orU6dj4Vstav/UgfoclsI5JHxdr63xg2JWywJMEJAB4ciwjN9XTMnsv5sF2hoqMfJes9BcB7iLQHSbrO2Lpzie8+jrV0nf7PS8tO5g1Hc/g40hhB39xFrcjJVC6d4UYs2Lp7Isj3SPrvEdAAoD3ZlK2oxUts7dVRfNuMrB/2Ztlg68IsMZrBLqTDHpwoKp/6U633bfKzQa6T5y5PRWrDwb04QAdA2A7N/1IbQcIEB42qmuO2+HWRWscqCYlbCQgAcBGuE5Klx6pog11N8ohQk5Sd7/W0FMEoKUg/ahC1WMo1i6vz2TW2+Fs5bwZdRsGancBmQcCdDAxDgIhakct0fQmgdKhPr3Fum/ukckMeNOhuCqHgASAcmj5YG2+OX6BJrTKC1V8MCz7LK4EsAKELmKsAFOXJryrGL3MZq9JxgfVWvWatf29qlhLpHRdEbpOFbmOyKjT4HEgbAXCNDCmwcQ0GJhGwDb2WRZlLxMonXBJRD+MpXOXe9mneCuPgASA8nj5YnXpCQET5k0KaowvDItJISAEPEtAa/QaxCfInf6eHdGojUkAGDU6b2/smdu0n9ZcejRHvpP19qjEnRDwMAHuMVnNmpbu+LuHTYq1URKQADBKcH7Y9nry6PoiiosA7O0Hv+JRCAgBTxFYqk3+6tRMrvSVkvwJIAEJAAEc6sdbKh0pXDveuFIOEgr4oKU9IWARgdJrfQ3gyvqVvT+iJUuKFsmKjAcJSADw4FDssJRvaZwDk66HwpZ26IumEBAC/iegtX5HGcbJ0baOdv93Ix0MR0ACwHCEAvT/exKzd9LQC2HwlwLUlrQiBISABQTYxBO6mpunLcjlLZATCR8QkADggyFZabH0lUD1BHUVAd+yUle0hIAQ8C8B1rjq7a1W/iCsR1P7d3KVOZcAUBk/3+4uNMeTrPR1YDXet02IcSEgBCojwPpdUlWnRNra76pMSHb7kYAEAD9OzSLPrzU3fk4TFsrRrBYBFRkh4CMCpSOoAT1naurebh/ZFqsWEpAAYCFMP0oNvUK4f+zP2OSzlFLKjz2IZyEgBEZOQEObBHVZrzn2p/JK35FzC+JKCQBBnOooesrPaThYE25SpHYexXbZIgSEgB8IEF4greZH0u3L/GBXPNpLQAKAvXx9pd6TSIwpVvVeCqYz5CwBX41OzAqBzRIo/davoK4YWKcv3Lmzs19wCYESAQkAch38C4HCnMZDTUU3KmBHwSMEhIDvCbyowKfUp3JP+L4TacBSAhIALMUZHLE3Zs0aW6zTl5nAd+TTgODMVToJD4HSCX7KMK7UtR9cMPXmJRvC07l0OlICEgBGSiqk67qSTdMV9I0ATQ0pAmlbCPiPANHLDJwSa+t4zH/mxbFTBCQAOEXax3VWzptRNzBY3coaZ0Kh2setiHUhEHQC/Uy4gmt7L5Hf+oM+6sr7kwBQOcPQKHQ3x3cjwtUADg9N09KoEPALAY0skT4zku581S+Wxae7BCQAuMvfl9XzyabjAf3fANX7sgExLQQCRECzXqGUcZYc4BOgoTrUigQAh0AHrUzpJsGBOv0Tgj4HUDVB60/6EQJeJ6Ch1ytWP9djen8hH/d7fVre9CcBwJtz8Y2rnrlNO7PGrxjc4BvTYlQI+JwAab2oWEVny8l9Ph+ky/YlALg8gKCULyTjs03WVylS04LSk/QhBDxHgOhlIj4zsiC72HPexJDvCEgA8N3IvGv4+USips7oPY1A/wlgO+86FWdCwG8EuIcJF0Xf7LuZliwp+s29+PUmAQkA3pyLr12V7g8YrNPf01r/QCn1GV83I+aFgIsEGFitwJf2r+PfySt8XRxEQEtLAAjoYL3Q1quJIyYYVbXnsomzlEKdFzyJByHgEwLrGLhyrDn2qsmZzAc+8Sw2fUZAAoDPBuZHu6/MmzG5ur/mJ1B8OoBaP/YgnoWAEwQ23tlPVyttXlafWbzWiZpSI7wEJACEd/aOd/5qoilSbfCFJvTJCspw3IAUFAJeJaAxyAo3oKp4cewPi9/0qk3xFSwCEgCCNU9fdNOVPCqmdNXZGvw1+WrAFyMTk3YR0HiPFK4jk35Zn+l43a4yoisENkVAAoBcF64R6EnMnGgaxrdJq+9B8WTXjEhhIeAwAa31G8owfjWgzGt3vr3zPYfLSzkhMERAAoBcCK4T6Jo/fQu1oe4kBr5PwOdcNyQGhIBNBLSJ5w2Dr3jfrFuwRyYzYFMZkRUCIyIgAWBEmGSREwS4tVXlX3ryaAWcx+ADnKgpNYSAIwQID0Pz5ZF0LksAO1JTigiBYQhIAJBLxJME8i1NhwB8BlgfLWcNeHJEYmp4Av0EuoOgf12fyj0x/HJZIQScJSABwFneUq1MAm8mGrbpN9TJRPR1MO9S5nZZLgQcJ1D6mF8pul7pwdvkUT7H8UvBMghIACgDlix1l0BhTuOhrOg0aBwPhS3cdSPVhcA/CWjoPiJKA+r6WFvHY8JGCPiBgAQAP0xJPH6CQH5u/DNgnKg1TlOEzwseIeAeAf00wbi+3zAXyN387k1BKo+OgASA0XGTXR4h0JNs3L8IPpU0jiOltvaILbERZAJav0Uw/qiJboyl258OcqvSW7AJSAAI9nxD0x1Pn17Vs+24w0A8xwSOVcDE0DQvjdpPQNMqKH0na1oY3X3fh6i1VdtfVCoIAXsJSACwl6+ou0CgFAZe237sEcyUMLU+Vk4kdGEIASjJWr/NCncqGAsj5pgllMmYAWhLWhACHxGQACAXQ6AJPPmNvau3Xjf5CCI1B6yPAamtAt2wNFcRAQ29RkHdCeJMpFj3gPyjXxFO2exxAhIAPD4gsWcdgecTiZo66juYiI8iwkwGfcE6dVHyIwENsAKeZsK9irG4fmXvY7RkSdGPvYhnIVAuAQkA5RKT9YEh0JVo3E5V0UxmzITWR8pNhIEZ7eYb0fotKOM+hr631uQ/bZ/pXB2SzqVNIfAJAhIA5IIQAgBKryHuefGpvTWZMwl0lIY+QI4sDsiloTFISj/KTIuZeHE01fmMvI43ILOVNioiIAGgInyyOagElp/QsGVt0TiACQcB+kCA9gcwIaj9BqkvrfU7hjIe19BLCeqxMeaYJyZnMh8EqUfpRQhYQUACgBUURSPwBDZ+QrBs9w8DwUEMdaCcXOj+2Ie+wye8SIzHNLAUjMei6exL8hu++7MRB94nIAHA+zMShx4l8EbLrK0HtXkAEx1IGl+Awh4aiCo5ZtuWiZX+sQfrLjCeM5T6u2b9GBnq8eiC7Du2FBRRIRBwAhIAAj5gac9ZAqsSiXH9Ru8eJmhPYr0nq9J/aU8A2znrxN/VNPTrivEcQT0H4ucAPFfVa7wwpb29z9+diXsh4B0CEgC8MwtxEmACr5107CS9oX8PGLSnNrGTUogyEGWto6F9+kDTKq10XmnKEyHPipfD5Of02Nrnp95817sBvhykNSHgCQISADwxBjERZgIr582o2zBQHTEUR0tfIYARJagog6MEXW9qNUkp1PmJEQMfEPC2BvcoUJ4JeWLKEyNf1MV8NcYX6jOZ9X7qSbwKgaARkAAQtIlKP4EksLyhobZ6kp5IZs1EMs1JMIyJmvVEME8ipSZqNicqNiaB9HgC1zBUDZuoYYVapagGrGs0uIagagio0dA10KiFAgMYUFADDAww9AAY/Qo0wBoDAA2QgQGCHmBGP1i9D8IaEK9lojVK01pAr2Wl1qBorjWrqtesHf/62n2ue2owkIOQpoRAgAj8LxMJbNKdy6wzAAAAAElFTkSuQmCC",
        ie: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAADwCAYAAADvl7rLAAAgAElEQVR4Xu2deZhT1fnHv++5mRkQcbetYHFhkkCRZAax1h21tu5b7Ugyg4raUluX1tYu2oVutta12kX91bowSehUH7Wuba1oVdSKTBJEyM2gVgG3WhcQnJnc9/09dxA7DDNkuzfryT/6kHO+7/t+zp03995zznsI+qMJaAKbEJg8b9EulqehWZgmEmQcIDsBtBODdyIYO7HIzobibQHDYFgEBkEpUgy1QYjfYyVvkKg3SOQNIvUmE94gwQpidKc6AiaIpBKwUyU4oX3QBEpOQIT8nUkfG5hGoABBvAJpZpaJSqmt3fSHwWsUJC6gxSRqsQHr0WXt0/7tps2RtHUCKAd1bbPkBHzR5CRA9iXBNCZME3BQQY0tuSMjGbTQTUruFFJ/NsOB5aXySyeAUpHWdkpHYK6o5knJFoNxsBAOQgYHwcDOpXOgaEsPQdFV5qlTH3T7UUEngKLHSgtUAoHJkW5vhuhIYvV5QA6EwraV4FcxPojFScODC5aHWh8pRmdLfXUCcIus1nWVwLh7Fm015l3PYUI4UrEcCUNNdNVgGcVZ8KcG7v/GslnTX3XaDZ0AnCaq9VwjMOnWZTtanv7jQNZJxOoIKIx2zVjlCb9BQCgVDj7spGs6AThJU2s5TsCekssYnlMIdBIYB0PBcNxItQjac46KLk6FA79yymWdAJwiqXUcIzA1kty+V+EUiIQAPgRQH86vO2aiuoWILzVDrZc4EYROAE5Q1BpFE2i+P91kvL3+eJDMspg/r5RqLFq0tgV+YYaDFxcbok4AxRLU/Ysi4JvfvY+Imk3CMwG1fVFiddZZhGan2wO3FBO2TgDF0NN9CyJg3+L3QU4TwZegMKUgEd0JgHwAJQebM1ufKRSHTgCFktP98ibQ3Jn4jFL4ChhtdfYGP29WuXZggYnttwr0HO3tzbXP4HY6ARRCTffJmcDuN784qmnUu2Ewf03ImJZzR90wDwL0EzMc+FEeHT5qqhNAIdR0n6wEBnbUGQ3nMfjLCmrHrB10g4IJMHOfImOy2R54IV8RnQDyJabbb5FAc+fiTylDXcSWhGv+TT6zvaX3DShaycAritUrUPKqABkQBrb7kshH234J9HEh+GDBx2B716FzMx2Em8xQ8Ox8L0+dAPIlVkPtB6be/rNunHhkvAg+pkDbC8l2JNjOArZXRPa22CYCGhjcIIIGRaphAAEjI4r7iI0PYPA6AGthKYGy7AU74+398TWECiR42SJZrIBuYSwmUs/z9qNXFfrsja4uw9c/aTcisZPBkWSpcDEblhjobxDLm++24poapFq64JyKZUrX0k/09Vs+UvATi4+JfQTajUHjFbCTU3ZqSce+pTaUelIgDwuMJ41+z+Llp09+y80Y975hUcParRuPtojPAOgYBWxItPl8SC4zQy3fzatLPo112wom0NVlNPc1+w2lpllQrQrSCnCLnlvPYcyYhUk9q5T8Q8T4x3rPmsdXtu2/PoeerjTxRRftBGk4lwWXKAVPrkaYsbqnMTUBbW1Wrn30HUCupCqsnb0bbux7nn0H9ruDDmLmz7hdyabCEBTnjsW9rPCwgnGXwX33uLHTrjgHAX9n9wECiUEZn8xVi4CjUuHgg3m0z7WpbldWAiLk+1N8OpiOAuPzrGifgm4TyxpEmY1b3AvDuJ/A87F+1AOpsyatKbNHWc1P6Vq6QyaTuUWA47I2tpcGEX6fDgW/mktbu42+A8iVVBnaTelaunV/f+ZYAo4TxhHFvCQqg/uVYZJZSKl/CtDZ18u3vzS79Z3KcCw/L/yRxAVCfFW2jVEW46UVHcE9clXXCSBXUiVq579p+ViM6jveIj5FAUcCNKpEpqvbjP2HTuoVUbIaoj4FttZDqT+yUjf1zJy6orqD2+C9P5r4lQAXZYvFEPYta29NZ2un7wByIVSKNl1dhtfyHgnBGWThOBiqqRRma9IG410YcqeIEU2H9nrI7Zp6pWQ4pWtpY19v3zNkqMCW7BJkVirc0pmLb/oOIBdKLrWxF80YZMwWkQ4o+oRLZupX1uIVZBg3Cvr+aIan/6cWQEzqTE5lsZ7Z0o+EgH+dDrd+PZd4dQLIhZKTbexf+37fCSB1HkFmOCmttUYgYHEvKXWHGHxNMTvnKoWvN5b4FgkuH9kf/qcZbj0kF391AsiFkgNt7Hp23ND7JRI6RwgTHJDUEgUQIOBRJr48PbPl/qp9PJgryufrfgQwDhoOwcB6gI7g+Fzw6ASQC6Ui2vi64uMlQ98S4EsKGFOElO7qJAHGUhB+ZqYDXZhL7KR0KbT80XiHgOYNa4tZ1jWuH5PLYiadAFwareb5SyYq5u8w8+mObvpwyd+6lWUsJaIfp8JTb6+mOwJ7fUB/X+aNkYuk0uRcThjSCcDhK7+5M7GrMjAXFs6o6wq2DnN1X04SAuOidHjq39235YwFX3TxP0d6DADkIDPc8ng2SzoBZCOU4/cDK7b6M98TknP13H2O0CqwGQs/AJFv9XRMe74C3dvEJW80cREBw5YIJ6ETU+2Bu7PFoBNANkJZvh+Ym81kLiDGJbVwHFWROGqjO8OCwg19vXxJJa8c/PDA02XDQc+1YKhOAEVcsr75yaPYkmuUXeRBf2qPAPPrpOhbuS6qKQcAXyyehlDzUNsC+Uo63HJDNp90AshGaJjvB17wZeTXUHJMAd11l+ojsMAQnpPr8tpShuePJH4vhK8MkwDOT4dbrsvmi04A2QgN/r6ry/BnJn1TWObqqrb5gKuBtoz1pHBxKhT4dSXNFvhi3T+HqM0PCCG60AwFrs5GXieAbIQ+/N43/7kgOHMTQHvn2EU3q0kC1mOsGmZXygYjbzRxCQE/2wy10Hlme+A32YZAJ4AshGYsWOBZ9dqOPxRLvpdPdZZs4PX31UuAmdcqpc41w8Fbyx2FL5b8BkSuGiYBzDHbAzdm808ngC0Qmhzp9mZgRIhkn2wg9ff1R0AgEbV+1DnlLCzijcbnEOj6YeifkUuC0glghOvWF0t+iUWu1st36+8PO6+ILV4hCqek21vjefVzqLEvFp8Fods2l6OTzHDgrmxmdAIYQqi586ltDDX6jwJ8IRs8/b0mMECAsR6GzDFDLcOvzXcRkzea+AIBtw81waAZPeHAo9lM6wQwiNDk+Ym9+i3coef1s102+vthCZD8Zux7mQufnTO9v1SE7LUoYLl/qD2CCqbCU5PZ/NAJ4ENC/kiyHZAbhbBVNmj6e01gJAL2dmOPx3Py0rYp/y0FpeZo8hAFeWSzOwCP9bGetmlvZvNBJwC7QEfGfwUBOVVQyQZUf68J2Cf2CnuOWTFrSo/bNPzRxGEC/GOwHftgk572llG5rFeo6wRgF+CU0b3zARzt9kBp/foiwOC3FKmTzFDwMTcjH24WIJ/KwHWbACZHFu+WIeNeAvZyc4C0dh0TGChFZpyay668Qik1R5NXKsiFm9wBCB7uaQ8enotmXSYAf2zJdBG+D8DHcoGk22gCBRNgWEJ0dro9cEvBGlvo6Isl7oHg2CFN/s8MB7+ci726SwD2M5MFvktBjc0FkG6jCRRNwD5GXNFFZrjlyqK1hgg0RxKpobNWBPpOKhwYtk7AUPt1lQB8sfhJyEhM1913+jLUejkREFxitgcvzaltDo3sZeorX91h3dAj4hg4viccvCcHifo5GswbTc4mlv/TZbpyuSx0G7cICPD9dDj4cyf0J85b2mwYmc1OAKIM9kydFnwxFxt1cQfgiybOBvONUKou4s1l4HWb8hFwKgn4IsmjQWK/y/row8D7PaHA2FymAO1ONf8H4Y/FzxRL/qD/+Mt3wWvLmxMg4BupcPCaYtj4o4mvC7Dpnn+WhWZHywG56tZ0Athw22/dpP/4c70cdLuSEWAWIePMYmYHvLHE70hwziY+k/zGDLWcl2scNZsAfLH4qRCJZjtOOVdQup0m4DgBu/ioIV80Qy13FqLtjcQfIqJN5vtzLQa60V5NJgBfJPlZFus+fSBHIZeV7lNaAvKBIuPw5aGpC/OyK0K+zuTrMLDz4H5kYVJqVjCVq1bNJQB7kY9lZRYopbbOFYJupwmUkwAD/xHLs18+ewd8kfinQfT0Ji8Amf/b096yU64vAGvuJeDAtAgyC4dmxXIOrratCeRCQIC00d+43/LTJ7+VS3tfLPEjCOZu+vyPe81Q8Lhc+tfcI8DuN3dvZzThKQPKnw8A3VYTqBwC1mNj1/DhudQT8EUT9q//pwf7LsC30+HgFo4N3zzSmngEsFdErX51hwcAfLYsg8n8OgNj9GNHWejXlFEW+W1Pe8u5WwqquWvxzipDr232gltkX7O95V/5AKmJBOCLJn4L4Kv5BO5MW2awcbsoaSXA64ymVql3AgI6Mx0O3DwSh2GPBme8azamdkRbm5UPv6pPAL5I8ssgyXoEUj5QcmlrP7OR0BUEuUQIE3Lpo9toAjkRsLgXDTjInNn6zHDtfZ3dUSgVGvL8f7cZCp6Yk/6gRlWdACZFknszW0+UenOPfZumoO4CWV2A2j5f6Lq9JpCNABNeZKO/9YW26e9u0nauqObm+JtKqR2GaHzNDAd/l0136PdVmwDsl36eUWqxEuyRb9CFtrenawCcSfYiLlCXPh6sUJK6Xy4ECLgjFQ6eMrhtczS5n4JstmYgnw1Ag/WqNgE0R+N3KlDetzy5gB+ujYj8Qyk+TaAOZ4v+qE8JKpSk7pcXAaJzzVDAfsc18PFH4j8Vou8P1rDAqRXh1kl56X7YuCoTgDcaP49A1xYScL59mJExiL6fSk+93O9NnifCV+u9BflS1O0LJmBxr9Ggpi+bGXxuQwJY/KyQMW3Ir/jlqXDw24XYqLoE4J2/ZDJl+NlS3H4zY7VScqoZbnncG0v+hER+UAhk3UcTKJJAfOya/k9/sP3oHfv7+lYP/QEi5gNTHa1PFGKjqhLA3jcsalgz1vNkiU7oXdAPFXoxtNcb/mjyGiGcXwhg3UcTcIQA8aXCRppINp0eZHnN7AmOx1ziQuxUVQIoya/wQP029UvTk/oBnv+i+H2JPwhodiFwdR9NwDECdnFRhWVDq1gL4ffpULDgNTBVkwCa5yemqQz+5WZJLwavMUh1pELBvwzUW1u9Q6cinOrYIGohTcBhAor40OWh1s1OBsrVTHUkgK4uw5fxPe3qrT9JD1t8Qk/HtOeb70830Ttruwjq+FxB1lI7+2QZBbVCFKcB4z9KZK0oXgtRa4XwPgRNJBhDhK0EGAPA3nk5DuA9mdUEPUNSmqvBfkfV0xP4ZKG3/7aXVZEAhi195CRjkb83QZ26pD3w9u43vziqoem9uwj4vJMmKldLPhCop4jkEcXylFhkpl4I/LvQi2pgX8bqHSewwc3EtA8xDoSi/QHZpnIZVKdnDLqqJxz4ZjHeV3wCmBhb8kmyMs+7ttFG5GqzwbzIXkM97p5FW415z/OXoVVWigFcoX1XERC1QPdhu9FP9Rzt7XXVz7mivN54AEp9VrEVGjqN5artGhYX4dZ0e2u8mBArPgH4Yok7IDi5mCCH68tAvyE4J9UevMn+PnBbYsx6D91LkBlO26oEPWZeqwy6nYTmpczAI4X+wjsRy6T5cR8LhQDpgFCzE5r1pmGBXl0RDowrNu6KTgCTYt0zWNSCYoMcpv87IJxihoIDp6pO6Vq6dX+m937AOMgFW2WVHDikEnRtk6jr7Eecsjoz1PjAnUHiRAF9TxGmV5RvFe8Mr1w71vKvPm76umJcrdwEMFeUz5d8FkBLMQEO7WtvsiBSx6RnTl1W43/8bwBy2agM3ZA8Lfi+kwzd0PJGlxwhxD9SgpxLWrvhRzVpEvDzVDi4ybLgfP2v2ATgjyTOEsIf8g1oS+0JeNLyWCf0tE17s3b/+JkBdX1fL1/y0uzWd5zkVwotbyR5hpBcroCdSmGvqm1Y3JtpavC90LbXy4XGUZEJwH4e/0BJDxR9otDANutHuHud8X5oZdv+6+3v7Bd+Y9c03C/AIY7ZKLOQCD1jAOcsbw/Yd05V+5nStXSH3kzfZQrq7KoNonSO32qGg2cUaq4iE4A/kvyOkPyy0KA2/+OXG03D/OrGaim7di0cPap/zL2KcJhjNsoqxExCl6YazLn5VoQpq9tZjA8c5irqFj2FuCVQzIqNluUdgSWFjGXFJQD/TcvHWqPXv6igdiwkoGF++eeaoeCPN/77lK6ljX2ZzF9qZp6f+XWQ0WG2Bx5yhFeFiUyOdHv7Se5QMKZWmGuV5M79Zjh4TCEOVVwC8MaS3yeRnxYSzKZ9mCHGOWZ74MaN/z6wSOW1HW6H4ITi9cuvYL/T8Hg8Jy9tm/Ja+b1xzwP7cW3rtQ3RWhk3N0gxaP+ecODJfLUrKgHs2bVoW0/GeLHYMlv2UlbDUO2pUPD2j4DYswrN8c7NaqnlS6xS2hPuXWe837bxnUaluOWWHwPJe9V2t9XM+DkMSoC/psPBI/OVragE4MSzPwnWEeTk5e0tfx0MwxdN2HcCX8oXUCW2F9Afx+/y1pxHDj00U4n+uebTXFF6d+YW6FZzWXB7r/+7YxpeUsreVFLw5x1F6pih56z5ookrABS1ZrpgjxzuSIJrU+3BCxyWrR45EfLGEvMI1F49TpfM07zfBVTMHYAvmjgdwC0Fo7LwJhqMI8yZeyUGazj3TqFgz5zrSHKLOTN4Zj5nvzlnvHKUNuzWXPcQAQdWjleV4YliCuQzI1AxCaA5ujhZ6Jtee120UnT4xtV9G4fCH0mcI4S8SyVXxlAO9YLuND3Lv1hL03zFcPZFF+0Ey3gKhppYjE4N9r3NDAftH9OcPhWRAPzRxGECDKzLz/vD1iuWNB029GRVXyx+KkSimx2flLeB8ncQ4HHZbqvPur5rr/yh5uVBc+fiTykYi0pRHzIvx8rYeGCTG1m7p0LTVufiRkUkAF9n8k9Q0paLw4Pb2Ov6PeDDlodaXxr8775I8rMs1n1KqcZ8NSutvX13M8pjTKv1qb5CuXtjifNJ8OtC+9dkP5LLzFDLd3OJrewJwD7oEH20Mu8/VotXWB7PoStCU18ZHGhzLN4KkUcV1NhcAFRyGzube0jNGPpSs5J9LrlvIuSLJv4KoiNKbrtCDTLzfzP9241/afYeH2RzsewJwBtNXETAr7I5usn3A+W76NCejuDKwf/uvy2xhyh+Ekp9PC+9Sm0sdJ7ZHvhNpbpXKX75Y4vHiRhLAWxXKT6V3Q/B6WZ78LZsfpQ9ATRHEilF8GVz9KPvSXpgYIbZ1rJqcJ+BDST9mSfz0srZaOkbktDfUu2BOilLVjxfXzR+IUBXFq9UIwokT5mhlv2yRVPWBOCNJfYlwVPZnMz2x19700L0nkW019DHm5w51WFDex3Je2Mblupj2v83+LmUDCtvAogmribg67ldr/wCszpk6G0/RKg5mozVVPluoi+bocD/5cZFt9pIwB9LHC+CuzWRDQTsU6x72lvO3RKP8iWAuaIm+pasNCC7ZBswErysYB28rH3av4e29UUTlwL4XjaNavmegEdT4WBN1iUsxRh4o4nH9AKhDxMA+K0mT+O4pW1T+kZiX7YE4I/EDxWih3O4KFZB6GCzPfDC0LZ29ZjNjkrKQbBymzAz0fSeUEt35fpY2Z55Y93HkKh7K9vLEnpHcrIZarmzAhNA4vdC+EoWFG+QhYNTs4Kpoe2ao8lDAPm7AhpKiNNtU0VVd3HbuarQH9grkEwOPUKrKnx3w0nC3WYoeGLFJQBftPsVQO06kmP2XKYHxozh1jXb032Wh59xrGiIG+Dz1LR3MUqD+IbObuQpo5sD8MXisyCUdQqsHmDZa0lGC318pIrQZXkE8Ea6W4jUiLe59hl9SuFwc2brM0MHyS7h3ZfJPFlrGZ6Ags94r4cLOZ8YB06R3qphFQzsnE+/Wm0rQrPT7YFhN9qVJwFEE5cQ8LPhgcsHDHVkTzjw6Gbf26u+5ifvrLnKMBb3GrD2WDZr+qu1ehGWOi5vtPsagqrfbdODgTPdZ3YEjh1uDMqSAHyx+JMQ+sxQh5iRIchJ6Y6WYV/i+KLxHwL0UX2/Ul9UrtkjudEMtcxxTb8OhbPdZdYTErtCFtC7c0/HZ94bGnfJE8DuN3dv19iEtzbbpccspOi0VLilc7jBGXi7a+EeKFVyn129WBgWe5S/Z+bUFa7aqUNxXzQeByhYh6FvfvNM1J4OBaJlTwDezvixpOieoY4I4YJ0KHjtcIPVPH/JRMW8qCbXemd5S6sv3sIJ+KLx7wL0i8IVaqgnc8zsaA2XPQH4I4nLhfCtwY5s6Ygj+7juxqb37Gqnjh4RVilDKyzHjfTIUyk+VqsfkzqTU1lJslr9d9Jve1atpzH9saEFZUp+O+2NJP9FJPt8FFyW519fLPEHCM5yEkalaDFjdU9jaoKu8uPeiPgjiX8LYYJ7FqpHmZgPTHW0PjHkx7d0AdhTeL19mbeVgmeDVbrTNKeeMtJR1b5I4jQQbi2dhyW2RHypGWq9pMRW68qcN5b4HQnOqaugRwp2mOutpHcAg5f/2mWu+nu3OWKkogX+eQm/ZeBZBYyp1cEjC5OGW+VYq/GWIy69QWgQdcbTZkdwk9m3kiYAXzT+TYCuAOj5JsGBI61Osrf3qnfef7q23+DS82Y4MKUcfxT1ZHOgeCgaBk6DrvePPc1u9DbtkDpr0pqNLEqaAPyRRESID7bIs/+W9rr7OpPXQsl5NT1g+va/ZMPrjSZMXSfgQ9xCx5jtgfvLkgDsBUDKUl/eUt1yfzRxpAAPlOzqKJMhIrVPKjTVntrUH5cJ+GLxmyFU8BHaLrtXUvmhS85Ldgdgn8rbm7H2G3aJ74cI7Ns1C43JXGoElJSa88ZWmeHgiBuhnDdX34q+SPLLILmhvil8GP2QUmElSwC5wPfFEndAcHIubau6DVOn2RGYVdUxVJHzzdHkfgqysIpcds9Vi3sbmhq32VgkpGISgDeaCBGw2VJF90iUUVmX/Cop/A2nTje8U1KjlWxs0CGiFZEA9ogu+biBzNJa2t+/pfFXSvzLZ7aYlXyN1JpvzZ2JVUUePFszSAYvu6+IBOCPJm4X4As1Q3hLgbC8Zna0ZK2DWBcsShikLxL/mz48ZANwgUTS4ZYO+//LngDqcqEGwyrhta9NDRBgVXM7SQscWQGeS4eDU8ueAOylwf19vc9DGZ8sMBbdTRPQBPIkYJcJ23ZN/5hn50zvL+sdQHM0eaWCXJin/7q5JqAJFEmAoIKp8FS7eGp5PvbRzoCR+N/GoPL4oa1qAvVIgIQ6Uu2BSNkSgC+a+DuAz9YjfB2zJlBuAhtrcJQlAfiiyRMBGfGwgnLD0fY1gZonwNRldgROLXkCmLFggeeVV7d7zoDy1zxkHaAmUKEESKzFqfZpe5c8AXij8TkEur5CuWi3NIE6IUDvmeHAtiVNALt2LRzdlNl6RR1s9qmTi0iHWc0E2GN9rKQJwB9NfF2Aq6sZmvZdE6gVAqxQukcAu7qv0bTmBf3rXyuXj46j2gkwcHzJ7gD8kcQ5QvhdtUPT/msCtUJASM4pTQLYcGRzSpdlqpVLR8dRCwTstQAlSQAjnQZUCxB1DJpA1RIg3FSSBOCLdj8KqIOrFpR2XBOoSQJ0p+sJwBuJn0xEd9QkPx2UJlDFBAh41NUEsKG+/9rnAbVnFXPSrmsCNUmAYS1xNQF4Y4lvkeDymqSng9IEqp4Ar3QtAUy6ddmO3NDXU5NHelf9wOsANIEBAu+4lgC80e5rCOoCDVoT0AQqkwAD77uSAJrnL5kI5mUKaKjM0LVXmoAm4F4CiCTmK8KpGrEmoAlUNAHnHwEmRZJ7s1jP6AqsFT3w2jlNAMxY7fgjgC71pa8sTaA6CDBkuaMJwBdLHA7BQ9URvvZSE6hzAiwLnU0A0cTTAD5d51h1+JpAVRBgyF2OJQB/JHmCkNxVFZFrJzUBTQBC+L0zCUCEmmPdCQVj4Lgh/dEENIHKJyDA9x1JAP5ovE1Af6r8kLWHmoAm8BEBwenFJ4C5ony+JUsA+ZRGqwloAtVDgEEzik4A3mgiREC0esLWnmoCmoBNwBBr9+ISgP3r35x8DgqTNdLcCNhzryB6K7fWupUm4A4BJRabnp5Di0oAvlj8VAjNd8fF2lQl4BupcPCa2oxOR1VtBApPABsKfdrHC+9VbUGX1V+mTrMjMKusPmjjmsCHBApOALrUV6HXED1vhgNTCu2t+2kCThIoOAH4ovFFAO3tpDP1ocU8KqO2SZ4WfL8+4tVRVjKBghKAN7rkCAL/rZIDq2TfiPnAVEfrE5Xso/atPggUlAB80cTDAA6tD0TOR0mg76TCgV85r6wVNYH8COSdALyxxL4keCo/M7r1YAIi8o90e8tnNRVNoNwE8k4A/mjidgG+UG7Hq9q+xb3rmtZvv7Jt//VVHYd2vuoJ5JUAfJHkniArDShV9ZGXOQACjkqFgw+W2Q1tvs4J5JcAYvHrIHRunTNzJnyRq832lgudEdMqmkBhBHJOAFMjye3Xk7yigDGFmdK9NiXAL5jh1omaiiZQTgI5JwBvNHERAfrNtYOjpUgdsDw0daGDklpKE8iLQG4JYK6oic3JFYbC7nmp68ZbJGBXZEmHgl/VmDSBchHIKQHocl/uDA+D39p2jbXLs3Om97tjQatqAlsmkFMC8EbiDxHR4Rqm8wRI6MRUe+Bu55W1oiaQnUDWBOCfl/CLgeXZpXSLAgksMMPBwwrsq7tpAkURyJoAmqPJKxVET1cVhXnLnVlh756ZwcUumqhL6cmRbq9F6nEGG3UJ4MOglaVeNmcFpw3HYIsJoPn+dBPeWbtKQe1YzwBdj505Zna0hl23U2cG9KrVjQNOvzTDge/lnQC8sWSYRCJ1dt2UPFxmZBrIal7WPu3fJTdeowabo8n9FERPsQJgtqb0dEx7Pv8EoF/+le7Pg+QWM9Qyu3QGa9jShlqVC6Gwbw1HmVNoJNbiVPu0EZie6DMAABL/SURBVOt2jPgIMDG25JOGZF5ydd0/030WZIpeX2CPJTMTTe8JtXTnNLK60YgEfLHk1yDyG40IEMj56XDLdSOxGDEB+KIJ+5nhUvcgMis2WljxSQD92D07VaWsZwSKHC5/bPE4Ec8yQLYpUqrquzPwPnv6x7/QNv3d/BNAZ+J5N8t9s+BPPe3BmSW506iiodTrAoobLH808RcBjitOpUZ6E24yQ8GztxTNsHcAzfMT0xTjWfcwMDPL1I0vJnydiQegcKR79qpJmVf29WLqS7Nb36kmryvBV18keS5IRrzdrQQfS+kDkdonFZq6KO8E4IsmfwHId11zlvBnMxRs26ivKwxvSlogkXS4pcM1/jUo7I8uCQispwEaVYPh5R8S42mzI/iZbB2HvQPwxeJpCDVn61zo9yLcmm5vjX/Uv6vL8GX8KwDsVqhmrfUjobZUe+DPtRaXG/HsfnP3dkYTnjKg/G7oV6NmrtfPZgnAG+luIVLuvYlmPGh2BI8aCtUXjX8ToCuqEbYbPjPzf7mxofWFtr1edkO/ZjTtH49+3wMgOqJmYioyECa82GOkvGhrs7JJbZ4AYsmfkMgPsnUs9HsSOSzV3rJgaP89uxZtq/qMlUqprQvVrrV+YnGysanxgKVtU9bWWmxOxePrTF4LJec5pVcLOkK4IB0KXptLLJslADcP/Mi2KMEfSfxaCOfn4njdtCHca6YCJ2Aucd3EnGOg3ljy+yTy0xyb10UzBv6zVQa753rwzCYJYOJtiY8Zil+DUlk3CRVEk+Q0M9Qyb6S+kyOLd+snI62AhoL0a7STANekw8Fv1Gh4BYXli8YvBOjKgjrXdCf5nhlu+WWuIW7yh+6LxWdB6LZcO+fVjuW1hsaG3Za2TenbUj9fLPEHCM7KS7seGpNcZoZa3JuZqSKG/mji6wJcXUUul8RV+9e/yePZI59Hxk0SgDca7yRQuzve0k/McOBH2bTt0uMsklIKnmxt6+57XUkYrk9RV/VFld+vvx3qpncA0e5XALWr0wwY6G+w+ndbNmv6q7lo+2LxmyF0Ri5t67DN70xP6vxc3vDWEpspXUsb+zLW7wlyZi3F5VgszK83NDY25/Prv0kC2HDoh9hz8Y5/BHx7Otz6xVyFm+cvmQjmZfpdwAjERP7e0NAwc2nblP/myrSa29nr+yGGfSLVftUch5u+C8k56VDL9fna+OgOwB+NdwhoxBd0+QoPbs9KPt8zsyWv04T19M6WidtzvYqMk8yZeyWKGZtK7zsp1j2DLcyHUh+vdF/L5R9Dlu+6y9tTHzn00Ey+PnyUAHwunfozsChhZmAiiCQf53zRRTuBG3qgsG0+/eqpLQnWMcl302bwt7U2Tbj7zS+Oamh67xfEfIFrs1I1crEQ4YRUKPiXQsL5XwLoTDzlSgEFwlwzFCxou6/7W5ILQVaBfVgWisc4Oz1z6rIK9C5vl3yxxEEscqMCTcq7c511KPak6YEEMGPBAs/qlduthaGaHOXHLMRqYuq04IuF6O7atXD0mP4xy4UwoZD+ddXH4l4YxmW0vvGK1FmT1lRj7Ht2PTfBY1lXQJDz+6JqjNMpn+2X6woUMMOBgqt2DySA5mh8igI955Rj/9Phf5rh1kOK0dU7BfOjZx82Yohx+Zpt+q5bfdz0dfn1Lk9r+yUfi3ERMeZAYXR5vKg+qwRcngoHv12M5wMJwBdJzAQhVozQcH0LfTM5VEvXCyhgZJhfF6Wu81j9f8x1+rUAK0V1+fDMifNh8VmO330W5VlVdF7V4PFMynfab2hkGxJArPvnEHWxk2HblW6V6t/FDE//T7G6E+ctbTbQ95y+SPInaY8DlNxrgG5IeVJ/L/f6AfuxbnRmzIkKmCNAUXeH+dOonR5OVY4aSADeaPfdBHW8k3gE+Gs6HHSsyo8vkpgLQtaVhE7GUGta9uMBgR4koXv7+vjBUlUdso+W/0DhKCVysgUcqY+YL+7K2lhOrziVDb033AG4Uf9PaI7ZHrjRCSdtDXslWG+md5GCMdUpzXrWGbgzIMQNomcFskiEF40f985zhcwlD+a49w2LGtZt2+C3LOzFkANBfLBi2ktP5Tlztdnr/eGxPtXTNu1NJxQJIuSLJdY5W0qJuR+ecS+Gp77uhJMbNexahcjgab1PwEmqg7QYFhS/CqaXoehlgbxMQu8SYR1D1tv/JUGviF12i0YRZDQgOzGpccQyDoomMMSrV3C6ND6wy3wjnA4HHXtfR82diV2VwiuOusyy0OxoOcBRzQ/F/NHEzwS4xA1trakJVDiB+WY4GHLSR2qOJg9RkEecFBWiH6RDgZ85qblRa2BTSG/fM2SogBv6WlMTqEQCJHi5t4+DTr+3ITdqAORSjrgYyM2diz+lYCzSc8bFUNR9q4cAM8M4rCcceNRpn8kfTX5bIJc5JmzhTbMj8PF81/7na98XSX4ZJDfk20+31wSqjgDxpWao1ZXHXvJGE1cT8HWnoBBwRyocPMUpvS3peKPdfyaoktgqRTzahiYwlAALHu5pSH3OrfUb5Ism7DeKM51Cn+0wQqfs2Dp2PXjPKLVYCfZwUldraQKVQIAZq4XRuuK04Btu+UPeaHIBQWY4ZkAZLaXco+6b/1yQLGuhELZyLAYtpAmUmcCGlbRyqBluedxNV8g3L7EYBlqdMGKfRtrjSW3r1u3KSD56o4kQAVEnYtAamkAlEBDIV9LhFtffcdnvAEwCvE4ELcDj6XDwICe08tVojiavVJAL8+2n22sClUaARX7b095ybin8oonR5GoDsosTxspav94+IqrPf68+ZdiJkdQa5SJgF/gYP+7tI4tdkp2r/+SLJt8FZJtcO2ypnYDOTIcDNzuhVYiG/6blY2X0B48BFCykv+6jCZSVAGNZE9EBS9oDb5fKD/J1JjJQMJwwyIz9ejqCTzmhVaiGrys+Hhl6GsD4QjV0P02gDARWZTzG/qU+DJZ80W4LUMqJgJnXb9vT8Zn3nNAqRsOeGWDuf0xBjS1GR/fVBEpCgPGuAh20vCOwpCT2Bhmh5s7uXqVUY7GG7W2KPeHgzsXqONV/oJy00APO7nJ0yjutowlsJCAfkODo4U7MLgUj+xFgnTNr6iVhhltaSuF0rja8se5jRNSdentqrsR0u1ISsIt6EvFJ6VDrfaW0O9iWfQewRim1ddEOMN1ndgSOLVrHYQF/NN4mkJhTjzkOu6fl6pUAwxKFU9Ph4B3lRGC/A/gvoLYv1gkB/TEdDlTkqb7eSPIMIusmnQSKHWXd3xkCzAQ6PRVu6XRGr3AVey/ASwB2K1xiQ08SXJtqD15QrI5b/f2RZLuI3OrUjIdbfmrd2iYwsMSXMMtsD86vhEjJG0n+i0j2KdoZF7csFu3bhwL+SPKLlkhUlxRziqjWyYcAM/cpg2aaoZY78+nnZlv7DsB+AXF0sUZI5Iep9pafFqvjdn9/JHmCsPUnXWLcbdJaf1MC8gFEfcFsD9xfSWTsBHALgNOLdUqIfpoOBX5YrE4p+m84cVbdpQ8eLQVtbQPgt4lxXKqj9YlKo0H+aOJXAlxUtGMkl5mhlu8WrVMigUmdyakZyINKYVyJTGozdUjAruXHhjqyUg9uJX8kcY4Qflf02DBdZ3YEzi9ap4QCA4dR9lkPQmFyCc1qU3VCgGEtUR51lNnWsqpSQ7ZfAh5MJEUXGxTw7elwa9Wd6mpXFWpqNP4kJJ+r1EHSflUfAQH/pdHT2F7s2X1uR06Tbl22Izf0FX1+HwFPpsLB/d122BV9eytxv+9yEH3DFX0tWl8E7MfhVPBizCWu9MA/PBos/ioUfaIYZy3QqyvCgap+nh5YMMTW9XqGoJgroY77MtbDkDlmqGVetVDYcDhoJP4QER1erNOG1T+uUo+izjU23/zufayM6jIUds+1j26nCcDiFaJwSrq9NV5NNDYkgFjyJyTyg2IdZ+D4nnDwnmJ1yt1/4DRbsm5x+sTkcsel7btEgHB3xug//YW26e+6ZME12YEE4O/sPkCUcqL66JVmOPgt17wtsbAvGr+QQb/UuwlLDL5KzA2s7FN0sRkKXuX2QThuIRlIALBfgmX89ovA7YozxC+Y4daJxWlUVu9JkeTeLDJPTxVW1riU3xt6HkqFS1kC342YNyQA+zHAoVN2mGRaT6il2w1ny6W5+80vjmpoeu8XxHyBPue+XKNQIXaZBQb9dp2x7tsr2/ZfXyFeFezGRwnAH4ufKUI3Fay0sSPhJjMUPLtonQoU8EfihwqRXfS06N2TFRiedikrAX6BoL6UCgcfztq0Shp8lAD27Fq0rco0rFLAmGJ8t5+LDEP2SIWmrS5Gp1L7Bm5LjFnnoZ8olgv01uJKHSWn/bJ/9nHd+2Oti1cfN32d0+rl1PsoAdhO+KPJ6wUyp1iHhPD7dCj41WJ1Krl/8/zENMVyI0B7V7Kf2rdiCUiCoc7pCQeeLFapEvtvkgAmz0/sZTGKr0xqJ0xFB7t9rlk5gdpLiBua1NeI8WN9J1DOkXDJNuNdMfDDtJH6bamPunMpomFlN0kAdgunDgu1wCnP+tH7pM6atKaUAblta3Kk22uJcR7Dmu1ILUW3Hdb6eRJgBtS8fqjvvBie+nqenauu+WYJwBdJHg0SR6qUktDftl7bd+yzc6b3Vx2ZwQ53dRn+/knHMsk5xPw5PRNQ1aO5JecfEuGLqm01XzGjsVkCsMV8scRdEJxQjPBHfQXzzIbU7Gq8jfLfltgDhpwpJGcAaldHeGiRiiMwsG1Xeb5jzgw8UHHOuezQsAmguTOxK8DLnLrFte8EevusU1+a3fqOy/EULd/c+dQ2Bo3+IgizhPng4n7trccEHosgM4p2TAs4TkCA55TQT1LhqbdX60q+YqEMmwA23AUkvwGRq4o1sLG//U7AUJhlzmx9xilNp3SmdC3dus+yjidIG0Q+X/xpQrwSRBebM4Od9oXliyUOEsElBHzeKZ+1TuEE7F98Qzw/rec//I30RkwAA8uDLd/jEPpM4aiH9hx4wXKT6m/83vLTJ7/lnG7+SpPnLdrF8jQeC5ETYfHhTmwBZub/Gsq47H3P2uuGWyXmjy4JCMtFDJmpKxPnP2bF9rCP3lZEV6TCwQeL1aqV/iMnAADNXYt3pozxBAFeZwOm98C4lUR+m5oVTDmrPbzauHsWbbX12ob9ADkCgiOdPEKcwW8ZQr/ub8hcm8uOMPsEY+rHV0TkS1Dq46WIv25tWNwLMv7MBl9Va0vUnRjTLSYA28CkWPfu/WIsNCC7OGFwE42B9QLqEUDuNRT9bdnM4HNO2bDr/RkZa5+BMw8sHMSK9nF+Vx+vFFK/bjQ81xdS+mlK19LGPss6hUTOBvOM4t43OEWuRnTs/fmGuoHQf7MZnl50xasaobJZGFkTwMD7gPnPBcH8T0C2cRMEM1YbCk8KcQqsUqKQIkNWct8Ha3ra910z+EXNjAULPKtfHbsdk+eTBqsJTDyBQJMImGIBUxSwk3u+yrNC6qrxn3ir65FDD804Yad5/pKJSjJnQlS73mtQGFES2Mt072JSt6RDez1Ury/28qGXUwKwBf2xJdMzFv+5bJVymIUV1irGOlZq62L3LOQDyW5rX1xMNJ+Udb2rLzJFyBdLHEBC7UI4GcDH8vW1vtozi9ACIprX4PHcUcidWH3x2jTanBOA3W2ggm6T+oMAX6gLaHbSMdRCgnRaRiaWy/O9o1y6uozmzKQDFeMLRHKCECY4ql+tYhue6x8ikjutBusvPW3T3qzWUMrtd14JYKOzvmjiq7D4KifenJcbwLD2GUvFoPmqXyKp04IvVoqPzdH4FAPqGAaOIsvar2b5Dw/83wD+RoS/YV3TX2ttiXm5rrGCEoDtrHf+ksmUkYtrY0pr4G2k/Ut/l2U13L1i1pSecg1IrnZ37Vo4enRm7IEEOUwg9n+nF79+IVfrJWm3CkxPgPAYsfy9VLNFJYmsgowUnAA2xrDhbXv/hQJ1dqmfy4viaPEKGOphkPwDkvlHtb8ptmcUevsy08jAp0mwtwDTiDG5GnYqMniNgsTBnrgYeMrDmSeWtU+zf/H1x2UCRSeAjf5N6Vq6QyZjnS2QI0iwvxC2ctn3nOXtIiUglSSFZ8D0Lw8yC+rhAhsoZdb4ziQo41MEa4oIfGSpiTBootszOsMNDgP/USwmFKUFSANYLkrFe07d6wX9xj7ny9nRho4lgMFe7X3Doob3t2nah4UPIaEZIrJvaU7iZbZYvewhMkWQIpJlUOoZj6GSS9um9DlKrsrF7BOhpCEzXpSMB8t4iD3bIDuBaEcQdiDBWEswBiRbC9MoQ7EHTB4IGZZBGY9Ivyjpg0X9EHwgBr0r4HcU4R0w3gbRmxCsgsIqCK2i9Y2r9HN75V00riSA4cK0S4419jVOsAxrgmI1QYgmCPiTxGo7URgDwRgiuxyZjGFgjAIbYPQRqV4m9NLA/1u9TJ73iPEGgNdFyesEvM7A6w0KL65fv03PS7P3+KDyMGuPNIHKJPD/RIpzV851P8oAAAAASUVORK5CYII=",
        firefox: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAHwCAYAAADQAtd+AAAgAElEQVR4XuydB3xUxfbHfzN3WwLSsgmKqFTF3p5dyQYEsVewPrvis2BDkmCLTyAbULGAij67fwsW7IqUbADFXlAUBSmKlGQDqCTZ7O6d+X8mPnigIdnd3N295cznw5MHM+f8zncu2bNzZ84wUCMCRMD8BKZO1fpVd+nUyLmfS5nHBPMLyDzGhJ+B5Qn1X8m7CIEcxqWXAR4I5gF0L+Muj4D0QgqPZJoHkF4uhAece5oCFyIqOI8CrJFJPSrBGzXGolLEo4DWCC6b/k4IRDlHA4BaBtRKycISqOVgtZLLsGCs1itEeFHBug0YNkw3P1RSSAScTYA5O3yKnghkn8CeZVM9kfz8naWu92Ca7AnJekDKnmDYGWD5DPBLITqDc2v8exVCCs7XcaAWkDUMfIWEXM7Algkhl3OwZd51tb8sLBsWzT59UkAEnEvAGj9QnDs/FLlNCOw6pdIv9NieQtd6cSZ7SCF7QkMPIWVPLrCjZT7cjZsPIQR+5ZpcLgRbpjEsl4wtY0xf5hL820VXH11rnCuyRASIQHMEKAGg54IIGEigz/3veHX4+mlM7C0Z9gGwDyT2AcMOBrpxgqlVQmAB18QCCb5AMnyTW71uEa0aOGHqKcZMEaAEIFOkyY/tCOwy5b0dtJhnf0DuzYF9pMQ+gun9OLjLdsGaICABEefg3zNggQD7hkksiHtiX60YPmS1CeSRBCJgOQKUAFhuykhwVghMnar1XOPfS9PEEZDsCCn0I8D5LlnRQk7/SmA5Az4QkB9AYt7S2g8WoqxMECYiQARaJkAJAD0hRKAZAntOrmzfIGOHAPwISHmEZOxQDnQgWBYgIPCbAOZzDR9CsA/aReIfL7jpmDoLKCeJRCCjBCgByChucmZWArs9Nm87vaFhgA4+kEEcwQTbFxyaWfWSriQICOjg+ArAB0zyWV7OZi+8qmhjEhaoKxGwJQFKAGw5rRRUqwSkZL0mzdyLMQyRwLFSyCM55+5Wx1EHyxMQQsQ453Mh2buMsXeXXFX0HRiTlg+MAiACSRKgBCBJYNTdugR6TZnREVEczRgbIiCGcPDu1o2GlBtFQAj8whl7DwzvMtE4a8mI4343yjbZIQJmJkAJgJlnh7S1jcB/v+WD43gIdqxk4nDaod82pHYf3XTSQGofSJUMaPG3f7pi8EJaHbD7rDs3PkoAnDv3to28z6TZewJiGMCGSch+tg2UAks/AYnvJWcvChF/cfk1xyxKv0PyQAQyR4ASgMyxJk9pJNDzwdm7MSHOFEIM0zjfM42uyLRzCXwDyV6UQp+69NrBi52LgSK3CwFKAOwykw6Mo/fkyj5M6sMADJPAvg5EQCFniYBg+JJJ9qJbxqf+cM0xy7Ikg9wSgTYRoASgTfhocKYJ9Lx3ZlfukudL4CwGdkCm/ZM/IvA3AgKfMo4XIKLPLBlxXA0RIgJWIUAJgFVmysk6p07Vetd0GQTBLhNMP4k28jn5YTBv7E3HC6FNk5CPLl03bzZVIzTvXJGyPwlQAkBPgmkJ9Lm/srvg+sVMiIup7K5pp4mENUNAAss48B9Niid/uGbwKoJEBMxIgBIAM86KgzUFyipdK/PkcWDiMgkcB4A7GAeFbnUCTVUI5dsS7NGlBevexbBhutVDIv32IUAJgH3m0tKR9Hiosocm4pdCsosAdLN0MCSeCDS3KiDFrwz8canL/yy9btDPBIkIZJsAJQDZngGH++87afYhgokbIXE6fdt3+MPglPCbVgXES1Li7qXXDP7MKWFTnOYjQAmA+ebE/orKyngf/xEnSsFGguNI+wdMERKBbRCQrEoyedfS8Lx3aNMgPSWZJkAJQKaJO9hf93s+zPG4Gy5gXN4Aib4ORkGhE4GtCDCwRZKJe/Rc1zPLLyqKEB4ikAkClABkgrLDffR+aHoBi/MrdSmv4pz7HY6DwicC2yYgUA0NkzSX9tCPw4vChIoIpJMAJQDppOtw233un9Vb53IUgAs44HU4DgqfCCRBQDQwoT2psfgEqjSYBDbqmhQBSgCSwkWdEyHQc9KsXRjTb2U6vxAcWiJjqA8RIAJ/J9B0OyHwGJgc+9NVx/xCjIiAkQQoATCSpsNt7frQrB1FDDfr0C/lnLsdjoPCJwKGERBAFGBThDtWvmL4kNWGGSZDjiZACYCjp9+Y4HtMrtxeg14iJK6gpX5jmJIVItAsASEi4HwyE9EKuneAnpG2EqAEoK0EHTx+1ymVfj2mjwLE1QDPcTAKCp0IZJSABOoA3B+Nxu9aecOQdRl1Ts5sQ4ASANtMZeYC2fnBuZ3dMnKj0OW1nPP2mfNMnogAEdiSgAB+16ScKDyYuHT4oN+IDhFIhgAlAMnQcnhfVaf/l3xxBZPyDgl0cTgOCp8ImIaAECLMmHbr0q61j9J9A6aZFtMLoQTA9FNkDoF9Js8aLKQ+kYHvYQ5FpIIIEIFmCHwDya776ZqBs4kOEWiNACUArRFy+N/3mjRzVw7cLYETHI6CwrcgATcEAAnZ9L/qxx1r+q/6kz//v23bNI1j5I9XHr3UthFSYG0mYOt/AW2m42ADPSZWdtLc+i1CiBF0pM/BD4LFQ1cJwA5iA3YWYfQWYfQVa7GrWIOdxbqmNEA1lQgIMESZCw1wI6J+MXfT7xvZn79Xf6b+fwPz4DeWg99YLjaw3Kbfb0AOfuO5WM9ym/qZpamjg5pk92i53nE/XHLkH2bRRTrMQ4ASAPPMhTmUTJ2q9a7ucokAG8Mh880hilQQAWMJtJNR7C5WYW+xEvvEV2Jf8TPUn7W1qSRCJQVhtMda3hFrWAesVb94B6xhHZv+rJa1y+zqg9DXSOYavbR27lN04VBbZ9he4ykBsNd8timavpNm9ZeQ90tg3zYZosFEwGIENEjspq/GQWIZDo0vxT76SrigpyWKODRU8+2wmnXCCp7X9Gs59zf9VyUMaXw18TkYG/HTVQM/TEtgZNRyBCgBsNyUGS/4v8v9EwBcarx1skgErEdArQYcoi9F//iPOEJfjA6yISNBRJgLvzCVEPyZFCzl+VjEd8Aq3skw/1LiQS6jpUtGHPe7YUbJkCUJUAJgyWkzTnSvyTNOY7qYDK5tb5xVskQE7ENAg8BB+nIMjC9EUewHbIfM39b7O8vBj7wrFmk7YBHfvum/K1nnlFcLpBS/cq79a8lVA9+0z0xRJMkSoAQgWWI26b/bA+93izM+CcCpNgmJwiACaSfgho6j4otxfHwBDosvhnp1kK1Wxzz4ge+ABVp3fKntggV8R9SzJC/dFGyqEHLEsuuOXputOMhv9gjYOgFYGyzat2tJ5dfZw2tCz2VlvHf+EZdAZxPA0dGECkkSEbAEAb/YiOP1r3Fq9AvsILNfhE8Hw2Jte3yp7dz06yu+c9OGxFabwHrJ2I1Lrx7wJBjLXkbTqlDqYDQB2yYA4YoBBwsZf78uwrfvWRbK/Jqd0TNlgD11pp9J9giYLDTAHJkgAkQAAAdwePxHnB37BP/Ql5uGidpMuIz78YnWEx9qffCFaxfEWrqdW7BZDBi+ZMTAn0wTBAlJKwFbJgC1waI940LM0TjrooPt5/RVgAOnfOb+LbZhpA7cTrf1pfXfExl3OAFVY+C86HwcHf8uq68HmpsGtcHwc60HPtD6Yr6rN1ax5jYWigZI7badavm9obKiuMOn0/bh2y4B2DChf894jM0DZ93U7Ekpz8kvrXre9jO5jQB73fd+X8b4/4HjIKcyoLiJQKYJdBfrcEHsAxwf+wZqE6EZmzppoFYGqlz98LXWfesNhRIfaRrOpUqCZpw54zTZKgGoqThiOybdnwDotwWiMf6S0K3GIbOIJSlZn0mzLhYM9zGgnUVUk0wiYCsCKhG4PFqFQfGFTa8KzNpq+HaYrfXDLNeeWKDt+Gd1RCE2co1d9dOVRz9DewPMOnNt02WbBEBKsJqKwCv8L7vaBeSrBSVVp7cNk7VG95s0My/257v+06ylnNQSAXsSUCWIr2+cgQNNtEdgW6T/mgzojL2oM++/fr7yqPX2nB3nRmWbBCBcEbgZEmP+NpUSi/2loV2dMsW9Jr0/kIE/DaDpFQg1IkAEzENAFRa6Pvo+uokN5hHVgpLVrCPedu+Dd7S9Vq9ydz57yZWDqywhnEQmRMAWCUBteWCIzuTbHOxvq2xCQDIt1jG/+ANbX4bR5/53vFJzj4FkIxOaeepEBIhAVgj4ZBwXR+fi3NhHaSs3bHRg6pXAZ3wXfKXt9Ea73zf8c8QdD1AVQaMhZ8Ge5ROANRMGF2jR6EKmwb8tfoLL/gWjquZmgW9GXPadPGN3XbDnGMN+GXFITogAEWgzgb6iGrdF3mi6ndBKbaNw6Y2ad2pn8ceEgtI5X1pJO2ndmoDlE4BwsP9rAD+5pYllwHV5JaH7bDf5UrJek2YPZ1KfCM59touPAiICNiegTghcFP2gaUXArKcFWpoCqWMed+G+Lj3zp7FhL6Xn9iSbPwPZDM/SCUA4WHQ+IJ9qDaCAfLqgpOqC1vpZ6e+7TXkz1xfPmcIkzrOSbtJKBIjA3wnspf+KOyPT0E1aY2/AXyOQUl8B8Mlu6P/pVDqPNgta5CG3bAJQWxHorkt8w4FWr8mSQi7MH121l0XmpFWZuz44s5cQeJWu7W0VFXUgApYhoG4gvK3xDQTiiyyj+W9ChaiDxp+RujYxf/SsH60biDOUWzYBCJcXvg7GTkpkmgSkcMHdpUvJzOwX7E5EcAt9ej8w61hIqQr7dG6jKRpOBIiAyQgwSJwfnY/h0UrTVRJMBpX6masJNhWcjckrqVyYzFjqmzkClkwAaoNFx0jI95LBxMCG5JVUTk9mjKn6lpXxXv4jb2FClIFzS86bqXiSGCJgYgJHxJdgbOOryJFRE6tsXZo6hcW5eFWHdqfTS7K3TivzPSz3QSKnHOiuXb/dgr9U+2uVnJTszvzSytta7WjCDj0mVnZyufVnJHCCCeWRJCJABNJAQBUPmhh5AfnC+ieYmxIBJt+UnN2ZXxz6LA24yGQKBCyXANSWF14vGbsn+VjFLH/JnKOTH5fdEb0emLG3YGKaBq13dpWQdyJABDJNYHv5OybVP4ud5LpMu06bP1WdFVyWFIyaszhtTshwQgQslQCsHndUvsbZYg6eyj32G/N65Xey0lGV3pNmngWBx8CRm9BsUiciQARsR6CLrMP9Dc9BrQjYpQkgzqV8JO7y3rH9Te9X2yUuq8VhqQSgtiJwl5S4MVXITMjD80ZXzU91fMbGqfP9k2fdyoA7MuaTHBEBImBaAh0RweT6p6GKB9mqCfzBOLsrprnv3v6m9+tsFZsFgrFMAqAq/rn0xmUAS/nbMGPytrziqjvNPC97lk31RPxdHgFgq7oFZmZO2oiAFQh0lvV4uOFp9BBhK8hNTqPAGmgoyRsVepqpoxDUMkLAMglAbTAwQQJtqnPPJObmlYb6Z4RsCk7UZj/ujr/KwIpSGE5DskBgO0Sws1iHnZp+1WIJ3x6Vrt2yoIRcOoGAX27E4w2Po6uwZyl+VVlQ08SVXUrmfOOE+cx2jJZIANS7fzfny9vy7V+BFgIx4fZ0NuNSU4+HKntwPfY2A98j2w8F+W+egPqhu7tY1fQutp9Yi75izeYfxH/Ah7t8Q/Ceyzb1pugxMCmB3noNHok8ifay0aQK2yZL7Q9gYA+ARW+3+yVubSPV9tGWSADCwcIKgI1qe7iABDshv6TybSNsGWWj1wPv/4MxvAXwrkbZJDttI6BWIfuIGuyr/4x9xcqm/27rW9cX2i4o856MtbxD25zSaCKQIIGD9WW4t+E5SxcLajVUIVdJzm7MLwm90Gpf6pASAdMnAGsmDG7H9ejKREr+JkKACUzJGx26IpG+mejTZ9KMk6Vgz9FO/0zQbtmH2m19iP4TDov/hEP0Zegk61scEIeGRzyFeMZzOET25ZMChxE4Lzof10Rn2T9qibckdw/PL56xyv7BZjZC0ycANcHAcAY8bBgWIVfllVZ1N8NGk96TZo6AEPdSZT/DZjdpQ+r9/YD49yjSF2E3fQ0S3X+0inXCLb5TsVDbMWmfNIAIGEVgXORVDIx/Z5Q509oRwHoOdp2/pPJp04q0oDDTJwDVFYFvuISxL1alPNhfWvVp1uZLStZ78qwJQOpHGrOm3QaO1Yf+4Pi3GKB/D/U+NdkWcvXDnd4TsZF5kx1K/YnANgmo64C52qsEQG/6XetN7QN4tv4R7CAtf81J68H+2eNNqevD82+euzrRAdRv2wRMnQDUlAcCjKHS8AmUGOsvDd1iuN1EDJaV8Z7+Ix/iwOWJdKc+xhBQPygHxRfi+PgC7K2vTMmo+qE8yTsQz7kPSWk8DXImAfXB3lOE0Uuvxi5yHbrJ9SgQf0C9cuqABrQXjfAivtXqk0oCGpkHdcyD35GDDSwXtaw9qlkHrOIdsZJ3wQqehzWsA/bVf8FDDU8nmDJYfw7UagBjuCa/OPR/1o8muxGYOgEIB/u/DPDT04Bokb8ktHsa7LZoMlBW6fo5X3+CSZyXad9O9ac+7M+IfYYB+iJ4ZDxlDOtYO5T6TsdX2s4p26CBziCgQWJv8QsOjS3FAWI5dhdr2vTstUStnnnxIy/ATmI98uRGZwDeFKVkz4hGeWVBWchhgRs3zaZNAH6/K+CPxLGaAy7jwv2fJcn5gfmjZn+RDtvN2exz/zteybzPgcnTMuXTqX7UB/0x+rc4I/Y5+ultXylcyLuh2DcUNXw7pyKluBMgsJ/+M46PLUCh/gM6yoYERlCXNhOQWCwgziwonfNlm2050IBpE4BwMHAVgEnpmhMJeU9+SVXKZYWT0dX9ng9z3K76VznHkGTGUd/kCHSQDRgW+wxDY5+2uoM/UcvqXP9Y7wmIsrTkoYnKoH4mJnBy7EucE/vYnhX6TMx9kzQdMuoCG5VXErrPAnJNJdG0CUB1eWA+Zzg0jbRW50UC3VlZWVpPcO322Lztog2RNzgQSGMsjjatlj7PjX6MU+NfINeg4igSrOmI3+OeIx3NloJvnYDagHdS7EucFP8KfkGr0a0TS1uPN10yfkGn0nnr0+bBZoZNmQCsHT+gtybEknSzZpIfk1c6+/10+dn5wbmdXXrkXcYY7RpLA2RVG/2i6FycFvsCbuiGeYiB407fyZju2tMwm2TI/gTUZr/+8cU4LfYZDtKXJ3yk1P5kMhih0H/iUjuly82hbzPo1bKuTJkA1AaLbpOQab8JTwDTCkpCaXkn3/uh6QVM196XwL6WfTpMKlzV31dFUM6KfgIfYoaqVJuqRvqG4nOth6F2yZizCKijpqfFPscJsa+hnldqGSWwkUl2YV5p5SsZ9WpBZ6ZMAMLlhYvAWNpvVBFC6Fy4dvHfMvtXI+euz/3v5AvuClFdfyOpAm4InBn9GBfEPoR63290U0etRuScgx/49kabJnsOJaAS1CGxbzEs/klKNScciq3NYQsBybksz4sU3Zru17xtFptFA6ZLAMLjAv3A8X2mmEiJO/JLQ2VG+ftz2b9xNmPYzyibZAc4Mv4jrmuciZ3kurTgUDv8r/adh+U8Ly32ySgROEBfgTNjn6J/fJFjzuxne9YZk++gPvfsvDvetef1iW0EbLoEoCYYGMkAVSUvU211XiS/Byt7KdpWh2rDX6y+YQa9828ryf+N7yFqcX3jdByqLzXO6F8sqUt8rvCdj1W8U9p8kGEisIlAN7Gh6aSK2jRo1xv9TDXbAt8wDcflFYdSqwBmqmCMFWO6BKA2WFglwfobG2bL1pjEZXmlof+0xWe3KW/m5kRz3wGThW2xQ2P/JKA29V0UnYfzox80Lf2nq6lv/sNzzsevrHO6XJBdItAsAXVi5eT4VxgW+xQqKaCWPgIC4leX5j6uy02zFqTPi/UsmyoB2FB+ZOcoc1Wnq/jPNqdHYnFeY6Bfqu+KVJEfHZ7X6Jy/Mf8AVEGV0sa3ob79p7Opd/7Dcy6gZf90QibbrRJQlQPVhVTnRudjd9H2wlWtOnRoBwH5u8ZwRl5x1QyHIvhb2KZKAGqCRecwyKzUd2ZgZ+aVVE5N9sFQ5X1/yRMvUoW/ZMn9vb/6RnRtdCZOjn2V9iNUDcyDK3z/xCJth7YLJwtEwCACB+rL8c/Y/KYrqakZT0AIxDjD5f7S0JPGW7eeRVMlAOFxhf8Hzs7JBkbB8G1+Q2DfpFYBysp4r/wjn6La/m2fsf30X3B75HV0k+lfCtXBMDLnTHyo9Wm7cLJABNJAoK9Yi/Nj8zEwthBqhYCasQQY2I15JZX3GGvVetZMlgAEVoMja2ewmGSX5JVWPp7QNDZd6TvjIYAPT6g/dWqWgHq/P7yxEufG5mdsZ/Q93mPwovsgmhEiYHoCO8r1uCD6IY6LfZ3WvTCmB5EGgQzs9rySyn+nwbRlTJomAaipKNqNSbkom+TURpFGT6zvTjfMb/WQee/JMyZAspHZ1Gt137uIWoyNvAr1bSdT7U3XfhjjOyFT7sgPETCEQIH8Hf+Mzscp8S/TdrOgIUItZoQxNiGvuHKUxWQbJtc8CUAwMJwBDxsWWaqGGG7xF4fGtjS896SZIwDQxROpMgYwJP4tShrfQY5s8+nLhFUs5gW4OOdiutgnYWLU0WwE1L0Xao/AadEv4DW4CqbZYs2YHikfzCupupox571rMU0CUDsu8LzkOCtjk74tRwINuovv3XXU7GZ34fSZNONkKeQ0cG4adllnloQA9UNrZGR60xnoTLZGuHF+7iVYzv2ZdEu+iEBaCDQlAtH5OD3+Oa0IGEBYAo/5i0OXOS0JMM2HWDgYWAXAFFuyJTAzvyQ06K/PVa/JMw9iUlQBPMeAZ85xJtRZ5/GRqegrqjMe+0TvYLzgPjjjfskhEUgnAXX74EWxeTi56UKs9NXLSGcMprEt5YP+0ip1Db1jmikSgJpxA3dlXP/BVNQZLvQXh57apKnHQ5U9ND32EcC7mkqnRcQcrC/DmIZX0DELF6N8q+2Iy3Iuoh+PFnlWSGbyBNSVxJdG5+DY2AI6NZA8vs0jJOQ9+SVVN7bBhKWGmiIBCFcELoCEqc5lqqIRkmsHqFcBPSZWdtJc+odg2N1Ss2sSsefEPsbVjTOz8oPpF9al6YIfKvNrkoeBZKSVQA8Rxr+iIQTiWd1PndYY025cYqy/NHRL2v2YwIEpEoDq8sADnOFqE/DYWoLAZy9GA0V3+494g4EVmU6fyQWpJcnSyFs4Pp6d6pvqvf+wdv/CGtbB5KRIHhEwlsDe+kpcHZ0FVV+DWgoEEtgMnoJV0w0xRwJQEfiQSxxmOjoAZmu7fl+aM4y++Sc5OeoO9PENL0HdgJat9h/PUXjUQ1czZIs/+c0+gUL9B1zdOAs7i/Tcopn9CNOnQEJenl9S9Wj6PGTfctYTADl1qFa7pOYPcJh2Y91477F4xX1g9mfLIgrU+8iJDc+jpwhnTfE61g6n5V4FVfKXGhFwMgENAqfHPseljVVZ2YNjVfZCCJ25+Cn5o0JvWTWG1nRnPQFYN2HgPkLXv25NaDb/vql0rO9MfOgyf+lYVU9/O9mIHMSQgyi8MgY1yU3FRBkQlxrqmQd18GIj86HO4A/I3cQaTGx4AeqYUjbbXd5j8BJV+8vmFJBvkxHoIBtwWXROUzKgkgJqiRCQ9RB8gH905ceJ9LZan6wnALXlRRdLJh8zO7gI3Lg+5yx8oe2SVan54g/0kjXYUaxHd7EB3eQ6dJV/oIvYiM6yIeniIFHmQpi1RzXrgDWsI5ZreVjO8rGM+/Ezz0vqx4S6yOTuyNSMFvdpbjLW8g44PfcqxKBlda7IOREwIwG1MndD43SokznUWicgdYSlWxxeMGrO4tZ7W6tH1hMA024AbGYeI8yFm3xn4hOtZ9pnWRWlUu/t9hK/Ynd9dVO53F6iBiqLz1SrZ158z3fAt1o3fMl3wZfaLlAMmmtH6T9iXORVUxQloW//mXpCyI+VCQyKf4frou9D1RKg1jIBBrnU7WKHdBgZyt57zTRMUtYTgHAwMBuAZXbYq2/Mt3tPwWxXP0OnQ9341U9fhX/oK7C/WIE99VUZ/bBPJBj1jfprbSd8oPVBpXt3rGYdm4apsr63Rd4wxbLiBpaLk9pdA3UCgBoRIAItE2gno7gyOhunxT7L2GVclp0TKaryutQNYsM/j1k2hr8Iz34CMC67NwCmMpESDE94jsAjnkKo36fa1Ga5w+NLmn6pD331j9FKbSHvhkXaDjgt9gXMUkb7P57+eNTT30oYSSsRyDqBffSVuKXxTagLuqhtmwATmJI3OnSFXRil/ullAIH1EwOd9EasN8BUVkzM0/pinO941LL2CfvfU6xCYXwRjtQXo7dek/A46tg6AbVCcWK7a7Ge5bbemXoQASKwFQGPjONfsRDOin5EqwEtPxtX+0tCk+3w+GQ1AagdV3iY5OxDK4P8DT7c4zsG77n23mYYe+q/4mj9exTFvof61k8tPQTUHNzuOzk9xskqEXAIgf3Ez7g98gbU3R3U/k5AAHEu+TH+0tnq9bWlW3YTAIucAEhkhr/UdsaDngFYoHVv6q7+8RwXX9BUBY/+ISVCsO19Ls+5EF//l3/brZEFIuBcAuqa7uuiM3BK7EvnQmghcnUygLuwf15xaKWVAWU3AagoGi+lvMnKAP+q/VOtB9zQsa++0jTvxe3Ed1uxqGt+z8y1zas5J0wZxWgBAofFf8It0TfppEAzcyUY5ud3+qPQypsCs5oAhIOBNwCcaIF/ByTR5ATU6stTnsNNrpLkEQHrEegk63Fz41voH//ReuLTrFiCTcwvqbwhzW7SZj67CcC4wAJwbPvledrCNtawqqklwU1xDM7YyKxhTZ3EUEf/VDEjakSACKSHgKogqF4LqM2C1LYgwNjp/uLKV63IJKsJQHWw8DcO+qltxQfHTJq/0nbG8JzzzSSJtBABWxLoK6oxJvIKetBxwc3zu+XV8Vab9KwlABvKj+wcZxTmtNQAACAASURBVC66ospqT4wJ9U7wDsHL7n+YUBlJIgL2I+BDDDc3vo3BsW/tF1yKEUmIj/0RfiQrC1lqeSRrCUD1+MB+XIC2mKb4wNGwPwmo5f8T2l3bdJ8BNSJABDJHQL0SuL5xOtxJ3RiSOX2Z9iQh/51fUnV7pv22xV/WEoBwsOhkQL7WFvE0lgioaoQX515MIIgAEcgCgb30XxFsfBnqkjKnN3V9sAZ2VN7oqvlWYZG9BKCiaASkvM8qoEinOQmocsyPeY4ypzhSRQQcQKCLrEMw8lLT0WenN3VpkGDx/fKLP7BERpS1BKAmWHg3A7Ps8QmnP+hmif+inIvxndbNLHJIBxFwJAH1GmBU5B2cFP/KkfFvHbR83F9SdYkVQGQtAaitKHpOSnm2FSCRRnMS+I3lYEi7G+kNpDmnh1Q5kMA5sY9xTeMMx98lwCQ/Jq909vtmfwSylgCEg4WzADbA7IBIn3kJqCuZS31nmFcgKSMCDiRwlP4jxjRMgzot4NQmpb5CNmp7FZSFNpqZQdYSgOqKwDdcYi8zwyFt5iZAx//MPT+kzrkE+umrMTHyAtT+AAe3yf6S0NVmjj9rCUA4GKgGkG9mOKTN3ATOy70ci3mBuUWSOiLgUALd5Abc1/AcdhbOLPciBCRcsrBgVNVcsz4CWUkA5NShWs3S6igH42YFQ7rMTaCOeXB0u1H0/t/c00TqHE5A3SNwf8Nz2E2scSgJ+WNepGBvVvZS1IwAspIArB07sKum6U59Isz4HFhO0ydaT1yTc67ldJNgIuA0ArmyEXdHpuIAfYXTQt8U763+ktAYMwaflQRg3YSB+whd/9qMQEiTNQg84T4SD3sD1hBLKomAwwl4EUNF5GWo64Ud1wQaNIY9OpeGlpst9qwkAOHyAQPAxCyzwSA91iFQ7DsDIVc/6wgmpUTA4QRUrYBxkZedea2wxFv+0tCJZnsEspQAFJ4Kxix5faLZJtCJetT1y6e1uwarWUcnhk8xEwHLEnBBR7DhFaijgk5rkrGT84sr3zBT3FlKAAIXguEJM4EgLdYgoINjRM45+EzrYQ3BpJIIEIGtCKiVgGDDSzhSX+woMhJYtiE3Z/e+I95tNEvg2UkA6B4As8y/JXW84j4Q473HWlI7iSYCRADwyDjuibyAg3TTvRZP6/RIKUfll1ZNSKuTJIxnJwEIBm4BcGcSOqkrEdhMQK0CqPf/d3pPQAPzEBkiQAQsSEBVCpzc8CzUjYJOaQLiN13IvjuMnltjhpizkgDUBgMTJDDSDABIg3UJLON+FPuGYgXPs24QpJwIOJhAR0TwSP2T6CHCzqEg2EP+0ZVXmiHg7CQAFYVTpGSXmwEAabA2AVUQ6A7fyajSdrN2IKSeCDiUQFfxOx5veBx+aeqy+YbNjhBC1+DeJ2/0rO8MM5qioewkAOMCz0uOs1LUTMOIwFYEJBge8A7A/7kPIzJEgAhYkMCuYg0erX/KQRcIidf9JXNOyfZUZSUBCJcH3gTDCdkOnvzbi8CD3iI85T7CXkFRNETAIQSOjP+ICZGpzrlKmPFD/MWzP8nm9GYlAagJBmYw4OhsBk6+7UngEU8hHvMcZc/gKCoiYHMCF0Q/xJXR2TaPclN4Ypa/ZE5WPwezkgDUlgfmSAb6Ke2QxzzTYf7HcxQe9RRm2i35IwJEwAACYyLTMCi+0ABLFjAh+UB/6eysZTxZSQDWjiv8WOPsYAtMD0m0KAG6K8CiE0eyHU9AHQ98sv4x9HTAyQAh8VFBaShrm5eykgDUBAu/YmD7Ov5JJwBpJfC053BM9gxIqw8yTgSIgPEEeohaPNnwGHKkKW/RNTRgBjYkr6RyuqFGEzSWlQSgemzgO65h9wQ1UjcikDKB5zyH4j5PVl+zpaydBhIBJxM4LvYNbm983fYIpI55+TeHsvJKPCsJQG2w8CcJ1sv2M0sBmoLAC+6DMdE72BRaSAQRIAKJE/h3ZBqOccB+AMlZIH9UZVXiZIzpmZUEoDrYfyUH39GYEMgKEWidgLo/YIJ3CFTNAGpEgAhYg0A7GcXzDQ9DFQuyc5PAzPyS0KAtY5RTh2ps2Et6OuPOyk/DcDBQDSA/nYGRbSLwVwLT3AegwnssJQH0aBABCxE4RF+K+xues5DiFKUKdqh/dOXHm0ZXj+/ft2DUnLRemZiVBKA62D/MQQXcU3xMaFgbCLzh2g/lvhMg2mCDhhIBIpBZAqWNb+OU2JeZdZp5by/7S0JDN7mtCRaemF9S9WY6ZVACkE66ZNuUBN5y74ux3hMpCTDl7JAoIvB3AtshghfrHkaeje8LUHcESObZtWvpzKWKgEoAmGCL/aNDi9L1TFACkC6yZNfUBN5z7Y1/+06CTnsCTD1PJI4IbCIwKP4dxkRetTkQ9oC/pHKECnJt+dG9NB4/218cGpuuoCkBSBdZsmt6Au+790KZ92RKAkw/UySQCPxJ4KGGZ3CAvsK+OISoczGxU6fSeetlWRmv9VbO9ZdWpe2CE0oA7PsoUWQJEJjp2h23+U6F7pwrSBKgQl2IgDkJ9BXVeKr+UWiQ5hRohCqJEn9pqKLpNUB54dcut3ZS55Gz05L1UAJgxISRDUsTmKvtitKc0xGDZuk4SDwRcAKB0Y1v42R7bwhcnhcJ9GZlZaI6WPgKB0L+kqoH0jG3lACkgyrZtByBz7UeGOkbinrmtZx2EkwEnEQgX/yBV+ofhBcx24YtIU9SJwDCwcIKIdj+BaNDaalkRgmAbR8hCixZAot5V1znOxth3j7ZodSfCBCBDBK4JjoL50XnZ9BjZl0JyPcLSqqOqQkGhgvI+1mE5RWUhTYarSLjCUBNxaBuTG9cCs7pq5bRs0n22kxgDeuAG3POwhJe0GZbZIAIEIH0EOgs6/Fa/f3wyXh6HGTZqhCQcIndNJ33lgzvguFUf3HoNaNlZTwBCJcH3gTDCUYHQvaIgFEE1GuA270nY45rV6NMkh0iQAQMJnBd4wycHdtcOM9g69k3xxjuhmRPSMhvmcCUvNGhK4xWldEEIBwMnAfgGaODIHtEwGgC6s6Apz2HYYqniI4JGg2X7BEBAwio+wGm1U+CZt+SXjUxoe/p5poqnb/cXxLqaQC2rUxkLAGoHh/YXsblQo2zLkYHQfaIQLoILNC643bvKVjFO6XLBdklAkQgRQJjI6/g6Pj3KY62wDDGTocunwVHjhTabvmjZ/1opOqMJQDhYGAagFOMFE+2iEAmCETgxsOeAKZ6DqJ6AZkATj6IQIIE9tFX4tGGJxPsbb1uUuJdxrA7gB4ArvaXhCYbGUVGEoCaYOAsBjxvpHCyRQQyTWAZ9+NBzwDMdfWlGwUzDZ/8EYFtEHi+fgp6iRpb8hGQgoOtBbADgNf8JaFTjQw07QnAmgmDC7RodCHT4DdSONkiAtkioBKB1137N7lfz9thMeuKFVoXxKmQULamhPw6mMBZsU9wfeP7ticggPX5kYBfFQgyKti0JwDhYOAlAGcYJZjsEAEzElAf/r/wzljO8/ALz8NK1hmreSesZR2wlnVEhLnMKJs0EQHLE+gk6/FO3b123gy4eY6EFAcUlM4x7F7ktCUAsizgCvvkrQzsNss/YRQAEWgjAXW0cB1rh/UsF38wH/6AFw3Mg3p4EGWupjLEYov7CDgE3NDhRRw5Moo/4MMTnqNQxzxtVELDiYD9CNwbeR6HxX+yX2B/iYgxXJ9XHLrXqEDTkgCoD/91XsyWDEcZJZTsEAGnE1AnEW70nYmlPN/pKCh+IrAVgePjC3Bb5A0nUDF0H0BaEoDaYOBaCRiWpThhVilGIpAIgQ0sF5flXIifOZ2mTYQX9XEGAfUa4N26e2x/p6eAqM0vnpPPmDHXIRqeANSO6b+TdPHvAFBBdWf826MoM0xgkbYDLsy5mE4iZJg7uTM3AXUcUB0LtH1jYg9/8RxDih8YngBUBwOvcsDQowq2n1AKkAgkSeDqnPPwqaaOBlMjAkRAEbgkOheXR6tsD4MxXJpXHHrMiEANTQBqgkXHM8i3jBBGNogAEdg2AVWP4CnP4YSICBCB/xLYT/8FUxqesj0PCTyWXxK61IhADUsAlpUFfB18cqEE62WEMLJBBIjAtgk84BmIZz2HESIiQAT+S8ANgZl14217Q+CmidYhv+taUrWnERNvWAJQUx4oYwy3GyGKbBABItAygStyzseX2s6EiQhYmkBfUY0j4osxw70HfmWd2xzLIw1PYl+b7wNQ1QG1htzOeXe8+3tbgRmSAKwvD/TQJb5TFxa0VRCNJwJEoGUC6gTAsNx/0SZAelAsT6C9bMSMuglNu/e/4jvjVc+BmOXql3JVTbtfEbx5wiUf6C+dPbutD4AhCUA42P9lgJ/eVjE0nggQgdYJ3OQbhjmuXVvvSD2IgAUIPF3/H+wm1mxWWsO3w7Puw/Cq64CmIlnJtCHxb3BH5PVkhli1b6m/JBRsq/g2JwA15YEAY6hsqxAaTwSIQOsE7vUOwvPuQ1rvSD2IgEUIXNs4A+fEPv6b2mrWAQ96A3jPtXfCq1399NV4qsGQDfJmp/eyvyQ0tK0i25QAyKlDtfBP1V8wxvZpqxAaTwSIQMsE1H0CA9qNoiuJ6UGxFYGj9B9xV8PUbcakXg2M8x2PFTyv1bh9iCG0cTwMqpPTqr9sdZDAsvySUJs33LcpAagpD1zBGB7KFgTySwScRGC+qzeu853tpJApVgcQ6IgIpm+8u8UP7Ua4cb93IF52/6NVIm/X3Qu/3NhqP6t3cMl4l06l89a3JY6UE4B1waM76np8CV3z2xb8NJYIJE5grO8EvOHaL/EB1JMIWITA8/VT0EvUtKp2pmt33Ok7CRG4t9n38frHsadY1aotq3eQTA7IL65q0+v3lBOA2mBgggRGWh0i6ScCViCgbgM8sd2IphsEqREBuxEobnwXp8U+Tyisxbwrrss5G2HWfLX58sjLGBBflJAtK3cy4mbAlBKADRP694zH8D0491oZIGknAlYh8LA3gCfcR1pFLukkAkkRGBL/FndEXkt4zGrWEVfnnIuVzVyKlUwykbBDc3Z80l8Suqgt0lJKAMIVRVMhZZt3ILZFOI0lAk4hoDY/nZdzWdJHopzCh+K0PoFuYgOm1U9KKpAwbw9VEOsXtvXNmFdGZ+OC6IdJ2bJmZ/m5v6Sq9U0RLQSXdAJQO67wMMmZE+ha85kg1bYioN51Xpp7IdSyJzUiYGcC79ZNRBdZl1SIa1gHXJZ7IdSRwU3tn7H5uLpxVlJ2LNlZoCEvGmjPyspEqvqTTgCqKwIfcgkqQp4qcRpHBBIkoHY+35QzFB9rbT7tk6BH6kYEskdgfMNLKNR/SFrAEl6Ay3IuQD378430WbFPcH3j+0nbseIAwcWuBaPmLE5Ve1IJQG1F4Awp8VKqzmgcESACiRGoZe1R7DsD32jdExtAvYiAxQmcH/0QV0VTq247V9u1KVmWYDgj9hluanzP4jQSlc9O8ZdUplz6MOEEQE450F27frvvAPRJVBr1IwJEIHkCs127Y7z3WKxnuckPphFEwKIEDtBX4KGGZ1JWv+mK7FNjX6Ck8Z2U7VhqIJOj/cVV5alqTjgBCFcErobEA6k6onFEgAi0TOAnLR8TPcfgU60HoSICjiOQI6OYXTe+6WKgVJoOjstzLsAeYhVubJyeignrjZHsGX9p5fmpCk8oAaipOGI7pruWgLOCVB3ROCJABJonUMc8mOIpaqpypiOhf5KEkgjYksD/1T+CPqI65djUiYD33HvjsmhVyjYsNVDgM//o0EGpak7op01NedG/GZO3puqExhEBItA8AVXZTH3rV0eaqBEBpxO4JfIWTox/1SYMv7McdJANbbJhmcECf/hHh/53BCJJ4a0mAGsmDC5wxSJLwXm7JG1TdyJABLZBQB1bqvAdi3laX2JEBIjAfwk4awOfMdOuSfTsXBpanoq1VhOA2orAXVLixlSM0xgiQAT+TkDV87/XOxhq6Z8aESAC/yOwp/4rHm94gpAkQUACZ+eXhF5IYsjmri0mAGvHDuyqMX0ZOHJSMU5jiAAR+B8Btcw/1nMCPnTRQRp6LohAcwQ8Mo5Q3XhoSLm2jRPB3ucvCV2XSuAtJgDhikAQEsWpGKYxRIAI/I/AbFc/BL3H4zdGuTQ9F0SgJQKJ3gxIFP8kICQ+KigNpVScb5sJgLruN47Yzxxb1Fgk4kSACCRFQJXyvds7BG+4901qHHUmAk4loC4FUpcDUUuYQCSv8x8d2PDPYwmP+G/HbSYANeWBGxnDXckapP5EgAj8SUDV7x/tOx0/N3NjGTEiAkSgeQLnxuZjhBNq+Rv4AAgpDigonfNlsiabTQDk1KFa7dKaJQCoIkmyRKk/EQDwivtATPQORgwa8SACRCAJAgfry/BAw/8lMYK6MonL8kpD/0mWRLMJQE1F0UlMypTrCycrgvoTAbsQaGAejPUejxmuPe0SEsVBBDJKQN0IqG4GpJYEAcEe8o+uvDKJEU1dm08AygPvMIZjkzVG/YmAkwks53ko9g3Fcu53MgaKnQi0mcD0unvQSda32Y5TDKS6EfBvCUDtmP476S62nIOlWpLZKcwpTiKwmYC6wOff3hOhVgCoEQEi0DYC6lIgdTkQtQQJCFGXVzpnO8YgExzR/ApAOFg0GpBjkzFCfYmAUwmo08oPewbgKc/hTkVAcRMBwwmMbJyOobFPDbdrZ4NCom9BaUjt3Wu2VY8PbF8wKrRmy7/82wpA9djAd1zD7nYGRbERASMI/AEfbvWdivmu3kaYIxtEgAj8l8Dpsc8xqvFd4pEMAYZT/cWh17Y1pDZYdEOXzr8/sOVxwa0SgHXB/nsL8AXJ+KS+RMCJBNTRvpG+M7GC5zkxfIqZCKSVwIH6cjzY8GxafSRjXN3SqSW3up6MeaP63uovCY3Z5gpAeeBJjfFH8kpmf7ipz1YJQE2w8A4GdptRasgOEbAjgU+0nhidczrUCgA1IkAEjCeQJzfinbp7jTecokUd3PTliRljz+cVV56zrRBrKvrPY5K/5S8JBZtNAGqDgS8lsF+KjGgYEbA9gWnuAzDBOwTqBwI1IkAE0kdgdt14tJPR9DmwmWUGfJVXEtp/W2GFxwVWg+Ezf2noxL8lALUVge5S4hebMaFwiIAhBNRmvwe8g/Cc+xBD7JERIkAEWibwVMNj6KevJkwJE5D1ecVV7Zs7CVBTccR2TLp/FxC1BSVzNp9T3vwKoLYicImUSLqSUMLaqCMRsCiBRrhxu+8UVLp2s2gEJJsIWI/AmMg0DIovtJ7wLCpmcbFz3i1z/vZFvqa86EDG5GdKms55n66jZv+kfv+/BGBc4HnJcVYWtZNrImA6AhtYLm70nYlvtR1Np40EEQE7E7gsWoVLo3PtHKLxsUk+0F86e/ZfDddUBM5lEk27KiVwdn5J6IWtEoCm9wMc2xuviCwSAWsSWMU7YUTOOfiFdbFmAKSaCFiYwAmxr3Fr45sWjiDz0qVkw/NLKx/5q+dwMHAngFv+/HM53l9SVbw5AaguD/ThDIszL5c8EgFzElik7YDrfGdjPcs1p0BSRQRsTmA//WdMaXja5lEaHd7/Pty3tBwO9n8Z4KerPxMCMwpGhwZvTgDCwcB5AJ4xWgrZIwJWJPCx1gvFvjOorK8VJ48024ZAgfwdb9bdb5t4MhTIy/6S0NC/rQCUFy4CY39uYhJY4x8d2uF/CUB54X1gbESGBJIbImBaAuoWvzLfSYjTNb6mnSMS5gwC6qDt3I3lcEF3RsBGRCnwmX906KAtTS0rC/jaecRGzvnmu8k9LuR3GBkKN20CDJf3D4HxQiP8kw0iYFUCr7gPxF3eY6GO/FEjAkQg+wSm1U9CN7Eh+0KsokDIav/oqq5byt3yBMCmPxdc9i8YVTW3KQFYO66wVuO008kqc0w6jScw1X0Q7vYeY7xhskgEiEDKBNQeALUXgFriBP6IIKdnWSiyaURtedHFksnHtrQgIS/PL6l6lK0dO7Crpulb3RCUuCvqSQTsQeB991641XuKPYKhKIiATQjcEXkdQ+Lf2CSazITx11sBw8HAJABXbemdAXfllYRuYuuCgSMFQIctMzM35MWkBCQYLsm9CAt5N5MqJFlEwHkErorOxvnRzXfXOA9AChFLzgL5oyqrNg1dO67wY42zg7c0JYBpBSWh01g4WHQ+IJ9KwQ90IX/WONs5lbE0hgiYjcBX2k4YnnOB2WSRHiLgWAJnxj7FDY3THRt/KoEzibPySkMvqrGybKin1rP2d3Du3dKWhPw6v6RqPxYOBlRxAFUkINn2Mpj8ApKNS3Yg9ScCZiVwve8sfOjqY1Z5pIsIOIrAgPj3KI+84qiY2xosA67LKwndp+yExxUdAi4/+qtNAWwoKAl1ZuGKwEOQuCJRp0JAahru6DIq9O9wsPArxtg+iY6lfkTA7AR+4NvjgtxLoF4JUCMCRCC7BPbVV+KRhiezK8Jy3uU4f0nVzUp2TTAwkgETmgtBslgHVh0MvMqBUxOKUYg6xrQL8korX6ku778/Z/yLhMZRJyJgIQIjc4ZhrrarhRSTVCJgTwI7yXV4ue5BewaXpqgY2KN5JZWXK/O15f3fkowf36wrJvZg4fLCD8DY4a1pUe/7wflJXUsqv/5vZjFRLTW0No7+nghYjYC6+OeSnIusJpv0EgHbEWgvGzGrrtkvsLaL1aiABOSrBSVVp8spB7pr12+3DkD7Zm1LDFIJwP9KBG5DgWTiA537Ttv+pverVRc5dahWu3TtrwDfquCAUQGQHSKQbQL/yvknvtB2ybYM8k8EHE9g3sZyuKkaYDLPQaW/JDQgXD5gAJiY1cLAf7Ka8qOWM7btn3QSeMwfyb+Slb0U3WSotnzAYMkEbc1MZkqor6UIqFcA6lUANSJABLJL4O36e+EXG7Mrwlrev/SXhA4IB4vuB+Q125IuJUay2orCKVKypvcFWzYhhK5xfuOm3YRb/l04GHgCwIXWYkJqiUDiBFQ54NPbXY1VrFPig6gnESAChhN4rmEKeus1htu1rUGh/5QX1frV+sTKFlfpBYKsJlh0D4O8fqsPf2CDJvmZeaWz3/8rJHWusMa3tpqDd7QtQAqMCAB41nMYHvAMJBZEgAhkkcDDDU9jfyoHnPgMCKyBhn9BYlpLg9RmQVZbEbhdSpRt7ijlD1K6TsofPevH5gbXBIuOZ5BvJa6GehIBaxJYx9rhhHbXQoe6l4waESAC2SBwV8NUHKU3+3GUDTmm96nO+HMpv0tgc//LrCYYGM6Ah5uiEmK6lsPP6nx9aJvXL4WDRY8DkrZIm/4xIIFGEKAjgUZQJBtEIHUCdB9A6uxaGimBmaymorCISTZbgk309/LfxIa9tM3Ll9Xu/5qla9dy8Lz0SCKrRMBcBGa7dkep73RziSI1RMBBBEY1vovTY587KOLMhCohPma1tx/bQfoaTvOXhlott1QzvqiQCRnKjDzyQgSyT6ARbgxufwMicGdfDCkgAg4kcGV0Ni6gC4EMn3kd8ruk6p3WBAvvZmA3GK6EDBIBExO4xXcaZrj2MLFCkkYE7Evg0uhcXBbdfLmdfQPNcGRS6iuSSgDCwcIfAEY1UjM8UeQuuwTec+2F232nZFcEeScCDiVwbmw+RjS2VM/GoWDaGraQ1QknANXlgT6cYXFbfdJ4ImA1AhtYLo5tdwNUbQBqRIAIZJaAev+v9gFQM5aAOi2QcAIQDhZeA7D7jZVA1oiANQhcnHsxFvJu1hBLKomAjQicHPsSoxvftlFEZglF1iecALR4q5BZ4iEdRCBNBFRBIFUYiBoRIAKZJXB8fAFui7yRWadO8CZEY0IJQKu3CjkBFsXoaALztL64MedMRzOg4IlANggcE1+If0daLGqXDVmW9ymAeEIJQPX4wqO4YHMsHzEFQARSJKD2ARzTjg7ApIiPhhGBlAkMin+HMZFXUx5PA5snkHACUBssuk1C3kEgiYCTCZzYbgSqWQcnI6DYiUDGCRwd/x5jI69k3K/dHQqBWEIrAOFgoBJAwO5AKD4i0BKBG33DMM9Fp2DpKSECmSRACUCaaCeyB0Dd/lfrq/kNgC9NMsgsEbAEgfu9A/F/btoIaInJIpG2IUAJQLqmMoFTAOvGFR0huJyXLglklwhYhcDr7v0xznu8VeSSTiJgCwJD4t/ijshrtojFTEEkVAcgXB4oBkPQTMJJCxHIBoFPtJ64JufcbLgmn0TAsQToGGCapj6RSoDh8sLXwdhJaZJAZomAZQgs5fk4O3e4ZfSSUCJgBwInxb/CzZG37BCKqWJI6C6AcDBQDSDfVMpJDBHIAoHf4MPg9iOz4JlcEgHnEhga+xQjG6c7F0D6Il/U4imADRP694zrfGn6/JNlImAdAjoYDm9/s3UEk1IiYAMCdBlQuiZRft5iAlAbLBomIV9Ml3uySwSsRqCwfTEicFtNNuklApYlcEl0Li6n64CNnz8pqlpJAAITJEBrnsajJ4sWJaCqAaqqgNSIABHYmsDh8SWY7+oNiYTKyySMT10FrFYBqBlO4M0WZyocLJwFsAGGuyWDRMCiBCgBsOjEkey0EyhpfAdu6BjjPcHQJEDZPTX2Rdr1O9DBsy0mAGvHFdZqnHVxIBgKOcsEfmM5TQo6yoYsK9naPSUAppoOEmMiAhfF5uGKxhCe9hyOyR7jvjfe2fgaBse+NVGk9pAiJCZtMwGoHdN/J+niP9sjVIrC7ASizIU5Wl/Mc/XFF7wH1vI/a+6rbxT58g90Fb9jB/EbdpTr0V2sR3e5DjuLdeiQ4QQh0G4UGpjH7DhJHxHIOIHjYt/g9sbXm/yO9p2GWa49DNFwX8NzOFSnveiGwNzCiIT89zYTgJrxgROYwJtGOyV7RGBLAuqb/v95DsWr7gPxRwrVpjvLeuwiwugtatBbVKOPWIu+oga5stFw0Ord5mHtRxu6vGm4SDJIBLJE4EB9VRV9KwAAIABJREFUOR5seLbJ+0bmxXm5l2M169hmNU80PI499FVttkMG/kpAjthmAhAOBkoAlBM0IpAuAm+598X93kFQ5+uNbAwS3eV69NNXY3d9DfYQv6KfWIMcGW2TG/VDbWC7m9pkgwYTAbsS6C7W4ZX6BzeH95nWA1flnNfmcF+tm9y08kfNWAISOHvbCUB54FkwUN1TY5mTNQBxaCj3HgeVAGSqcaBphWAvfSX2Vb/Ez+gmNiTlfgXPw7DcfyU1hjoTAacQUAl2qG78VuHe6T2xzf/Olc22Ju9OmYOk4mTs6JZWANS2y/2TMkidiUArBHRwFOecgbla9q/VzRd/YH99BfYXv0AtX+4ialtU/4W2C/6V80+aYyJABLZB4K8f1utZLs7IvarplUAqzYcYqjZWpDKUxrRCgOvYu9kEQEqw2vL+f4DzdkSRCBhJYLz3WLziPtBIk4bZ8suN+Ie+DAfHl+FgsQwqQdiyveHeF2O9JxrmjwwRAbsReLnuQewk120V1rOew/CAZ2BKoaqlf/UKgJrxBDwu5DebANAJAONhk0VgtqsfSn1nWAZFL1HTtPv4sPiSppWCRz0BPOU53DL6SSgRyDSBKfVPYz+x9eExdcLnjJwrN5/sSUbT/vrPeLjh6WSGUN8ECOiQ0a4lVd5mE4Bw+YABYGJWAnaoCxFIiIA6Onda7lVYx6y5qKSWIn0yRlUAE5pt6uRUAmMjr+Do+Pd/C/919/4Y5z0+aSxD4t/ijshrSY+jAS0TUDcB5pfO7dFsAlBTXnQ5Y3IKQSQCRhF4zHMUHvEUGmWO7BABImBCAurWPnV731+b2vtzRu6VWMU7JaX6/OiHuCo6O6kx1Ll1ApKJD/KL5xzZ/ApARSAIieLWzVAPItA6gRg0nNDuWvr23Doq6kEELE3gsugcXBqd02wMr7n3R3mSqwCjG9/GybEvLc3EjOIZY8/nFVee0/wKwLjCFxlnw8wonDRZj8AM1x64xXea9YSTYiJABJIicHrsc4xqfLfZMeqLwCm51yDM2ydsc1LDszhIX55wf+qYIAGBoH90qLTZBGDtuMKPNc4OTtAUdSMCLRJQG//UBkBqRIAI2JuAev+v9gFsqyV7T8C0+klJ1+uwN2FjopPAFfkloSnNJgDV4wK/cI7uxrgiK04moINhULubUEf18538GFDsDiGwZTng5kJW5b5PaH8tInC3SsSLGEIbK6CKeFEzlgADG5JXUjm9+T0AwYA6AJ34Oo2x2siajQgs0nbABTmX2CgiCoUIEIFtEegr1uLZ+kdbBDTBOwQvu//RKsREbLVqhDo0S0BwsWvBqDmLWbiisNRfXLW55r+cOlSrXVoTJ25EwAgCqWz8McIv2SACRCDzBFR5bbVs31JbzvNwZgIltQfFF2JMZFrmg7C5RyGEnp9Xl7Nu3XYXsPC4/hFw7XJ/SWVTtYXf7jmmSyza2HJNVJsDovCMI3CX9xi85D7IOINkiQgQAdMS2A4RzNx4V6v61CVB6rKgltq/opW4MPpBq7aoQ3IEJLCMg58nRfx9Fh4XqBeAi2vsWH9x5awNE/r3jOucLl9Ojin13gaBG3xn4QNXH+JDBIiAAwio9/UfbhwLdSNnS222a3eU+k5vsc/dDS/iSH2xA6hlNkQp5EIGlgcuO6gVgI2q5r+A/N0FeWScc40L0MHLzM6Jbb2pO8EX8wLbxkeBEQEisDUBtQKgVgJaaupG0BPbjWixMugb9fejq/id8KaJgAA2qBWA38GxnfIhBFYyDSVM4tk0+SSzDiOg/pFXsw4Oi5rCJQLOJZDoB/dkzwCoY4HNtU6yHtPr7nEuxExELmQ1qw72D3PwvM3+hKijWwAzQd8ZPora3YT6FK8CdQYhipII2IvAi/UPoUcrV2uriFfwPAzbxmbAw+I/4d7I8/YCY7Jomr7wh8cV/grOuplMG8mxCYFEj/zYJFwKgwg4nsBTDY+hn746IQ6X5VyIBdrfS86ocsKqrDC19BFgkEtZTTCwlAE90+eGLDuZgCr4cU67y/Er6+xkDBQ7EXAMgSkNT2M/fesrgbcV/LaOCd/f8BwO0WkvepofmkWsemzgO65h9zQ7IvMOJvAV3xlX5P4TEs3WnXIwGQqdCNiPwMTICzg8viShwFRlwGPbXw91T8Cmpk4SzKwbj3YympAN6pQaASnlAlYbDHwpgf1SM0GjiEBiBO71DsLz7kMS60y9iAARsCyBYOQlFMV/SFi/Og6ojgVuaur1gXqNQC3NBAQ+Y+Hywg/AWPNbMdPsn8w7h0Aj3Dgv9zL8zLs4J2iKlAg4kICq3qeq+CXaqrTdMCpn6Obu50Q/wrXRmYkOp34pEhAM81l1sHA6Bxucog0aRgQSJvCN1h3Dc86HTtd7JMyMOhIBqxG4LfIGjo8vSFi2Wv5XrwHU6wDV7om8gCMSfIWQsBPq2ByBEAsH+78M8JZLMhE8ImAQAVUWWJUHpkYEiIA9CYxufBsnx5KrJTfGdwLedO0HNwRmbpwAH2L2hGOuqN5k4WDgCQAXmksXqbEzgXLv8VC7f6kRASJgPwIjG6djaOzTpAL72NULI3znoLXrhJMySp1bJCAgn2bV5YEHOMPVxIoIZIqAKgN6Tc45+ELbJVMuyQ8RIAIZInB94/s4K/ZJUt7Ua8Hj2l2Hf8bm47zo/KTGUufUCEjgXhYuD4wBw82pmaBRRCA1Ar/Bh0vaXYxfGG0KTI0gjSIC5iRwXXQGzo5+nLS4cd7jcU7so4SqCCZtnAb8jQBj8jZWUx64kTG0fn8jASQCBhNQH/4qCVDJADUiQATsQeDaxhk4J5Z8AqBKA++SQAlhe1AyQRQM17Da8qKLJZN06NIE8+FECapI0NW5525VCMSJHChmImAXAiMaZ+HcGC3jm30+Jdi5LFwROAUS08wulvTZl8BM1+64xXcaVQq07xRTZA4icHXjrKZ3+dTMTYBJHMuqgwP6c4gqc0sldXYnoKoEqmqB1IgAEbA2AVXERxXzoWZyAoIdymrHDdxDcj3xsk0mj4nkWZfAJO9APOM+zLoBkHIiQARwXeMMnJ3CHgBCl1kCgotd2e93BfzROGoy65q8OYGAuvyHQSYVqtoJ/DrVCEiKGXUmAmYicGPjdAxLsg6AmfQ7RYtHaH4mJVhNef8Y5/x/1zE5hQDFmVYCqSQAAsCtvtOh9gVQIwJEwHoERjW+i9Njn1tPuIMUCwGZ3yff3XQ/a3hcYDU4tndQ/BRqBgikkgAoWapQUHHOGZin9c2ASnJBBIiAkQRSKQVspH+y1ToBAWwoKAl1bkoAaoKFXzGwfVsfRj2IQOIE1Ld5dbd3Kk1dEHKj70yoEqHUiAARsA6BOyKvY0j8G+sIdqBSKeTC/NFVe/13BaD/e+Ccbmhx4IOQzpDbkgAoXeoK4ZE5w/CJ1jOdMsk2ESACBhIIRl5CUfwHAy2SKaMJSIb38otDx/6ZAAQLHwPYxUY7IXvOJtDWBGBTEnCTbyitBDj7UaLoLURgYsMLOFxfYiHFzpPKmHwkr7hq+KZXAHcwsNuch4EiTjeBVPcBbKlLvQ4Y5RuKD1190i2X7BMBItBGAg81PIMD9BVttELD00zgVn9JaMymBOAyBvZImh2SeQcSMGIVQGGLgeM232mY7ernQIoUMhGwDoEn6x/D7mK1dQQ7Uim7wF9S+XRTArAuWHisAHvHkRwo6LQSMCoBUCJ1MJT7jsebrv3SqpmMEwEikDqBl+sexE5yXeoGaGTaCUgmB+QXV1U2JQC1waI9JeS3afdKDhxHwMgEYBM8qhjouMeIArYQgXfrJqKLrLOQYudJFRJ9C0pDS5oSgDUTBrdz6dGNzsNAEaebQDoSAKVZ3R1wv3cQlH1qxhFoJ6PoKOvRHhF4parIIBEHRyNz4w/mw3qW03Q6gxoR2BaBuXVBeGScAJmUgCoC9Fv7nJy+I95tbEoAVAuPK1wLzgpMqplkWZRAuhIAhUPtByjznUwfSCk8G93EBuwhVmNXsRq9RRjdRS22l7/Bl8AP7t9ZDlbxTljO8rBE64rv+A5YqO2ICCUGKcyEvYa4ITBv4zh7BWW3aISs9o+u6qrC2pwA1AT7f8TAD7FbrBRPdgkYcQqgpQjUB89I3zCsY+2yG6jJvXdEBIfFl+Cw+E84UCxHvvjDUMU6OL7XdsBHWi/Mc+2K7/kOhtonY9Yg4Jcb8XbdvdYQ61iV8nN/SdU/tkoAascFnpccZzmWCQWeFgLpXAHYJHgt79BUNXAxb0pqqf2XQHvZiIHx7zAovhAH6D9Dy+ALE7VCMEPbE2+798EKnkdz4hACfUU1nq2nA2Vmnm4BTCsoCZ22VQIQLg+MAcPNZhZO2qxJIBNJQIS5MMZ7Ema49rAmJANV76f/glNjnzdVY/MiZqDl1Ex9qe2Mqe6DUOXq13SSg5p9CfxDX47JDc/aN0AbRCYh78kvqbpx6wQgWHQ+IJ+yQXwUgskIZCIB2BTyc55DMckzAGpJ2klNfbtX3/TPjX6MXcUaU4b+K+uMpz2H4y33Pk0XPlGzHwG14jQu8qr9ArNRREzisrzS0H+2SgBqKwKHSon5NoqTQjEJAfWtT+0mz1T7StsZN3tPQ5i3z5TLrPlxQcfxsQW4MPoBuskNWdORjOPVrCMmewfSak0y0CzS98zYp7ihcbpF1DpTJhfsyC6jKz/YKgHYUH5k5zhzUfUGZz4TaY06kysAmwJZz3JR5julaVOaHRuDxOD4d7giWgm1o9+K7XOtByq8x9IeAStO3jY0XxWdjfOjH9ooIvuF4vZ48zreML3ps36rF3LVwf5hDtqxY78pz25EmV4B2BStOoHwvPtgPOgd2FRK2C5tH30lro++jz30VZYPSc3LE56j8JTncHotYPnZBMoib+DY+AIbRGLTELY4Avi3BKCmov88JvkRNg2dwsoSAfVBLCGz9hGsTgeM8Z6ARZq1j6Z1kvW4NjoDx8a+bSJqp/Yj3x63+07GUp5vp7AcF8ukhmdxkL7ccXFbKOCQvyRUtEnvVisAtRWFU6Rkl1soGJJqEQLZWgXYhEf5f8X9DzziLcQf8FmE2p8y1Qa/U2JfYnhjJdR5fru2KHPhPs/ReNnddESZmgUJvFj/EHqIWgsqd4hkwR7yj668stkEIBwsvAZg9zsEBYWZQQLZ2AfQXHgbWC4e8xyFV90HmH7JWX3LPzr+PS6LVmEXB/1QVRUe1ZHOOubJ4BNKrtpKQD2vc+oqqAxwW0Gmdbwc4S+peqD5BKB8wAAwMSut/sm4IwlkewXgr9BVoZrHPUfiHdc+pjsyqE5MHB3/DhfE5qG3XuPI50UVDxrpOxM/8y6OjN+KQfvFRrxdT1UATT13EoP8paGZzSYAa8cO7KppujkPEZuaKolrjYBZVgD+qnMN64AX3IfgTfd+2Mi8rYWR1r/vKBtwQvwrDI1+hh3kb2n1ZQXj6s6BYt8Z+ELbxQpyHa9xb30l/tPwpOM5mBpAnHf33zL712YTAPWHdCmQqafP0uLSfS9AW+A0MA9maHvgLfd+WKDtCKU1E02d4z84vgzHxRcgEP8BbuiZcGsZH+qUQJnvVMx07W4ZzU4Vekx8If4dmebU8E0ft4D8vaCkquOWQv/2U646WDidgw02fTQk0HIEzLoK8FeQqlBNyNUP81x98bW2E2IGV63rIBvwD30Fjoz/2PTLzhv7jHhI1XMz1nsi3nLva4Q5spEmApdG5+Cy6Jw0WSezbSUgJD4qKA0d1mICEK4IBCFR3FZnNJ4I/JWAVRKALXWrOwYW8u5YwLvjB20HLOV+rOSdE9430E5GsYsIo4+sRj99NdQZ/t5ibdaORFr1qVQrMv/2noR33HtbNQTb6x4TmdZUjpqaaQlM9peErm4xAagJBs5iwPOmDYGEWZaAFROA5mCrDY21bDus4+3wG8tBPdxNJwrULmiv1NEeEXTA/7d3JmBSFeca/v46PSsjArOIiCgqLolb4ooL0zOKOybqdY/eXI3R5EZjTGBmMCajV5kZwZi4x6tx4xoFoyEuKArTAyox7lETgwoucWNmAFlm6emuuk+10YgC08vp7nNOf/U88zzKVP3/9791oL8+p05VL2ria7BZgF/by/WFaLk3lp6IhaEdc52a+ZIgcFfPLZ49hyIJ+cHvIvhuVUNkvfN+vvIIoLOtbicx5vXg02CFuSbg5TUAuWbBfOkR6EcRzi0/E39X/t7UKb3qvTvKmt/I2itR6oHTJ71LKb/KRDtfr5w6/2+bvANgDKSzrXaVggzNr1xmDyKBoNwFCOLc+KWmTrUZzig7B/a8BzZvELDnUTzQc503xFDFVwlorKmMhodJc7P9J/jztsGlzl2t4QUAPt8ukDxJwC0CNABukSzsOM842+GCstMKG4KHqp8QW4LpfbM8pIhSvkRgvS2AP/vdhg0AFwLy6skSARqALIEtwLCnlp/LswM8Mu9nRxfh+9EOj6ihjC8TEJHplQ3tU77y5xtC1d1Sd4IRcx8xkoDbBD57vz5oh9m4zYnxBidwbfEhmFm83ltNgw9ij6wQmNZ3Pw6Jrfd4OSt5GDQ9AmLMSZVNHbOTMwBt4dHG4L30UnEUCWyagNe2BeZ8+ZOA3avB7hTIln8C9vm/XQfA5k0CjsHY4U2RrxzTuNHtzpZPC7+nFEZ7sxyq8jMBGgA/z553tL+panB6OQ8vzfeM2I2s5q2dkW8ZzL9xAp1VjZGaDf16owagsy18jxicTKok4DYBGgC3iRZmPHug03Hl6+1rUpgg8lz1frGluKbv7jyrYPqNERAxj1Q2dBydkgHg0cC8oLJJgHsCZJNuYcReokbijPLvFUaxHq7yu9Gn8INou4cVFrY0Y3BpdVOkOSUD0Hll/TdF6+cLGx2rzxYBGoBskS2cuH8K7YkrSo8pnII9WunVfffggNibHlVHWRA5tKqhfX5KBsDMOtHpXtppV3VUECEJkAAJeI3AeWVn4kVnjNdkFZQeBSSe/3PLa49Ou9b9a6Jq2NjmSF9KBsB27po24VEodbhHS6MsEiCBAiWwILQLmkpPKNDqvVP2OL0cM3tu9o4gKlmfgNEdVU0LwxvDsslDz7taw40AWsiUBEiABLxC4C/OWEwuOwl9KPKKpILVccLA85jSP7dg6/d64QL5ZWVj+2VpGYDutvD+xmCx14ukPhIgAX8RWC1l6FQViJoQiiWGar0WQ03vJotYg1LcVnIg7inaH/ZNErb8E2jtm4262D/yL4QKNkhAKzOhZkrHorQMgGkOh7pLsZLrAHh1kQAJZEJgAAr2tv2i0E54SW0Ne6DPl1uNWY294m+jPvY6Doy9CQcaa6UEL6kx6AjtjMdDu6BXijORwbEuErDP/x9bd9Wgxs3FlAyVEgHTU9lXM1yaZ0fTMgB2UGdbeK4YHJFSXnYmARIggX8R+EiGorXkaCwObZ80k2q9BiUYwPtqOD7bPjrpweyYEwK76A9xe8+tOcnFJKkT0BqP10yNHLapkYPeR+turbvIwFyVenqOIAESKGQC9oP7gaJv4trievRISSGjCGTt/xl9Gj+M2oNj2TxJQMzUqoaOTa7hG9QArLgivKt28IonC6QoEiABTxL4pxqBy0uO4Wt6npwdd0Td3Hs79oj/051gjOI+AS37V01tfyajOwB2cFdr+AMAW7qvkBFJgASCRMAe93xP0X64qSSMfq7SD9LUrleL3f9/7tqr4MAEtkZfF6axpjKKEdIciWVsAJa31t6hIGf6GgjFkwAJZJXAMlWF/ymZhNecrbKah8HTJ2A/sEOIZWzOjoi9ikv7/pi+EI7MKoFN7f//xcSDPgKwnTtbak8VEZ72kNUpY3AS8CeBOBTuLDoAt5ZMgF3tz+ZdAmdFn8Si0Di8obbISOQVfX/AobG/ZxSDg7NIQHB+VUPkusEyJGUAVrUcNDxqVKdSyhksIH9PAiRQOATsgTyXlU7K+AOlcIjlr9Jx+mPc3vM7/LjsVDznbJu2EPt2xmPrrkaZ2ejbZWnH5kB3CCiEthnR+MS7g0VLygAk7gJcEV4kDg4aLCB/TwIkEHwCA3BwS/EE3FU8HvYOAJu3CYQQT3z4WxPQUPofiIR2TltwOPY62vruS3s8B2aXgIF5ubqxY89ksiRtALgtcDI42YcEgk/gVWerxLP+t1VV8IsNSIXnRiOwt/9t+2Xpt/BoaLe0K7PP/u0aADbPEri8qjFySTLqkjYAK1on7Kah/ppMUPYhARIIHoE+CeGmojrcW7wf7Gp/Nn8Q2DX+Puwre5+t2L+iZBL+VLRHWuJLMYBHefs/LXY5G2TMvlVNHc8mky9pA2CDdbaGlwowNpnA7EMCJBAcAi842+Dy0mPwvgwPTlEFUIl9Tv9/Pf+LrYzd0f3TNq3kaMwp+kZa1R8RewWX9s1JaywH5YCANh9UNnWMFknu/cwUDUDdrwTmJzkogylIgAQ8QMDu4Gd38rM7+nFLXg9MSIoSLu5/EMcOvLzeqEwMwDV9d2O/2NIUVbB7rgiImJsrGzrOTTZfSgZgeWv9BAXdkWxw9iMBEvAvAbt3f0vx0fhYDfVvEQWsfGOL9ez6jYfSeARgz2eY03MNN//x8DVlFCZVT4k8lKzElAyAmXWi072080MA1ckmYD8SIAF/EbBH9f66ZCIeDu3uL+FU+zkBe7LizHU3w+7Y9+X2i9Lj8Fjo6ynT+l50Ec6J8vtfyuByNsD0rOmTyrHNka9O+kY0pGQAbIzO1vAtApyds5qYiARIIGcE7OthV5YcgW6pyFlOJnKXgF3sd0PvXdgzvuHXwCeXnoSFoR1TSmpf9Hxg3TUYaVanNI6dc0lAz6lqXPjtVDKmbAC6W8JHGMHcVJKwLwmQgLcJrJRyzCg5Ek+EdvG2UKoblMA50YX4XnThRvv9oOwM2EWdqbQD4m/i6t57UhnCvjkmIEbOrmxq/10qaVM2AKY5HFpebD52lIxIJRH7kgAJeJOAvR18VckR+ETKvCmQqpImsKd+Fzf03LXJ5/TfKT8n5Z0b7Ye/NQFs3iQQh4mWmPjIYU1P/vt1jySkpmwAbEw+BkiCLLuQgMcJdEkFWkqOwpMp3g72eFkFK2+46cHMnptRZdZuksGkIRdguSS/sHMb3Y17e25Ckm+WFSz/vBZuzJ+qmjq+laqGtAxAd2vd4Qbm0VSTsT8JkIA3CPwptCd+UzIRa6XEG4KoIiMC9hn9Nb0zsU/87UHjHFTRBLuVc7JtSv9cnDDwfLLd2S8PBMTglMqmyL2ppk7LANjHAN2l+IBvA6SKm/1JIL8EPlDD0FJyNP7icD+v/M6Eu9nt6ny7Sn+wZh/zHDbkp4N1+/z39i2CP639DewOgGweJaCxpre0f4utL1rcm6rCtAyATdLVGrZHDf53qgnZnwRIIPcE7CY+9xXtjetK6tGHotwLYMasEdg/vhRX996d1JFMb6gafKf8+0lrSdZYJB2QHd0nYOSuqqb2M9MJnLYB6G4L728MFqeTlGNIgARyR+B5Z1vcWBzGK87o3CVlppwQGKVX4Y7eWzHUJPflz673+GnpSUlps9sI/6nn2qRjJxWUnVwnIAZHVjZF0nokn7YBSNwFmHbwm1DO9q5XxIAkQAIZE7A7+d1efCBeUmMyjsUA3iNQamK4pdce8bs8aXGzi/bBjJLDk+p/+sBiXNA/P6m+7JQnAtosr9yhZpScNDuejoKMDEBna+2lAvlFOok5hgRIwH0CcajEu/wzi8djiRrpfgJG9AyBy/sewMTYaynpsTs8/r5ov0HH2G//f+y5DsNMz6B92SF/BLTBdTVNkfPTVZCRAfj4yvrtJabfUAoZxUlXPMeRAAl8SsAu7vpj0TcSz/lTecWL/PxJ4IyBxfhRGt/Of1J6Cp4O7TBo0WdFn8S50cig/dghvwREmwMqp3ak/Sg+4w/u7pbwQiM4OL8YmJ0ECpPAy87oxEl9852vISqhwoRQYFUfFFuC6X2zklr092U0x5X/CPZNkE01u57ggZ7rUGH6C4ysv8oVmKWVjR0ZPYLP3AC01f6XMZLS9oP+wky1JOAtAl2qAo+GdsODoT3wtqryljiqySqBHfRy3NJ7O+wt+lRbP4oQrmiAHmTghdHHcWr0mVTDs3+OCRiYy6obO36ZSdqMDcDy5nCFKtYfQakhmQjhWBIggY0TsBv2dDg74bHQrnguNBZxPnUruMvFPo+/rfd3sCv/02n/UCNxZvn3Njl0tF6Be3puQtGgNiEdBRzjFgGtddzRGFv584XvZRIzYwNgk3e11t4KyFmZCOFYEiCB9QmskCFYFNoREWcnPBvaDgNp3fQl1SAQKMEAbuydia/H30+7HHu882Wlx25yfFvffQjHXk87BwfmiIDBQ1VNkUmZZnPFAHBPgEyngeNJAInvXH9Xo/Dn0PZ42tkBf3O24vcwXhgJ2zetbzbqYv/IiMZgbwDsF1+Ka3rvzigHB+eGgFGYVD0l8lCm2VwxAFZEZ0vtyyKye6aCOJ4ECoWA/cB/S22BF50xeMHZFi+EtsEnKC2U8llnkgTceiZ/XtmZiWttQ60Icfx+3W+xtVmRpCp2yxeBuDbv1kTrxkpz82DLOQaV6JoB6GoN222B7fbAbCRAAhsgYE/fe90ZhdfUpz+vOqOxTorJigQ2SuDUgWdwYf/jGROynxSHDpmy0evt7OgifD/akXEeBsg+ARHzi8qGjv9xI5NrBmBF66Gbawx8AEi5G8IYgwT8SMDuud8tQ/CeGoFlqjqxSv8tVY23VA1W8q+GH6c0b5oPj72GS/v+6MoxvPY6PLn8vA3WYo/7ndn7vyg2sbzVysTJEdBATOLxMdUXL/owuRGb7uWaAbBpulvrbjYw57ghjDFIIFMCbznVWINSDDO9qEAfKkwf7Pap6TR7fKpdiW833FktZVgl5bCL9Dpls09/1Gb4QIbhIxmGPr6Pnw5ijvkCAXvAz1W99yKEtHZ4/QrLjS0AtOvyxQxeAAAgAElEQVQLftt7O3aP/5P8fUBAAw/UNEaOd0uqqwZgxfRDdtfx+MtuiWMcEsiEgP2A/mHZGVj2hXfl7T94JSaKUsQS33iKEIMDAwUDk0gmiIsgbhSiCKFfhdCHYq7Az2QiODYlArvG38f1vTNdPYK3teSoxIZRX25uPWJIqUB2TpuAGHV4ZdOCeWkH+NJAVw1A4i4AdwZ0a24YxwUC9ra7NQFLVbUL0RiCBLJLYEf9EW7omYnN0OdqotPLv483Vc16McfqLtzRcyvsK4Zs3idgd/4b0dCxg8i/vqu4INl9A9Bad5KBudcFbQxBAq4QsLfrf1R2Ot5QW7gSj0FIIBsE7AfyTb13un4Aj30MNrHip7DrUz5rdqOf23puxTj9cTZKYcxsEDBorGqKtLkZ2nUDYJrDoc5iLFMKPHzczZlirIwI2Of2F5aegtecrTKKw8EkkA0Cdge+3/bdiSq91vXwT4V2wEWlp6wX98f9j+O0AW736zrsbAXUel1RadmYzS96zNX3NF03ALb+rta6KYBx1alkiyvjFg6BXinG5NKT8KyzbeEUzUo9T8C+e39Tz52oMu5/+Nviry0+JHE89Gft4PgSTO+d7crbBZ6HGxiBcm1VY/sFbpeTFQOw8urwsHg/7B7FFW4LZjwSyISAXc1/SenxaA/tlEkYjiUBVwiM0StwY2/2PvytyLPKz0rsO2GbPUfgzp5bXF9j4AoMBtkgAbvvf3ERxg2bvHCZ24iyYgD+dRfgGsCc77ZgxiOBTAnYTVFmlByJPxTtlWkojieBtAnY9+9v6L0ra9/8rTD76uphQ36WODzKLva7pecO2IWGbP4hYAT3VjdE1n+G45L8rBmAj1sO3U5MdIlSynFJK8OQgKsE7ig+ADcW1623OMrVBAxGAhshYBffXdf7f64v+PtyuoWhHROPvWy7vO8BTIy9xjnxGQFjZO/qpvbnsyE7awbAiu2cVnuvKPn06mMjAQ8SmFe0Ky4rmQT7aICNBHJBwG6686vee3JyG35GyeGYXbQPzoo+iXOjkVyUxxzuEmivaozUuxvy39GyawCurP+maJ0V55ItIIxbeARecUYnviVxq97Cm/tcV2xP3Luyd7arm/xsqoaTyn+A7XUnpvX9gYv+cj3ZLuRTMEeNaOyY60KoDYbIqgGwGZdPC89TChOzVQDjkoAbBD6UzTG57GS88aXNUtyIzRgkYAkcEXsVl/Q96Nr2voNRtdd0c9m3cG3v3dznfzBYHvy9Frxa0xDZLZvSsm4Aulrq6yF6fjaLYGwScINAH4pwWekkzA99zY1wjEECnxM4LfpnXBCdn9Nv4S+pMdjOdGKo6eVM+JGA4LtVDZE7sik96wYgcRegJbxYCfbPZiGMTQJuEbiz+ADcVFyXWDnNRgKZELDnTPy4fx5OHng2kzAcW2AENPT71cPXjZVzn8/qPs05+Rdu+bS6o5QyDxfYHLJcHxOwmwXZ/QK4LsDHk5hn6eWmH1f0P4ADYm/mWQnT+42AABdWNkZ+k23dOTEAtoiuaeFnobB3tgtifBJwi0CXqsDPS47Hi84Yt0IyToEQGGlWY0bvPRinlxdIxSzTLQL22/8n5UO2H3fB3H63Ym4sTs4MQGdb3bFizJxsF8T4JOAmAbtp0K3FE3Bb8cF8JOAm2ADH2jP+Llr77sNw0xPgKlla9giYH1Y1dtyYvfj/jpwzA5C4C9Ba+zwgXz2UOheVMgcJZEDgJWdrNJd+G3ZlNRsJbIzASQPP4sL+x+HAWkc2EkiNgDHxd6r6R+4ozbOjqY1Mr3dODUDnleFjROPB9KRyFAnkl8A6KcZVJUfg4dDu+RXC7J4jUGpimNL/CI6O/dVz2ijIPwRE8L3KhsituVKcUwNgi+IbAbmaWubJFoEOZye0lh6FFTIkWykY10cEttXdaOm7D9vpTh+pplTPEdDxtyqjzs7SHInlSlvODUB3W+1EY2RergpkHhLIBoFPpAxXl0zEXN4NyAZe38S0m/s09T2cs539fAOGQlMnIObMqoaOu1IfmP6InBsAK7WrZUIEomrTl82RJOANAk87O2B6yRH4QA3zhiCqyAmBISaauOVvDQAbCbhA4PXK7ap3lZNmx12IlXSIvBiA7rbw/sZgcdIq2ZEEPEygT0K4pbgWvy/aFzEeKuThmXJHmj3M59L+P2KUXuVOQEYpeAIGOLW6MXJPrkHkxQDYIpe3hu9XwHG5Lpj5SCBbBJapKswoOQLPOdtmKwXj5pFAsYnh3IEOnBr9M+wOf2wk4AYBu+d/dW94D2luzvmrI3kzAJ1tdTuZePw1pRTPYXXjKmIMzxBYENoZ1xYfyscCnpmRzIXsFv8nLul/ENvo7syDMQIJfIGA1nJ0zdT2R/IBJW8GwBbb3Vp3s4E5Jx+FMycJZJPAABzMKtoXt5UciDUozWYqxs4iAfus/wfRdpwwYDcyZSMBdwlomHk1jR2Huxs1+Wh5NQCdVxy8pTjOEgAVyUtmTxLwD4FPUIq7Sg7ErKK90Y8i/winUkyM/Q0XRuehSq8lDRJwnYDWOu4oZ4/KxvbXXA+eZMC8GoDEXYC22kuMkcuS1MtuJOBLAl1SgduKD8Kcom9igN8lPT2H28c7Ex/8+8aXeVonxfmcgOCmqobID/JZRd4NwHu/Gl9W0leyRCmMzicI5iaBXBD4WA3FXUXjMSf0DUQllIuUzJEkgc1NL86NRvDtgRe4yC9JZuyWHgEN/Ulcm3FbTl2U192j8m4ALL6u1vB3AOR0A4T0po2jSMAdAt1SgXuK9sX9RXthrZS4E5RR0iJQigGcFn0Gpw8sRoXJ+gFsaWnkoGARMMDk6sbIjHxX5QkDYAykq23CYoHaL99AmJ8EckmgR0owp2hPzArtw7cGcgkeQBHi+NbAizg7uggjzLocZ2e6giWQ2PJ35NdydeDPpjh7wgAk7gK01O6jjTyjFDyjqWAvUBaecwL2BeBFzk64r3hv/MUZm/P8hZSwBAM4buBFfGdgMar1mkIqnbV6gYDICVUN7fd7QooXRHymoau19lZAzvKSJmohgVwTeFeNSKwReLhoD6yU8lynD2y+zdGHbw88j1Oif+E3/sDOsscLM7qjqmlh2CsqPfVt+6Pph9WoeN8SBcVD171yhVBH3gjYbYWfDI3DI0W74WlnHN8eSHMmtjYrcGr0GRwdexn22F42EsgHAQ2jRTn7VE9Z8EI+8m8op6cMQOJRQGvt+YBc4xVA1EECXiBg9xNoL9oF80Jfx0vONojzSdkmpyWEOGpj/8DxAy9gr/g7EG7d64XLuMA1yLVVje0XeAmC5wyAmXWi072081kA3/ASKGohAa8QWCXlWBgah4WhnfCs2g72MCK2TwnsqD/CUbFXcPjAq7zNz4vCMwS0xj/FGfhadcNTnlp04jkDkLgL0Fa/rzbxxQrC3Tc9cwlTiBcJ2L0EnlPb4s+h7fGMMxZvqyovysyqpm11N8Kx13FY/FXYTXzYSMBzBIw5vqqp4wGv6fKkAfjUBIRvhMF5XgNGPSTgZQJ2x8HnnLF4PrQNXlJjYBcUBq3Zk/h2jb+P8bE3URd/HdvqrqCVyHoCRUDPqWpc+G0vluRZA7Dy6vCweC/+DoWRXgRHTSTgBwL2ccGrzmi86ozC39QovK62xCdS5gfp62kcq7vwjfg72Dv+DvaNLcVm6PNdDRRckATWimCXyobIP71YvWcNgIXV3VJ7ohGZ5UVw1EQCfiVgtyN+Q7bAm04Nlir7U4X3pNIzawnsh/su8Q+xi/4AX4t/iD3j72KY6fErbuouYAICXFjZGPmNVxF42gAkHgW01M6ByLFeBUhdJBAEAgaCLlWB9zEc76th+FANw8eyOT6WzdBlf1QFVkspbD83mgONLcxqjNKrMMqsgv2GP1Z3YjvdiS30ajdSMAYJ5JeAxnOV0fB+0txs9/nyZHPnb3MWS+u6vH4rHYr/TUGGZjENQ5MACQxCwO5LYB8f2B9rBtaiFOukGHY7414UJQ43iiKEATiIQUHBJPbWH4J+DDH9GG56UGXWYgTWYrjugTUBbCQQRAL2qF8I9qlpWviil+vzvAGw8DpbwueJ4EYvg6Q2EiABEiABErAEDOTq6sb2i7xOwxcGwB4W1N1W+wQg9V4HSn0kQAIkQAIFTeDNmFO858jJ8zx/wpQvDIC9lFa2hLeNC14BUFHQlxaLJwESIAES8CQBe+vfgRxcObVjsScFfkmUbwyA1d3VVvdDGHO9H8BSIwmQAAmQQGER0EZaaprap/qlal8ZgE8fBUx4HFCH+AUwdZIACZAACQSfgAAvjRi+Zl859/kBv1TrKwNgoXZfPmHreAiv8MRAv1xi1EkCJEACASegdb8yau8RF0de9VOlvjMAiUcBreHvALjLT6CplQRIgARIIJgEjDFTqps6pvutOl8agH+ZgNkA/sNvwKmXBEiABEggOATEYNGI/nDYyxv+bIy2bw3A6mmHVPab+OvioPCOPwvO3x1WQgIkQAJ+JrA25Ojdh01euMyPRfjWAFjY3S3hk43gHj+Cp2YSIAESIAF/ExCDcyqbIrf4tQpfG4BPHwXUtgEyxa8TQN0kQAIkQAL+I6CBB2oaI8f7T/m/FfveAJjmZtVdvOARKHW4nyeC2kmABEiABPxBQGCWqhLZa/hPIqv8oXjDKn1vAGxZH00/rCYUj74EYEs/Twa1kwAJkAAJeJyA1v1GnAOrm9qf97jSQeUFwgAkHgW01NdriT+uIGrQqtmBBEiABEiABNIj8KOqxkggdqQNjAGw89jZWnupQH6R3pxyFAmQAAmQAAlsnIDRZlb11I6Tg8IoUAYgsR6gdME8bhUclMuTdZAACZCAZwi8Kb1le1VeOne1ZxRlKCRQBsCySKwHGOh/EUpGZciGw0mABEiABEjAEujTCuNrpkTsWrPAtMAZADsz3a31B8S1jiiFosDMFAshARIgARLICwEDnFfdGPltXpJnMWkgDYDl1dVWdwGM+U0W2TE0CZAACZBAwAmIyO8rG9pPC2KZgTUACRPQEp4JwelBnDjWRAIkQAIkkF0CBubluFNy4MjJ89ZlN1N+ogfaALz3q/FlZdGSpwB8Iz94mZUESIAESMCnBDqdkNpn+M8WvONT/YPKDrQBsNWvnFG/TaxfP8dDgwa9FtiBBEiABEgAgNYYQMgcUjOlY1GQgQTeANjJ62wJh43BPC4KDPKlzNpIgARIwB0Cfj/kJ1kKBWEALIyu1tofAHJDsmDYjwRIgARIoAAJGHNNVVPHjwuh8oIxAAkT0FJ7PUR+WAgTyxpJgARIgARSI6A1Hq/eofpIOWl2PLWR/uxdUAbANIdDncV4RClM9Od0UTUJkAAJkEBWCBi8EUJsv2FNT67MSnwPBi0oA2D5r2g9dPNYPLZYOdjFg/NBSSRAAiRAAjkmoKE/EXH2q25o/0eOU+c1XcEZAEt71fQJY2MD8mcoqckrfSYnARIgARLIKwENxByDSZVNkUfzKiQPyQvSAFjOXdPq9gNMOxTK8sCdKUmABEiABDxAQMScVdnQcZsHpORcQsEagIQJaKs7Xhs9W0FUzskzIQmQAAmQQJ4JyMVVje3T8iwib+kL2gAkTEBr7fmAXJO3GWBiEiABEiCBnBPQBtfVNEXOz3liDyUseANg56K7re5KY8xkD80LpZAACZAACWSLgMjsyt7aU6S5WWcrhR/i0gAAMAbS3Vp3B8Sc4YdJo0YSIAESIIG0CURWlpcdMe6Cuf1pRwjIQBqAf02k3SNgRZmZY4wcFZC5ZRkkQAIkQAJfIGCM+asjRRNGND7xCcEANABfuAo+aJ5UXlyy+nGIHMCLgwRIgARIIDgEjIm/A43x1Rcv+jA4VWVWCQ3Al/itvDo8LNZnOkRk98zQcjQJkAAJkIAXCJg4uhCSgwpto5/B2NMAbIDQx1ccsoWj4osgGDcYQP6eBEiABEjAuwQ0sBIK9TVTIi95V2V+lNEAbIR79+UTttaOWSTibJOfqWFWEiABEiCBTAhoYJUYObS6qf35TOIEdSwNwCZm9uMr67d3YvGFUDIqqBcA6yIBEiCBIBLQMKuVOBOrGhb8JYj1uVETDcAgFLumhXeG0hFAbeEGcMYgARIgARLIOoG1AnV4ZeOCp7OeyccJaACSmLzu1rqvG3tuAFCdRHd2IQESIAESyBcBrdfpkBxZM6VjUb4k+CUvDUCSM7WidcJu8bhaIA6qkhzCbiRAAiRAArkkoNFrHHN0dUOH/cLGNggBGoAULhFrAjTUfN4JSAEau5IACZBAbgj0wWBSVVPkidyk838WGoAU5zDxOEDrBVBSk+JQdicBEiABEsgOgT4xOK6yKfJodsIHMyoNQBrzmlgYCDOfbwekAY9DSIAESMBNAhprjODY6qZIxM2whRCLBiDNWbavCCIWX+AoGZNmCA4jARIgARLIgICG7lZGjqxq6ng2gzAFO5QGIIOpX9F66BhtYk9wx8AMIHIoCZAACaRDQJsPRKnDKhvbX0tnOMfwMKCMr4HEtsESfxwKu2UcjAFIgARIgAQGJSAwSx3HHDps8sJlg3Zmh40S4B0AFy6OVS0HDY8i9IgS7O9COIYgARIgARLYCAEteFVi8cN4ql/mlwgNQOYMExE+mn7YEEdH7xODI1wKyTAkQAIkQAJfIGCgnykuLjtq84seW0EwmROgAcic4ecRzG/3KururrgdSk5zMSxDkQAJkAAJQM/XferbNc2RtYThDgEaAHc4/tsEGEhXW+0MgVzkcmiGIwESIIGCJGC0mbWqovzMcRfM7S9IAFkqmgYgS2C7W2p/EjdylVIg4ywxZlgSIIHgE9BGWqob2y8WgQl+tbmtkB9OWeTd3VJ7ohG5E0BpFtMwNAmQAAkEjoDWGHBEzqtsav9d4IrzSEE0AFmeiO7W+gN0XM/hIUJZBs3wJEACgSGgoT9R4pxQ1dBuz15hyxIBGoAsgf1i2OUt4R2UmIcB2TEH6ZiCBEiABPxM4G3RztGVU+f/zc9F+EE7DUCOZsnuFRAT5z5A6nOUkmlIgARIwFcE7Gt+caf02JGT5y33lXCfiqUByOHE2dcEV6wcer2BOSeHaZmKBEiABHxAQP+ht3jgjK0vWtzrA7GBkEgDkIdp7GqtPV9rc7VSyslDeqYkARIgAW8R0GitbIpM5Ur/3E4LDUBueX+eraslfKgWzFLA8DxJYFoSIAESyC8BjTVw5LtVDe3351dIYWanAcjjvNsjhZ2YfoAHCeVxEpiaBEggLwR0HH9XguOrpkZez4sAJuUmNfm+BhJnCAz0/06UnJRvLcxPAiRAAjkicJ/uw39xW98c0d5IGt4ByC//z7N3toR/agStCgh5RBJlkAAJkICrBLTWcRFpqm7qmO5qYAZLiwANQFrYsjNoeWv9BIXYLEBtkZ0MjEoCJEACeSPQCaNOqWpasCBvCph4PQI0AB67IDqvOHhLcZy7AYQ9Jo1ySIAESCBdAs9KTJ9Q+fOF76UbgOPcJ0AD4D7TjCOaWSc63W91XqoNpvIwoYxxMgAJkEB+CVy/srzspzzJL7+TsKHsNADem5PPFXW31B9mTPwuKKnxsExKIwESIIGvEDBxdKEI/1U9JfIQ8XiTAA2AN+flc1XLrwyPVFrPBNQhHpdKeSRAAiSQIKA1HhcT/8/qixd9SCTeJUAD4N25+VyZaW5W3aWRKVrjMqVQ5APJlEgCJFCABOIwUQW5uKohchV39fP+BUAD4P05+lxhZ1t4b9G4G4JxPpJNqSRAAgVBwCwxyjm1esqCFwqi3AAUSQPgs0m0GwcVxQeu5oFCPps4yiWBABMwwK1xp/jHIyfPWxfgMgNXGg2AT6e0s7V2kmjcwgWCPp1AyiaBABDQwErHmHMrmzpmB6CcgiuBBsDHU756RrgqGtM3AeoEH5dB6SRAAj4koAF7jskPa6ZEPvKhfEoGeBZAEK6CzpbaU7XBdY6SEUGohzWQAAl4mIA2y0Wp8ysb22d5WCWlJUGAdwCSgOSHLvZ1QWjcoIDj/KCXGkmABHxIQJu7ixG6YOjU+d0+VE/JXyJAAxCwS6K7JXyyEVwLoDpgpbEcEiCBfBHQ5gOjcF51Y8eD+ZLAvO4ToAFwn2neI66edkhlVPTVEHNG3sVQAAmQgK8J2BX+DkI/HdH4xCe+LoTiv0KABiDAF4XdShgSv9FAtgtwmSyNBEggOwTehsE5VU2RJ7ITnlHzTYAGIN8zkOX87/1qfFlZtPjnWstk7iKYZdgMTwJBIKB1vxHnyr6SvpatL1rcG4SSWMOGCdAAFMiV0dU2YRcYdT2AugIpmWWSAAmkSsDgobijLtxiyoK3Uh3K/v4jQAPgvznLSLF9ZVAMZkDJqIwCcTAJkEBwCOj4WybkXMiT+4IzpclUQgOQDKWA9elsO3AzheJLYkb/2IEUB6w8lkMCJJAsAY1eKExbWV42fdwFc/uTHcZ+wSBAAxCMeUyris5ph+wIif9aBEemFYCDSIAEfEtAw9xfFHIuGv6zBe/4tggKz4gADUBG+IIxuLO17mgx5mqeMhiM+WQVJLApAkab15Q4F1U2LZhHUoVNgAagsOf/8+pN84nFXSWd5xvRlyiozYmFBEggWATi2rzriPyysj98pzQ362BVx2rSIUADkA61AI/5cNrB1UWimrXI9xUQCnCpLI0ECoJAXJsVSmTaqiFl1/E5f0FMedJF0gAkjaqwOnZNC+8MpVsB9a3CqpzVkkBQCJgeAL9WKLqSu/gFZU7drYMGwF2egYu2ojV8kDamDSIHBK44FkQCASSggZijcas28UurL170YQBLZEkuEaABcAlk0MN0ttUdK3FzORR2C3qtrI8E/EhAaxil8AejnYurp85f4scaqDm3BGgAcsvb19lMc7PqKmk/WQTNgOzo62IongQCQkDDaEfLLDG4YsTFkVcDUhbLyAEBGoAcQA5aCjPrRKd7adfpgLkEwA5Bq4/1kIAfCGiNAaVkplbxlpopC9/wg2Zq9BYBGgBvzYev1CSMwLLlp0HjYojs5CvxFEsC/iXQB2N+p6SobUTjE+/6twwqzzcBGoB8z0AA8ttHAytK2k+AyFQD7BmAklgCCXiPgNbrxFE3xQUzaqZEPvKeQCryGwEaAL/NmMf1rmitPVIb0wBRtR6XSnkk4AsC9j1+R8kNxdr59dCp87t9IZoifUGABsAX0+Q/kV1t9fsC5mc6Hj9eKeX4rwIqJoH8EjDG/FVBru0p6f+/rS9a3JtfNcweRAI0AEGcVQ/VtLIlvG1M5AIDfbaCDPWQNEohAc8R0FrHoWSOGLm2uikS8ZxACgoUARqAQE2nd4uxRxCLCX0XwI/4CqF354nK8kPg09v8uEWh6Hou7MvPHBRiVhqAQpz1PNZsDGRFa/1Eg/h/a8ExCqLyKIepSSC/BDReMcpc21ccncnb/PmdikLMTgNQiLPukZpXtB46RiN2DoCzAWzpEVmUQQLZJrAWMLMU5LYRjZEns52M8UlgYwRoAHht5J2A3U+ga1nX0aLNOdroI7loMO9TQgEuE0hs0yt6IZS6LaaK7xs5ed46l1MwHAmkTIAGIGVkHJBNAp1XHLylOKEz4tD/6UC+ls1cjE0C2SZgTPwdIHSnhnP7Fk1PLM12PsYngVQI0ACkQot9c0qgsy28txg5E1qfDCU1OU3OZCSQLgGNXgjuh5LbKqe0LxCBSTcUx5FANgnQAGSTLmO7QsA0h0MrSnBoXMypSstxUNjMlcAMQgLuEegD9GMQ+YP0lM+pvHTuavdCMxIJZIcADUB2uDJqlggsaw6XblaGIwRykombY2gGsgSaYZMgYHoAM9dA3Wf68FBNc2RtEoPYhQQ8Q4AGwDNTQSGpEkiYgVI5XEMfbzSOcZSMSDUG+5NAigTWGsHDCrivv3ezR0Y1P9iT4nh2JwHPEKAB8MxUUEgmBOxjgq4yc7AY+ZbATDKQ7TKJx7Ek8AUCnTDyKJS5f00vHh3bHOkjHRIIAgEagCDMImv4CoGutgm7GKOOFuCoOMyBDqSYmEggGQIaiDkGi43Io8bgsarG9he4kC8ZcuzjNwI0AH6bMepNmcDy5nCFlEm90WaigpkIkZ1SDsIBQSfwtmg8ZsQ8Jn3l87mIL+jTzfosARoAXgcFR6C7LTzaGKnXxtQbY+ocJWMKDkKBF6yBVY6Yp2FknhZ5tLqh/R8FjoTlFyABGoACnHSWvD6BVdMnjI1pNcEYHCzGHMQ7BMG7QgywTICnjMFTjuinhvfVvybNzTp4lbIiEkieAA1A8qzYs0AIrJ4RruqPmfHGqPFKzHhovQ+UGlIg5fu+TPsMX8G8DMiTYsxTWhU/Vd3w+Ae+L4wFkIDLBGgAXAbKcMEjkDir4O3uPUTr8TAYbwQHCDA2eJX6ryKtMaCA1yHykoF5WaBejIVCz3Cvff/NJRXnngANQO6ZM2MACHzyq8NHDPQP7ClK764NdgX0rgayi4IMDUB5niwhrs0KR8nLBnhZDF7WDl6q7qn+mzTPjnpSMEWRgMcJ0AB4fIIoz18Eui6v3wpFZmcYvaOBGifGjNMa2yvR20GpEn9Vkye12iw3RpaIY5bAyBLj4DUV1S9X/nzhe3lSxLQkEEgCNACBnFYW5TUCxkC6rpy4pWMGttNixgpkO2OwLfDpjwZGKyDkNd1Z0aP1uriSd5SRd0ThHaPNUqVkWVzwppiBt6obnlqTlbwMSgIksB4BGgBeECTgAQJ2ncHKpSu3AmJj4sZsDWC0AKMhMsqI3lIZ2TIGjPbqhkYaRhuNVY5Cl4nLcuOgU2n5SBz9IbR8KGLeH4D6oLS4+L3NL3pshQeQUwIJFDwBGoCCvwQIwC8E7F2E5dMOqXFUbAyU2lqM2doAmwlEQYxoYxSMspvWKQ1RStn/l3LA2NMTK4ygAtCbwUiFaF0BqMSpiqKwVgNrIGYtoNaIwVpA1sDoNZB//bf9vf0zwa2mWn0AAAAkSURBVFqBTvy3xLBWStQapYrWDF09fhVfq/PLlUSdJPApgf8HX8nYEJFnTzwAAAAASUVORK5CYII=",
        safari: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAgAElEQVR4XuydB5hU1fXAz71vZmd7b/NmF1iqCmKviA2wxIKiYo3GlmiMJWrUaBLN30SjMZpETaxJNGos2FsUuwgKgo2+wAI782Z7b7Mz797/dwcwCuzuzLwyr5z7fXzyyb3nnvM7b+adee/ccwjgQAJI4HsEGhsbx6mqeiDnfA9K6STO+WjGWCWltAAAMhljjFIaBYB+xlgbpbQFADYTQtZzzpcDwOd+v38NIYQjWiSABJCAVQkQqyqGeiEBMwhwzklDQ8O+nPOZjLHplNL9AKBU696MsUYAeNvj8TxbUVHxX0JITKtMXI8EkAAS0JMABgB60kRZtiGgKMq+hJBzOeenAoDfSMVFMEApvTczM/O+4uLiTiP3QtlIAAkggUQJYACQKCmcZ3sCnHOqKMrphJBrAGCfNBgkXhXcKMvyw2nYG7dEAkgACXyPAAYAeEG4gkBDQ8Px0Wj0DkmSdrOAwa+rqnpudXV1mwV0QRWQABJwKQEMAFzqeLeYvXnzZtnr9T7AOT/BYjav5pwfHQgENltML1QHCSABlxDAAMAljnajmaFQ6ERCyD8BoNii9tcSQqb5/f5mi+qHaiEBJOBgAhgAONi5bjYtHA7frKrqzZRSq1/jH/j9/hmEEOZmf6HtSAAJmE/A6l+O5hPBHW1NQCT6hcPhBwHgIrsYQgi5zu/3/9Eu+qKeSAAJOIMABgDO8CNasZVAOBx+lHN+gZ2AMMZ6MjIyJpSXlzfYSW/UFQkgAXsTwADA3v5D7b9DQFGU34tjdnaEwjm/KxAI/MKOuqPOSAAJ2JMABgD29BtqvR0BRVHOBoAn7AqGc97JGPNXV1f329UG1BsJIAF7EcAAwF7+Qm13QiAYDE4EgGWU0hybAzpVluXnbW4Dqo8EkIBNCGAAYBNHoZo7JyBq+YfD4QUAcLADGD0uy/J5DrADTUACSMAGBDAAsIGTUMWhCYTDYVHP/zEnMGKMbaqqqhrjBFvQBiSABKxPAAMA6/sINRyCAOfcEwqFaimljrlpEkJq/H7/RnQ6EkACSMBoAhgAGE0Y5RtGIBwOn8Y5f9awDdIj+BxZlp9Mz9a4KxJAAm4igAGAm7ztMFtDodCrhJDjHWbWbbIs3+Qwm9AcJIAELEgAAwALOgVVGplAXV1dps/naweAzJFn22rGI7IsX2wrjVFZJIAEbEkAAwBbug2VDgaDB1FKFzqNBOf8X4FA4Hyn2YX2IAEkYD0CGABYzyeoUQIEQqHQBYSQRxOYarcp98iyfLXdlEZ9kQASsB8BDADs5zPUGABCodANhJDbnQaDEPJTv9//d6fZhfYgASRgPQIYAFjPJ6hRAgQURfkVANyawFRbTWGM7VlVVfWVrZRGZZEAErAlAQwAbOk2VFpRlCsB4M9OIsEY21hVVVXjJJvQFiSABKxLAAMA6/oGNRuGgKIoJwHAiw6DdJMsy7c5zCY0BwkgAYsSwADAoo5BtYYnEA6Hx3DO6xzEqTUzM3NccXFxp4NsQlOQABKwMAEMACzsHFRteALBYLCBUlrhEE4/lmX5YYfYgmYgASRgAwIYANjASajizgkEg8HnKaVzHMDndVmWnVbR0AFuQROQgLMJYADgbP862rpQKHQ+IeQfNjeyNhKJ7F9TU9NhcztQfSSABGxGAAMAmzkM1f0fgdbW1vxIJBIGgGybcgkRQg7B7n829R6qjQRsTgADAJs70O3qh0Kh+wghl9mNA2Nsk9frnVFRUbHebrqjvkgACTiDAAYAzvCja61obm72RyKRtZTSXLtAYIwt8fl8s8vKysTTCxxIAAkggbQQwAAgLdhxUz0JhMPhn3LO79dTplGyRM7CwMDAZTU1NQPJ7sE5l1paWsoHBwcrCSHlAFAGAKUAUEwIKVJVtVCSpALOeR4A5DHGxKsR8SeTUuoDgAwA8DLGJEop3bY/Y0yllKoAoDLGGOdclSQpCgD9hJABznm/+DvnXPy9V5KkLs55/A+ltFP8lxAiOjO2iD+EkGZKaXN5eXlPsjbifCSABMwjgAGAeaxxJwMJhEKhZwghcw3cQhfRjLHSqqqq1p0Ja2hoyIlGo+MkSRoLAKIi4GgAGMU5rwaAKs55+Xdv3LooZKwQEeQ0cc4V8UeSpBBjTOQ9KISQelHHwe/3BwkhIvjAgQSQgMkEMAAwGThuZwyBurq6TJ/P9yoAzDRmB92k/lWSpNtisdjuhJDJjLFdKaWTAED88eu2i30ERRlj9ZIk1YmAgHO+nhCyBgBW+/3+dYQQ8SQCBxJAAgYQwADAAKgoMj0ERBCQmZn5L8756enRAHfVk4B4NSECA8bYakrpSs7515TSrysqKlZjYKAnaZTlVgIYALjV8w62OxwOX6aq6h2U0hwHm+lm0wYJIatVVf2KUrqMc/45IWSZLMt9boaCtiOBZAlgAJAsMZxvCwKhUGgUIeQ2xtiZNntvbgu+VlNSPC0AgFWEkM8ppYtjsdgnVVVVywkhzGq6oj5IwCoEMACwiidQD0MIBIPBiYSQKwghZwNAoSGboFBLEuCcdxJCPiWEfAIACzjnn+FTAku6CpVKEwEMANIEHrc1l4DID8jIyDiKEHKCqqozJEkSWfY43EVgEAA+45y/Rwh5r729/dPJkyeL/4cDCbiSAAYArnQ7Gq0oCkcKricgcgYWAMB/AeBNWZZXu54IAnAVAQwAXOVu9xoriuiEw+FpADB7659x7qWBlu+MAGNsI6X0Tc75m4SQd/F1AV4nTieAAYDTPexi+xRFEVXwjgKAkwDguK1V81xMBE1PgoCogvgOY+wlQsgrsiyLKoc4kICjCGAA4Ch3ojHhcLiMMXYCpfQkzrkoCpSFVJCAFgLihIFIJCSEvMgYm1dVVRXUIg/XIgGrEMAAwCqeQD1SJtDc3JwXi8VO5pyfxRibQSn1pCwMFyKBYQiIVgmU0k845894PJ7nKioqGhEYErArAQwA7Oo5l+u9YsWKjMLCwmMB4CyR2Y+/9F1+QaTB/K1PBj4EgKcyMzOfKykp6UqDGrglEkiZAAYAKaPDhWYT4JyThoaGw8QvfQA4RXTBM1sH3A8JDEFAdEx8kXP+mCzL72ABIrxO7EAAAwA7eMnlOoZCIdEN70JCyAUAIP6OAwlYmUAIAP4tSdIjFRUV662sKOrmbgIYALjb/5a1XhzbUxTleELIjxljx2A5X8u6ChUbgsDWfIF3CSEPVlZWvowNjPBSsRoBDACs5hGX66MoymgAuAgAzgeAgMtxoPkOIcAYa6SU/oNz/kAgENjsELPQDJsTwADA5g50gvqcc6ooikjku4RzfhT+2neCV9GGnRHY2rToZUmS/ur3+0UCIQ4kkDYCGACkDT1u3NTUlBuLxS5gjF1JKR2LRJCAywh8yTm/t6+v78kJEyZEXGY7mmsBAhgAWMAJblMhGAxWbe3QdzF26HOb99He7QlsfT1wbzQa/dvo0aPbkRASMIsABgBmkcZ9QFGUfQDgGsbYaVisBy8IJPB9AoyxHkrpI5zzuwOBQD3yQQJGE8AAwGjCKB8aGhqOZ4xdBwDTEQcSQAIjEoiK4kKqqv6+urq6dsTZOAEJpEgAA4AUweGy4QmIoj3hcFg04fk1AOyFvJAAEkiOgEgYpJQ+DQC/w1bFybHD2YkRwAAgMU44K0ECW6v1ncI5/xUA7JHgMpyGBJDAEAQYY0ySpOcA4P/8fv9KBIUE9CKAAYBeJF0uZ+tRvtPEjZ9SOsXlONB8JKA7AREIiFcDHo/nN5WVlXW6b4ACXUcAAwDXuVxfg8WNPxwOn8EYEzf+XfWVjtKQABLYCYEo5/xhr9d7a3l5eQMSQgKpEsAAIFVyuE5k9R9DCLmDcz4VcSABJGA6gT4A+KvP57sdOxGazt4RG2IA4Ag3mmtEKBTaixByJwDMNHdn3A0JIIHtCTDGmiVJuqWysvIhQkgMCSGBRAlgAJAoKZwH4XB4DOf894yxMymleO3gNYEErEVgNaX0F5WVla9ZSy3UxqoE8Evcqp6xkF719fXFkiTdBACXAYDPQqqhKkgACWxHgBDyLgBc6ff7VyAcJDAcAQwA8PoYkgDn3BMOhy8HgN9gyV68UJCAfQgwxmKU0vt8Pt/NmB9gH7+ZrSkGAGYTt8l+iqIcyhi7H4/02cRhqCYS2AkB0WdAkqTrKysrHyeEcISEBL5LAAMAvB6+R6CpqakyFovdBQBnIxokgAQcQ2AhpfQnlZWVyx1jERqimQAGAJoROkPAtsf9qqreIklSvjOsQiuQABL4DgHRY+AuVVVvra6u7kcySAADALwGxHl+0aTnfgDYHXEgASTgeALrOeeXBgKB+Y63FA0clgAGAC6+QDZt2lTk8XjuJoT8yMUY0HQk4EoCjLEnAOCqqqqqVlcCQKMBAwCXXgShUGg2IeTvAOB3KQI0Gwm4noBIEqSUXirL8ouuh+FCABgAuMzpwWCwhFJ6LwCc6TLT0VwkgASGIEAIeYZz/jNZllsQknsIYADgHl+LSn6nqap6H6W03EVmo6lIAAkkQIAx1kQp/aksy88nMB2nOIAABgAOcOJIJjQ0NJTHYrG/UUpPGWku/jsSQAKuJ/C4z+e7HAsIOf86wADA4T4Oh8NzOed/A4ASh5uK5iEBJKATAcbYRkrpubIsf6yTSBRjQQIYAFjQKXqo1NTUlBuLxe4DgPP0kIcykAAScBcBxhiTJOmPbW1tv5k8efKgu6x3h7UYADjQz+FweD8AeIpzPt6B5qFJSAAJmEtgqaqqZ1RXV68zd1vczWgCGAAYTdhE+ZxzGg6HrweA3wKA18StcSskgAQcTIAx1k0I+UkgEPiPg810nWkYADjE5fX19QFJkv4NAEc4xCQ0AwkgAYsRIIT8g3N+uSzLfRZTDdVJgQAGAClAs9oSRVFOBoBHAKDYarqhPkgACTiLAGNslSRJp/n9/hXOssx91mAAYGOfc8694XBYdO67wsZmoOpIAAnYjABjrJdS+mNZlp+ymeqo7ncIYABg08uhubnZH41GnwWAQ2xqAqqNBJCAzQlwzu/v6Oi4Gk8J2NORGADY0G+hUEjc9J8jhFTaUH1UGQkgAQcR4Jx/yjk/raqqKuggs1xhCgYANnOzoihXMcb+SCn12Ex1VBcJIAGHEmCMNW/NC/jQoSY60iwMAGzi1oaGhhzO+SOc8zNsojKqiQSQgLsIRAkhV/n9flF5FIcNCGAAYAMn1dfXTyCEvEApnWIDdVFFJIAEXEyAMfZQIBD4GSEk6mIMtjAdAwCLu6mhoeFIxtg8ACiyuKqoHhJAAkhgG4EFovlYZWVlEyKxLgEMAKzrGwiFQhcSQv6OVf0s7CRUDQkggZ0SYIxt8ng8x1dWVi5HRNYkgAGABf3COScNDQ1/4JxfZ0H1UCUkgASQQEIEVFXtkiRprizLbyW0ACeZSgADAFNxj7yZoijZjLF/U0rnjDwbZyABJIAErE2AMaZKknS53+8XTzNxWIgABgAWcoYo7jM4OPgKIWRfC6mFqtiUQIxx6IsB9EYZ9KscIirAIAOIqRxUzoEDAUIAKHCghIBEAMQXgk8i8T8Z0pa/Z3m2/MEvC5teCNZR+y9+v/9qQgizjkru1gQ/0xbxf319/VRJkl4DgGqLqIRqWJRAR4SB0ssg1BuLbO6OdQa72UDDgKq29DPaFeHenhjLHIjyHE6oTy8TCGfcQ6V+D1EjPi+N5EtSNC8L1PJMDxT7uKcy1+vzZ0NeIDcjsyyTQHmWBB6q1+4oxykEGGMvRKPRs2tqagacYpOd7cAAwALeC4fDR6iq+jKlNM8C6qAKFiHAAeD1jQM937QOttd2qLH6HtXXPsiLGIMsi6g4tBqM8QyJdpVl0u7KPBodmy95xuZ7cicVeYtG50lQ5MPowPI+NE7BBdFo9MTRo0e3G7cFSk6EAAYAiVAycM7WTn6ix7Zuv9YMVBdFm0hA6WGNx7/eWmHilqZt5SHQW5ZJ28cW0tgeZb6cKQWkdNfSTFKQgV9JpjkhjRupqrqSUnpMIBCoT6Mart8aP21pvARCodAFnPOHKKVSGtXArS1KYP7m/i+vX9Szp0XVM0StLMrbxxZ6Ovcuy/DuW5FRsXuxx1OITwsMYW0BoSFK6bGVlZXfWEAXV6qAAUCa3B4Oh3/BOb8zTdvjtjYgcPey7gVP1A64vttjvpc0TymVeqdXZuTvV+krrsn3YEKiDa7fBFVsZ4wdV1VVtSjB+ThNRwIYAOgIM1FR4XD4Djzjnygt98778XsdH3/eHJ3uXgI7t9wrka7JRVLrEYGM/EMDmSUipwCHfQkwxnoJIScHAoH59rXCnppjAGCi3zjnUjgcfgAALjJxW9xKRwKNfQyKMwl4qfEfnaNfbV3a3Mf20VF9R4rK8vC2vcs8XcePyayY5s/MyvVigqENHT0IAGfJsvy8DXW3rcrGf4vZFo2+inPOvaFQ6D+iPra+klGakQREJv6K5gh7ZXMk+H5w0NM6wOVzJ2atuWqv3ElG7itk7/90YzBGaJXR+zhJPgGIjc7zKMeN8WYeMzqrPJCDTwfs4l9RMIgQcnEgEPinXXS2u54YAJjgQXHzb2homMc5P9GE7XALjQQYB1jcMBh5prY39FljtGiAke81YqIc+t44sdhbni15NW415PKoCtED5jVKABR/zmqAXJJBwjPH+GJzxviqJhThEQMNKE1ZyhjjhJArA4HAvaZs6PJNMAAw+AJYsWJFRnFx8XN48zcYtEbx4pf+F43Rwadre4IfNsSKoyoUDidySpF35eNHFe6mcdshl69uj9Wd9XZ7jVHy3Sg3P4M2HjfaG507IacK8wYsfwVcI8vy3ZbX0uYKYgBgoAPx5m8gXJ1Er22LsCfXDG6aH+wv3P6X/khb/GVaftP0Kl/5SPNS+fd56waW3La0e79U1uKakQmUZdHQmROzvSePzSzH2gMj80rHDM75LwOBwB/Ssbdb9sQAwCBPb735i8f+Jxi0BYpNkUDnIId5a3oanl4XUVsHeSBFMZDtJcH3TyqpMiIh8LdLej56eUP/oanqhusSIyByBnYp9NRfPDmrfHrAlyOJ5gg4LEOAEHKz3+//P8so5DBF8Go3wKHi5l9YWPg8IeR4A8SjyBQIiEf8CxsG+h5e3t/wdUusGgjo8v7+3F2y1161R87EFFQadsnZ89s/WdUWm6a3XJQ3NAFRhGj2mMze8ybnVlVkY+qFha6VW2VZ/o2F9HGMKhgA6OxKvPnrDFSjuO4oh6fX9itPrO2XugeZ7mV1jUoIPPTF1m96BtnuGs3H5akQ4IztWpSx6bKpmf6D/VmZqYjANfoSwCcB+vLcJg0DAB25bs32fx4f++sINUVRqzvU6H1fd29eqAxWASGG9lnYrcCz6oljinZNUdWdLtv76eZWIFCip0yUlTyBAh9puGBStnTaxKyyTNEvGUfaCGBOgP7o8YrWiSnnnITD4SdEMQudRKKYJAmIx/wfhga77/2qp7WuWx2T5HJN0/VMCGyPRLtnvNSBnSE1eUTfxR7Cuk+ekN1xyW451djJUF+2SUrD0wFJAhtuOgYAOsEMhUL3EUIu00kcikmCQJQBzFvX3/Tgim7WNUgqk1iq21Q9EwIXNw6uuuSDTl2fKOhmqNsFETZ4eGVG6Ko9c8aMyse6Aum4HDjnV2CdAH3IYwCgA8dQKPRbQggmqejAMhkRAyqHf6/uV/65oidrgH+/WE8ycvSaq1dC4KOr+hbd/3XvQXrphXL0J0A4qAfInk3XTc0ZPaYwA8sN6o94SIlbiwVdiBUDtUPHAEAjQ0VRrgCAv2gUg8uTINAb5fDoyu7gE2sG82KcFySx1NCpeiUEXrOg86P3Q4N4BNBQb+klnLF9SzM23rgPBgJ6EU1EjigbTCk9HXsHJEJr6DkYAGjgpyjKDxljj1FqQmcYDXo6ZWl/jMMD33TXP1XbX6hyasl35HokBM5+vfXT+h52oFP85go7GKiHBDybrt8rtyaQ58XvVXOcPsg5Px67CKYOGy/UFNmFQqETOOcvUEo9KYrAZQkSiDGAx1b3Kg+u6MuOseFL9CYo0tBp9x6S3zwt4CtLdZOD5zXXDqgwIdX1uC6NBDhEjx6dGbx+75yaQh/WEjDaE6KVMADMqqqqWmT0Xk6UjwFACl5VFEX0aH8bAPCMcAr8El0imvI8t7av+S/L+2AgxlO+oSa6n17zsj0Qev/k0kAqFQLFSYa9/tPcRylk66UPyjGfgERI7zmTMtovmZJX5cPjg0Y7oJ1SemhlZeVyozdymnwMAJL0aDAYnEgpFdFmcZJLcXoSBBaGB7tv/rSrS0up3iS2033qeZOyaq/cMzfpX/FKD2s8/vVW3QsW6W4gCkyIQCaF1qv3yuGnjM8uxS/bhJClOinIGDuoqqoqmKoAN67DazIJryuKUgoAnwLAuCSW4dQkCGzqisZu+LRn85r22NgkllluaqoJgfM39395/aKePS1nECqkiYA/G+r/cFBR2e6lHnxqqInk0Is55ytisdj00aNHtxu0hePEYgCQoEtra2t9OTk57wIA1mdPkFky03qiDP6wtHvDGxsHdavTn8z+RszdvcS76rGZhUmd5797WfeCJ2oHDjFCH5SZbgKMTfdnbLzlgIKxWEzIMF98HIlEjqqpqRkwbAcHCcYAIAFnbq3y9yQAnJnAdJySJIEX1/c33760yxPjtCjJpZafnmxC4I/f6/j48+aoyDHB4VACEuHdV+6R03f2pJwK/ALW38mMsRcCgcBphBCmv3RnScTrLwF/Kooi2lH+OoGpOCUJAnXdavSajztDG00u25uEipqnJpsQePSrrUub+9g+mjdGAZYn4M8hm/88rahiQpFkaK8Ky4MwRsE/y7L8c2NEO0cqBgAj+DIcDp/LOX/MOS5PvyWDKsAfv+je+Py6gYBebXnTb9XQGiSTELj/043BGKFVVrYHddOPgKgoOGdsZvC6ffNGe/HUoH5gAYAQ8lO/3/93XYU6TBgGAMM4NBwOH8Y5F8f9Mhzm97SZs6xpsOeqjzp6etT01OxPh+GJJgRGVYgeMK9RAqB4K0iHo9K4Z56HhO85NC9/7zJfThrVcNTWjLEYpfR4WZbfcpRhOhqDAcAQMBsaGmoYY5/jcT99rjZRt/+3S7o2vLVpYIwbb3CJJASubo/VnfV2e40+xFGK/Qgwdswo36ab9y+owdoB+nhPVdUuj8dzsN/vX6GPRGdJwQBgJ/5UFEUUYVkIAHs4y93pseazxsHOaz/uivSqvDw9Glhj1/umFzQfLGcMWdBo3rqBJbct7d7PGtqiFukikJ/BG+47tDB/SkkGFoPSwQmMsU0ej2f/ysrKJh3EOUoEBgA7DwCewox/7de5aNP728WdG96oG6gB7JcAIyUE/nZJz0cvb+jHJkDaLz37S2BcPWNSZujqPfNGebDViB7+/Njv988ghET1EOYUGRgAbOdJRVFE5ujdTnFwuuyobY8NXPJ+R2t7lAfSpYMV9z13Uua6q/bMG78z3c6e3/7JqrYY1pmwouPSpFN5FtQ/fEShvzrPiz1HNPqAMfZgVVXVJRrFOGo5BgDfcWc4HD5CVdW3scFP6te4qGX/0PLu+geW95UTQvF403YoRULg6ycUZlTk7PiFfuiLrd/0DLLdU6ePK51IgHLed9N++d0nj8vEEtHaHXypLMsPaBfjDAkYAGz1YygUquacL6WU2qbpjNUuwda+KP/JR911GzpVW5fxNZrrbsWe1U/MKtpl+332frq5FQiUGL0/yrcngf0rPBvuPqRwbLYHv7Y1eFC8Apgpy/JHGmQ4ZileSQBQV1eXmZGR8TEhZF/HeNZkQz5vjnb+7IOO6CAD0S8BxwgEtk8IbI9Eu2e81JGH4JDAcARyPCT8zyMLi8cXefDpWoqXCmOsmXO+V3V1dShFEY5ZhgEAAITD4X9wzs93jFdNNEQ88r/36+5N/1o1IN7143vKBNnneEjovZNLvm0ZvLhxcNUlH3Qm1Tcgwa1wmtMIED5w4145nadOyMFXAin6lhCyqLKy8jC3JwW6PgAIhUIXEEIeTfE6cvWyniiHC+d3rK/tjmF3xBSuhO8mBD66qm/R/V/3HpSCGFziUgKH+T0b/nhI0VgPlo1K6QoghNzr9/uvSGmxQxa5OgBQFEX84hLFfvC8bZIX9Nr2SP+F73Z29rqool+SiEac/t2EwGsWdH70fmgQjwCOSA0nfJdAeSZs/tfMwqrKHCwknMqVwTk/MxAIPJ3KWiescW0AIN77+3y+xQCAWddJXsn/rRto/NVn3XmMYOCUJLodpm9LCJz9euun9T3sQK3ycL37CHgIa//b4UXSvuUZ+e6zXpvFjLFeSZL29/v9K7VJsudq1wYAwWDwAUrpT+zptvRoLd73376kZ8O8db1Y2EdHF9x/WEHLNQs62wdUmKCjWBTlIgIEIHblnjmN507KxrobSfpdVdWVkiTtJ8tyX5JLbT/dlQFAOBw+lXP+nO29Z6IBopb/+fPb16/pVPF9v87cRUJg9yAvohSfqOiM1nXijhnlrfvdgYU1WDwwadc/IsvyxUmvsvkC1wUA4XB4DGPsS0JIgc19Z5r6zb0x9ez57aGWCIwybVPcCAkggZQITCz0bHj0yMKxOV7Xfb2nxGvbIjfmA7jqCuGce8Lh8AIAOEDTleKixWvaB3t/9G5nX0QFLJDkIr+jqfYmUOgloaeOLqio3EnFSXtbZpz2onNgRkbG3hUVFeuN28Vakl0VAITD4Ts459dZywXW1ebj4GDLzz/pzGIA2KPcum5CzZDATglkEGj916yCrF2KsKtgopcI5/xzWZYPdkt9ANcEAOFw+HBVVd+j2JUuoc/Cc7W9oduX9YlCI1jcJyFiOAkJWI8ABej90/S8yGFyZrH1tLOsRrfLsnyjZbXTUTFXBADNzc15kUjka0rpGB3ZOVbU/d/0bXx0efdobOHrWBejYS4iIE4IXLyzR+MAACAASURBVL9XTtPcidmyi8xO2VTGGCOEHBYIBMTrYkcPVwQAiqI8BACuy/BM5cr97eKO9S/XRTHTPxV4uAYJWJUAY/ziyTn1l07NxUTeBHzEGNvo8/mmlpWVdScw3bZTHB8AKIpyDAC8aVsPmaS4yjlc+VHXuoUNgzvtVW+SGrgNEkACBhI4eVxW3a/3za0xcAvHiOac/ysQCDi6R4yjA4C6urpCn8+3HACwOMYwH8sY4/CTdztrv2iLYiEax3x9oSFIYOcERA+BP00vGou1AhK6QubIsvxiQjNtOMnRAUAwGHycUvpDG/rFNJWjjMP573bWrsSbv2nMcSMkkG4C+5Z6Nvz9yMKxEnH0LUAzZsZYIwBMrqqqatUszIICHOv9UCg0mxDykgWZW0alKAM45+32dbWdMXzsbxmvoCJIwBwCU0u86x8+smCcFx8FjAT8P7IsnzXSJDv+uyMDAEVRShljyyml2C97iKtyUAWY+1b7+s3YyteOn1vUGQnoQkBUDfz3rKKx2EtwRJwny7LsuB+UTg0AngKAM0d0qUsniMf+Z/63rXZDN8N3/i69BtBsJLCNwIRCacOTs4rHeigyGYoA57yBMTa5urq6zUmUHBcAhEKhWYSQt53kJD1tYRzgwvfa1n7Vok7UUy7KQgJIwL4EJhV5Njw+s3Asvg4Y1oePy7J8nn29vKPmjgoA6urqMrdm/eM59iGu0ss/6lz7SXgQb/5O+hSjLUhABwJTSzzrH51ROA4TA4eGyRibWVVV9a4OuC0hwlEBgKIotwLAryxB1oJK/OrTrto3NkXwsb8FfYMqIQErENiv1Lv+gRmF4xx1Y9ARLCFk3cDAwO41NTUDOopNmyjH+FlRlF0A4CsAyEgbTQtvfNey7nVP1Q5gtr+FfYSqIQEjCVDOwKdGod/jG3abmQHv+jsPKcSnqENT+r0sy474oemkAOB9ADjcyA+QXWU/9E3vhgdW9o21q/6oNxJAAtoIFEV6YFb9Unh2/GEJCTp1XNaGG/fNxe+MndOKEkL29Pv9KxOCaeFJjggAwuHweaJso4U5p02159b1bbp9SfcobOyTNhfgxkggrQSmttXBFV+9CFcd8lPo8WYmrMulkzM3XTwlb3TCC9w1cYEsy9PtbrLtA4BgMFhCKV0NAKV2d4be+n+iDDZd/mFnEVDw6i0b5SEBJGB9AmfXvg8/Xf4K/OjIa6G2INmK6IzdekB+03Fjsiqtb2laNPyhLMtPpGVnnTa1fQCgKMrDAHCRTjwcI2ZD52Dv3De7VEZ4vmOMQkOQABJIiEBWLAK3LPk3HFv/Odx4wPnw2ugDElq3/SQObPDBwwp696/MLEpJgLMXhb1e7yQ7dwy0dQAQCoX24px/TinFEhbf+aC19kXVE19vb+5nBCN3Z38BoXVIYAcCNd0NcPfCB2FcZxieGzcdbt3nbE2UCIHOF44p9o3OlxJ/f6BpR/ss5pz/KRAIXGsfjb+vqa0DAEVRMPFvuytPlPid/XrrhsZ+hgk8dv1Uot5IIEUCR9cvhd8ueRyyYxFYUTQazp3xC4hST4rS/rcsm/KGV44vLi/OwnqB28GMAsAesiyv0gw5DQJsGwAoinISADi2TWMq1wIHgPPmt69Z3hablMp6XIMEkIA9CXiZCj//6nk4p/a9uAGdGTkw96ibIJxdrJtBgSxa9+LxJTUYAuyAdL4sy0fpBtpEQbYMADjn3oaGhpWcczzX/p2L5beLu9e+XDeAVf5M/ADhVkgg3QTK+zvgrkUPw54t6+OqcELgskMugwX+KbqrdmCFt/ZvhxdiMbHtyBJCfuD3+9/UHbjBAm0ZACiK8nMAuNtgNrYS/9Tavo13fdE7xlZKo7JIAAloInBA0xq4Y9EjUBzp/lbOg7v9AO6fcqImucMt/vHk3LpLpmTVGLaBDQWrqrqyqqpqKiFEtZP6tgsAth77WwcAhXYCbaSu37RG2s+d35FNCB2+xJeRSqBsJIAETCNAOIeLVv83fsRP4uLl35axqGJXuPTQy4ERA/OiGaj3HFrQdlggo8w0g+2x0SWyLD9oD1W3aGm7ACAcDv+Vc365nSAbqWtbf0w9/rX25gEGmPFvJGiUjQQsQiAv2g+//+yfcLjy9fc0asguhrmzboQOX67hmlLOu148ocRXnSPhj46ttBljTT6fb7ydjgXaKgAQ9f4ZY99QqkNaq+EfEeM3EK19T3mzbe2mbmztazxt3AEJpJ/ALh31cPcnD0JVb8v3lBGZ/j864hr4psS8J/MFXtj839mlo3ySrW4jRjvRVn0CbOW5YDD4PKV0jtEetIv8W5d0r3lxwwBm/NvFYagnEtBAYM6GT+DGZU9DBhMnz74/bt/rdPjPhCM0SE9t6f7l0toHjijGxOP/PQXo9Xq94yoqKhpTI2ruKtsEAIqi7M0YE0V/bKOzka6cH+xTrv+42481/o2kjLKRQPoJiBv+TUv/AyfXLdypMq+P2h9+eeAFaVP053tlb/rhxBzsGbDVA4SQe/1+/xVpc0gSG9vmZqooymsAcFwStjl26qbOwf5T3uqIMU7yHGskGoYEkED8Ub945C8e/e9srC/ww1kzbhixxa+RKDlnkSePLoruVpRhfPKBkYboJ3sQACbKsrxJP5HGSLJFANDQ0HAgY2yRMQjsJVVU+jvq1eZNXRHAiNterkNtkUBSBESSn0j2E0l/Oxu9nkw4c9YvYWNeRVJyjZic7SGh+bNLAlkeW9xSjEDwPZmiO20gEDjf8I00bmALbymK8jYAzNJoqyOWX7Oge8X7oYHJjjAGjUACSGAHAuJY32XLX4YLV78F4rjfUOPagy6Gt6v3sQzBfcs9ax46oghzkgCAMaZSSqfIsiw61Vp2WD4AUBRF9Fz+yLIETVTsg2B/6OpPepLt6WmihrgVEkACWgiIgj6isI8o8DPceGLiDLhzz9O0bGXI2l/tkxOcMz67yhDh9hP6pCzL51hZbcsHAMFg8ANK6WFWhmiGbq390dgPXu3ojHIoMWM/3AMJIAFzCYhSvqKkryjtO9z4snQcXHj41RClkrkKJrAb5azn5RNKMwI5UkYC0x09RTwF4JzvWl1dXWtVQy0dAASDwRmU0nesCs9Mveb+t33Vus7YrmbuiXshASRgDgHRxEc08xFNfYYbbb48mHvUr6Apq8AcxVLYpTJHWv/accXj8LxWHN7jsiyflwJGU5ZYOgBQFOUTADjYFBIW3uTxVf3r/vx1DzY+srCPUDUkkAoB0bZXtO8VbXxHGiohcMlhV8Fn5dZ/zX7+pMx1l++Z5/rvLPEUwOv1TqqoqNjSqcliw7IBQDgcPoxz/oHFeJmuTl3XYM+cNzopIZBt+ua4IRJAAoYRGNcZhrsXPgg13Q0J7fHX3U+CR3Y9JqG56Z7EgQ0+e3TR4IRCPBpICPmH3++/MN0+2dn+lg0A8Nw/QIxxOPaVtrrWCDOvvqcVr1LUCQk4jMCx9Z/DLUv+DVmxSEKWfSBPhSunXRpv9WuXUZIhbfzvSUVjJBvpbBDbQVVVx1ZXV4cMkp+yWEteTeFweLKqqqLmvyX1S5l2kgvvWNa58pnawd2SXIbTTSTA1SjwgV6gOdic0kTstt1KvOO/9qt5cGbt+wnbEMwphdOPugm6vVkJr7HKxHMmZa+9es8c15cK5pzfFQgEfmEVv2zTw5I3WEVR/gUAlk2cMMOJG7ui3Se/2eYjQF2fTWsGby17xBo2gFQaAOLBxmhaODp9bUVfO/xp4UMwta0uYVMHqRfOnnk9rCm058k6USXw+WOL1LEFGa5+hckY687Ozq4uLi7uTNj5Jky0XABQX18fkCRJfEK8JthvyS1E6Y/jXmlb29CPXf4s6aDtlFLbFODRAfCU1wDg4047uMx0HQ9sXAV3fPooFEV6ktr7ln1/CC+MnZbUGqtNrsyE9a/PLhtnuZuNyaA4578MBAJ/MHnbYbeznE9CodAfCSHXWgmS2bo8tqqn9i9f908we1/cLzUCrLcD1PYw0NwikAorUxOCqxxJQFTyu3jVm/DTFa8B5SwpG1+sORhu3u/cpNZYdfJVe+RsOHeX7LFW1c8MvTjnDX19fWMmTJiQWOKHCUpZKgBoa2sr6O3t3SxJUr4Jtltyi6Z+NnjsK80RDhQb/VjSQzsqxWODEGvYcspHKqkCmoWus4nrDFUzf7APbvvsH3BoeHnS+6wurIZzZl4H4hWAEwblpOut2YXZJVkejxPsSdUGQsiP/H7/Y6mu13udpQKAUCh0PSHEUo9I9AY+krxz5nesWNkWxVr/I4Gy2L/HwrXA1RgQSkGqGAtEcsYXt8Uw20adXds3wz0LHwS5tzVpnUWyn0j6E8l/Thq7F3lXPnZUoduTmpfJsmyZBg6WCQA4556GhoZNnHPZSRd9Mra8Vddf/8vFPdXJrMG51iCgtoaA9XfFlSEZWeApG435ANZwjelanLJhAdy47GnwsljSe4tjfuK4nzj258Txt8MLWg6syHBWZJOkozjn0wOBwIIklxky3TIBQDgcPpVz/pwhVtpAaE8kxo98ub05xqHcBuqiitsRYD3toHb8r6CLlFcKtKAMObmIgE+Nwq+W/Qdm1y1M2WpR6EcU/HHqyJN4/btzyqo97j7h/Zwsy3Ot4GPLBAChUOhdQsiRVoCSDh1+s7Drm9fqI7unY2/cUzsBHouAOA743eEpGwXEl6NdOEqwPIHqnma4+5MHYVJnMGVdRYlfUepXlPx18vjxrlm1l0zNdW2SM2MsRggZGwgE6tPtZ0tcaaFQaBIhxNJ9k410VEMP6z/2jRZCOMk0ch+UbSyBmLIW+HeauRDJA56KsQAW7NpmLAl3ST9C+Qp+99m/IC/an7LhormPaPIjmv04fYiEwLdnF+YUZ3ms187QPPi/l2X5V+Ztt/OdLBEAKIpyDwBclW4Y6dr/nHfav1nZGsNf/+lygE77qq1BYP3d35NGM3NAKh2l0w4oxkoEJM7him9egh+teRvEcb9Uh2jrK9r7ija/bhmHyRnL75leMMUt9u7EzrDf7x9FCEk+UURHaGkPAOrr67MkSRI1kot0tMs2opY1DzZf9E57Kbi87LFtHDaMoqynDdSOxh1mSAXlQPNKnGAi2rCVQMlAF9z56SOwX9NazUzu3PM0eGLiDM1ybCYgNu+YgsjYggw3vyObI8vyi+n0W9oDgFAodL7olpROCOnc+6iXm9a1DBDXt81Mpw/02ptHIxBr/H4eQFw2IfFTAeJ0AA77E9izZT3cteghKO/XXtX1rep94BcHXWx/KClYML5AWvXsMcW7prDUKUvekmU5re0d0x4ABIPBxZTS/Zzi0WTseH5d//rfL+1xz3O/ZODYdG5MWQOc7VjxTdQF2JIPQG1qGaotCJy75h246usXwJNkVb+d0avLq4SzZt0AvR73pv48fERByz7l7jwWyBjjkiSN9fv9G9P16UprAKAoiiiI8Hm6jE/nvoMqwLQXGhtVRivSqQfurS8BtaUe2MDO672LCoGiUiAO+xHIiQ3A/y1+HGYFl+mifL/HB2fNuAHWF/h1kWdXIRXZZN2bJ5S6+QloWpMB0xoABIPBByilP7HrxatF77uWdn/z1LoBTPzTAtGCa1l3K6idTUNqJhX5sXWwBf02nErjusJwzycPwJjuHfM7UjXlhgMvhDdGufLB5w7I7jw4NzSzOiuQKkubr6v3+/2jCSGpZ5FqAJC2AKC2ttaXk5MTdmPyX08kxg57qa2TA3Fl4qOG69XyS/lgP8SahnmiRyh4yscA8WLrYMs7U3Tl3LwYfvP5k5AV069/y9PjD4fb9j7DDuabomOel2z8YE7pmLTdjEyxcuhNKKUzKisr30uHGmljrijKHAB4Ph1Gp3vPO7/o+frptf3OrPWZbrjp3p9ziCprAYZ5R0w8PvBUjAEgmA+QbncNtb8o43vdF8/B6es/1FXFb0pq4EdHXANR6uqeODswvXn/vM2zazLdel72cVmWz9P1QktQWDoDgBcA4OQE9XTMtO5IjB3+cnsX51DoGKPQkO8RUFs2AxvoHZYKzSkE8ToAh/UIVPa1wZ8WPgS7t+mbm9Xhy4W5s26Ehuxi6xmdZo3yvLD5gzllo9J2Q0qj/Yyx3oyMjMry8vKdJw8ZqFtaeG/atKnI6/WKwukZBtpmSdF/WNbz1bO1/XtYUjlUShcCrLsF1M7mEWVJxQGg2a7tfD0in3RMOKhxFdzx6aNQGNH3u5gRCpdO/xksqnR7M7yhvXrz/tmbZ9fkuPIpQLraBKclAFAURST+PZCOD3g69+waiLEjXsFf/+n0gRl780gfxJo3jbhVvHVweQ0Qj+vi4BHZmD1BVPK7ZOXr8JOVbwDV4Yjf9vrfP+VEeHC3H5htlq32y8+ATR+cLNpounLMl2X5KLMtT1cA8DEAHGK2sene7/YlPV89twF//afbD4bvn0AewDYdSEYmeMpEPkBaPoqGo7DDBgWDvXD7Z/+EQ8LLDVH348op8LPpl4Fo9YtjeAJ3TCsIzqrKcN1ZWcaYKkmS3+/3j/zoUMeLyPQrsqGhoSYWi62nLit92zUQU494ua2HAynQ0X8oyqIExBMA8SQgkUFzi0EqxHIQibDSe87k9k3xLn7+vja9RcflhbOLYe5RN0GnqyveJo62LJOve2t2uSvrAhBCfur3+/+eOC3tM00PABRFER2QbtWuur0k/OmLni+fXNu/p720Rm1TJcC6WkDtSjyY95RWA8nMTXU7XJcCgdPWfww3fPEMiIx/I4bI9D93xi9gRZFbn2qnRvXhIwub9inzlqe22r6rGGMfVlVVHW6mBaYHAPX19SskSXJVJozKORz0XHNDjJNKM52Le6WPAI/0Qqx5c8IKECptKRUs4fGwhKGlONGnRuE3S5+EEzZ+mqKExJbdus/Z8Ny46YlNxlnfEhhfQFY8e0zpZLchYVtG9ahRoxSzbDc1AAgGgxMppWvMMs4q+7y4YWDtrUu6J1pFH9TDBAKcba0HkHiBL+rLAanMlUnQJjhkyxajeprg7oUPwcSOoKF7vjrmQLhp/x8ZuodjhTPGn/9BUW9NQYbrHolxzq8IBAL3muVbUwOAUCh0PSHkD2YZZ5V9Zr7UsrYtwjEAsIpDTNJDVAQUlQGTGVJ+GdD80mSW2GIuHxwAYLG0vuY4MvQl3Lr4MciLJueTZAGvLayCs2dcDxHJm+xSnL+VwMEVGV/dd3iBG49Lvy/L8pFmXQimBgCKoohnbgeYZZwV9vm8abDhx+934qN/KzjDZB1YZzOo3S3J7SpaB5eOAuLLTm6dlWczFWKNdSAVVaYlAJA4j3fwO2/NfMMpdXuz4MxZv4TNua57ha0rW86h7/2TinyFmR5JV8EWF8YYi3HOK6qrq43JSt3OftMCgM2bN8uU0qDbsv/Perv9y9XtMUz+s/gHzwj1+EAvxFoSzwPYpgORPFtbBzvgu49ziHdIjPRuCWwyc4xAPaTM0oFOuHPRo7Bv81pT9r1q2iXwXgA/7nrA/uGkrOU/3zN3ih6y7CTDzKJApgUA4XD4Us753+zkCK26hnqivSe83iG6vmBml1aYdlzPGETDoi9A4nkA28ykmbkglVbb0erv6ax2NALr2fJjxlMmnmyYFwDs3bIO7lr4MIggwIzx2KRZ8Kc9TjFjK1fskUlA+WRumWzaTco6VF+SZdmUMvmmsVUU5W0AmGUdxsZrct2CzmXvhAb3Nn4n3MGqBGJNdRB//53CELUBRI0Auw7W1wVqW+hb9T1lo017tSEe91/59YvgMaCq3878sbRsAlx0+NWgYrEfXS/XOw/Kr585ymf/SDg5Kn2qqpZWV1cbm6wCAKYEAHV1dYU+n080SXdNVkyMARzwXFM7tvxN7sp32uzv/gJO2jaRD1A2BkS1QLsNHo1saYv8nRuwR5Q9NtiW3OgA3LrkMZgR/MI0ZC2ZBTD3qBtB/BeHvgTG5tPl844tceNrgOP8fv8b+tLcUZopAYCiKGcDwBNGG2Ml+S+u71196+d9u1hJJ9TFfAJ8oAdiLfUpbyz6BIgbJ1AbtQ7emvTH1ej37BZ1DohXvBEzZkzoDMHdCx+E0d3it4Y5I0YoXHTE1bCs1JXF64yHzEB9Y3ZxrDJbMu7CMd6KpHcghNzn9/svT3phkgtMCQBCodAzhJC5Sepm6+knvtH2dbBbnWprI1B57QSYuqUegIZBswtAKpY1SDB36VDtkD2V4wxrfHT8ps/ixX0yY4OmGive+Yt3/ziMI3Dy2Iyvfr2f644Erpdl2fCo0vAAgHNOw+GwCMlLjLtErCU53B/tPe6ljkyg4IA0bmuxtaM2scYNIB6JaxlSkR9oTqEWEaasHe7oo8c/HojOZ+NFGd8bvngWTlv/kSn2fXcTke0vsv5xGEsgUyLhT04t9Rt+szLWjKSlq6o6sbq6ujbphUksMJypoij7AMDnSehk+6m3fd6zdN76fmE3DiQAakcDsJ52bSQIBU/FGCAe6z4JZf3doLYOXWHP65+ga6lj0cDnTwsfhCltI7de1gZ/x9Wb8srhzJk3Qo/XfvkZerMwQ95fpuWGp1dl+c3Yy0J7XCnL8l+N1MfwACAUCt1ACLndSCOsJvugeS3BiMpd19LSan6wij7bZ8Onqpd4f+4pF62DrZcPwGMRiDV+P+lvezu98iTdchkOblgJd3z2DyiI9KSKM+V1A56MeKW/2oJAyjJwYXIEppZ6v/zXjEK3FVh4Q5bl45IjldxsMwKAdwkhppU2TM58/WcvbhgMXvJhJ9789UdrX4lqDKJhfZ7k0dwikAotVliSMYgfdxzh/bs3MElz8EI5g5+sfCP+R/w9HePGA86H10a7qqBpOjB/b0/OeN/Hc4qzcn0ew+9ZaTd2qwKMsZ5AIFBECDGmXaXRxwDr6+uzJEkSzz6t+9xSZ2+f/2770q9aYvj4X2eudhcXa9gA4leyHkMqqQKalaeHKF1kxCv9DYz8S9wb2AVAwzl58Wtf/OoXv/7TNUR3P9HlD4f5BK7dK2fNWROzJ5m/c/p25JxPCwQCC43SwNBoKhQKHUUIecso5a0mdyCq8mnPt/RyQl3XxcpqvrCaPmp7GFhvhy5qEUpBEkfqdE6oS0U51tUCalfzyEsJgXgAkOIQ7/nF+37x3j9dY0XRaDh3xi8gSrGwZzp8UJ1Nl798gutqAvxaluXfGcXb6ADgj4SQa41S3mpy39zcv/qmRT2pf8tZzSDURzcCrK8T1Db92nyTjCwQlfW0/KLWalxSNQ4IhfgrgBTG6es/hOu+eA5Exn+6RmdGDsw96iYIZ9u3MmO62Om4b+zd2UVQlOlxUwRmaHdAQwMARVFEOS7XJG6c+077kuWtsf10vOBRlFMI6JgHsA2JlFcKtKAsLYTE+35VvPdnib2HF08tPCIJMIkhzvTfvPQJOG7T4iRW6T+VEwKXHXIZLPC7riCd/jA1Srx0Stbyiye7qkHQQCQSKaqpqUmtnvgIvA0LABRFKWWMNbml+1+McdhvXksH4WD9w9oaP4S4PDUCsfA62L46XmqS/rfK7AY78Z05i2f8J5PTEO9wKI4BJjhGdzfCPQsfhPGd+j01SXDrHaY9uNsP4P4pJ6a6HNfpSMCfTVa+fkLpbjqKtIOow2RZNqTQhWEBQCgUmk0IeckOdPXQ8f36wXXXLOw0vHKTHrqijPQQ0DMPYJsF8RurKBUsmfdUVG0NAevvSgqiyFcQhYASGTODX8D/LXkMRF3/dI9FFbvCpYdeDsyCRy/TzSYt+zNQ3zm5mBVnWiABxjwAN8qybMhResMCgHA4fAfn/DrzGKV3p4ve61yyrHkQH/+n1w2W3l0kAYogQO9BM3NAKh2lt9idymPdraB2Jl9rP97ToHLcsDqKzn1Xff0CnLvmHVNsGWmThuximDvrRujwYU7vSKzM/PfLJmeuuHBK3mQz90zzXq/Lsny8EToYFgAoiiIeWUw3QmmryWQc4IBnGltVQl1T7thqPrCDPuK9eaxhvSGqSgXlQPOMvfz4QC/EWusBOE/ahngRo4qxQ64rG+iCPy58CPZuWZe0bCMWiEz/Hx1xDXxTUmOEeJSpgYALTwO0+/3+EkJI8h+8ETgbEgBwzr3hcLgTALI0+Nk2Sxcqgxt/9nHnGNsojIqmjUAsXAtcNSCbPd46eDSI0wFGDJG7oDaKpD81JfGiDXD8VcVOxr7Na+GPix6BkoHkXiukpEiCi27b+wx4evzhCc7GaWYS4MAGP5xd4snP9FivJKZBIAghk/1+v+4FMAwJAMLh8H6c8/Sm7hrkiJ2J/dmHHYsXNkT3N3FL3MqmBFJ5f56oqfH37OJXtt6tg0XSX9NGTQ2N4scWRRnj7cb5q9+CK755CaQUniokyiXZea+P2h9+eeAFyS7D+SYS+M3+eWtPqsmcaOKW6d7qx7IsP6y3EoYEAIqiXAEAf9FbWavKmzavZWO/yvEJgFUdZCG9jMoD2GaiqBAoKgXqOUT9AlHHQMugvhyQyv6Xp5AX7YffLX4Mjgh9qUWs7mvX5/vhrJk3QL+Fmy7pbrQNBe5eQr54bGbpXjZUPVWVH5Fl+eJUFw+1zpAAIBwOP805P11vZa0oL9wb7T7utQ7r1GW1IiTU6VsC8aY5DRsMJaJn62DW0wZqR6Nmfb+bqDixIwh3L3wIRvUkn0yoWZFhBPR6MuHMWb+EjXkVRm6DsnUgkCHx+k9PLa/WQZRdRHwpy7LuAY8hAYCiKKI/pzlpyWl23z9W9X1x39e9ujsmzWbh9gYSiClrU36XnpBaonVw+RgQiXdaBo/0Qaxlc0pJf9vvSzNzQSqthhM3LoJfL30KfGpUi2qGrL32oIvh7Wps42EIXB2FFvroq4/PLMiryvW4JkmDMRaLRqN5ehcE0j0AqK+vD0iSNHRTcB0vBCuIOvOt9iVrOrD6nxV8YRcd1NYgsP5uQ9UlHpF1r6F1sBqDWOMGcMAWHQAAIABJREFU3QIVX2YO/HrjR3DKhgWG2p2q8CcmzoA79zwt1eW4zgQClMCqX+2bt/SksZlzASDDhC0ttQWl9KDKyspP9VRK9wAgFAqdSAh5WU8lrSxrv2ebWlROSq2sI+pmLQJ6PVYfySqaUwjidUDSg3OINW8CPtif9NKdLQhEuuAvtW/B5K70V/XbmX5flo6DCw+/GqJU0sVeFKI3AdY9zZ/x/D3Tio70SO54srwzgpzzywOBwH160tU9AAiHw7/mnP+fnkpaVdbK9ljDOW+3W6w5u1VpoV7bCPBoJP7r2owhFQeAZucntZWeFQsPbd8Id9S+BYWx9Ff12xmENl8ezD3qV9CUVZAUI8MmiyOiJlZ1NMwOnQS78XH/UOg45/8KBALn64Q2Lkb3ACAYDM6jlJ6ip5JWlXXXFz2Ln1rbj8f/rOogC+sVU9Yk3EhHixnx1sHlNSAq8SUy9DqlQDmHn9V/CpcElwAB3euXJGLKiHNUQuAnh/8cFpel7zSZqK8gci3if6IDQHOKQDy5cfugnKy8ad/cL04enyneyyR28Tof2jJZlnVNUtE9AFAUZS0AJN71w8ZOO+6V5i/D/e7pdmhjV1lOdbWlHthAjyl6xYvwlIl8gOE/7uKRv3j0n0qlv+8aUhTth7tq/wsHd2w2xb5UN/nr7ifBI7sek+rylNaJapDf3vDFTX9rMqRI2JRKAiByN1w9GOmaFvC9cM+0PFc/7h/iGhjw+/25hJDUqnHtRKiuAYCiKNmMsW5K9a5EYr2PhCj/u9+zTd0cCB4BtJ57LK9RqjX1UzWM5haDVDjM8TaR9Cfa+2qsUji1uwH+vPYN8EeMTXJMlcO2dR/IU+HKaZeCaPVr5BDHPvnA1l/4g+KGv2MVyHiuhvCNyxsOFXjh1SeOLs4P5EiHGekTm8veTZblVXrZoOvVHw6H9+ecf6aXclaWs6YzFj7zv+0pZFhZ2SrUzSwCfHAgfsM1c3hKq4Fk7qSxjUj6a9kc/2WqZZwd/gqu2/QxZKRYLljL3smsDeaUwulH3QTdXv3LJgu/cnGj3/ZYfxgW4vUMLfQnnaORjK12mCse9998UP6yE0ZnuDK7Pxkfcc7PCAQCzySzZri5ugYAiqJcBAC6lyvUy1g95Ty6smfJ/d/0Y/c/PaG6SRbnEBVvyzgzzWpCpS2lgrdLMlM7GoD1tKesR5YahVvXvwvHtaxJWYZZCwepF86eeT2sKdShWiLn8ff2397sxY2fJeZPURo5/sjfVV1tt/MyPu5P5bK/TZblm1JZuLM1ugYA4XD4r+Kogl7KWVnOj95r/fTrZnaglXVE3axNQG3ZDGyg11QliS873jRo29Ca9FfT3w5/XfM6jO9rNdWOVDe7eb9z4cWag1NbLm74g/3f3vCZOCaZQgAnujZK+WUj5mSkpqQ9VsUf988szg/k4+P+JD32kizLJye5ZsjpugYAoVDoQ0LIoXopZ2U50+Y1retXyXgr64i6WZsA624BtbPZdCXFzYfml0L8NUQ86S+xX63bK3pMay38bt07kKMOmm5DKhuKG78IABIenAGPbLnhM/HrPn7DT/1Eg3gCI45lksychFVw2kRKYMVv9sv78sQazO5PxbeMsVVVVVW7pbLW8CcAiqKInwHFeilnVTm9g7HY9OfbCVDAyiFWdZIN9IqX2hU3YLMHIfFHz/EM9BRuaB7O4NpNC+A85QuzNU95v9WF1XDOzOtAvAIYcjAWf3/PvnMsLxU+O5Mfb4ZULLv3jD8jXYcFfC/cOT1vhpeAm2r4p3zNDrFw0O/35xBCdOkprtsTgGAwWEIpbdHbWivKW6BEaq/4uMsVRx2tyN8xOqUhD0Aru/LBXrhn7Ruwt0Wr+u3MPpHsN3fWTRDK3a5gJ1P/d7OP9GpqdzwkV0JAyi8FmufeYqGFXvLKk0cXF/hzKGb3a/0AAoCqqhOrq6trdRClXyEgN50AuG1p16J56yIH6eEAlOFuAmrzZmARc/MAUiV+QFcQ/rTmTSiJajstkOr+qawTx/zEcT9x7A/U2NYbfu+WR/uxSCoiE14jnrLEE/0y9D9tkLASaZyIj/uNgU8pPaGysvI1PaTr9gRAUZSzAOBJPZSyuow5b7Yt2dil4gkAqzvKBvqxrhZQu8zPA0gGjajkd1FoKVy5aSFIFq3qN5Q9D48/Av5cc+iWxL2YebkKNCsPpCIZwPklUXZEz0jXoVUZz//xkPyZ+Lg/mU9aYnMJIb/w+/13JTZ7+Fm6BQBu6gFwwLzmjVEVxujhAJThbgI80guxZutWzMtXI3B77dtwZJs5vQv0vBo+LaiCiybPAVW/B50jq0coSAXlQHOLRp7rwBlFmdLLT8wsLMTH/YY69wFZli/VYwfdAgBFUR4DgCRSbPVQ33wZkZjKDnq+TaRNe8zfHXd0HAHOttYDSD273Cgmk/pa4N7Vr0H1QKdRWxgmtzEjF+bscRa0GVDsZyilRRnf+CN/r/vK+UoMlv/6wLyvMLvfsEv6u4LfkmVZlxrWegYAotH3NFPMT+MmK9sGg+fM79ShikgajcCtLUUg1rRRt9a7ehk2p2kl/GbD++BjuiQb66VWQnKihMJ5U06FL/LMK9Tp4nK+nYfKvhfump4/0wOY3Z/QBap90lpZlidpF6NjN8BgMNhAKR2m2Lge6qZfxjO1/UvvWNaja0em9FuFGqSTAOtsBrXbGgdoRBnfX9e9D6c2rkgnEk17/2HMofCYvJcmGYku3lLOtxJotkXaCSequA7z4o/7ZxUW+rMxu18HnMmIiPj9/ixCiObHhro8AWhqasqNxWLW7v6RDN5h5l63qP2TdzbHHP+kQydcKCYBAnygN16L34ghis+I6n/EmwngydjSFliSgIjGM9uaz4iCN5xBoKsJ7l78D9itM2SEKqbIfLN0Ilw98VhT9hJdFuOFfRJstWyKUiZsIh7333Jw3lfHjcZiPibg3ukWqqpWVVdXa/6g6hIABIPBPSilX6YLhpn7nvxG6+JN3Wx/M/fEvRxOgDGIhkVfAM0BfRyUuDGJX6Si4lyi7WUPU76B3y/+J+QP2ueI3/ZXxYasIpg79QzolYxvHx/vrlhQ7rpyvmMLPB8+cljB+MIsGnD4p9LS5nHOpwcCAfHaXdPQJQAIhUKzCSEvadLEJosPfr5pw0CMjLWJuqimTQjEW/EODqSsrXgUTXKKgOYUJHzTF5tRzuCy5a/CRav/C0SnACRlIzQs7Je8MHf302FddokGKSMv3VLOV955V8WRlztmRibl7ZU5tHtMgUfdNV/KmlSUUVJT6PXKOQQkg1ssOwaiBkM452cGAoGnNYjY8mNBqwCxXlGUSwDg73rIsrKMSDTGD3ihNUqBGv8Tw8ogUDfdCaidTcC6k2+oI25I4teo+JPsmfOiSA/c+ekjcEDjat3tMVvgtROPgddLdcmLGlL1eCOl4oB7y/km4FQCEMvLoK2BbNo3ochDdymkeeMLPEU1BV5SkkkTkIBTEiFACLnW7/f/KZG5w83RJQAIhUK/JYT8RqsyVl9f2zEYOv2tTnz0ZXFHsf4t6Sgk/kuEbHlMu+3vdMv/2/IOfPt/T59hQme1NZiUAvHMc/EYmibfkmKP1g1w16KHoaIv9TbASSlr4OSnKqfCrWOPMG4HUc43rzTeQAlH6gQ8AH1F2bR9TB6NjM+XMnYr9haNL/DmjMqTIMujy60odeXst/IeWZav1qq2LtQVRXkIAC7WqozV18/fPPD19Yu6p1pdT7frJx6li5tpvNlNMkM0yfleUCB+sYjgQfxnS8Cww79ve9z57b+LefHw49s1W6KR76z/do+tQQgBUNsb4tXqEhki6Sz+GDrFErNn174PV381D7xMTWQ7S8/5KrcSzp1yKgymEAQlYhiRPFsS/XzZiUzHOSkSwFcKyYEjhDzj9/vPSG7VjrN1CQBCodCrhJDjtSpj9fUPfdO16IGV2APA6n6K68dUUFtDtqmznyhTmpUPUpE/6cf9Qn5WLAK3LPk3HFv/eaLbWXpeuzcLTpl6JoR9eYboSTNzt3TwMyi4MERphwnFVwpDOnSBLMvTtbpblwBAURTxjeL4s/G/XNj18Vv1Ec3QtToN1ydIgPN4nf1U3q0nuIOp06TCii3v+lMYY7vCcPfCh0D81wmDEQIX73oSLCwcpb854pF/vJxvaqz1Vwgl7ozAzl4p/GBMVo4uNzWLI1dVta66ulpzMrourMLhcIhzLlucmWb1znm7/ZOV7VgDQDNIkwWwvi5Q28MAXFRwtuEQN6QiGWh2fkrKH7P5c7jl839DtsHd71JSLsVF9446CP5Wpf9p3C2vV0QHv8wUNcNl6STw+nElA/5c6njnMcZ6q6qqcrWy1hwAcM5pKBQapNT5z8mOerl1WcsA21srdFxvPgEejWzJCzCxI5wuVhICnpLq+Jn+ZId4xy/e9Yt3/k4aHxWOgUt2OxG4PoeYvkUjaidIhZUpvV5xEl872/LHg/PXz6j2jbOzDYnqHolEsmpqalI/O6zHMcDGxsYKVVUbElXazvP2f7a5Lsahxs42uFp3xkBtCwEb6LENBvFrNJVf/uX9HfCnhQ+ByPZ30gj58uHUPc6EDo+OP/JEBz/xeiWn0EmoXGnLebvlLLty92xX/EjjnI8KBAL1Whyt+QlAMBjck1L6hRYl7LJ2r6eb+wgBTAe2i8OG0NNKtfeHQ5nqO39xrl+c7xfn/J00okSCM3c/DVbk6tdyRHTui3fw87ivg5+Tro1tthxc6V1832GF+r8bsiAszvnegUBA071XcwAQCoVmEkLmW5CPrip1DMR6jny5XfM7F12VQmEpE+ADPfGnAZxZMy8gnu1fklzJCVHJ76JVb8JlK16LV/hz2rhl3JHwTMXuuplFc4u2lvPFAjW6QU2zoECO9NWrxxfvkWY1TNmec350IBB4W8tmmgMARVFOAYB5WpSww9qVbZEN58zv0px1aQdb3aIjj0VAbQmB+K+VhkhE85TXJPUuOi/aD7d99g8QNf2dOF4q3w1+OX6WLqbFO/iJpMosY44P6qIkCkmJQJaH1H1ySqlbXtOeLcvyUymB2rpIcwAQCoUuIIQ8qkUJO6z9KBT5+qoFXVgEyA7OSkZHkRfQrsC26oHJLDVqrqd8TFJFfnbpqId7Fj4IgR5rtBTWm8uanFI4fffTIUI9mkWL4knxR/6SV7MsFGA9ApxD3xdnlLniNS0h5DK/3/83LV7QHAAoivJzALhbixJ2WPvC+sji333e5Yp3S3bwh946su4WUDub9RabtLx4eV9R6CfBMWfDJ3DjsqchgyVZ9TBB+eme1u3xwalTz4DNmdoT9L4t54vNatLtVkP3f292kVqY6Um+PrahWhki/EZZlm/XIllzABAKhW4hhNysRQk7rH1oee8nD6zom2YHXVHH1AjwgV5Q24JpywsQjX08leMSrjx31uRiOHGgDna7/frUDLbBqssnHQ/vlGg71bWlnK8MxJf8UUobIEIVtyPw1FGFTbsUecudDoYQcoff779Bi52aAwBFUcSvf/EUwNHjts87P5q3fvBQRxuJxsXrBMTrBUTNzwuQ8ssSbjgzpTwLXps7HnweAh+++rEjg4B/ynvDnWO0Fd6kmTnxwj5Yztc9H+47DspfM2uUz9jWkNbA+XdZln+qRRXNAUA4HH6Uc36BFiXssPbqBZ0ffhAaPMwOuqKOGglwUS8gDKy/S6OgxJeLxDRP5YSEEv8KfBK8ffYEGJX/v67UTgsCluRXwflT5oCaarEfUT1RBFR5JYk7AWc6gsDPpuZ8ccGu2Xs5wpjhjXhKluWztdipOQAIBoPzKKXiJICjx/nvdnz0VUsUnwA42svfN070EBC9BIBzw60WN6p4a98RhvjAPjZ7DMyq2bEssFOCgJaMHDh56pkg/pvKEAl+8US/FLslprInrrEOgVPGeRfftK8ragG8LsuypiZ8mgMARVFEDYCZ1nG/MZqc/Gb7ok1dsYOMkY5SrUqAR3rjXQW5wa1zPZVjEypGc+X+5XDDwZVD4rJ7EBAjFH40+RRYmp9aaxEt3RKteg2iXskRmC5nfPqX6QUHJrfKlrPfl2X5SC2a6xEAfAYAjs+On/Vy69LWAeb4jodaLianruVqdEtewKCmsttD4hGNZ+Ln/kcY06tz4T9zakAaIYvdzkGAeOcv3v0nPbCcb9LInLpgcjFd/O9ZJY6/J3HOPw0EApp+lGoOAILB4DeU0ilOvZi22XXo8y3Le2Lc8XY63Y8p2yfyAtobgPV1pixiqIWJlPytzPXCO2dPgJKsxM7C2zEIENn+Ius/2SHK+MYf+XuxnG+y7Jw4vzqXLn35uBI3/Fj7SpblPbX4UHMAoCjKagBwfMblwc83rR6IkV20wMa19ifAetpB7WzUNS9gpMf/XkrghdPGwb7+5Oqb2CkI2JRVCKdOPRN6pP8lNiZytcTrJhRWABAs55sILzfMKcmk38yfXaJfzWjrQlsjy7Kme5IeAcA6ANB2UNe6gL/V7MB5TesGVTLeBqqiigYT4JG+LX0E1JjmneJn/+WJw8q59XAZLtqzNKW97BAEDEheOH33ubA2O3Eb4+V8C/0pdUpMCSQusg2BXC9Z+9Gc0uE/VLaxZlhFN8uyPFqLKXoEAJsAYJQWJeywdv9nW+pinI/8otYOxqCO2gmoMYjF8wL6NckS9eilkqohZcyeWAgP/EDbx8vqQcD1E46GV8oS/yETL+crCvt4kntaoMlRuNg2BDwAmxafXqbpxmgHYxljzVVVVSMfHRrGGD0CAAUAEq9dageyO9Fxn6cbg5zQob+pbWoXqq2BAOegdjQA6+1IWchwxX8mFPvgzTMnQI5X++NtqwYBoruf6PKX6Igfl8wvA8Byvokic908Snj487nljr8nAUCHLMtFWhysRwAgCqgn/uxOi7ZpXLvvs00NjJOhz1+lUTfcOr0ERAAgAoFU6gWIKnU0e8cz/eKmL27+IgjQa1gtCFheUAVn7XYSRMnIZdvFqxLBimSmVhtAL4YoxwYEOGtddkaF4ytAMca6q6qqdvzySMJFegQA7QCgvVNHEkqnY+peTzW2Eok6/qJKB1sn7CleBcSPCiaZFyCO/4ljgNuPvx87Ck6apP/HyipBQGdGDpx2+LVQ3zPy0xPqE+V8ZQApsRMQTrie0IbUCRBOupaeUarpxpj67qau7JNlWVNErDkACAaDPZRSTUqYiizFzfZ5uqWLE+6GiypFQrgMRF6ASA6M9CUMw+Mfv0NrWpHwJxL/jBrpDgI4IXDZIZfBx+WTIBYWOcRDjHg531KgeY5/wGiUq10p10UtgSOyLO/46yEJr2sOABRFEV1THJ+Ns+d/mvsoheTOYSXhCJzqEAIiL6CzEcRxwUSGV5wAoP97BC6O+okjf+Lon5EjnUHAg7v9AO6fciIAUyGqrB36/u/xgTgiiQMJJEOAcT7w5Rnlmm6MyeyXrrmMsVhVVZVXy/6av2WCwSCj1OBvKy0W6rR27/80R4GCJtg6qYJibEBAFAwShYOAs2G19QZ2+TahTRT5EcV+RNEfM0Y6goBFFbvCpYdeDkyc2+ccoiFRRmSoJwAUPOVjsMCPGReDg/ZghA98OdcVAQCvqqrSlCGsOQBQFMX4TikWuDj3/k+zChRGzlaygK6ogjUIiNLBseaNwyYHbgsARAj99JyxIMr9mjnMDAIasovhtFk3Qqdvq40jBQAChCjxW1QJNLvATCy4l40JMM77vzyjPMvGJiSkOmMs/QFAMBiMUfqdZ5gJqf7/7V0HmFTV9T/3vpntvbA7b3aBpSiK2EVUbIhYQEEp9mjsmqbRJJrEFE1iyj8xmpjExCT2jpUqXQVRUBQBUaTs7syb2d7LlHfv/7tDCdJ2yntvXjn3+/gQ995zfud37uw7c9+551hvEp4AWM9nZkAcDW4FHg0fFMruVwCiwY9o9JOOYUQQEKEuuO7su+Cz0r1KaQzwCmBvLmheyc5uiXj9Lx1bxFI6CWfdH11eYWwknQaGTPEKwDE5AC829VEA20eVadjHtlXJuppB7Ww+5AmASAKcNKI01uI35eO4FJjUOwj4zfGXwwsjzvoaQtFk6ZBJgPvYQzJzwCWKJtn/+0YKnsSlANDx8WXlTjgyMkUSoEh5tv2D8fjnmzuB4i0A/PUSBwNqFNRWBVioZ8DJw0aOgsXXHQUFmel/u6RXEDB38Fi4d9z1+3ERe0XSuH1AjvaeQCQXSKXVB7w6mZAgnGxbBjiobesuq0ypQI5FyMFrgEY56oQXmpo4gXKj9KEeazLA+3t29glg6oAGZLokmH/H+XB0pXlOK7UOArYWeODKifdAn2v/gkaxRMlWUUg0wSGuBxZVgmgEhAMZ2JcByqFp7eXltv9dbYpCQPX19R2SJNn+fvxJLzXWq5xU48cNGTggA+L6X2cTsK6WuAn686yT4Oqx5rvmplUQ0OPKgivOvRd25FcckBPW0QRqV3PcfO33iz7WCbAS8wKSZtCeC11AfB9eVuaEsu2mKAUsPsG2r5B38kuNX0U4dgO056+M1KwSSX6xb/3h/rgFXTW2Bh6eNTbu+UZP1CIIuPuUm+Dt6oO3ZReVE1lfV0qmicZAsbwArBKYEo92Wuxy8W0fTh9kvshaY5LN0gyoHgBsH22d+nLzZ/2MO6HHtMbb1N7iWG8nsPYAcHbo+/57s3CUXAQLvzsRxCsAM49UgoBnDjsHfn/szEOaF1W+jOtVyUAcxfICRJ+ATKzTNRBXTvh5lotvXjV9UPztJa1LSvrbAQcCgS2c8xHW5TA+5BNeb17THuInxTcbZ9meAc5AbW9IuBNgYbYbltwxCYaWmue9/6F8lUwQ8EnZcLj+7LsgKor9HGTwSAiiDdu02yYiL6CwAmieE3K/tKPNjpLyXWTDiullR9nRtn1s+lKW5cNTsTPlm0eKoqwHANt/M75wTst7wR42PhWyca09GBAPL7XFDzwqqmDHP8QV9qevGw/nj/bGv8gEMxMJAloz82HWpJ9CY/ahb2GJXAm1o1Fz60RioFRUESsghMOZDJRmko8WTSs7+Lsn+9DyqSzLx6ZijhYBwAcAYN6Xmamws9faqxd1LN3UGo6/cblGelGMuRjY2fq3YcASvwdCfceEI+CnFx5tLoPiRBNPEKASArecdSd8WH7YgFLFt38RSOkxRHdFqbRqvyZLeuhCmeZjwJtNV791cek48yHTFhHnfLXX6z0lFakpBwB+v38FIeSMVEBYYe133+1Y9J4SPtcKWBGjDgwwBmqbknTS2ukjKuCVm88EycJtMwYKAh4ZMw0eP+L8AcnX/Pj/ABoJlUAqFXkBtm9UOiDfTptweJH07vPnlZzuALuXy7J8dip2phwA+Hy+eZTSC1IBYYW1v/24a9FLW/oxALCCszTGyMN9O4/81UhSkisLsmH59ydBWZ71G5QdLAhY5j0G7jj1VhCtfgcasdyJ7taBpqX+81g74XKg+ba/pJQ6VzaScHyZa8Xj5xSfaSOTDmbKPFmWJ6di58Cf1gGkBwKBFzjnl6UCwgprn/qid9mfP+lJKdqygp2I8esMxN5VdzYdspzvoThzSxTeuO1sGDvUPj3t9w0CfLllcNmkn0CXO46CoKL+f+CrpF6hJLs3aXYBSCUezAtIlkCLrTvHm7nsD+MLnPC7+nlZlq9MxT0pBwCKovwTAG5KBYQV1q7w9a6+c2WP7d8rWcEXhmBkauxuP+sfuJzvofD8eupxcMvpA78TN8QmDZXsDgLC1A1XTfwRfFEU303gVIv/JGsCcWfuzAtwZSQrAtdZhIHLR2Yv/+HxeV9vPGER7InAZIw9VlVVdWsia/adm3IA4Pf7/48QclcqIKywdmt79POZC9uOsAJWxJgaAzwkyvkqwNVoSoKmHVMNj19zakoyzLxYBAEvLt4Ir9XEaaMahWjD1oRqJmhpP6EUpJIqIFmYF6Alr2aT9Z1jst/75qg829/YIoT83uPx/CgV/lMOAAKBwH2c8/tTAWGFtWEGreNebCgGauEsLisQnU6MnAPrbE6pPO1u+CMHFcCi750LeZmudFqkm+5QlMO9y/zw/Mb43+XHGiT1duiGKV7BUqHIC7DPK5l47XbKvAfH5a85b0iWE2q2/FSW5V+n4teUAwBFUb4HAH9OBYRV1p74YnOAAfdYBS/ijJ8BkeAXS/QL98W/6CAzczJcsYf/4RX2bJGxoyMMN86phY1N8XMlTlWiTXUpc6uVAJqdD1KxDECxXoBWnJpFzuNn5206flD2kWbBoxcOzvl3vF7vX1ORn3IAEAgEvsE5fzIVEFZZO3520ye9UUip8IJVbHUSTlGPnrUpmh1N//OqU+DS4wbbksKF2zrhuwvroTM0cLfDPQQwFqv6l+wtCr2IJK5MkMq8IP7GYR8G5kwp8sm57viSUqxt9jWyLD+TiglaBAAXcs7npgLCKmsvntO6zNejOiG71CouSQ1nkuV8D6X0xtNGwm8vOT41XCZcrXIOv1vVAH9d0wg8QXxqcz2w/u4EVxkzfWdegBdIljVKMxvDiqW1RNfOKmeUgBOyPS+QZXlBKt7SIgAYyzkX1QBtP+5a2bFgmS88cKUT2zNhfQNFGd/Ykb+G1ehOHFIKb94+ATIkex0rN/dG4db5dbCyPvGHOOtqBrWjyfQbRsovA1po+xbypveDBgCVjy8rlzWQYwURJ8qy/FEqQFMOAILBYA1jTMOuHqmYo+/a/2zqXfzXz3om6qsFpevNQCrlfA+GrTQ3E5Z9fxLIhfbqSLdG6YGb59ZBsCfxIkgi4U8k/lll0Ky82GkA5gVYxWP748yi5LNVM8ts35tml+VDZVmuTcVbKQcAjY2NedFoNLWm3qlYYODaT5rCa69f2nGigSpRlZYMiHK+7UHNM9EpIfDyzWfCmSMrtESbdln/WtcM978bgChL9NAfgPd3Q7TFl3QBpXQZL+oExOp6/ATkAAAgAElEQVQFuDEvIF0+SEVvZa60ct6UktNSkWGhtbmyLPemgjflAEAoVxRFpANbv87pAEz2haPN42a3b5coF5VdDt3uLBWv4FrNGeDh/lhhHx4Nay773vPHwF0T7ZN03B1m8P1F9fDWluSu7MW++bcFLPfw37MxCAWp2AM0x563ODT/AJhI4HHl0pJ/Tyg5x0SQ9ILSJ8tyyseNWgUA4hjCnmnP+7uvlXP+pa9brVvbGO5Y1RBVNzdHs4IhtTTK+UjO+TAK1AkJKHptbM3lirrzsdazPPFvsgOBmXiEB56//gyIowT+QKJM8fMvWvrhhjm1sLUtuU59VnnnHw/ZooeA6CVgG+fGY7TF58wckb343hPybP+aljFWW1VVNTRVd2kSAPj9/vcJIY4uk8tY7Jy0jhGyZWNLNLimIdq9pilMtrRF8zojTFY5HEYYk7GQUKpbNoH1sXK+im4Z6INLcmHpnZOgKNse8d6rm9vhB0t80BthCZC8a2qK3RITV2jMCpqZG+sqCFQyRiFqSYmB+07Mf/eS4VlO6AS4SpbllF91aBIA+Hy+2ZTSS1PynL0X93POt3b2qVvXtaktq4Oh0PqWqGt7Z6SoNyINwVcK2jtfq3K+B0OW4aKw4DsT4WhvsfbgDZYYUTn87B0Fnvi0JSnNO7kOxH3Pn2blAi2qgNh9QnEqw0XAIf4W/2S7Tmpi/9jrv8X/3zk/Nmfn5L3+7CNj35/H/s12HgLF1sc/iOTemReQYfu3nPGTYtKZ/zmncMOxZRlHmRSelrBelmV5VqoCNQkAAoHAI6IqUapgHLo+9krB363WrcFXCqlvAVHOd3cHv9SlHVTCQzNPgmtOHqajBmNE+7sicNPcWlgXTCKXSI3GXq0kWt7XVVad/nv3OyOBXUEFAz5AQEEIST9mY7aEdbUwxt+dXtqSm+FyQp3nP8uyfGeqztIkAPD7/T8ihPw2VTC4/n8MiFcKlNL6KOdf4iuFOHeGaDYjEv1CSTzM4lQhpl1xUg385bKxCaww59QVtV1w2/w6aOtPoKqfMIWpwLpagfW0JlU9MfZuvXCQOUlBVJZlgBPwr5tV7rWsAQkAJ4T80OPx/CGBJQecqkkAoCjKNQDwVKpgcH3cDMReKfSEYeva5vCeVwrb2tjgMPBJcUux0URx7SzWwY8l+DBLkIPRchEs/M5EyHJb952w+O770AcN8MfVDZDIDT9RNEnUUBB/Ej1G35tmkpENrkEp5y8l6DmcbncGCiWyZtmMMic0ARKuvEqW5edS9akmAUAgEDiLc74sVTC4PjkGxC/0l77sa/rjJ90ZUe6w64mcg9rRAKy7LTnyElhVkOWOJf0NLbVu2Vjxbf9bC+pg2Y74SneIh74IrsQxv2ZVEwkBt3wYALFXxcQEthJO1YGBI0ukJc+c64grgIK9M2RZfjdVGjUJABRFGQIAO1IFg+sTZ2BzWyR813vtDYFeqE58tbVXiDv9sbv94X7dDRHX/J66bjxcMNq6J4yfBLrhxje2gq8nCkQ8fHc/gGPJcQxAVUGUSIZIOPa3eJWi14mKq3wwkMxc3f2GCpzDwIwRmW//+IQCR5yAMsaqq6qqfKl6V5MAgHMu+f3+fkqpPZufp8qyDuu7IxweWNO1Y1FtqBooWPc8OkludhabCaZ0FJ2I6u+efQT8bPLRiSwx1dwn3t8KP37jYwhHE8uA18sIcb+eFjghV0svBlHuvgz87pT8lecOzkr5apwFmA17PJ5sQkjKH2ZNAgBBmM/n20optX5atMm97+jjfuEb0cGvTftyvody+2nDB8Grt5wFEtXs42LYLuuLqHDXK2vhpY/MdUAXu19f7pTaYYa529GKFk4pqS3PlcRptN3HFlkW79BSH5r9RgsEAos5504owZg660lKcPJxf+zZHxEd/Hy6lPM9mEsqC7Jh2Z2ToDzfenfAtzV3wbVPrITPg8mV9E1ym8a3jNBdeQCa/QqKTy/OsiUDhPDgmhllFZRaMEpP3CNvy7J8XuLL9l+h2adPUZR/AcCNWoBCGV9nQBz3/3JN144lDj3uF2yIJD+R7KdHOd+D7TcXJfD6bRNgXI31jqrnfOaD77z4IXT1J97Fz6jPn6t8CJDMlMuZGwUX9ZiYgaJM8sHSaWUnmxiiZtAYY49VVVXdqoVAzQIAv99/DyHkQS1AoYydDIjj/he/6Gv606cOzO7fvQl0Lud7oL0mOsKJB9MDk4+CW8ZaK+lPdO67f+6n8LcVX5j+YyQVlgPNt15wZXpiHQhwbLlr4T8mFGvyrdjs9GlVA0DYqVkAoCjKJQDwqtnJswo+px/3xwKgUO/Ou/2qvt9iRetX8cAnGTlAxTdSyQVTRhbCvyZb63ViQ2cf3PD0+7B6e5MltrkoCSyVYR6AJZxlcpDfPzZvydWHZzviFTTnfKrX631TC5doGQAcAQCbtADlZBl43L/T+6yzGdSuZu2P/EVJV/HAFw/7rFwQRWn2bfQyvDgTFlwxEvIyrHNPfdXWJrjxmVXQ2KX/lUjNPp+YB6AZlU4X9Or5JZuGFkr26cl9CIdyzkd5vV5Njvg0CwA2btyYUVhY2Espts1K5sO457j/sx53VOVFyciwxRpRX1508Av1aGNO7IGfFfuGLzLPdz7wD/5gz3FTmHf5CDi81DpJf39Zthl+NX89qImU9dvNLqEgmt3E7v+nYbgG1WCTnTTwbieVnEPLusvLCwDAbSe7DmJLxOPx5BBColrYqlkAIMAEAoEtnPMRWgBzkozPmyOhu99vb3RiMZ+9/cz7RVc5f2rFZ8QDLSNr58M+M3vnAz+BinOPnj8YLh1ljfirsz8C337hA5i3wZ/cx4VQcFUMBeLKBNbRtPPExeAhegKI3gA4kIFkGSjMgPeXXVJ+SrLrLbbuC1mWR2mFWdMAwO/3v0UImaIVOLvL2VnMp2P7otrIYCcW89njX1HOt7Mp1sUv4UEoUPGg3/UOf+cDP7lt/c1jSuE3Z1sj6W9joB2ue3IlbG/uTpiy3QtEi1uanb/zn5xDtLlO90ZK+4KlWXkglTmuiGXSPsOF+zMw0Zs57/fjCy50AjeEkDc9Hs9UrWxN7jflQbQHAoHfcc5/qBU4u8oRx/0vf9nf+H+fdGdGOS+0q53x2JVoOV9CxTf8nJ0PfPHHnZX0A39vfMdX5sDrM4eDW9L0IxEPBQnPeWHtDrh79lrojyTf+OhAHflEsqXasC2pDn8JG7FrgfCnSz482eW4DhmAB0/NXXFedc6ZDqHiQVmWf6yVrZr+tlMU5SoAeEYrcHaUg8f9//Mq6+0E1h445AOHUOl/D3vx4M/Q/t18SbYLFl05EuR8c79CFGV873n9Y3hq9daUPhqx7PvS6gMGTqyvK1ZsycjhqhgWS8zEgQwkwUD03ellzbkuUpnEWsst4Zxf4fV6X9AKuKYBQDAYHMMYW68VODvJEcf9v1jTsX1pfWjIIbPQ7GT0wWwR5XzbG3a2ld1nEMn1v2/4WTmx99N6DlE37LlpNXDmkF1H4XoqS0F2XWsPfPOplfCpL7WuhyLhz1VRs9/Nh72hqe1BQ7or7tYpFVUCzStOgR1c6lQGMqj62eqZlWOcYj8h5CiPx7NRK3s1DQA45+5AICBeSmZoBdDqcvC4/+se3FnO178n61w8kPYc54sjfZexW+eHp1TAnSdXmHqbLf48ALc+txra+8Kp4RRJf4OGDvxtW+QDNG7Xrv3vAKhFHoLIR8CBDCTKwPFl7vmPn1N0QaLrLDo/5PF48rS6ASA40DQAEAIDgcCnnHPrtk3TcGfgcf/XyRTf+Fl3aywzf89DX0rfsfs5Nfnw9NQa7T8EGu0hxjn8buEG+NOSTZpUQJZKZKA58aWciGuB0YYdhnRbFKc+Ls9IjVhDMU5i4L4T85ZcMtwZBYAA4BNZlo/T0r+aBwA+n+8pSuk1WoK0miw87j+Axxjb+TCRzNExuqogI/bevyjLnJ2UW3pCcPMz78OKLQ2abH+aVwJSUWInHSJgU9sCmugfSIircpjur3sGwoA/txwD0XcvKQvmZhCnHB89JcvytVp6SfMAQFGUOwDgIS1BWkXWrla9sex+lUN8X7WsYpyNcGZIBN6cNQKOqcg2pVUf1bfDN594F5SOXk3widMWlyi5m8T1yFhRpl79uwlKxR6gudaov6CJU1BIygxkSbBu1YxyTb8RpwxKXwHfk2X5ES1VaB4A+P3+8YSQd7UEaQVZm1qi/T9Y1dbk9GI+VvDVH86pgqvHlJgS6r8/aYafvb4GQt2dmuCLHa8Pqkn+5IWxnfkA0RTzDwawRryaEK8ocCAD8TIwXs6Y+8jphZPjnW/1eZzz07xe7yot7dA8AFAUJYcx1umkksA/er9j26K6/qGOz+7XcmfqJGvWkcXw8CTzFZ7pjTC4a7EPXv+iHdTmemD9yRf42UMdIRBruSuKI6UweLgfok0iH0CccekzYrcTPFhEVB927Sn1kfFF74z3us+wp3Vft4oxFuWcF1RXV/dpaa/mAYAA5/P5PqOUHqUlUDPLOu2VpnV9KjjpKMrM7jgotiPLsmDu5SMgy2WuJj9bWkNww5wdIP4WQ22uA9afei8ELY/VRfKmuLqp5xABgAgEcCADAzHAgLWumV6W4XZJeQPNtcPPCSHrPR7PMVrboksA4Pf7/0sIuU5rsGaV98P3Ouct9occUYrSrD4YCFdBphTr8FdTZOw1w4FwvfFlO9y1yAc9EbZnarSpNuWSvOJ9uggAtByanUwcBJSWAYuWdqMs8zFQmS0tm3dxydnmQ6Ybon/Lsnyj1tJ1CQACgcBtnPO/aQ3WrPLWtUQ+vGFx+1iz4kNcAP+9aCicP1w0DDPHiDAO978TgMc/2b8BT7RxB/Bw8id94shfHP0nk/R3SHaYClFRKljVpBHZfqr0CFrM4W1EoTUDN43OnnvbUXmOef8PALfKsvyY1jzqEgDU19cfLUnSp1qDNas88X5m7CstPsZhqFkxOhnXt04sh5+O1/bbcCp8BrsjcNPcWlgbOHCWf+whG0muPW/KSX8DGMZDvbGmQXrkA4giUK7K4alQi2udwUB06bTS2qJM6pjNQikdU1lZuUFr9+oSAHDOqaIorYQQx1yFu25J24L1zdHztXYQykuNgVOqcuHl6cNASuIKXGqaD7z63fpuuG1eHbT0HfxbdDS4bU+lxIQwiKS/ssGxIkt6DtbZHOveqMdwi4JAJqkVoYd9KDN1BnJc5IP3ppednLoky0ho93g8JYQQzbNwdQkABK2KoiwAgPMsQ3GKQJf7Qyu+/16nUzpSpciWMcsrct3w9pUjYVBu+osPiU/uIx82wu/fDwIb4GMcDW5N6tqdKPQjCv7oPnRsHSyVeIHmmOdVje5cooKEGZhak/nWz8cWXJTwQusumCfLsi6vO3QLAAKBwH2c8/uty3liyBmHvpNebuzg3BldqRJjx/jZLkrglenD4GRvrvHK99HYEVLhOwvqYdH2+O72RwNbEn7Pbvg9ejW6Mx+AJd+S+ECOwTyAtG9XcwNgjL9xYdkn1YWSk25d/USW5d/o4RjdAoBgMDiBMbZED9BmlXn5wtaFX7arjjn1MKsfBK5fnOGBW44vTzvEzxr74MY5tVDXGX8hnajyZUIPVtEieWfSn7HXG3l/N0Sb6zXlWHR/FGWBcSADB2Igk/KP3p856AQnsUMIOcvj8azQw2bdAgBREAgARO9Sc9270oPFXTKX+vqX372y6ywdVaDoOBiYPKIQHp8yJI6Z+k55dkMr/GS5H0LRxF7dRZUvgIveCXEMQiWQKmrSdn8+1ta5uzUOpPFPccuHHbJdcfyScKbdGJg8JPPNB8YVXGw3uw5hT0hV1WKtCwDt1qdbACAUKIryDgCc7hRncYC+415oaKGEOqU5helcO6w4ExZcMQLyM9LX5Kc/yuCepX54cZOIfxMfEf/m+LLsY0l/1UAy0/iaQ+QDNIlri/2JG3qQFaI1sGgRjAMZ+BoDjPE3LypdX5Xn0rwgjomZXi7Lsm71DnQNAPx+/y8IIT83MbmaQ7tuSfu89c0RLAqkObMDC8x2UZh3xQgYVZo18GSdZuzoCMONc3bAxqbkH4gR3+dxoZMKBwHNL41rrp6TRJ8AVfQLiPPUYiAsyXQuHEgm/tz6DGRQ+HD1zHJH1VshhPzM4/E8oJf3dA0AFEURdZp1eXehFyGpyv24MbLyxmXtp6UqB9cnzsCj5w+GS0elr6Pcgq2d8L2366EzlEJiHOcQOwEYYNDsApBKvQNNM+znomOg6ByoxYjlNIgGRjiQgb0YuHJU1ht3H5M/1UmkcM7He73elXrZrGsAsHHjxozi4mJxDqrvxWS92ElCLmNMPXl2y5cqgyOSWI5LkmTg2qNL4bcT0vNAVDmH364MwqNrmyCxt/0HMJYxiChfHJKFWKJcxVDDk/4Gco3aFgDW0z7QtLh+7pYPx95acTHljEkMoG/FtNJAYSZ1TIYoY6zb6/WK+/8RvbysawAgQCuKshAAJullgBnl3vt+51sL60JOuqeaVjccW5EDb84aDm5J9+28n51NvVG4dV4drPJp0L1PSGcqRJQvD8onoRSkQTUgquaZbnAG0YYdyRUx2seYWG5DliP6vJjOjWYENChLWrJgask5ZsSmFybO+QKv13uBXvKFXN1/YyqKcicA/ElPI8wmO9ijbr5wTqvobZr+CjRmI0djPMVZEiy66jDw5hvfRe5DpQdumVsHwR4NA3Q1CpHAloOyZPYHoyhhLHoZAI/vFsPBDBW5DSLHAQcyIBj4yQl586aPyHZabtUdsiw/rOcOMCIAGAUA8WU16WmpwbInvtHyTms/c0SvaoOp3aOOEoBnp9XAWUOMzxh/7OMm+NV7QYgOVNYvQXJEQp2oBHigIRWUAy0oS1Ci8dNZdxuo7cGUFMcaGg3C1hopkWiTxZxD3ZqZJUUuSXJUiUjG2OFVVVUHPw7UwL+6BwACo8/n204pddSn+YUtffN//3G3rsc3Gvjf0iLuHlcBd42rMNSG7jCDO96uh7lfdeiil0dDIHoB7DtoVh5IZdW66NRDqNriA9bXlbxoQiBWD8Dg4kbJA8aVejFwqsf9+l/PKJqml3wzymWMbauqqtK92ZEhAYCiKKI18G1mJFovTBFV7Rz7SmsXAUhPZppehplE7tlD8+GZqTUgTgGMGptb+uGGObWwrS25Tn3x4BT36aON2782NdYlT2TFU2Mr/cWD96BzmMgHEK2Dk3894ioXjY3SWOMgJQJwsSYMMFDfvLhkXVWudKIm8iwihHP+qNfr/bbecA359en3+y8ihLyptzFmk//td9reWhWIYjKgxo6pKsiINfkR7/+NGrM3t8EPFvuhL5rau+2B8PJw38536LsHobGMf5H5b7URs6WpNr6iRgcwziqvPKzmFyvhLXTRFcumlzquyRohZIrH45mrt68MCQB2lQVuBoBsvQ0yk3xfj/rZxXNaxXVATAbUyDEi019k/IvMfyNGROVw3woFnlzfYoQ64KHenQ/NXcPqVfFYVzOoHcm1DhZtjWM9DnA4loGfnpgz59LhuVMcRkAfAJTJstyrt92GBADCiEAg8Cbn3HHfhs97s3lpUx+foLcjnSL/dxO88I2jjal+5++KwE1za2FdUPfP4R738f4eiDbXxf5tl0x4takOWKgn8S1K6K48AMN+TSWOEVfoxgDhsOWDmSWyS5Kc9h7oDVmWDcl5MOyT5ff7ryeE/Fu33WJSwW/7QovuWdl5rknhWQrWjCOK4S/nGZMIt7y2C26fXwdt/SlU9UuC3d0d9mhWLkil1QDEsI9oEmjjXJJC62BxAiBOAnA4j4GLh2a/+ouT8y51muWEkG96PJ4njLDbsN8uiqKUMcaClFLjXtwaweDAOsInvdwkKgMeNfBUnHEwBo4oy4K5l48AUe9fzyFu9T30QQP86YMG0PiGX1ywReY8a28AV4VI+rPPR2Xvk424iNg1SSosB5pv/quPidiEc+NggJHOFZcUt+RnSY6qCS0qyQJARVVVlSHvHA0LAITL/X7/CkKI4+7GP/JJ95tPfNHnpBaWcXzC458iOvstuHIEDCvSNxFOfNsX3/rFt/90DREAiKx/4tbX1nTYp3Y0AutK7Pda7CSkbHA64KLONDIwupi+/vSkUkOOwdNo5oFU69r9b1+FhgYAiqLcAQAPmYxw3eGEw2rTKa+3qJyTSt2V2VDBv6cMgQtHFOpq2ScNvXDjnFoQ7/1x6MRArHVwLYjbAXEPzAOImyrbTGQQeeui0vXePHqCbWyK35DvybL8SPzTU5tpaADg8/mqAKCOUiNvb6dGkFar73yv8/UV/pATI9qUKLzthHL42emelGQMtFhk+ItMf5Hxj0NfBkRdAFXUB0igdbCoCCgqA+JwBgOVWdL8eVNLHFdEje0c1YMHD9amrWYc28XQAEDgURTlPQBwXLvcjhDbdvbrTeUitzsOv+AUABjnzYWXpw8Dl07xorjTL+72izv+OIxjgPV2gtrqj1uh6AkgbkTgcAADjPH/nFuy7Ngyt+NuTnHO3/F6vYbWPDA8APD7/d8mhPzFAVt5PxOvebvtrY1tWBgoHt8PynXBoisPA/G3HkNU8xNV/UR1PxzGM5BI62CrlUE2nk37aCx0k6VLppWc7cRTYkLItzwej6iaa9gwPABoaGioiEQifgfeBoBAt7rhgreaR1JK7ZfhpeGWFd/4xTd/cQKgxxB1/EU9f1HXH0eaGEigdbBogeySD08TUFRrJAN/P7No4cmV7vOM1GkGXSL73+VyyZWVlY1G4jE8ABDG+f3+JYQQxx3xCNtnLGids61DdVplq4T2tHjnL979az1E5z7RwU908sORfgZijY8a4msd7KoYZsubEen3gnkQ5LnJ8uXTSs6g1EpNLzTjb7Esy4bXi0lXAHADIeRxzaizkCBfZ/TjKfNbjqJAMywE2zCoF4wohP9M0b78a7AnArfMrYMPlSQq0hlmvfMUsZ52EK8DBhpSUQXQvJKBpuHPLczAH8fnzT/bm+245D/hMiOL/+y9RdISALS0tBSEQiHRMNyRqb3T57fN3d4ZnWzhz6ou0MU9f3HfX9z713Ks8nXDrfPqoKk3qqVYlKURA2qLH1hf5yGl0ex8EH0RcNiTgQI3LFs6rVR8+9f2w28BuhhjPRkZGZWDBg3qNhpuWgIAYaSiKM8CwJVGG2wGffUd6rqL5jUfibkA//OGqPAnKv2Jin9aDXGp79G1TfDblUFQOV7x04pXzeXE0TqYUAlc8mGaq0aBJmCAMf73CUWLT67INPwI3ATWA2Ps6aqqqm+kA0vaAgC/3z+JELIwHUabQecVC9re/KIjitUBdzlD1PgXtf61Gp0hFb73dj0s2Hrob5Za6UM5qTEQT+tgV+UwS7ZFTo0Z+68uzpbeXjSl6FwnZv4L7zLGJlZVVS1Jh6fTFgBwzmkgEBBtz7zpMDzdOpv62IbzXm8aCpTmpRtLuvWL7n6iy59WY2NTP9w4Zwfs6AhrJRLlGMCAKBMsygUfbEjFHqC5RQYgQRUGMhB97tzi90aVuM4yUKeZVNV7PJ6hhJC0XElKWwAgPKAoyoMAcI+ZvGEklluWdby6pjHsuG5Xe3N8TEU2vDlrBGRI2mzFFze1wT1L/dAfTcvnycjtY0tdanMdsP4DJ2rSnEKQSmRb2u1Uo4bkS2+8dmHJVKfaDwC/kWX5J+myX5vfukmib2hoGB6JRLY49eins4/tOOP1llxKQfs7b0n6xMhlRVkSLLpyJFQVpH4hIhTl8JPlfnh2Q6uRJqAurRlgKkRFqWB1/4RNIrnA5RmptUaUly4GGOlccHHJ9kG59Jh0QUinXsYYd7lcwysrK7enC0daA4BdpwCLAGBiughIt96fr+585a3a0Ix04zBav6ju+8zUGjh7aOqVkes6w7FGPp81JtBkxmiDUV/cDPBQD0SbxNvB/YercnisWyIO6zNwSqX7pUfPLJplfUuStuBtWZbTWvQo7QFAIBCYwTl/OWkKLb5Q5dA69sXGFk6Io77a3DWuAu4eV5Gy9xZv74RvL6iHjpBoo43DLgywjiZQu5r3MwfzAOzhYc6h7v3pZSTLTartYVFSVsyQZXl2Uis1WpT2AIBz7vb7/fWU0tSfBhqRYrSY57/se/0P67od0ynwrCH58Oy0Gkilxw/jAL9/PwiPfNgIeMHP6B1rgD7ROri5Dnio92vKRBKgCAJwWJuBW0fnvHzzUbkzrW1F8ug550FZlqsJIWktTpL2AEBQ6PRkQACIjJ/d/H5vlJ+R/JayxkpvvhsWXXUYFGclX++jpS8Kt82rg3frDa+bYQ2SbYLyQK2DxfG/eA2Aw7oMZEnw/qoZ5cc6tRDcLs89KMvyj9PtRbMEAEMYY1udWAVq9wbY1BJ55+q3208BCu50bwq99LslAm/MHA7HVeYkrWJtoBdunlsLge5I0jJwoXUYYH1doLb4vgbYLRIBJX26RFqHGYsiZaD++9yiJceVuSdZ1IKUYYvGP4SQYV6v98CJLilriF+AKQIAAdfn882mlDr6StzVi1pf3dSq2paD307wwrVHJ9/X/fFPmuH+dwIQEef/OBzDgNoeBNbdtsdeqcQLNKfAMfbbydDhRdLsl88rmW4nmxK1hTE2u6qqyhSJ36YJAAKBwJmc8+WJkmmn+V1htfbM11rFCYDtLjtfOqoIHj1/cFLu6okwuGuRD974sj2p9bjI4gyIfIDG7cAjoZghmAdgTX8yznwrZ1SEcl3g9Hc4Z8iy/K4ZvGiaAECQoSjKJwDgyDuhuzfDPzf0vPKPjb2miA612qCjSrNg3hUjQNT7T3RsaQ3BDXN2gPgbh3MZ2Lt1MHFlgigLjMNaDHzrqJwXbxide5m1UGuOdp0sy8drLjVJgaYKAPx+//WEkH8naYtdloVOn920uicKZ9rBoLwMCguvGAnDijMTNh1bDSMAACAASURBVOf1L9rh7sU+ECcAOJCBvVsHu0VjIOc1jrPsJshzk6XvXFp2GgAk/ovAslbvDzxdbX8PRqGpAoAtW7ZkZmdn1zr5SqBw1PbOyPuXzG0/hlJIPlvOJB+ax6cMgckjChNCI97x//KdAPz7k/3vgSckCCfbjgG1VQHW2xFrDSxaBOOwAAOMdL5+YcHngwszTrYAWt0giqt/vb29Q0eOHGma40xTBQCCeUVRRF3kX+nmBYsI/sGqzheX1IcsfVx2y/Hl8IszEruzLbL7RZa/yPbHgQzsx4BoHdy4HUhWHkhFji0dYqmNMa0m87mfjS1wZOv3fRz1Y1mWRf8b0wzTBQC1tbXFkiTVUYd3yWMc2sfNbt4eVflxptktCQAZK+fC7BnDwJVAtZ936rrh9vl1IO7540AGDsYAD/eDuBngGjQUSTI5A1luvmrF1NIxbkly9HENY6wrEokMrqmpMVUms+kCgF2nAA8BwB0m39u6w/u0ObLk2kWt4ymllnpvVp7jgkVXjYSK3PhKGohLfaKin6jshzf8dN9WtlDAuluB5hQB0MQTS21BgDWM6Hl+UuHaw4szbJHPlArlnPM/er3eu1ORocdaUwYAfr+/mnO+jVLq+Gofty9rf3F1Y8QyrwIkQuDl6cPglKrcuParqOEvavmLmv44kIGEGGAMA4CECDN28pSh7mfuP7noamO1mlJbRFXVmurqar/Z0JkyANh1CvAEAFxrNsKMxqNy3nrq7JYdEZWb5urIoTj46XgPfOvE+Lobr2/si3Xxq+8MG00r6kMGkAEdGch2k+XvTis50emvcgXFhJD/ejye63WkO2nRpg0AfD7fYQCwycnlgXd79fO28IorFnScZPZbAecPL4D/XhTfe9lnN7TCj5f5IaxiVb+kP724EBkwIQNMZS3zLy7b5smTTjIhPEMhibK/brf78IqKiq2GKo5TmWkDgF2nAM8CAGaPAsBPPuh8bv6OkGm5qCnKgAVXjISCzEM3+emPMrhnqR9e3PS/0q5x7lWchgwgAxZg4JYjs5+9ZUzeVRaAagTEp2RZNu1JttkDgFGMsY2UYqYPY6znrNdbPuyOwNlG7NpEdGS5KMy9fAQcWZZ1yGXb28Nw09wdsLGpPxHxOBcZQAYswkBltuu1OVMKL8L8LQDx7R8AjqyqqvrSrO4zdQAgSAsEAi9wzi2TBKenoxt72Kfnz22uAE4q9dSTqOyHJ1XDrCOLD7lswdZO+N7b9dAZEp8JHMgAMmA3Bijhm9+9pDQz2y3V2M22JO15VpZlUydBWiEAGK2q6no8Bdi5BV/b3v/yAx92TDdL+vPVY0rgD+dUHfTzoXIOD64Mwt/WNgG+7U/y1wguQwZMzgAjvP/xs4uXnljuvtDkUA2BJ779U0qPkmV5syEKk1Ri+gBA2OXz+Z6mlJo6kkqS/4SXMcb4dUs7X9rQkv6rgUcPyoa3LhsBGdKBt1FjTxRunV8L7/t6ErYTFyADyIB1GJgyNOvJ+0/ON+27bqOZ5Jw/4fV6v2m03kT1WSIAaGhoGKaqqoik4qsskygLFpsf4bxl/OymLRGVjEsX9KIsCd6+ciRUF2QcEMIH/h64ZV4dNPRE0gUR9SIDyIABDJRk0rcWTys9FwAOnQRkABaTqBD3mg+TZbnWJHgOCsMSAYBA7/f7HyWE3G52Qo3CF+zhay+c21SVjnwAsWmenloD59QcuLrnPz5qgl+vDEIUy/oZtR1QDzKQFgYoJ5venVmWmS3B8LQAMKFSQshfPB7Pd00IbT9IlgkAGhsbK6PRqLhLafkOeVptjLk7+l+574OuaQBgaMXEO0+ugB+esn8jlq6wCne+7YO5X3VoZSLKQQaQAbMywEjnk+fkfzBmUKb49o8DYpn/PW63e3hFRUWDFQixTAAgyFQURXRSuscKxBqF8fsr2p9ZHowYlh9x5uA8eO6SYbBvj5/Pm/tjVf22tZum06VRLkA9yIDzGGCMf+vo/GduGJ1zjfOMP6TFv5FlWXS0tcSwVADQ2tpa2Nvbu4VSGl+tWUu4IGWQvRNfa17RGuYXpCxpAAFyvhsWXTkSSrK/fuAwe3Mb/GCxH/qiTG8IKB8ZQAZMwMCRJa7nnjqn8HK8nfU/ZzDGGjMzM0eUl5d3mcBFcUGwVAAgLAoEArdzzh+NyzqHTOqLqNtPm93cBYQerZfJbonA6zOHw/GV/3sDI8r43rdCgafWt+ilFuUiA8iAyRjIc5OlKy4tO44AHLr4h8lwGwDnVlmWHzNAj2YqLBcAcM5dgUDgMwAYpRkLNhBU26muumRu83CgdP+X8xrY95uzvfDNY0r3SPJ1iqp+dfBJQ68G0lEEMoAMWIEBkfS3+OIiUpTjOsIKeI3CyDnfKMvyMYQQS1U6s1wAIBwaDAanMMbeMsq5VtGzqC706g9Wtk+mlGZqifnSUUXw6PmD94hctqMLvrWgDtr6LbXXtaQEZSEDjmOAMWh65YLijSOKXGc5zvgBDCaEXOjxeOZbjRdLBgCC5EAgsJhzfo7VCNcb7+/XdDz1wrbwN7TSc3hpFsy7fATkuCmIW31/XN0Af/6wIfbfOJABZMAZDDDGQr8dX/TG+dWZs5xhcUJWvi3L8nkJrTDJZCsHAKJE8CfYdOLrO0mUoLxuaccLG1qiKXfjysugsQ5/w4szY9/2b5tfBytqLZPfYpKPGMJABqzPwGWHZf73R8cVmL6yXRqYFpXOjjZ7yd+D8WLZAEAYpCjKQwBwRxqcbmqVjLHuC+e2Lm3s5RenAvSfk4fARSMLYV2wF26aWwv+LqzqlwqfuBYZsCIDxw/KeOqfZ+ZfRSk9dK9vKxqXImbO+f95vd4fpCgmbcstHQC0tLQU9PX1fUl1SnxLm1c0UBxhEDj9teYt4Sg/IxlxNx9fBr88Q4YnPm2Bn72jQETFM/9keMQ1yICVGSjPpq/Nn1I8iVKaa2U79MBOCFFcLtcoK13725cHSwcAwphAIHCtaLygh4OtLrMrHPnirNfa+jmQYxKxZaycC09PHQr3LvPDq5vbE1mKc5EBZMAmDGRLZPnyS0pHuSVztR83Eb1Xy7L8rInwJAzF8gEA55wEAoH3AODUhK13wIKGbrZm8tymEgY0rlrd5Tku+PsFg+EnyxX4oqXfAQyhicgAMrAvA5TA2hXTygpyM8hhyM4BGXhXluWkTlfNxKflAwBBZjAYHBONRj/GhMADb62tnZFll83vGMWAew61+SRC4OoxJSAq+3WHsaqfmT6oiAUZMIoBSvjmBVNK+8pypOOM0mkxPWFCyHEej2eTxXDvB9cWAYCwCvsEHHorftwUnnf9oraTqUT/V81nnyXiql9vBB/8Vv9QI35kIFkGOKj1b04eVFudR8cnK8MB634ly/J9drDTNgFAfX19NiFkA6V0mB0co4cN7/nDr373vQ5RO6FQD/koExlABizNQOMTE4vWHV3qtuSddoOY3xIKhY6uqamxxftR2wQAwvl+v/9cQsjbBm0ES6pZWBd58d7326cAAGb1WtKDCBoZ0J4BBqz1n2cWrRxbmXmR9tLtI5FSek5lZeVSu1hkqwBAOMXn8z1NKTWsPa4VN8Ib28LP/fyDjmmUwv86+1jREMSMDCADqTPASOefz8hbdIY3a3rqwmwt4UlZlq+zk4V2DADEO+6NWBvg0Nv01a96nr1/Te8lGATY6eOMtiADCTPQ86ux+XMurMm6LOGVzloQiEQio4cMGdJmJ7NtFwAI5yiKcgkAvGonR+lhy9za/mfvW91xMQDN10M+ykQGkAETM8BY9wOnFLw1eWj2FSZGaQponPOpXq/3TVOA0RCELQMAwU8gEHiBc45R7QCbZakv9NJdK9vPJUCxt7eGHywUhQyYmgFGOn91Wv78Cwdn4u/IgR31nCzLKfdWGViN8TNsGwAoilLGGNtEKS03nlZraVzdEH3t1qVt4ykF5MparkO0yEDCDIiEv4dPLV56ZnXGjIQXO2wBY6wBAEZXVVW12NF02wYAu14FiKSWV+zoOK1t2tCmzr16YfMxlNAqrWWjPGQAGTAJA4w1PDah6IOTKjJTahRmEmuMgHGpLMuvGaEoHTpsHQDsCgKeBIBvpINcq+ms71RXTF3QXAmcHm417IgXGUAGDs0AAah9amLR5tF4zz+urUII+a/H47k+rskWnWT7AGBXx8BPKaVDLeojQ2G39PO157/ZQFUuHW+oYlSGDCADujFACXz++pSS5qoc6XTdlNhIsKqq27Oyso6xcqe/eNxh+wBg1ynA6Yyx5ZRSGg8pTp/THVY3nz+nNdAbgbOdzgXajwxYnQG3RFbPnVKcWZaFtf3j8SVjTCWEnOn1elfGM9/KcxwRAAgHBQKB33LOf2RlZxmJnRGiXPha4+rGEFxqpF7UhQwgA9oxkOemCxdNLR2RKUFc3UC102xpSb+RZfknlrYgTvCOCQA2btyYUVxcvAoAToiTG8dPY4x13bC4Y/anLeFrgVLH7BXHOx4JsAUD1fnSC6+cVzjBLUmDbGGQAUYwxtZ4vd7TCCERA9SlXYWjfqnX19ePIISItsFY+CbOrccYi/7uk77/vvhVzzWUk6w4l+E0ZAAZSBcDDNRTvdJ//3pGibi7np0uGFbTyznvkCTpuMrKyu1Ww54sXkcFAIIkRVGuBIBnkyXMqevergs9f8/K9glAaYVTOUC7NWKAMc4oRCjQDI0kopg9DLCubx+V98p1R2RfizlPiW0LQshlHo/npcRWWXu24wIA4a5AIPAfzvk3re0649Fv7VSXXD63tUKlcJTx2lGjbRjgzHdMecYHnzZHsfmMhk4lDHY8NrH44xPLXZi3kziv/5Jl+ebEl1l7hSMDAEVRchhjaymlR1jbfcaj7wrxjZPfaqnvVvn5xmtHjXZgoEgia96cVlQx/pUWioWntPGom8DKeVPKpNIcMk4bic6RwjnfyBg7qbq6us85Vu+01JEBwK5TgNGqqn5AKc11mtM1sLf12kVtb3zWGr4WAK9WasCno0SMLnEtffrc4gmPb+qZ/bfPevEUIEXvy7nSC69NLjnNTaA6RVGOW84Y66aUjpVl+XPHGe/kAEA4G/MBkt/y4q7s01/2Pfnndb2XEgpFyUvClU5jYOaI7MX3npA3EQBCp7zSsiaksvFO40ALexlA36zh2U//+MQ8UekUE3STIJVzfrnX630xiaW2WOLYE4Dd3vP7/X8lhHzLFt5MgxFftEbnX7moVeZAjkmDelRpQQYeODlv1eSh2acK6JtaIu9cubh1HCYEJupI/tXfzir8eFxF5qxEV+L8PQw8LMvyHU7mw/EBgKgPUFRUtIIQfHeW7AchzMhXU+e2rGvoVWcmKwPXOYeB2RcUbKkpyBy52+JrF7e/+llLBBPX4twCeRlk/pzJhZ6CDPexcS7BafszsNLj8ZztlPv+B9sAjg8ABDE+n090wBP1AbAdbvK/KvoeXNPzzMtfdV8BlOYlLwZX2pkBRnj/xzMHEUogc7ed3dFoHSYEDux1wd2Equyn/nRqvvjWj6/dBqbsgDMYY42MseMGDx6sJCnCNsswANjlykAgcKaqqosppS7beDcNhmxsi7559fzWwUQi+O0kDfybXaWbwpYPZpbv+fa/G+8/P+uZ/Y9NmBB4MP9xwjc/fFrhp2d4My8zu49Nji/COZ/g9XrfMzlOQ+BhALAXzYFA4Fuc878awryNlfRH2bbLF3W8X9cevhJLCNvY0UmYVpErrZo/pST2/n+fETp9dtPaniicloRYWy8pz6YvvXpu4VG52a4jbW2oMcbdIsvyP41RZX4tGADs4yNFUcTmuMn8rjM9wsgzm3ue/tOnvaJegGx6tAjQEAbGVWQs/ttZheIGwH7j87bwiivebjsFEwJ3UcNYw61H57958+icazDLX5Pt+Q9Zlm/TRJJNhGAAsI8jOefuQCCwFADwapIGm7yll6+ePr+1pTPKJmsgDkVYnIEbR+Usvf2Y3AkHM+PqRa2vbmpVHZ8QmC3BwtkXluRU5kinW9zlpoDPOX9HluWJTk/629cZGAAcYHsGg8FB0Wj0Q0rpEFPsXouDEMU2fr+u54UXv+qdToAWW9wchJ8CA4+cVbBmfEXmSQcT0RVWa09/tVlyaoVABqx15rCcV358Yt5lhJDCFKjGpXsOUtgOSZLGejyeJiTl6wxgAHCQHREMBo+KRCIrJUkqwE2jDQO+LnXpZQvbwn1YRlgbQi0oZfHUUl9JFhW3bg46nJoQmOuCec9PKsqqyncf9ITEgi5PK2TR4Y9SeqrH49mUViAmVY4BwCEcoyjK+YyxOZRSyaT+sxwsxljXIxv6X3jq856pAIB9yi3nweQBc2BtH80sL6KUDvR7J3T6q01reyJOSQgkgRtGZb1125icK7BVefL7a9+VopU5IeRCr9e7SDup9pI00AfRXtYmYU0gELidc/5oEktxySEYaOxVV82a3xrsjILj3/c6ZaPkSGz9ezMqjo7H3g3NkXe+saj9FKDgjme+NecwVpkrvfj8pJKawgyKTXy0dyJm/A/AKQYAcWw6RVH+DADfi2MqTkmMgdBr2/qev39t1zjCyajEluJsqzFQk+daMXty8Znx4rZ1QiCBdb8/peCzidWZVwDYOciJ19vazuOc/5/X6/2BtlLtJw0DgDh8yjmnfr//ZUopfluNg69Ep4QZ/+rGpR3vrG+KXE4p5CS6Hudbg4HzqrIWPXha/rnxou0Osx2nv9biJgDeeNeYfZ5I8junKmv2704tPN+F3fv0ctfLHo/nckII00uBXeRiABCnJ7dv356VmZkp3iXh9cA4OUt02lftkXk3LG1nXRGYkuhanG9+Bu46NnfFVYfnxH0CICz6+4aeV/61sXeG+a0bEGF0UJb00rPnFnlLc2hCHAwoGSfszcDynp6e80eOHBlCWgZmAAOAgTnaM6O2traYUvqeJElYkSsB3hKc2vfatr4Xf72m4wQG0pgE1+J0EzPw5MSCz8aUZibq0/5TX2n8uF8lB6oeaGJr/wfNRfmSR88oajyh3DULE4r1cxljbENOTs74kpKSDv202EsyBgAJ+tPv91cTQt4HGx1LJkiBIdOjKtT9ck3n23NrQxdiJUFDKNdXCWP8vZnlHTkumnATm40t4RXXvN1xquUSAjlbf+dxBWuuHJExE68T67u9AKBeVdVTqqur/bprspECDACScGYwGBzDGHsHO3IlQV6CS3pVvu7WZR3rNrSEZgLQ/ASX43SzMMCZ7+PLKw55//9QUK9e1P7qplartAxm22YMz1l874n5FxCAarO4wMY4Wgkhp+Nd/8Q9jAFA4pzFVvj9/lM5529TSnOTFIHLEmCgoTe6+KYlXcG6vsgMyklWAktxqgkYKJLImqUzyg5aAXAgiKJC4JmvtYorgabtK8E48503OGfeAyfnnJEhSXirZSCnavBzUWXU5XJNrKys/EADcY4TgQFACi73+/2TCCFvAUBGCmJwaZwMMMZ4XRefd/Oy1u7mPrjUckfCcdppx2mjS1xLnz63OKUKd2ZNCOQA/tMrM+Y9eFrB2FwXOcaO/jOpTSFK6YWVlZWidwuOJBjAACAJ0vZeoijKdMbYi5jckyKRCSxnjLEtHdE3vvNed6ixN3Ipdo9LgLw0TZ05InvxvSfkHbALYAKQTJUQyABqJ3iyFv52fP7JGRTwwZ+AI1OduqvK3wyv1/tGqrKcvB4DAA287/f7r+ecPx5HiVMNtKGI3QyIQKC+m8391vKuTl9f9FIKkI3smJOBB07OWzV5aHbKmfwbmqPLv7Go7bR0nv4QBp9fPCL73XuPyzo9w+U6wpyM2xeVOAmklF4ry/LT9rXSGMswANCIZ7/f/x1CyCMaiUMxCTAgfiE0h8nC761oD37eEr6ISrQ0geU41QAGZl9QsKWmIHOkFqquXND22uaO6CVayEpEhkThvZuPzPn8+lFZkyRJwk6hiZCn7dzbZFn+h7YinSkNAwAN/a4oyvcB4I8aikRRCTLQE2Ef/uzDrk+X+UJnA5ARCS7H6TowwAjv/3jmIEIJZGohvivMdpz5WovIu9E9IZABC+e76JwHxhV0n+XNvAgAsJ21Fk5MXsb3ZFnGL1rJ8/e1lRgAaETkbjF+v/8eQsiDGotFcQkyoKrq9ic/Dy/9x+ddQ6NRPgEG7kCXoAacHi8DbgpbPphZrsm3/906//ppzyv/2axfhUCR0T+mJHPhb8blDfLm0Qsopa547cV5+jBACLnb4/HgFywN6cUAQEMyd4sKBAI/55z/QgfRKDJxBnrXN0Xeumd1Z0TpjV5IgZYkLgJXpMJARa60av6UkpTf/++Dof+0V5rW9alwSirYvr6WMYmSJd8clbfjhiMyT810SaO1k42SUmTgx7Is4xerFEncdzkGABoTulucoij3A8B9OolHsUkw0B9iax5a3/fJazv6RkUZPz0JEbgkCQbGVWQs/ttZhaneANhP8/rm8PLrFnWknhDIYMcRpa5lPz8pL/+wYreoPIkNqZLws15LCCE/93g84vcpDo0ZwABAY0L3FhcIBH7GOf+ljipQdBIMMMa6Pu9g8371YVffF+3hMwDosCTE4JI4GbhxVM7S24/JTakGwMFUXbGo/dUvkqoQyLoKMqQFtx6Z23nZ4dlnEABNX1HESQ1OG5gB/OY/MEdJz8AAIGnq4luoKMq9APCb+GbjLKMZYIxtm1Mbeufh9b1ZLf1sIgUoMxqD3fU9clbBmvEVmUlXATwUPyIh8OzXWjMZcM9APIqEviwXXXzpkGzf7cdkj8qRyOl4dXcg1tL687tkWf5TWhHYXDkGAAY4OBAI3M05/4MBqlBFCgxEIvyTF7b1f/TEpt78lnB0IuYLpEDmXksXTy31lWTRpPsADITiUAmB4qGfSaSlF9Zk1n13TN7g4iwiTiKwcudApKbx5+JaLyHku16v969phOEI1RgAGORmRVG+CwAPG6QO1aTIQCjKPnp1e9+nT3/en6n0sfEUAO99J8EpB9b20czyIp2/afed+krzp/0qHxeDyEhnthuWTR2a1XDTUdmDi7MkfOgn4bt0LNlV5Efc838sHfqdphMDAAM97vf7b+Cc/5NSSg1Ui6pSZIAQ8tU7/v5V/9rYG93QGj0MAMSDBq+FxcFrjsTWvzej4ug4pqY05bPWyLIfrez0X3NEbv+M4VlHSpyNw89ZSpQavliU96WUXifL8rOGK3eoQgwADHZ8IBCYwTkXGxyPIQ3mXgt1jLGejjB/96kv++vnbO/Law6x4wgn2PntIOTW5LlWzJ5cfKYW3KMMWzPQzzmf5fV6RXM1HAYxgAGAQUTvrUZRlPMA4FW8bpQG8rVX6a/tjKx+9stQyxJ/qKCtn40Bxo7EwkM7iT6vKmvRg6fln6s97SjRLgyIWzmSJF3s8XiW28Umq9iBAUCaPOX3+08jhMwBgKI0QUC1OjDAOQ+2hdjaN7aHgvN29Lu2dapVKsCxTr1dcNexuSuuOjwHTwB02Gs2EdkCAOfLsrzWJvZYygwMANLormAwOIZzvoBzrntN8zSa6WjV4r2mJEmbvmyLbJ5b29++KhBx7+iKlkcZOwIYDLP7ScGTEws+G1OaOcbRmwCNPyADjLFaSql4+G9GitLDAAYA6eF9j1a/3z9YBAGUUmwrmmZfGKVeZDoDQG13FDatbgw1rglGw582R911HdGSCPChHPgwAJpvFB5d9DDSCYR//t6M0sNzXBRPuXQh2dJCP3W73ReUl5cHLG2FxcFjAGACB9bX15dIkvQmAJxmAjgIIb0MNAPAtsY+VdnQEu1Y3xwNf9EeBV+PmtnSz/J7w2oppeAFJpUD5QXpgsoYC1FCFcZZfa6LNnnypK5RRe7wCZUZruOLaGF1oTQYAEZRavFAJl0E21gv53xpVlbWJaWlpZ02NtMSpmEAYBI31dfXZ0uS9BwATDMJJIRhTgZCjDHxrampX+WtgT7W5e+BPqUzGm4JMdYc5rwtpJK2Hk57VCb1q0QKqaoUYeAKM+7inFMOlKpRlbJd11ElAowSyinhUReFqJsQNUNikcIMV6Qwg7OiLMIG57hBLnC7huS6MgcXQF5ZllSqqqpXkiTx+kqTNr/mpBtRaczA821tbdeNHj06rLFcFJcEAxgAJEGaXkvEL+dAIPAQAIiiQTiQAWQAGbANA4SQ31VWVt5LCBGvwHCYgAEMAEzghH0hBAKBb6mq+jClVDIhPISEDCADyEAiDEQ457d5vd5/J7II5+rPAAYA+nOclIZAIHCBqqov4jvUpOjDRcgAMmAOBtoppdMrKyuXmgMOotibAQwATLwfxDVBxpioFSASqnAgA8gAMmAZBkSnTUrpZLzmZ16XYQBgXt/EkDU0NFSoqjobbwiY3FEIDxlABvZmYBkAzJJlWdxqwWFSBjAAMKlj9oa1cePGjOLi4kcB4EYLwEWIyAAy4GAGCCF/raysvJMQEnUwDZYwHQMAS7hpJ0i/3/9tzvlDlFLsRGchvyFUZMAhDIQ557djsp91vI0BgHV8FUMaCATO4py/DABlFoOOcJEBZMCmDIgeGJzzS6uqqt63qYm2NAsDAAu61e/3VxNCRBBwsgXhI2RkABmwFwPvulyuWYMGDQrayyz7W4MBgEV9LPICioqKHiKE3G5RExA2MoAMWJwBzvkfZVm+B9/3W9ORGABY0297UCuKcjUAPAYAORY3BeEjA8iARRhgjHVRSr8py7K4oYTDogxgAGBRx+0NOxgMHhWNRl/CjoI2cCaagAyYnAFCyHrG2Cyv1/uFyaEivAEYwADAJlskGAzmcs7/wjn/pk1MQjOQAWTAfAz8PRQKfb+mpqbffNAQUaIMYACQKGMmn68oylWMsb9jCWGTOwrhIQPWYqBd1CHBI39rOW0gtBgADMSQBX9eX18/UpKkFwDgeAvCR8jIADJgIgY456sppVd4PJ4dJoKFUDRgAAMADUg0jur8wAAACKdJREFUowhxS6CkpOQBVVXvprv6vpsRJ2JCBpABczLAGFMJIb+WZfkBzPI3p49SRYUBQKoMmny9oihnMMaeopQOMTlUhIcMIAMmYYAQ8hUh5JrKysrVJoGEMHRgAAMAHUg1m8iWlpaCvr6+v1JKrzEbNsSDDCADpmPgX5TSOysrK3tMhwwBacoABgCa0mluYYFAYIaqqn+jlJabGymiQwaQAaMZEOV8AeAWr9f7ptG6UV96GMAAID28p02roihlnPNHCSGz0gYCFSMDyIDZGHgqEoncMWTIkDazAUM8+jGAAYB+3JpasqIo0xlj4jRgkKmBIjhkABnQjQFCiAIAN3s8nrm6KUHBpmUAAwDTukZ/YD6fr5RS+jAAXKW/NtSADCADZmKAEPKf/v7+u2pqasQdfxwOZAADAAc6fV+T/X7/JM65KB40DOlABpAB2zPwBSHkFo/Hs8L2lqKBh2QAAwDcIDEG6uvrsyVJ+hkA3AUAbqQFGUAGbMdAiHP+297e3gdHjhwZsp11aFDCDGAAkDBl9l4QDAbHMMb+AQCn2ttStA4ZcBQDyznnt2IDH0f5fEBjMQAYkCLnTeCck2Aw+A1VVX9HKa1wHgNoMTJgGwb8nPO7vV6vKA2OAxn4GgMYAOCGOCgDooBQKBT6JWPs25RSF1KFDCADlmEgTAh5iBDyABb0sYzPDAeKAYDhlFtPYSAQGA0AD3POz7EeekSMDDiLAcbYfAC4o6qq6ktnWY7WJsoABgCJMubg+cFgcApj7A8AMMrBNKDpyIBZGfiMc36X1+tdZFaAiMtcDGAAYC5/mB4N59wVDAZvVlX1F1hS2PTuQoAOYECU8CWE3OfxeP5DCGEOMBlN1IgBDAA0ItJpYnblB9wLAN8FgByn2Y/2IgPpZoAx1k0I+ZPb7f7DoEGDutONB/VbjwEMAKznM1MhbmxsrIxEIvcRQm7C+gGmcg2CsS8D4g7/3wkhv/F4PE32NRMt05sBDAD0Ztgh8oPBYE00Gv2lKCtMKaUOMRvNRAYMY4AxplJKn+Cc/9Lr9dYbphgV2ZYBDABs69r0GBYIBI4EgPtUVZ2FgUB6fIBa7cXArgf/s4yxX2Nmv718m25rMABItwdsql9RFHFT4KeMscsppZJNzUSzkAHdGGCMRSVJeppS+uuKioqtuilCwY5lAAMAx7reGMN9Pt9hlNIfA8CVmCNgDOeoxfIMhAHgSUrpg5WVldstbw0aYFoGMAAwrWvsBczv91cTQr7PGLuRUppnL+vQGmQgdQY45x2U0sdcLtefy8vLA6lLRAnIwKEZwAAAd4ihDNTW1ha73e7bGWPfpZQOMlQ5KkMGTMgAIUQBgD9nZGQ8Vlpa2mlCiAjJpgxgAGBTx5rdrO3bt2dlZGRcSQgRdQSOMTtexIcM6MDAR6LEdltb24ujR48Wx/44kAFDGcAAwFC6UdmBGAgEAmeqqioCgamYMIh7xM4M7Ersm80Ye8Tr9a6ys61om/kZwADA/D5yDEJFUYYAwC2MseuxDbFj3O4IQ8UxP+f8P4yxx6qqqnyOMBqNND0DGACY3kXOA8g5dweDwamccxEMnEMpxX3qvG1geYsZY6Iu/0JK6T89Hs8cQkjU8kahAbZiAH+x2sqd9jOmoaFhuKqqNwLANQDgtZ+FaJHdGGCM1VJKnwKAf8uyXGs3+9Ae+zCAAYB9fGlrSzjnVFGUcwgh1wLAJdiAyNbutpxxojEPpXQ2IeTJysrK5YQQbjkjELDjGMAAwHEut77BTU1N+eFweCal9EpVVc/CxEHr+9SKFoiEPkrpEkLIc4SQ2ZWVlT1WtAMxO5cBDACc63tbWN7Q0FDBGJvBOb+cMXYa5gvYwq2mNUK816eUvgMALwDAbFmWm00LFoEhAwMwgAEAbhHbMODz+aoopTMYY9MAYDyeDNjGtWk1RHzTJ4SIh/5rGRkZs7FKX1rdgco1ZAADAA3JRFHmYUBRlDLO+UWU0mmc80kAkGUedIjEAgz0MsYWUEpfj0Qic4YMGdJmAcwIERlIiAEMABKiCydbkQFFUXIopRNUVb2AMXaBJEk1VrQDMevOwBYAmE8IWRCNRpdXV1f36a4RFSADaWQAA4A0ko+q08OA3+8/nBByAQCczxgTrwpy04MEtaaTAcZYl3ifzzlf4HK55mPL3XR6A3WngwEMANLBOuo0DQOi6JCiKCfvOiGYQCkdBwCZpgGIQLRkoJ9zvooQspQxttTr9a7B4jxa0ouyrMYABgBW8xji1ZWB+vr6bJfLdTLn/LRdtwpOAYAiXZWicL0YaBUPfABYSQhZ2dPT8+HIkSNDeilDuciA1RjAAMBqHkO8hjIgChA1NDSMZoydSggZCwAnqqo6Gm8YGOqGAZXtupP/GQCsBYAPxUPf4/FsxoI8A1KHExzMAAYADnY+mp4cAyKpkHN+LCHkJAA4flc74yMAICM5ibgqQQb6AWAT53w9AHwkSdKavr6+T2tqasT/x4EMIANxMoABQJxE4TRk4FAMcM5dwWDwcMbY0YQQ8edIzvkoxtgwSqkL2UuKgTBjbCuldLN44BNC1ouHvsfj2UIIUZOSiIuQAWRgDwMYAOBmQAZ0ZGBXkuEwADgcAEZxzodTSmsIITWcc9H+2K2jeiuIFu/kd3DOtxNCxJ+thJAvIpHI5qqqKvFvfNBbwYuI0ZIMYABgSbchaDswsKvBkVcEAwBQRQjxcs5Fx0PxR2aMeSmlgwAg24r2MsZ6OOeNkiT5CSF+zrkfAMTfCgDUq6q6vbq6OoDv6a3oXcRsBwYwALCDF9EGWzMgcg4AoHzXnzIAEFUOiwghhYSQAlVVCymlBQBQuKtLoggYROVD8Xc2YyyLUupmjEm7khcl8d8AIP6IoVJKxTdtlTEW+2/GWIRSKgrhxP5wzvsJIeK/ewGgY68/nYSQDs55O+dc1MVvAoDmcDjchO/kbb0t0TgbMPD/8gcSOs6XDBgAAAAASUVORK5CYII="
    });
    /**
     * @ignore
     * @param httpService
     * @param injector
     */
    constructor(httpService, injector) {
        this.httpService = httpService;
        this.injector = injector;
        if (this.injector.get(BROWSER_VALID).indexOf(BROWSER.ALL) < 0) {
            if (this.injector.get(BROWSER_VALID).indexOf(this.browserIdentify()) < 0) {
                document.body.innerHTML = (this.htmlToElement(template, this.browserIdentify()));
                throw new Error("*** Browser not supported for this application ***");
            }
        }
        if (this.injector.get(DISABLE_LOG)) {
            this.disableConsole();
        }
    }
    /**
     * @author l.piciollo
     * inizializzazione della fase di autenticazione del browser e innesco delle funzionlaità aggiuntive
     */
    /**
     * Inizializza le estensioni di prototipo e le funzionalità aggiuntive per il browser.
     * Da invocare all'avvio dell'applicazione (es. tramite APP_INITIALIZER).
     * @returns Observable che emette lo userAgent del browser
     * @example
     *   PlAmbientModeLoaderService.detect().subscribe();
     */
    detect() {
        return new Observable(observer => {
            try {
                this.extendsFunction();
                this.downloadFileOver();
                observer.next(window.navigator.userAgent);
            }
            catch (error) {
                observer.error(error);
            }
            finally {
                observer.complete();
            }
        });
    }
    /*********************************************************************************************************/
    /**
     * @ignore
     * @param html
     * @param browser
     */
    /**
     * Restituisce una stringa HTML con l'icona e il nome del browser.
     * @ignore
     * @param html HTML di base
     * @param browser Nome browser
     * @returns HTML personalizzato
     */
    htmlToElement(html, browser) {
        try {
            return html.replace("#0", browser).replace("#ico", this.mapIcons[browser]);
        }
        catch (e) {
            throw e;
        }
    }
    /*********************************************************************************************************/
    /**@ignore */
    /**
     * Estende i prototipi nativi di Array, String, Object e JSON con metodi custom.
     * Da invocare una sola volta all'avvio tramite detect().
     *
     * @example
     *   // Dopo detect() puoi usare:
     *   [1,2,3].moveDown(0);
     *   'test'.isNullOrEmpty();
     *   JSON.changeValues(obj, 'a', 'b');
     */
    extendsFunction() {
        // console.debug("*** add new extension function ***");
        /**
        * @author l.piciollo
        * estenzione dell'array nativo per l'aggiunta di funzionalita per lo spostamento degli
        * elementi in un array
        * si occupa di spostare un elemento di un array in una posizione precedente
        * @param from : indice dell'array per muovere il contenuto in una posizione precedente
        */
        // tslint:disable-block
        /**
         * Sposta un elemento dell'array in avanti di una posizione.
         * @param from Indice dell'elemento da spostare
         * @example
         *   const arr = [1,2,3];
         *   arr.moveDown(0); // arr = [2,1,3]
         */
        Object.defineProperty(Array.prototype, 'moveDown', {
            value: function (from) {
                if (from >= 0 && from < this.length - 1) {
                    this.splice(from + 1, 0, this.splice(from, 1)[0]);
                }
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /**
        * @author l.piciollo
        * estenzione dell'array nativo per l'aggiunta di funzionalita per lo spostamento degli
        * elementi in un array
        * si occupa di sposrare un elemento da una posizione ad un altra
        * @param from : indica la cella da muovere
        * @param to : indica l'indice della cella destinataria
        */
        // tslint:disable-block
        /**
         * Sposta un elemento da una posizione a un'altra nell'array.
         * @param from Indice di partenza
         * @param to Indice di destinazione
         * @example
         *   const arr = [1,2,3];
         *   arr.moveTo(0,2); // arr = [2,3,1]
         */
        Object.defineProperty(Array.prototype, 'moveTo', {
            value: function (from, to) {
                if (from >= 0 &&
                    from < this.length &&
                    to >= 0 &&
                    to < this.length &&
                    from !== to) {
                    const item = this.splice(from, 1)[0];
                    this.splice(to, 0, item);
                }
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /**
        * @author l.piciollo
        * estenzione dell'array nativo per l'aggiunta di funzionalita per lo spostamento degli
        * elementi in un array
        * si occupa di spostare in avanti di una posizione un elemento dell'array
        * @param from : indice dell'array per muovere il contenuto in una posizione successiva
        */
        // tslint:disable-block
        /**
         * Sposta un elemento dell'array indietro di una posizione.
         * @param from Indice dell'elemento da spostare
         * @example
         *   const arr = [1,2,3];
         *   arr.moveUp(2); // arr = [1,3,2]
         */
        Object.defineProperty(Array.prototype, 'moveUp', {
            value: function (from) {
                if (from > 0 && from < this.length) {
                    const item = this.splice(from, 1)[0];
                    this.splice(from - 1, 0, item);
                }
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /**
        * @author l.piciollo
        * estenzione dell'array nativo per l'aggiunta di funzionalita per lo spostamento degli
        * elementi in un array .
        * si occupa di eliminare un elemento da un array in una determinata posizione
        * @param from : indice dell'array per muovere il contenuto in una posizione precedente
        */
        // tslint:disable-block
        /**
         * Elimina un elemento dall'array in una posizione specifica.
         * @param position Indice da eliminare
         * @example
         *   const arr = [1,2,3];
         *   arr.deleteAt(1); // arr = [1,3]
         */
        Object.defineProperty(Array.prototype, 'deleteAt', {
            value: function (position) {
                if (position >= 0 && position < this.length) {
                    this.splice(position, 1);
                }
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /**
        * @author l.piciollo
        * estenzione dell'array nativo per l'aggiunta di funzionalita per lo spostamento degli
        * elementi in un array
        * si occupa di inserire un elemento in una determinata posizione
        * @param index : indica la cella da muovere
        * @param item : indica l'indice della cella destinataria
        */
        // tslint:disable-block
        /**
         * Inserisce un elemento in una posizione specifica dell'array.
         * @param index Indice di inserimento
         * @param item Elemento da inserire
         * @example
         *   const arr = [1,2,3];
         *   arr.insert(1, 9); // arr = [1,9,2,3]
         */
        Object.defineProperty(Array.prototype, 'insert', {
            value: function (index, item) {
                if (index < 0) {
                    index = 0;
                }
                if (index > this.length) {
                    index = this.length;
                }
                this.splice(index, 0, item);
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /**
        * @author l.piciollo
        * estenzione dell'array nativo per l'aggiunta di funzionalita per lo spostamento degli
        * elementi in un array
        * si occupa di ritornare solo gli elementi che non sono presenti nella lista in input
        * @param items : array di elementi da confrontare
        * @returns ritorna l'array con i soli item che non non presenti in entrambe le liste.
        */
        // tslint:disable-block
        /**
         * Restituisce gli elementi dell'array non presenti nell'array passato come parametro.
         * @param items Array di confronto
         * @returns Array con elementi unici
         * @example
         *   [1,2,3].differences([2,3,4]); // [1]
         */
        Object.defineProperty(Array.prototype, 'differences', {
            value: function (items = []) {
                if (!Array.isArray(items)) {
                    return [...this];
                }
                return this.filter(item => !items.includes(item));
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /**
        * @author l.piciollo
        * estenzione dell'array nativo per l'aggiunta di funzionalita per lo spostamento degli
        * elementi in un array
        * si occupa di verificare se un elemento è presente o meno nell'array
        * @param item : elemento da controllare
        * @returns ritorna il numero di indice array in cui è presente l'elemento
        */
        // tslint:disable-block
        /**
         * Restituisce l'indice dell'elemento nell'array, -1 se non trovato.
         * @param item Elemento da cercare
         * @returns Indice o -1
         * @example
         *   [1,2,3].inArray(2); // 1
         */
        Object.defineProperty(Array.prototype, 'inArray', {
            value: function (item) {
                return this.findIndex(element => element === item);
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /**
        * @author l.piciollo
        * estenzione delle string native per l'aggiunta di nuove funzionalità
        * si occupa di formattare una stringa, aggiungendo dei parametri nelle rispettive posizioni
        * @example "HELLO {0} {1}".format("TO", "ALL")
        * @returns il risultato finale sarà "HELLO TO ALL"
        */
        // tslint:disable-block
        /**
         * Formatta una stringa sostituendo i segnaposto {n} con i parametri.
         * @param params Parametri da inserire
         * @returns Stringa formattata
         * @example
         *   'Ciao {0} {1}'.format('Mario', 'Rossi'); // 'Ciao Mario Rossi'
         */
        Object.defineProperty(String.prototype, 'format', {
            value: function (...params) {
                return this.replace(/\{(\d+)\}/g, (match, index) => {
                    const value = params[Number(index)];
                    return value !== undefined && value !== null ? String(value) : match;
                });
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /**
        * @author l.piciollo
        * estenzione delle string native per l'aggiunta di nuove funzionalità
        * si occupa di controllare se una stringa è nulla o blanck
        * @example "HELLO {0} {1}".format("TO", "ALL") il risultato finale sarà "HELLO TO ALL"
        * @returns ritorna l'esito del controllo true|false
        */
        // tslint:disable-block
        /**
         * Verifica se la stringa è nulla, undefined o vuota.
         * @returns true se vuota/nulla, false altrimenti
         * @example
         *   ''.isNullOrEmpty(); // true
         */
        Object.defineProperty(String.prototype, 'isNullOrEmpty', {
            value: function () {
                return this === undefined || this === null || String(this).trim() === '';
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /**
        * @author l.piciollo
        * estenzione delle string native per l'aggiunta di nuove funzionalità
        * si occupa di inietare la funzionalità mancante in IE o Opera per
        * @returns true|false
        */
        // tslint:disable-block
        /**
         * Polyfill per String.prototype.includes (per IE/Opera).
         * @param searchString Sottostringa da cercare
         * @param position Posizione di partenza
         * @returns true se trovata
         * @example
         *   'test'.includes('es'); // true
         */
        if (!String.prototype.includes) {
            Object.defineProperty(String.prototype, 'includes', {
                value: function (searchString, position = 0) {
                    return String(this).indexOf(searchString, position) !== -1;
                },
                enumerable: false,
                configurable: true,
                writable: true
            });
        }
        /**
        * @author l.piciollo
        * funzione di utilita sulle URL in formato stringa, troca la url in caso non abbia parametri in query string
        * utile per la cache o analisi di statistica per chiamate al percorso
        * @returns string
        */
        /**
         * Trunca la URL prima della query string se non ci sono parametri.
         * @param hasParams Se true non trunca
         * @returns Stringa troncata
         * @example
         *   '/api/data?x=1'.truncateUrlIfNoParams(false); // '/api/data'
         */
        Object.defineProperty(String.prototype, 'truncateUrlIfNoParams', {
            value: function (hasParams) {
                const value = String(this);
                /**
                 * Se hasParams è valorizzato, lascio la URL invariata.
                 */
                if (hasParams) {
                    return value;
                }
                const queryIndex = value.indexOf('?');
                /**
                 * Se non esiste query string, ritorno la stringa originale.
                 */
                if (queryIndex === -1) {
                    return value;
                }
                /**
                 * Se non ci sono parametri da considerare,
                 * taglio la URL prima del punto interrogativo.
                 */
                return value.substring(0, queryIndex);
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /**
        * @author l.piciollo
        * funzione di utilita sulle URL in formato stringa, si occupa di eliminare parte del testo, ad esempio il tag che indica se *  meno una url è storable
        * @returns string
        */
        /**
         * Rimuove tutte le occorrenze di un tag dalla stringa (es. per cache).
         * @param cachableTag Tag da rimuovere
         * @returns Stringa senza tag
         * @example
         *   '/api/data#nocache'.truncateUrlCache('#nocache'); // '/api/data'
         */
        Object.defineProperty(String.prototype, 'truncateUrlCache', {
            value: function (cachableTag) {
                const value = String(this);
                /**
                 * Se il tag non è valido, ritorno la stringa originale.
                 */
                if (!cachableTag || typeof cachableTag !== 'string') {
                    return value;
                }
                /**
                 * Rimuove tutte le occorrenze del tag dalla URL.
                 */
                return value.split(cachableTag).join('');
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /**
         * @author l.piciollo
         * funzionalità utile pe ripetere la stringa per un numero di volte stabilito nel parametro
         * @example "HELLO ".repeat(5) il risultato finale sarà "HELLO HELLO HELLO HELLO HELLO "
         * @returns string
         */
        /**
         * Ripete la stringa per un numero di volte specificato.
         * @param count Numero di ripetizioni
         * @returns Stringa ripetuta
         * @example
         *   'A'.repeat(3); // 'AAA'
         */
        Object.defineProperty(String.prototype, 'repeat', {
            value: function (count) {
                const value = String(this);
                /**
                 * Converte il parametro in numero intero.
                 */
                const length = Math.floor(Number(count));
                /**
                 * Se il valore non è valido, ritorno stringa vuota.
                 */
                if (!Number.isFinite(length) || length <= 0) {
                    return '';
                }
                let result = '';
                for (let i = 0; i < length; i++) {
                    result += value;
                }
                return result;
            },
            enumerable: false,
            configurable: true,
            writable: true
        });
        /********************************************************************************************************* */
        /**
          * @author l.piciollo
          * funzione per cambiare il valore di un json, l'esecuzione avrà impatto su tutte le chiavi dei json anche annidati
          * che presentano il valore da cambiare
          * @param previousValue  : valore da ricercare e sostituire
          * @param nextValue  : valore da sostituire
          */
        /**
         * Sostituisce ricorsivamente tutti i valori uguali a previousValue con nextValue in un oggetto/array JSON.
         * @param json Oggetto/array di partenza
         * @param previousValue Valore da sostituire
         * @param nextValue Nuovo valore
         * @param ignore Chiavi da ignorare
         * @returns Oggetto/array modificato
         * @example
         *   JSON.changeValues(obj, 0, null)
         */
        JSON["changeValues"] = function (json, previousValue, nextValue, ignore = []) {
            const visited = new WeakSet();
            const recursive = (value) => {
                /**
                 * Se il valore corrente è uguale a previousValue,
                 * lo sostituisco direttamente.
                 */
                if (value === previousValue) {
                    return nextValue;
                }
                /**
                 * Se non è un oggetto o è null, non posso scendere oltre.
                 */
                if (value === null || typeof value !== "object") {
                    return value;
                }
                /**
                 * Evita loop infiniti in caso di riferimenti circolari.
                 */
                if (visited.has(value)) {
                    return value;
                }
                visited.add(value);
                /**
                 * Gestione array
                 */
                if (Array.isArray(value)) {
                    for (let i = 0; i < value.length; i++) {
                        value[i] = recursive(value[i]);
                    }
                    return value;
                }
                /**
                 * Gestione oggetti
                 */
                for (const key of Object.keys(value)) {
                    if (ignore.includes(key)) {
                        continue;
                    }
                    value[key] = recursive(value[key]);
                }
                return value;
            };
            return recursive(json);
        };
        /********************************************************************************************************* */
        /**
         * @author l.piciollo
         * funzione per cambiare il valore di un json, l'esecuzione avrà impatto su tutte le chiavi dei json anche annidati
         * che presentano il valore da cambiare
         * @param key  :  chiave da sostituire
         * @param nextValue  : valore da sostituire
         */
        /**
         * Sostituisce ricorsivamente il valore di tutte le chiavi specificate con nextValue in un oggetto/array JSON.
         * @param json Oggetto/array di partenza
         * @param keyToChange Chiave o array di chiavi da sostituire
         * @param nextValue Nuovo valore
         * @param ignore Chiavi da ignorare
         * @returns Oggetto/array modificato
         * @example
         *   JSON.changeValuesByKey(obj, 'id', null)
         */
        JSON["changeValuesByKey"] = function (json, keyToChange, nextValue, ignore = []) {
            const visited = new WeakSet();
            const keysToChange = Array.isArray(keyToChange)
                ? keyToChange
                : [keyToChange];
            const recursive = (current) => {
                if (current === null || typeof current !== "object") {
                    return current;
                }
                if (visited.has(current)) {
                    return current;
                }
                visited.add(current);
                if (Array.isArray(current)) {
                    for (const item of current) {
                        recursive(item);
                    }
                    return current;
                }
                for (const key of Object.keys(current)) {
                    if (ignore.includes(key)) {
                        continue;
                    }
                    if (keysToChange.includes(key)) {
                        current[key] = nextValue;
                        continue;
                    }
                    recursive(current[key]);
                }
                return current;
            };
            return recursive(json);
        };
        /********************************************************************************************************* */
        /**
         * @author l.piciollo
         * funzione per ricercare tutte le chiavi di un oggetto che hanno un determinato valore
         * @param value  : valore da ricercare
         * @returns Observable function
         */
        /**
         * Trova tutte le chiavi specificate in un oggetto/array JSON.
         * @param json Oggetto/array di partenza
         * @param keyFind Chiave o array di chiavi da cercare
         * @param ignore Chiavi da ignorare
         * @param stopOnFirst Se true si ferma al primo match
         * @returns Array di oggetti {key, value, object, path}
         * @example
         *   JSON.findKey(obj, 'id')
         */
        JSON["findKey"] = function (json, keyFind, ignore = [], stopOnFirst = false) {
            const result = [];
            const visited = new WeakSet();
            const keysToFind = Array.isArray(keyFind)
                ? keyFind
                : [keyFind];
            const recursive = (current, path = "") => {
                if (current === null || typeof current !== "object") {
                    return false;
                }
                if (visited.has(current)) {
                    return false;
                }
                visited.add(current);
                if (Array.isArray(current)) {
                    for (let i = 0; i < current.length; i++) {
                        const shouldStop = recursive(current[i], `${path}[${i}]`);
                        if (shouldStop && stopOnFirst) {
                            return true;
                        }
                    }
                    return false;
                }
                for (const key of Object.keys(current)) {
                    if (ignore.includes(key)) {
                        continue;
                    }
                    const currentPath = path ? `${path}.${key}` : key;
                    if (keysToFind.includes(key)) {
                        result.push({
                            key,
                            value: current[key],
                            object: current,
                            path: currentPath
                        });
                        if (stopOnFirst) {
                            return true;
                        }
                    }
                    const shouldStop = recursive(current[key], currentPath);
                    if (shouldStop && stopOnFirst) {
                        return true;
                    }
                }
                return false;
            };
            recursive(json);
            return result;
        };
        /**
         * Trova tutte le occorrenze di un valore in un oggetto/array JSON.
         * @param json Oggetto/array di partenza
         * @param valueFind Valore o array di valori da cercare
         * @param ignore Chiavi da ignorare
         * @param stopOnFirst Se true si ferma al primo match
         * @returns Array di oggetti {key, value, object, path}
         * @example
         *   JSON.findByValue(obj, 0)
         */
        JSON["findByValue"] = function (json, valueFind, ignore = [], stopOnFirst = true) {
            const result = [];
            const visited = new WeakSet();
            const valuesToFind = Array.isArray(valueFind)
                ? valueFind
                : [valueFind];
            const valueMatches = (value) => {
                return valuesToFind.some(v => v === value);
            };
            const recursive = (current, parent = null, key = "", path = "") => {
                if (valueMatches(current)) {
                    result.push({
                        key,
                        value: current,
                        object: parent,
                        path
                    });
                    if (stopOnFirst) {
                        return true;
                    }
                }
                if (current === null || typeof current !== "object") {
                    return false;
                }
                if (visited.has(current)) {
                    return false;
                }
                visited.add(current);
                if (Array.isArray(current)) {
                    for (let i = 0; i < current.length; i++) {
                        const currentPath = `${path}[${i}]`;
                        const shouldStop = recursive(current[i], current, String(i), currentPath);
                        if (shouldStop && stopOnFirst) {
                            return true;
                        }
                    }
                    return false;
                }
                for (const currentKey of Object.keys(current)) {
                    if (ignore.includes(currentKey)) {
                        continue;
                    }
                    const currentPath = path
                        ? `${path}.${currentKey}`
                        : currentKey;
                    const shouldStop = recursive(current[currentKey], current, currentKey, currentPath);
                    if (shouldStop && stopOnFirst) {
                        return true;
                    }
                }
                return false;
            };
            recursive(json);
            return result;
        };
        /**
         * ATTENZIONE da utilizzare con parsimonia, la funzione è molto pesante, in quanto effettua una scansione di tutto il json per trovare il valore richiesto
         * si consiglia di utilizzare la funzione findByKeyAndValue per ricercare il valore in un ramo specifico del json
         * @param json
         * @param keyFind
         * @param valueFind
         * @param ignore
         * @param stopOnFirst
         * @returns ramo di json dove viene trovato il valore
         */
        /**
         * Trova tutte le occorrenze di una coppia chiave/valore in un oggetto/array JSON.
         * @param json Oggetto/array di partenza
         * @param keyFind Chiave da cercare
         * @param valueFind Valore o array di valori da cercare
         * @param ignore Chiavi da ignorare
         * @param stopOnFirst Se true si ferma al primo match
         * @returns Array di oggetti {key, value, object, path}
         * @example
         *   JSON.findByKeyAndValue(obj, 'id', 1)
         */
        JSON["findByKeyAndValue"] = function (json, keyFind, valueFind, ignore = [], stopOnFirst = true) {
            const result = [];
            const visited = new WeakSet();
            const valuesToFind = Array.isArray(valueFind)
                ? valueFind
                : [valueFind];
            const valueMatches = (value) => {
                return valuesToFind.some(v => v === value);
            };
            const recursive = (current, parent = null, key = "", path = "") => {
                if (key === keyFind && valueMatches(current)) {
                    result.push({
                        key,
                        value: current,
                        object: parent,
                        path
                    });
                    if (stopOnFirst) {
                        return true;
                    }
                }
                if (current === null || typeof current !== "object") {
                    return false;
                }
                if (visited.has(current)) {
                    return false;
                }
                visited.add(current);
                if (Array.isArray(current)) {
                    for (let i = 0; i < current.length; i++) {
                        const currentPath = `${path}[${i}]`;
                        const shouldStop = recursive(current[i], current, String(i), currentPath);
                        if (shouldStop && stopOnFirst) {
                            return true;
                        }
                    }
                    return false;
                }
                for (const currentKey of Object.keys(current)) {
                    if (ignore.includes(currentKey)) {
                        continue;
                    }
                    const currentPath = path
                        ? `${path}.${currentKey}`
                        : currentKey;
                    const shouldStop = recursive(current[currentKey], current, currentKey, currentPath);
                    if (shouldStop && stopOnFirst) {
                        return true;
                    }
                }
                return false;
            };
            recursive(json);
            return result;
        };
        /**
          * @l.piciollo
          * scanner per json, ritorna all'osservatore la flatkey con il valore associato.
          * @param obj
          */
        /**
         * Converte un oggetto/array JSON in un array flat di {key, value} con path completo.
         * @param json Oggetto/array di partenza
         * @param ignore Chiavi da ignorare
         * @returns Array flat
         * @example
         *   JSON.json2flat(obj)
         */
        JSON["json2flat"] = function (json, ignore = []) {
            const result = [];
            const visited = new WeakSet();
            const recursive = (current, path = "") => {
                if (current === null || typeof current !== "object") {
                    result.push({
                        key: path,
                        value: current
                    });
                    return;
                }
                if (visited.has(current)) {
                    result.push({
                        key: path,
                        value: current
                    });
                    return;
                }
                visited.add(current);
                if (Array.isArray(current)) {
                    if (current.length === 0) {
                        result.push({
                            key: path,
                            value: []
                        });
                        return;
                    }
                    for (let i = 0; i < current.length; i++) {
                        const currentPath = path
                            ? `${path}[${i}]`
                            : `[${i}]`;
                        recursive(current[i], currentPath);
                    }
                    return;
                }
                const keys = Object.keys(current).filter(key => !ignore.includes(key));
                if (keys.length === 0) {
                    result.push({
                        key: path,
                        value: current
                    });
                    return;
                }
                for (const key of keys) {
                    const currentPath = path
                        ? `${path}.${key}`
                        : key;
                    recursive(current[key], currentPath);
                }
            };
            recursive(json);
            return result;
        };
        /**
         * @author l.piciollo
         * ritorna sottoforma di array key value tutte le chiavi del json
         */
        /**
         * Converte un oggetto/array JSON in un array di {key, value} (solo chiavi dirette).
         * @param json Oggetto/array di partenza
         * @param ignore Chiavi da ignorare
         * @returns Array di chiavi/valori
         * @example
         *   JSON.json2array(obj)
         */
        JSON["json2array"] = function (json, ignore = []) {
            const result = [];
            const visited = new WeakSet();
            const recursive = (current, currentKey = "") => {
                if (current === null || typeof current !== "object") {
                    result.push({
                        key: currentKey,
                        value: current
                    });
                    return;
                }
                if (visited.has(current)) {
                    result.push({
                        key: currentKey,
                        value: current
                    });
                    return;
                }
                visited.add(current);
                if (Array.isArray(current)) {
                    if (current.length === 0) {
                        result.push({
                            key: currentKey,
                            value: []
                        });
                        return;
                    }
                    for (let i = 0; i < current.length; i++) {
                        recursive(current[i], currentKey);
                    }
                    return;
                }
                const keys = Object.keys(current).filter(key => !ignore.includes(key));
                if (keys.length === 0) {
                    result.push({
                        key: currentKey,
                        value: current
                    });
                    return;
                }
                for (const key of keys) {
                    recursive(current[key], key);
                }
            };
            recursive(json);
            return result;
        };
        /**
          * @l.piciollo
          * scanner per json, ritorna all'osservatore la flatkey con il valore associato in formato JSON.
          * @param obj
          */
        /**
         * Converte un oggetto/array JSON in un oggetto flat {path: value}.
         * @param data Oggetto/array di partenza
         * @param ignore Chiavi da ignorare
         * @returns Oggetto flat
         * @example
         *   JSON.json2flatObj(obj)
         */
        JSON["json2flatObj"] = function (data, ignore = []) {
            const result = {};
            const visited = new WeakSet();
            const recursive = (current, path) => {
                /**
                 * Se è un valore primitivo o null, lo salvo.
                 */
                if (current === null || typeof current !== "object") {
                    result[path] = current;
                    return;
                }
                /**
                 * Evita loop infiniti con riferimenti circolari.
                 */
                if (visited.has(current)) {
                    result[path] = current;
                    return;
                }
                visited.add(current);
                /**
                 * Gestione array.
                 */
                if (Array.isArray(current)) {
                    if (current.length === 0) {
                        result[path] = [];
                        return;
                    }
                    for (let i = 0; i < current.length; i++) {
                        recursive(current[i], `${path}[${i}]`);
                    }
                    return;
                }
                /**
                 * Gestione oggetti.
                 */
                const keys = Object.keys(current).filter(key => !ignore.includes(key));
                if (keys.length === 0) {
                    if (path) {
                        result[path] = {};
                    }
                    return;
                }
                for (const key of keys) {
                    const nextPath = path ? `${path}.${key}` : key;
                    recursive(current[key], nextPath);
                }
            };
            recursive(data, "");
            return result;
        };
        /**
         * Elimina ricorsivamente tutte le chiavi specificate (o con valore specificato) da un oggetto/array JSON.
         * @param source Oggetto/array di partenza
         * @param keys Chiave/i da eliminare (null per eliminare solo per valore)
         * @param valueToMatch (opzionale) Valore/i da matchare per eliminazione
         * @returns Oggetto/array modificato
         * @example
         *   JSON.deleteKey(obj, 'id')
         */
        JSON["deleteKey"] = function (source, keys, valueToMatch) {
            const visited = new WeakSet();
            /**
             * Serve per capire se il terzo parametro è stato realmente passato.
             * Così posso distinguere:
             *
             * JSON["deleteKey"](obj, "name")
             * da
             * JSON["deleteKey"](obj, "name", undefined)
             */
            const hasValueFilter = arguments.length >= 3;
            const normalizedKeys = keys === null
                ? null
                : Array.isArray(keys)
                    ? keys
                    : [keys];
            const valueMatches = (value) => {
                if (!hasValueFilter) {
                    return false;
                }
                if (Array.isArray(valueToMatch)) {
                    return valueToMatch.includes(value);
                }
                return value === valueToMatch;
            };
            const recursive = (current) => {
                if (current === null || typeof current !== "object") {
                    return current;
                }
                /**
                 * Evita loop infiniti in caso di riferimenti circolari.
                 */
                if (visited.has(current)) {
                    return current;
                }
                visited.add(current);
                /**
                 * Gestione array.
                 * Non elimino gli elementi dell'array, ma scendo dentro gli oggetti contenuti.
                 */
                if (Array.isArray(current)) {
                    for (const item of current) {
                        recursive(item);
                    }
                    return current;
                }
                /**
                 * Gestione oggetti.
                 */
                for (const key of Object.keys(current)) {
                    const value = current[key];
                    /**
                     * Prima scendo nei figli.
                     */
                    recursive(value);
                    /**
                     * Caso 1:
                     * keys valorizzato.
                     * Elimino solo le chiavi con quel nome.
                     */
                    const keyMatches = normalizedKeys !== null && normalizedKeys.includes(key);
                    /**
                     * Caso 2:
                     * keys === null.
                     * Non controllo il nome della chiave, controllo solo il valore.
                     */
                    const onlyValueMode = normalizedKeys === null;
                    if (!keyMatches && !onlyValueMode) {
                        continue;
                    }
                    /**
                     * Caso classico:
                     * elimino per nome chiave.
                     */
                    if (!hasValueFilter && keyMatches) {
                        delete current[key];
                        continue;
                    }
                    /**
                     * Caso con filtro valore:
                     * elimino solo se il valore corrisponde.
                     */
                    if (hasValueFilter && valueMatches(current[key])) {
                        delete current[key];
                    }
                }
                return current;
            };
            return recursive(source);
        };
        /**
         * Clona profondamente un oggetto usando structuredClone o JSON.parse/stringify.
         * @returns Clona dell'oggetto
         * @example
         *   const b = a.clone();
         */
        Object.prototype.clone = function () {
            /**
             * Primo tentativo:
             * structuredClone è il metodo migliore perché mantiene meglio tipi come:
             * Date, Map, Set, ArrayBuffer, oggetti annidati, ecc.
             */
            if (typeof structuredClone === "function") {
                try {
                    return structuredClone(this);
                }
                catch {
                    /**
                     * Se structuredClone fallisce, faccio fallback sotto.
                     */
                }
            }
            /**
             * Fallback classico.
             * Attenzione: questo metodo perde tipi complessi come Date, Map, Set, funzioni, undefined.
             */
            return JSON.parse(JSON.stringify(this));
        };
        /**
         * Restituisce una copia dell'oggetto con tutti i valori specificati sostituiti da newValue.
         * @param currentValues Valore/i da sostituire
         * @param newValue Nuovo valore
         * @param ignore Chiavi da ignorare
         * @returns Oggetto modificato
         * @example
         *   const b = a.changeValues(0, null)
         */
        Object.prototype.changeValues = function (currentValues, newValue, ignore = []) {
            const valuesToReplace = Array.isArray(currentValues)
                ? currentValues
                : [currentValues];
            const visited = new WeakMap();
            const deepEqual = (a, b) => {
                if (a === b)
                    return true;
                if (a === null || b === null)
                    return false;
                if (typeof a !== "object" || typeof b !== "object")
                    return false;
                if (Array.isArray(a) !== Array.isArray(b))
                    return false;
                if (Array.isArray(a) && Array.isArray(b)) {
                    if (a.length !== b.length)
                        return false;
                    return a.every((item, index) => deepEqual(item, b[index]));
                }
                const keysA = Object.keys(a);
                const keysB = Object.keys(b);
                if (keysA.length !== keysB.length)
                    return false;
                return keysA.every(key => deepEqual(a[key], b[key]));
            };
            const shouldReplace = (value) => {
                return valuesToReplace.some(item => deepEqual(item, value));
            };
            const recursive = (value) => {
                if (shouldReplace(value)) {
                    return newValue;
                }
                if (value === null || typeof value !== "object") {
                    return value;
                }
                if (visited.has(value)) {
                    return visited.get(value);
                }
                if (Array.isArray(value)) {
                    const clonedArray = [];
                    visited.set(value, clonedArray);
                    for (const item of value) {
                        clonedArray.push(recursive(item));
                    }
                    return clonedArray;
                }
                const clonedObject = {};
                visited.set(value, clonedObject);
                for (const key of Object.keys(value)) {
                    if (ignore.includes(key)) {
                        clonedObject[key] = value[key];
                        continue;
                    }
                    clonedObject[key] = recursive(value[key]);
                }
                return clonedObject;
            };
            return recursive(this);
        };
        /**
         * Restituisce una versione Proxy dell'oggetto che intercetta accessi a proprietà non esistenti.
         * @param replaceWith Valore di default per proprietà mancanti
         * @param proxyFactory Factory custom opzionale
         * @param ignore Chiavi da ignorare
         * @returns Proxy dell'oggetto
         * @example
         *   const p = a.PROXY('default')
         */
        Object.prototype.PROXY = function (replaceWith = "", proxyFactory, ignore = []) {
            const visitedClone = new WeakMap();
            const visitedProxy = new WeakMap();
            const hasOwn = (target, prop) => {
                return Object.prototype.hasOwnProperty.call(target, prop);
            };
            const defaultProxyFactory = (object, emptyValue = replaceWith, level = 0) => {
                if (object === null || typeof object !== "object") {
                    return object;
                }
                if (visitedProxy.has(object)) {
                    return visitedProxy.get(object);
                }
                const proxied = new Proxy(object, {
                    get(target, prop, receiver) {
                        /**
                         * Evita problemi con proprietà native tipo:
                         * toString, valueOf, Symbol.toStringTag, ecc.
                         */
                        if (typeof prop === "symbol" || prop in Object.prototype) {
                            return Reflect.get(target, prop, receiver);
                        }
                        if (!hasOwn(target, prop)) {
                            console.error(`IS NOT POSSIBLE TO GET PROPERTY [${String(prop)}]. ` +
                                `THIS IS NOT DEFINED IN [${Object.keys(target).join(" ; ")}]. ` +
                                `Level: ${level}`);
                            if (emptyValue !== null && typeof emptyValue === "object") {
                                return defaultProxyFactory(emptyValue, emptyValue, level + 1);
                            }
                            return emptyValue;
                        }
                        const value = Reflect.get(target, prop, receiver);
                        if (value !== null && typeof value === "object") {
                            return defaultProxyFactory(value, emptyValue, level + 1);
                        }
                        return value;
                    },
                    set(target, prop, value, receiver) {
                        if (!hasOwn(target, prop)) {
                            console.error(`IS NOT POSSIBLE TO SET PROPERTY [${String(prop)}]. ` +
                                `THIS IS NOT DEFINED IN [${Object.keys(target).join(" ; ")}]. ` +
                                `Level: ${level}`);
                            return false;
                        }
                        return Reflect.set(target, prop, value, receiver);
                    }
                });
                visitedProxy.set(object, proxied);
                return proxied;
            };
            const cloneRecursive = (value) => {
                if (value === null || typeof value !== "object") {
                    return value;
                }
                if (visitedClone.has(value)) {
                    return visitedClone.get(value);
                }
                if (Array.isArray(value)) {
                    const clonedArray = [];
                    visitedClone.set(value, clonedArray);
                    for (const item of value) {
                        clonedArray.push(cloneRecursive(item));
                    }
                    return clonedArray;
                }
                const clonedObject = {};
                visitedClone.set(value, clonedObject);
                for (const key of Object.keys(value)) {
                    if (ignore.includes(key)) {
                        clonedObject[key] = value[key];
                        continue;
                    }
                    clonedObject[key] = cloneRecursive(value[key]);
                }
                return clonedObject;
            };
            const cloned = cloneRecursive(this);
            const factory = proxyFactory || defaultProxyFactory;
            return factory(cloned, replaceWith, 0);
        };
        /**
         * Generatore di tutte le disposizioni semplici di k elementi dell'array.
         * @param k Numero di elementi
         * @yields Array di k elementi
         * @example
         *   [...[1,2,3].simpleDisposition(2)] // [[1,2],[1,3],[2,1],[2,3],[3,1],[3,2]]
         */
        Array.prototype.simpleDisposition = function* (k) {
            const source = this;
            if (!Array.isArray(source)) {
                return;
            }
            if (k <= 0 || k > source.length) {
                return;
            }
            const used = new Array(source.length).fill(false);
            const current = [];
            function* recursive() {
                if (current.length === k) {
                    yield [...current];
                    return;
                }
                for (let i = 0; i < source.length; i++) {
                    if (used[i]) {
                        continue;
                    }
                    used[i] = true;
                    current.push(source[i]);
                    yield* recursive();
                    current.pop();
                    used[i] = false;
                }
            }
            yield* recursive();
        };
        /**
         * Generatore di tutte le combinazioni semplici di k elementi dell'array.
         * @param k Numero di elementi
         * @yields Array di k elementi
         * @example
         *   [...[1,2,3].simpleCombine(2)] // [[1,2],[1,3],[2,3]]
         */
        Array.prototype.simpleCombine = function* (k) {
            const source = this;
            if (!Array.isArray(source)) {
                return;
            }
            if (k <= 0 || k > source.length) {
                return;
            }
            const current = [];
            function* recursive(start) {
                if (current.length === k) {
                    yield [...current];
                    return;
                }
                for (let i = start; i < source.length; i++) {
                    current.push(source[i]);
                    yield* recursive(i + 1);
                    current.pop();
                }
            }
            yield* recursive(0);
        };
    }
    /**
     * @author l.piciollo
     * Identifica il brawser in uso
     */
    /**
     * Identifica il browser in uso tramite userAgent.
     * @returns Enum BROWSER
     * @example
     *   const browser = service.browserIdentify();
     */
    browserIdentify() {
        try {
            var test = function (regexp) { return regexp.test(window.navigator.userAgent); };
            switch (true) {
                case test(/edge/i): return BROWSER.EDGE;
                case test(/opr/i) && (!!window.opr || !!window.opera): return BROWSER.OPERA;
                case test(/chrome/i) && !!window.chrome: return BROWSER.CHROME;
                case test(/trident/i): return BROWSER.IE;
                case test(/firefox/i): return BROWSER.FIREFOX;
                case test(/safari/i): return BROWSER.SAFARI;
                default: return BROWSER.OTHER;
            }
        }
        catch (e) {
            throw e;
        }
        ;
    }
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Crea un link e un blob per il download di un file.
     * @ignore
     * @param streamData Dati binari
     * @param nomeFile Nome file
     * @param isTextfile Se true aggiunge BOM per file di testo
     * @returns Promise con [link, blob]
     */
    createLinkBlob(streamData, nomeFile, isTextfile = true) {
        return new Promise((resolve, reject) => {
            try {
                let jsEscape = "\uFEFF"; /**per il formato csv con accenti..*/
                let blob = null;
                isTextfile ? blob = new Blob([jsEscape + streamData]) : blob = new Blob([streamData]);
                let link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);
                link.download = nomeFile;
                resolve([link, blob]);
            }
            catch (error) {
                reject(error);
            }
        });
    }
    /****************************************************************************************** */
    /**@ignore */
    /**
     * Revoca l'URL e rimuove il link dal DOM.
     * @ignore
     * @param link Elemento link
     * @returns Promise<void>
     */
    destroiLinkBlob(link) {
        return new Promise((resolve, reject) => {
            try {
                URL.revokeObjectURL(link.href);
                link.remove();
                resolve(true);
            }
            catch (error) {
                reject(error);
            }
        });
    }
    /****************************************************************************************** */
    /**@ignore */
    /**
     * Simula il click su un link per download (browser non Microsoft).
     * @ignore
     * @param link Elemento link
     * @returns Promise<link>
     */
    noMicro(link) {
        return new Promise((resolve, reject) => {
            try {
                link.click();
                resolve(link);
            }
            catch (error) {
                reject(error);
            }
        });
    }
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Download file per browser Microsoft (msSaveOrOpenBlob).
     * @ignore
     * @param obj Array [link, blob]
     * @param nomeFile Nome file
     * @returns Promise
     */
    micro(obj, nomeFile) {
        return new Promise((resolve, reject) => {
            try {
                if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                    window.navigator.msSaveOrOpenBlob(obj[1], nomeFile);
                    resolve(obj);
                }
            }
            catch (error) {
                reject(error);
            }
        });
    }
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Estrae il nome file dagli header HTTP.
     * @ignore
     * @param headers HttpHeaders
     * @param fileName Nome file opzionale
     * @returns Nome file
     */
    getFileName(headers, fileName) {
        try {
            if (fileName) {
                headers = headers.set("content-disposition", "inline; filename=" + fileName);
            }
            return (headers.get('content-disposition').split(';')[1].split('filename')[1].split('=')[1].trim()).replace(/"/g, '');
        }
        catch (e) {
            throw new Error("content-disposition or filename is required...");
        }
    }
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Verifica se il file è di tipo testo (json/text).
     * @ignore
     * @param headers HttpHeaders
     * @returns true se testo
     */
    isTextfile(headers) {
        let text = (String(headers.get('content-type')).toLowerCase().indexOf("json") > -1 || String(headers.get('content-type')).toLowerCase().indexOf("text") > -1);
        return text;
    }
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Gestisce il download di un file (compatibile con tutti i browser).
     * @ignore
     * @param streamData Dati binari
     * @param contentType Tipo contenuto
     * @param fileNamed Nome file opzionale
     * @returns Promise
     */
    downloadFile(streamData, contentType = CONTENT_TYPE.JSON, fileNamed) {
        return new Promise((resolve, reject) => {
            let headers = new HttpHeaders();
            headers = headers.set('content-type', contentType);
            let fileName = this.getFileName(headers, fileNamed);
            let isTextfile = this.isTextfile(headers);
            this.createLinkBlob(streamData, fileName, isTextfile).then(obj => {
                if (/msie\s|trident\/|edge\//i.test(window.navigator.userAgent)) {
                    this.micro(obj, fileName).then(obj => {
                        this.destroiLinkBlob(obj[0]).then(() => { });
                        resolve("OK");
                    });
                }
                else {
                    this.noMicro(obj[0]).then(link => {
                        this.destroiLinkBlob(link).then(() => {
                            resolve("OK");
                        });
                    });
                }
            }).catch(error => {
                reject(error);
            });
        });
    }
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Collega la funzione di download custom al servizio HTTP.
     * @ignore
     */
    downloadFileOver() {
        try {
            this.httpService.DOWNLOAD = this.downloadFile.bind(this);
        }
        catch (error) {
            throw error;
        }
    }
    /****************************************************************************************** */
    /** @ignore */
    /**
     * Disabilita tutte le funzioni di console.log/info/warn/debug/error.
     * @ignore
     */
    disableConsole() {
        window.console = ((oldCons) => {
            return {
                log: (text) => { },
                info: (text) => { },
                warn: (text) => { },
                debug: (text) => { },
                error: (text) => { }
            };
        })(window.console);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlAmbientModeLoaderService, deps: [{ token: PlHttpService }, { token: i0.Injector }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlAmbientModeLoaderService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlAmbientModeLoaderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: PlHttpService }, { type: i0.Injector }] });

/**
 * Classe di servizio per il componente Alert.
 * Al momento dell'abilitazione sovrascrive window.alert().
 * Alla chiamata di alert(), viene visualizzato un alert custom tramite AlertComponent.
 */
class AlertService {
    componentFactoryResolver;
    appRef;
    injector;
    oldAlert = typeof window !== 'undefined'
        ? window.alert.bind(window)
        : (() => undefined);
    componentRef = null;
    alertEnabled = false;
    constructor(componentFactoryResolver, appRef, injector) {
        this.componentFactoryResolver = componentFactoryResolver;
        this.appRef = appRef;
        this.injector = injector;
        this.overrideWindowAlert();
    }
    /**
     * Funzionalità per abilitare/disabilitare il componente
     * e ripristinare alert() nativo messo a disposizione da window.
     */
    enableAlertMessage(enable) {
        if (enable) {
            this.createAlertComponent();
            this.alertEnabled = true;
            return;
        }
        this.destroyAlertComponent();
        this.restoreWindowAlert();
        this.alertEnabled = false;
    }
    /** Sostituisce `window.alert` con un broadcast verso il componente alert. */
    overrideWindowAlert() {
        if (typeof window === 'undefined') {
            return;
        }
        window.alert = ((...args) => {
            const payload = args.length > 1
                ? {
                    title: String(args[0] ?? ''),
                    body: String(args[1] ?? '')
                }
                : {
                    title: null,
                    body: String(args[0] ?? '')
                };
            PlCoreUtils.Broadcast().execEvent('CORE:INFO_SERVICE_DIALOG', payload);
        });
    }
    /** Ripristina l'implementazione nativa di `window.alert`. */
    restoreWindowAlert() {
        if (typeof window === 'undefined') {
            return;
        }
        window.alert = this.oldAlert;
    }
    /** Crea e aggancia dinamicamente il componente alert al `body`. */
    createAlertComponent() {
        if (this.componentRef || typeof document === 'undefined') {
            return;
        }
        this.componentRef = this.componentFactoryResolver
            .resolveComponentFactory(AlertComponent)
            .create(this.injector);
        this.appRef.attachView(this.componentRef.hostView);
        const domElem = this.componentRef.hostView
            .rootNodes[0];
        document.body.appendChild(domElem);
    }
    /** Distrugge il componente alert dinamico se presente. */
    destroyAlertComponent() {
        if (!this.componentRef) {
            return;
        }
        this.appRef.detachView(this.componentRef.hostView);
        this.componentRef.destroy();
        this.componentRef = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: AlertService, deps: [{ token: i0.ComponentFactoryResolver }, { token: i0.ApplicationRef }, { token: i0.Injector }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: AlertService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: AlertService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i0.ComponentFactoryResolver }, { type: i0.ApplicationRef }, { type: i0.Injector }] });

const PL_CORE_MODULE_CONFIG = new InjectionToken('PL_CORE_MODULE_CONFIG');
class PlCoreModule {
    alertService;
    plAmbientModeLoaderService;
    router;
    static interrupter = new Subject();
    routeEventsSubscription = null;
    static forRoot(config = {}) {
        return {
            ngModule: PlCoreModule,
            providers: [
                {
                    provide: PL_CORE_MODULE_CONFIG,
                    useValue: config
                },
                {
                    provide: BROWSER_VALID,
                    useValue: config.browserValid ?? [BROWSER.ALL]
                },
                {
                    provide: DISABLE_LOG,
                    useValue: config.disableLog ?? false
                },
                {
                    provide: MAX_CACHE_AGE,
                    useValue: config.maxCacheAge ?? 300000
                },
                {
                    provide: CACHE_TAG,
                    useValue: config.cacheTag ?? '@cachable@'
                },
                {
                    provide: DEFAULT_PATH_MOCK,
                    useValue: config.mockPath ?? 'public/mock'
                }
            ]
        };
    }
    /**
     * Modulo di inizializzazione della libreria.
     *
     * Uso base:
     *
     * imports: [PlCoreModule]
     *
     * Uso configurabile:
     *
     * imports: [
     *   PlCoreModule.forRoot({
     *     mockPath: 'assets/mock',
     *     cacheTag: '@cachable@',
     *     maxCacheAge: 300000,
     *     disableLog: false
     *   })
     * ]
     */
    constructor(alertService, plAmbientModeLoaderService, router) {
        this.alertService = alertService;
        this.plAmbientModeLoaderService = plAmbientModeLoaderService;
        this.router = router;
        this.initializeAlert();
        this.initializeRoutingInterrupt();
    }
    ngOnDestroy() {
        this.routeEventsSubscription?.unsubscribe();
        this.routeEventsSubscription = null;
    }
    /**
     * Funzionalità per il reperimento dell'interrupt di rotta.
     * In caso di NavigationStart viene lanciato il subject.
     * Utile per terminare le richieste HTTP.
     */
    static Routing() {
        return {
            getIinterrupt() {
                return PlCoreModule.interrupter;
            }
        };
    }
    initializeAlert() {
        try {
            this.alertService.enableAlertMessage(true);
        }
        catch (error) {
            console.error(error);
        }
    }
    initializeRoutingInterrupt() {
        if (!this.router) {
            return;
        }
        this.routeEventsSubscription = this.router.events
            .pipe(filter(event => event instanceof NavigationStart))
            .subscribe(() => {
            PlCoreModule.interrupter.next(true);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlCoreModule, deps: [{ token: AlertService }, { token: PlAmbientModeLoaderService }, { token: i3.Router, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.22", ngImport: i0, type: PlCoreModule, declarations: [AlertComponent,
            PlBaseComponent], imports: [CommonModule,
            FormsModule,
            HttpClientModule,
            NgbModule], exports: [CommonModule,
            HttpClientModule,
            PlBaseComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlCoreModule, providers: [
            PlAmbientModeLoaderService,
            /**
             * Default retrocompatibili.
             * Restano qui per chi usa ancora imports: [PlCoreModule].
             */
            { provide: BROWSER_VALID, useValue: [BROWSER.ALL] },
            { provide: DISABLE_LOG, useValue: false },
            { provide: MAX_CACHE_AGE, useValue: 300000 },
            { provide: CACHE_TAG, useValue: '@cachable@' },
            { provide: DEFAULT_PATH_MOCK, useValue: 'public/mock' },
            /**
             * Intercettore mock storico della libreria.
             */
            {
                provide: HTTP_INTERCEPTORS,
                useClass: PlHttpInterceptorMockService,
                multi: true
            }
        ], imports: [CommonModule,
            FormsModule,
            HttpClientModule,
            NgbModule, CommonModule,
            HttpClientModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.22", ngImport: i0, type: PlCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        AlertComponent,
                        PlBaseComponent
                    ],
                    imports: [
                        CommonModule,
                        FormsModule,
                        HttpClientModule,
                        NgbModule
                    ],
                    exports: [
                        CommonModule,
                        HttpClientModule,
                        PlBaseComponent
                    ],
                    providers: [
                        PlAmbientModeLoaderService,
                        /**
                         * Default retrocompatibili.
                         * Restano qui per chi usa ancora imports: [PlCoreModule].
                         */
                        { provide: BROWSER_VALID, useValue: [BROWSER.ALL] },
                        { provide: DISABLE_LOG, useValue: false },
                        { provide: MAX_CACHE_AGE, useValue: 300000 },
                        { provide: CACHE_TAG, useValue: '@cachable@' },
                        { provide: DEFAULT_PATH_MOCK, useValue: 'public/mock' },
                        /**
                         * Intercettore mock storico della libreria.
                         */
                        {
                            provide: HTTP_INTERCEPTORS,
                            useClass: PlHttpInterceptorMockService,
                            multi: true
                        }
                    ]
                }]
        }], ctorParameters: () => [{ type: AlertService }, { type: PlAmbientModeLoaderService }, { type: i3.Router, decorators: [{
                    type: Optional
                }] }] });

/** eventi registrati per PLlibrary */
var TYPE_EVENT;
(function (TYPE_EVENT) {
    TYPE_EVENT["PL_SET_PERMISSION"] = "PL:SET-PERMISSION";
})(TYPE_EVENT || (TYPE_EVENT = {}));
/** Decoratore di metodo: traccia input/output/error in console. */
function PLTraceMethod() {
    return function (target, key, descriptor) {
        return {
            value: function (...args) {
                try {
                    console.debug(`%c PLTraceMethod -  Class:   ${target.constructor.name} TRACE FUNCTION: ${key} INPUT`, `color: green `, args);
                    var result = descriptor.value.apply(this, arguments);
                    console.debug(`%c PLTraceMethod -  Class:   ${target.constructor.name} TRACE FUNCTION: ${key} OUTPUT`, `color: green `, result || "");
                    return result;
                }
                catch (error) {
                    console.error(`%c PLTraceMethod -  Class:  ${target.constructor.name}  TRACE FUNCTION: ${key} ERROR: `, `color: red `, error || "");
                }
            }
        };
    };
}
/** Decoratore di classe: abilita il trace dei lifecycle hook Angular. */
function PLTraceHooks(disabled = []) {
    return function (constructor) {
        console.debug(`%c PLTraceHooks -  Class:  ${constructor.name}  ENABLED TRACE HOOKS`, `color: green `);
        const LIFECYCLE_HOOKS = [
            'ngOnChanges', 'ngOnInit', 'ngDoCheck', 'ngAfterContentInit', 'ngAfterContentChecked', 'ngAfterViewInit', 'ngAfterViewChecked', 'ngOnDestroy'
        ];
        ///@ts-ignore
        let LIFECYCLE_HOOKS_APP = LIFECYCLE_HOOKS.filter(element => { if (disabled.indexOf(element) < 0)
            return true; });
        const component = constructor.name;
        LIFECYCLE_HOOKS_APP.forEach(hook => {
            const original = constructor.prototype[hook];
            constructor.prototype[hook] = function (...args) {
                try {
                    console.debug(`%c PLTraceHooks -  Class:   ${component} TRACE HOOKS: ${hook}`, `color: green `, args);
                    if (original)
                        var result = original.apply(this, args);
                }
                catch (error) {
                    console.error(`%c PLTraceHooks -  Class:  ${component}  TRACE HOOKS: ${hook} ERROR: `, `color: red `, error || "");
                }
            };
        });
        return;
    };
}
/**
 * Decoratore di classe che applica controlli permesso su elementi con attributo `PL-permission`.
 * Il meccanismo prevede l'ascolto
 * dell'evento TYPE_EVENT.PL_SET_PERMISSION, dove viene reperito l'array dei permessi previsti per un utente.
 * ricevuto l'array dei permessi, la routine si occupa di prelevare tutti i DOM che riportano l'attributo  PL-permission, e controlla
 * se contiene o meno uno dei permessi passati precedentemente con il listener.
 * verranno rimossi tutti i componenti DOM che non soddifano i requisiti
 * la direttiva posta in AppComponent, monitorizza tutta l'applicazione
 * il decoratore rimane in attesa in ad un evento di caricamento.. l'evento deve essere
 * @example
 * lanciare document.dispatchEvent(new CustomEvent('PL:SET-PERMISSION', { detail: [PROFILO1,PROFILO2,PROFILO3,...] }));
 * inserire nel DOM <input permission="READONLY" type="text>" e al decoratore passare @PLPermission(true)
 * l'elemento del dom viene elininato in quanto non contiene il permesso READONLY.
 *
 * per NON far eliminare il componente dalla routin.
 * inserire nel DOM  <input permission="PROFILO1" type="text>" e al decoratore passare @PLPermission(true)*
 * il componente non viene eliminato in quanto il permesso è presente.
 *
 * @param permission : Array<string>  array di permessi per il quale il componente deve essere presente, se vuoto non verranno
 * elaborate le routine
 */
function PLPermission(enabled = true) {
    return function (constructor) {
        try {
            if (enabled) {
                console.debug(`%c PLPermission -  Class:  ${constructor.name}  ENABLED PERMISSION CHECK`, `color: green `);
                const component = constructor.name;
                let original = constructor.prototype['ngAfterViewChecked'];
                if (!original)
                    original = () => { };
                let permission = [];
                PlCoreUtils.Broadcast().listenEvent(TYPE_EVENT.PL_SET_PERMISSION, (event) => {
                    permission = event.detail;
                    constructor.prototype['ngAfterViewChecked'] = function (...args) {
                        if (permission.length > 0)
                            document.querySelectorAll('[PL-permission]').forEach(element => {
                                let permitted = element.getAttribute("PL-permission").split("|");
                                let trovato = false;
                                for (let ind = 0; ind < permitted.length && !trovato; ind++) {
                                    if (permission.indexOf(permitted[ind]) > -1) {
                                        trovato = true;
                                    }
                                }
                                if (!trovato) {
                                    element.parentElement.removeChild(element);
                                    console.debug(`%c PLPermission -  Class:  ${constructor.name} PERMISSION DENIED FOUND FOR`, `color: red `, element);
                                }
                            });
                        original.apply(this, args);
                    };
                    constructor.prototype['ngAfterViewChecked']();
                });
            }
            else {
                console.debug(`%c PLPermission -  Class:  ${constructor.name}  DISABLED PERMISSION CHECK`, `color: green `);
            }
        }
        catch (error) {
            console.error(`%c PLTraceAll -  Class:  ${constructor.name} ERROR: `, `color: red `, error || "");
        }
    };
}

/**
 * Per assicurare che le estensioni runtime (metodi su Array, String, Object, JSON) siano disponibili,
 * importa e richiama PlAmbientModeLoaderService nel main.ts del tuo progetto consumer:
 *
 *   import { PlAmbientModeLoaderService } from 'pl-core-utils-library';
 *   // Nel costruttore principale o in APP_INITIALIZER:
 *   plAmbientModeLoaderService.detect().subscribe();
 *
 * Così le estensioni saranno attive a runtime per tutto il progetto.
 */
// Prototype Extensions (estensioni globali)

/**
 * Generated bundle index. Do not edit.
 */

export { AlertComponent, AlertService, BROWSER, BROWSER_VALID, CACHE_TAG, CONTENT_TYPE, DEFAULT_PATH_MOCK, DISABLE_LOG, MAX_CACHE_AGE, PLPermission, PLTraceHooks, PLTraceMethod, PLWorkerService, PL_CORE_MODULE_CONFIG, PlAmbientModeLoaderService, PlBaseComponent, PlCacheMapService, PlCoreModule, PlCoreUtils, PlGraphicService, PlHttpInterceptorMockService, PlHttpRequest, PlHttpService, PlNetworkService, PlUtilsService, RESPONSE_TYPE, TYPE_EVENT, TYPE_EVENT_NETWORK, createPlUuid };
//# sourceMappingURL=pl-core-utils-library.mjs.map
